<?php
namespace Drupal\webform_handler_list_a_space_basic\Plugin\WebformHandler;

use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\Plugin\WebformHandlerBase;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\webform\Entity\WebformSubmission;

use Drupal\node\Entity\Node;

/**
 * Webform submission action handler.
 *
 * @WebformHandler(
 *   id = "listaspacebasic",
 *   label = @Translation("List A Space Basic"),
 *   category = @Translation("Action"),
 *   description = @Translation("Creates a user and a property"),
 *   cardinality = \Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_UNLIMITED,
 *   results = \Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_OPTIONAL,
 * )
 */
class ListASpaceBasicHandler extends WebformHandlerBase {
    /**
     * {@inheritdoc}
     */
    public function postSave(WebformSubmissionInterface $webform_submission, $update = TRUE) {


        //DEBUG
        /*$values = $webform_submission->getData();
        foreach($values as $key=>$value) {
            //drupal_set_message($key . ' -> ' . $value);
            //$this->messenger($key . ' -> ' . $value);
            echo $key . ' -> ' . $value . '<br/>';
        }
        die();*/

        $user_name = $webform_submission->getElementData('user_name');
        $space_title = $webform_submission->getElementData('space_title');
        if(isset($user_name) && $user_name != ""){
            $this::handle_list_a_space_basic_form($webform_submission, $update);
        } else if(isset($space_title) && $space_title != ""){
            $this::handle_list_a_space_space_form($webform_submission, $update);
        }





    }

    private function handle_list_a_space_basic_form(WebformSubmissionInterface $webform_submission, $update = TRUE)
    {

        //Add user
        $user = \Drupal\user\Entity\User::create();
        $language = \Drupal::languageManager()->getCurrentLanguage()->getId();

        //Get the data from the form - user
        $user_name = $webform_submission->getElementData('user_name');
        $first_name = $webform_submission->getElementData('first_name');
        $last_name = $webform_submission->getElementData('last_name');
        $email = $webform_submission->getElementData('email');
        $phone_number = $webform_submission->getElementData('phone_number');
        $password = $webform_submission->getElementData('password');

        //Get the data from the form - Property
        $property_type = $webform_submission->getElementData('property_type');
        $property_name = $webform_submission->getElementData('prperty_name');
        $property_description = $webform_submission->getElementData('property_description');
        $property_logo = $webform_submission->getElementData('property_logo');
        $property_address = $webform_submission->getElementData('address');



        // Mandatory user creation settings
        $user->enforceIsNew();
        $user->setUsername($user_name); // This username must be unique and accept only a-Z,0-9, - _ @ .
        $user->setEmail($email);
        $user->setPassword($password);
        $user->set("langcode", $language);

        // Optional settings
        $user->set("init", 'email');
        $user->set("preferred_langcode", $language);
        $user->set("preferred_admin_langcode", $language);

        //Settings from form
        $user->field_user_first_name = $first_name;
        $user->field_user_last_name = $last_name;
        $user->field_user_phone = $phone_number;

        //Set the image
        //$user->field_user_image = ''; ///???

        $user->activate();
        // Add a custom role
        $user->addRole('CustomRoleName');
        //Save user
        $user->save();

        $user_id = $user->id();


        //Add a new property
        $node = Node::create([
            // The node entity bundle.
            'type' => 'ct_properties',
            'langcode' => 'en',
            //'created' => $created_date,
            //'changed' => $created_date,
            // The user ID.
            'uid' => $user_id,
            //'moderation_state' => 'published',
            'moderation_state' => 'draft',
            'field_property_host' => $user_id,
            'field_property_creator' => $user_id,
            'field_property_owner' => $user_id,
            'title' => $property_name,
            'field_property_title' => $property_name,
            'field_property_name' => $property_name,
            'field_property_description' => $property_description,
            'field_property_type' => $property_type,
            'field_property_address' => $property_address,
            'field_property_logo' => $property_logo
            //Not in the form
            //'field_property_email' => 'email@gmail.com',
            //'field_property_website' => 'http://drupal.org',
            //'field_property_phone' => '0541234567' ,
        ]);
        $node->setPublished(FALSE);
        $node->save();

        //get property id
        $property_id = $node->id();

        //Redirect to next form
        $str_location = "space?property_id=$property_id";
        header("Location:" . $str_location);
        die();
    }

    private function handle_list_a_space_space_form(WebformSubmissionInterface $webform_submission, $update = TRUE)
    {
        $values = $webform_submission->getData();
        foreach($values as $key=>$value) {
            //drupal_set_message($key . ' -> ' . $value);
            //$this->messenger($key . ' -> ' . $value);
            echo $key . ' -> ' . $value . '<br/>';
        }
        die();
    }
}
