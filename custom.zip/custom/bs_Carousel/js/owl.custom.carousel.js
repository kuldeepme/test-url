jQuery(document).ready(function(){


    var $homepage_owl = jQuery('.path-frontpage #owl-custom-view-more');
    //$homepage_owl.on('initialized.owl.carousel resized.owl.carousel', function(e) {
        //$(e.target).toggleClass('hide-nav', e.item.count <= e.page.size);
    //});
    $homepage_owl.owlCarousel({
        items: 1,
        rtl:true,
        margin: 20,
        loop: true,
        stagePadding: 20,
        autoplay:true,
        nav:true,
        dots: false,
        navText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
        responsive:{
            0:{
                items:1,
                stagePadding: 20,
            },
            500:{
                items:2,
                stagePadding: 20,
            },
            750:{
                items:3,
                stagePadding: 20,
            },
            1000:{
                items:4,
                stagePadding: 20,
            }
        },
    });




    jQuery("#owl-custom-view-more").owlCarousel({
        items: 2,
        rtl:true,
        margin: 20,
        loop: true,
        stagePadding: 100,
        autoplay:true,
        nav:true,
        dots: false,
        navText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
        responsive:{
            0:{
                items:1,
                stagePadding: 20,
            },
            500:{
                items:2,
                stagePadding: 20,
            },
            750:{
                items:2,
                stagePadding: 20,
            },
            1000:{
                items:3,
                stagePadding: 20,
            }
        },
    });
    jQuery("#owl-custom-main-slider").owlCarousel({
        items: 1,
        rtl:true,
        margin: 20,
        loop: true,
        stagePadding: 50,
        autoplay:true,
        nav:true,
        dots: false,
        navText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]
    });
    jQuery("#owl-demo3").owlCarousel({
        pagination : false,
    });
});
