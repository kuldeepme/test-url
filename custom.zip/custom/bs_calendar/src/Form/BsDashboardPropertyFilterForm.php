<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsDashboardFilterForm.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\node\Entity\Node;

/**
 * {@inheritdoc}
 */

class BsDashboardPropertyFilterForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_property_filter_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $user_properties = get_current_user_properties();
    if (!empty($user_properties)) {
      $values = $form_state->getValues();
      $form['error_message'] = [
          '#type' => 'markup',
          '#markup' => '<div id="result_error_message"></div>'
      ];
      if (empty($values['all_properties'])) {
        $selected_space_id = 'all';
      }
      else {
        $selected_space_id = $values['all_properties'];
      }
      $form['all_properties'] = [
        '#type' => 'select',
        '#title' => '<h3>' . $this->t('Dashboard') . '</h3>',
        '#options' => ['all' => 'All properties'] + $user_properties,
        '#ajax' => [
            'callback' => '::propertiesDropdownCallback',
            'wrapper' => 'properties-fieldset-container',
        ],
        '#default_value' => $selected_space_id,
      ];
      $property_date_arr = [];
      $nids = \Drupal::entityQuery('node')->condition('type','ct_reservations')->execute();
      $nodes =  Node::loadMultiple($nids);
      $user_id = \Drupal::currentUser()->id();
      foreach($nodes as $key => $value){
          if($value->isPublished()){
            $reservation_owner = $value->getOwnerId();
            if($reservation_owner == $user_id){
              $year_month = date('Ym', $value->getCreatedTime());
              $property_date_arr[$year_month] = date('M Y', $value->getCreatedTime());
            }
          }
      }
      $property_date_arr = array_reverse($property_date_arr, true);
      if (empty($values['property_date'])) {
        $booking_year_month = 'all';
      }
      else {
        $booking_year_month = $values['property_date'];
      }
      $form['property_date'] = [
        '#type' => 'select',
        '#options' => ['all' => 'All years'] + $property_date_arr,
        '#ajax' => [
            'callback' => '::propertiesDropdownCallback',
            'wrapper' => 'properties-fieldset-container',
        ],
        '#default_value' => $booking_year_month,
      ];
      $form['dashboard_kpi'] = [
        '#type' => 'inline_template',
        '#template' => "<div class='ds-property ds-kpi'><h3>". $this->t('KPI\'S')."</h3>
                      <div class='kpi-statistics-container'>
                        <div class='row'>
                          <div class='col-sm-4'><span class='views'><h4>50</h4>Views</span></div>
                          <div class='col-sm-4'><span class='booking'><h4>6</h4>New booking</span></div>
                          <div class='col-sm-4'><span class='rate'><h4>40%</h4>Booking rate</span></div>
                        </div>
                      </div>
                    </div>",
      ];
      $form['dashboard_revenue'] = [
        '#type' => 'inline_template',
        '#template' => "<div class='ds-property ds-revenue'>
          <h3>". $this->t('Revenue')."</h3>
          <div class='revenue-statistics-container'>
            <div class='row'>
              <div class='col-sm-4'><span class='earning'><h3>1700$</h3>Booked earning</span></div>
              <div class='col-sm-4'><span class='paid'><h4>1500$</h4>Paid out</span></div>
              <div class='col-sm-4'><span class='expected'><h4>200$</h4>Expected</span></div>
            </div>
          </div>
        </div>"
      ];
      $form['reservation_statistics'] = [
        '#type' => 'container',
        '#title' => '<h3>' . $this->t('Reservations') . '</h3>',
        '#prefix' => '<div id="properties-fieldset-container">',
        '#suffix' => '</div>'
      ];
      if (!empty($selected_space_id) || !empty($booking_year_month)) {
        $block = views_embed_view('view_reservations', 'block_3', $selected_space_id, $booking_year_month);
        $form['reservation_statistics']['reservation_markup'] = [
          '#markup' => render($block),
        ];
      }
    }
    else {
      $form['reservation_markup'] = [
        '#markup' => '<h4>' . $this->t('No data found....!') .'</h4>',
      ];
    }
    return $form;
  }

  /*
   * This function is called when property or property_date is changed
   */
  function propertiesDropdownCallback(array &$form, FormStateInterface $form_state){
    return $form['reservation_statistics'];
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}


