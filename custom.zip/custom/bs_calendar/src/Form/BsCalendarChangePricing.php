<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsCalendarChangePricing.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CloseModalDialogCommand;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\CommandInterface;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\taxonomy\Entity\Term;

/**
 * {@inheritdoc}
 */
class BsCalendarChangePricing extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_calendar_change_pricing';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, AccountInterface $user = NULL) {
    $sort_by_key = TRUE;
    $arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);
    $form['success_message'] = [
        '#type' => 'markup',
        '#markup' => '<div id="success_message"></div>'
    ];
    $form['validation_message'] = [
        '#type' => 'markup',
        '#markup' => '<div id="validation_wrapper"></div>'
    ];
    $form['date_options'] = [
      '#type' => 'radios',
      '#options' => [
        'all_dates' => t('All dates'),
        'specific_dates' => t('Specific dates')
      ],
      '#default_value' => !empty($form_state->get('date_options')) ? $form_state->get('date_options') : 'all_dates',
    ];
    $form['date_container'] = [
      '#type' => 'container',
      '#states' => [
        'visible' => [
         ':input[name="date_options"]' => ['value' => 'specific_dates'],
        ],
      ],
    ];
    $form['date_container']['date_from'] = [
      '#type' => 'datetime',
      '#title' => t('Start Date'),
      '#size' => 20,
      '#date_time_element' => 'none',
      '#date_date_format' => 'Y-m-d',
      '#date_time_format' => 'H:i',
      '#default_value' => '10:00',
    ];
    $form['date_container']['date_until'] = [
      '#type' => 'datetime',
      '#title' => $this->t('End Date'),
      '#size' => 20,
      '#date_time_element' => 'none',
      '#date_date_format' => 'Y-m-d',
      '#date_time_format' => 'H:i',
      '#default_value' => '12:00',
    ];
    $form['price'] = [
      '#type' => 'textfield',
      '#title' => t('Hourly price (VAT not included)'),
      '#attributes' => [
        'placeholder' => t('0'),
      ],
    ];
/*    if (!empty($node->field_space_currencies->getValue())) {
      $default_crrency = $node->field_space_currencies->getValue()[0]['target_id'];
    }*/
    $default_crrency = get_country_details_by_space_id($node->id());
    $form["currency"] = [
      '#type' => 'textfield',
      '#size' => 20,
      '#default_value' => !empty($default_crrency['currency_code']) ? $default_crrency['currency_code'] : 'USD',
      '#attributes' => ['disabled' => 'disabled'],
    ];
    $form['advance_options'] = [
      '#type' => 'fieldset',
      '#title' => t('Advanced options'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    ];

    $form['advance_options']['hourly_container'] = [
      '#type' => 'container',
      '#prefix' => '<div id="hourly-fieldset-wrapper">',
      '#suffix' => '</div>',
    ];

    $hourly_count = $this->config('bs_calendar_change_pricing.hourlysettings')->get('hourly_count');
    
    if (count($hourly_count) > 0) {
      foreach ($hourly_count as $key_hourly => $value_hourly) {
        $new_count[] = $key_hourly;
      }
    }
    else {
      $new_count[] = 1;
    }

    // Gather the number of items in the form already.
    // We need a element to started
    $num_hourly = $form_state->get('num_hourly');
    // We need a element to started, if not, set it
    if ($num_hourly === NULL) {
      $num_hourly = $form_state->set('num_hourly', $new_count);
      $num_hourly = $form_state->get('num_hourly');
    }
    //$time_formate = ['none' => 'None'];
    $time_formate = select_list_times();
    $form['advance_options']['hourly_container']['hourly_count'] = [
      '#type' => 'hidden',
      '#value' => count($num_hourly)
    ];
    foreach ($num_hourly as $key_hourly) {
        $form['advance_options']['hourly_container']['from_time_'.$key_hourly] = [
          '#type' => 'select',
          '#title' => t('Hourly discount'),
          '#options' => ['none' => 'None'] + $time_formate,
        ];
        $form['advance_options']['hourly_container']['to_time_'.$key_hourly] = [
          '#type' => 'select',
          // '#title' => $this->t('Time'),
          '#options' =>['none' => 'None'] + $time_formate,
        ];
        $form['advance_options']['hourly_container']['hourly_percentage_'.$key_hourly] = [
          '#type' => 'textfield',
          '#attributes' => [
            'placeholder' => t('0'),
          ]
        ];
        $form['advance_options']['hourly_container']['hourly_currency_'.$key_hourly] = [
          '#type' => 'select',
          '#options' => ['percent' => '%'] + $arr_currencies,
          '#default_value' => 'percent'
        ];
    }
    $form['advance_options']['hourly_container']['add_hourly'] = [
      '#type' => 'submit',
      '#value' => t('+ Add discount'),
      '#name' => 'add_hourly_discount',
      '#submit' => [$this, '::addOneHourly'],
      '#ajax' => [
        'callback' => [$this, 'addMoreHourlyCallback'],
        'wrapper' => 'hourly-fieldset-wrapper',
      ],
    ];

    $form['advance_options']['all_day_container'] = [
      '#type' => 'container',
      '#prefix' => '<div id="all-day-fieldset-wrapper">',
      '#suffix' => '</div>',
    ];

    $all_day_count = $this->config('bs_calendar_change_pricing.alldaysettings')->get('all_day_count');
    
    if (count($all_day_count) > 0) {
      foreach ($all_day_count as $key_all_day => $value_all_day) {
        $new_count_all_day[] = $key_all_day;
      }
    }
    else {
      $new_count_all_day[] = 1;
    }

    // Gather the number of items in the form already.
    // We need a element to started
    $num_all_day = $form_state->get('num_all_day');
    // We need a element to started, if not, set it
    if ($num_all_day === NULL) {
      $num_all_day = $form_state->set('num_all_day', $new_count_all_day);
      $num_all_day = $form_state->get('num_all_day');
    }

    $week_days = get_taxonomy_term_values('weekdays_', TRUE);
    $form['advance_options']['all_day_container']['all_day_count'] = [
      '#type' => 'hidden',
      '#value' => count($num_all_day)
    ];
    foreach ($num_all_day as $key_all_day) {
      $form['advance_options']['all_day_container']['all_day_weekday_'.$key_all_day] = [
        '#type' => 'select',
        '#title' => t('All day discount'),
        '#options' => $week_days,
      ];
      $form['advance_options']['all_day_container']['all_day_percentage_'.$key_all_day] = [
        '#type' => 'textfield',
        '#attributes' => [
          'placeholder' => t('0'),
        ]
      ];
      $form['advance_options']['all_day_container']['all_day_currency_'.$key_all_day] = [
        '#type' => 'select',
        '#options' => ['percent' => '%'] + $arr_currencies,
        '#default_value' => 'percent'
      ];
    }
    $form['advance_options']['all_day_container']['add_all_day'] = [
      '#type' => 'submit',
      '#value' => t('+ Add discount'),
      '#name' => 'add_all_day',
      '#submit' => [$this, '::addOneAllDay'],
      '#ajax' => [
        'callback' => [$this, 'addMoreAllDayCallback'],
        'wrapper' => 'all-day-fieldset-wrapper',
      ],
    ];

    $form['node_obj'] = [
      '#type' => 'value',
      '#value' => $node,
    ];
    $form["submit"] = [
      "#type" => 'submit',
      "#value" => t("Save"),
      '#ajax' => [
        'callback' => '::saveChangedPrice',
      ]
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function addMorePerHourCallback(array &$form, FormStateInterface $form_state) {
    return $form['advance_options']['per_hours_container'];
  }

  /**
   * {@inheritdoc}
   */
  public function addOnePerHour(array &$form, FormStateInterface $form_state) {
    // Store our form state
    $per_hour_array = $form_state->get('num_per_hour');
    // check to see if there is more than one item in our array
    if (count($per_hour_array) > 0) {
      // Add a new element to our array and set it to our highest value plus one
      $per_hour_array[] = max($per_hour_array) + 1;
    }
    else {
      // Set the new array element to 0
      $per_hour_array[] = 0;
    }
    // Rebuild the field deltas values
    $form_state->set('num_per_hour', $per_hour_array);
    // Rebuild the form
    $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function addMoreHourlyCallback(array &$form, FormStateInterface $form_state) {
 /*   $trigger_btn = $form_state->getTriggeringElement()['#array_parents'][1];
    if ($trigger_btn == 'hourly_container') {*/
      return $form['advance_options']['hourly_container'];
    /*}*/
  }

  /**
   * {@inheritdoc}
   */
  public function addOneHourly(array &$form, FormStateInterface $form_state) {
    // Store our form state
    $hourly_array = $form_state->get('num_hourly');
    // check to see if there is more than one item in our array
    if (count($hourly_array) > 0) {
      // Add a new element to our array and set it to our highest value plus one
      $hourly_array[] = max($hourly_array) + 1;
    }
    else {
      // Set the new array element to 0
      $hourly_array[] = 0;
    }
    // Rebuild the field deltas values
    $form_state->set('num_hourly', $hourly_array);
    // Rebuild the form
    $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function addMoreAllDayCallback(array &$form, FormStateInterface $form_state) {
    return $form['advance_options']['all_day_container'];
  }

  /**
   * {@inheritdoc}
   */
  public function addOneAllDay(array &$form, FormStateInterface $form_state) {
    // Store our form state
    $all_day_array = $form_state->get('num_all_day');
    // check to see if there is more than one item in our array
    if (count($all_day_array) > 0) {
      // Add a new element to our array and set it to our highest value plus one
      $all_day_array[] = max($all_day_array) + 1;
    }
    else {
      // Set the new array element to 0
      $all_day_array[] = 0;
    }
    // Rebuild the field deltas values
    $form_state->set('num_all_day', $all_day_array);
    // Rebuild the form
    $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function saveChangedPrice(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $validation_text = '';
    $price_added_status = false;
    if ($form_state->getValue('date_options') == 'all_dates') {
      if (strlen($form_state->getValue('price')) < 1) {
        $validation_text .= '<li class="item item--message">Hourly price (VAT not included) '.t('field is required').'.</li>';
      }
    }
    else if ($form_state->getValue('date_options') == 'specific_dates') {
      if (strlen($form_state->getValue('date_from')) < 10) {
        $validation_text .= '<li class="item item--message">The <em class="placeholder">Start Date</em> '.t('date is required').'. '.t('Please enter a date in the format').'. <em class="placeholder">dd-mm-yyyy</em>.</li>';
      }
      if (strlen($form_state->getValue('date_until')) < 10) {
        $validation_text .= '<li class="item item--message">The <em class="placeholder">End Date</em> '.t('date is required').'. '.t('Please enter a date in the format').'. <em class="placeholder">dd-mm-yyyy</em>.</li>';
      }
      if (strlen($form_state->getValue('price')) < 1) {
        $validation_text .= '<li class="item item--message">Hourly price (VAT not included) '.t('field is required').'.</li>';
      }
      if (strlen($form_state->getValue('currency')) < 1) {
        $validation_text .= '<li class="item item--message">'.t('Currency field is required.').'</li>';
      }
    }
    if($validation_text!=""){
      $validation_text = '<div data-drupal-messages=""><div class="messages__wrapper"><div class="alert alert-danger alert-dismissible" role="alert" aria-label="Error message"><button type="button" role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><h2 class="sr-only">Error message</h2><ul class="item-list item-list--messages">'.$validation_text.'</ul></div></div></div>';
      $command = new HtmlCommand('#validation_wrapper', $validation_text);
      $response->addCommand($command);
    }
    else {
      $times_paragraph_id = [];
      $space_prices_array = [];
      $cancellation_policy = 193;
      $price_percentage = 0;
      $values = $form_state->getValues();
      $date_option = isset($values['date_options']) ? $values['date_options'] : '';
      $price = isset($values['price']) ? $values['price'] : 0;
      $percentage = isset($values['currency']) ? $values['currency'] : '';
      $node = $values['node_obj'];
      $date_from = isset($values['date_from']) ? $values['date_from'] : '';
      $date_to = isset($values['date_until']) ? $values['date_until'] : '';
      if (($date_option == "all_dates" || $date_option == "specific_dates") && is_numeric($percentage)) {
        if ($date_from && $date_to) {
          $date_arr = get_fixed_date_time($date_from, $date_to);
          $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date']);
          $space_prices_array = $node->get('field_space_prices')->getValue();
          $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price, $price_percentage = 0, $cancellation_policy);
          $node->set('field_space_prices', $space_prices_array);
          $node->save();
          $price_added_status = true;
        }
        else {
          $node->set('field_price', $price);
          $node->save();
          $price_added_status = true;
        }
      }
      else if (($date_option == "all_dates" || $date_option == "specific_dates") && !is_numeric($percentage)) {
        if ($date_from && $date_to) {
          $date_arr = get_fixed_date_time($date_from, $date_to);
          $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date']);
          $space_prices_array = $node->get('field_space_prices')->getValue();
          $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price, $cancellation_policy);
        }
        else {
          $date_from = "2100-01-01T00:00:00";
          $date_to = "2100-01-01T00:00:00";
          $date_arr = get_fixed_date_time($date_from, $date_to);
          $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date']);
          $space_prices_array = $node->get('field_space_prices')->getValue();
          $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price, $cancellation_policy);
        }
        $node->set('field_space_prices', $space_prices_array);
        $node->save();
        $price_added_status = true;
      }
      if ($date_option == 'specific_dates') {
        // create discount per number of hours paragraph
/*        if (!empty($values['per_hour_percentage_1'])) {
          $date_arr = get_fixed_date_time($date_from, $date_to);
          $count_per_hour = $values['per_hour_count'];
          for($i = 1; $i <= $count_per_hour; $i++) {
            $currency_type = $values['per_hour_currency_'.$i];
            $price_percentage = $values['per_hour_percentage_'.$i];
            if (!empty($price_percentage)) {
              if ($currency_type == 'percent') {
                $per_hour = $values['per_hour_'.$i];
                $price_percentage = $values['per_hour_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date']);
                // Grab existing paragraphs from the node, and add this one 
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price_percentage, $cancellation_policy);
              }
              else {
                $per_hour = $values['per_hour_'.$i];
                $price_fixed = $values['per_hour_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date']);
                // Grab existing paragraphs from the node, and add this one 
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed, $price_percentage = 0, $cancellation_policy);
              }
              $node->set('field_space_prices', $space_prices_array);
              $node->save();
              $price_added_status = true;
            }
          }
        }*/
        // create all day discount paragraph
        if (!empty($values['hourly_percentage_1'])) {
          $count_hourly = $values['hourly_count'];
          for($i = 1; $i <= $count_hourly; $i++) {
            $from_time = $values['from_time_'.$i];
            $to_time = $values['to_time_'.$i];
            if ($from_time != 'none' && $to_time != 'none') {
              $date_from = date('Y-m-d', strtotime($date_from));
              $start_date = $date_from . "T" . $from_time . ":00:00";
              $date_to = date('Y-m-d', strtotime($date_to));
              $end_date =  $date_to . "T" . $to_time . ":00:00";
            }
            $currency_type = $values['hourly_currency_'.$i];
            $price_percentage = $values['hourly_percentage_'.$i];
            if (!empty($price_percentage)) {
              if ($currency_type == 'percent') {
                $price_percentage = $values['hourly_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($start_date, $end_date);
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price_percentage, $cancellation_policy);
                $node->set('field_space_prices', $space_prices_array);
              }
              else {
                $price_fixed = $values['hourly_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($start_date, $end_date);
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed, $price_percentage = 0, $cancellation_policy);
                $node->set('field_space_prices', $space_prices_array);
              }
            }
          }
          $node->save();
          $price_added_status = true;
        }
        // create hourly discount  paragraph
        if (!empty($values['all_day_percentage_1'])) {
          $date_arr = get_fixed_date_time($date_from, $date_to);
          $count_all_day = $values['all_day_count'];
          for($i = 1; $i <= $count_all_day; $i++) {
            $currency_type = $values['all_day_currency_'.$i];
            $price_percentage = $values['all_day_percentage_'.$i];
            if (!empty($price_percentage)) {
              if ($currency_type == 'percent') {
                $weekday = $values['all_day_weekday_'.$i];
                $price_percentage = $values['all_day_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date'], $weekday);
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price_percentage, $cancellation_policy);
                $node->set('field_space_prices', $space_prices_array);
              }
              else {
                $weekday = $values['all_day_weekday_'.$i];
                $price_fixed = $values['all_day_percentage_'.$i];
                $times_paragraph_id = create_paragraph_times($date_arr['from_date'], $date_arr['to_date'], $weekday);
                $space_prices_array = $node->get('field_space_prices')->getValue();
                $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed, $price_percentage = 0, $cancellation_policy);
                $node->set('field_space_prices', $space_prices_array);
              }
            }
          }
          $node->save();
          $price_added_status = true;
        }
      } // end specific dates
    }
    if ($price_added_status) {
      $command = new HtmlCommand('#success_message', $this->t('Changed Price added successfully.'));
    }
    $response->addCommand($command);
    $response->addCommand(new InvokeCommand(NULL, 'changePricingRedirect', [$price_added_status]));
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
