<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsFormCalendar.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Session\AccountInterface;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * {@inheritdoc}
 */
class BsCalendarSetAvailability extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_calendar_set_availability';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, AccountInterface $user = NULL) {
    $time_formate = select_list_times();
    $wd_added = array();
    $current_user = \Drupal::currentUser();
    $roles = $current_user->getRoles();
    $params_uid = isset($_REQUEST["uid"]) ? $_REQUEST["uid"] :"";
    $sort_by_key = TRUE;
    $arr_weekdays = get_taxonomy_term_values('weekdays_', $sort_by_key);
    foreach($arr_weekdays as $key => $val) {
      if($val->__toString() == 'Sunday') {
        $item = $arr_weekdays[$key];
        unset($arr_weekdays[$key]);
        $arr_weekdays[$key] = $item;
        break;
      }
    }
    $arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);
    $paras = $node->field_availability_days->referencedEntities();
    if (!empty($paras)) {
      foreach ($paras as $element ) {
        $weekd = $element->field_day->getValue()[0]['target_id'];
        $time_range = $element->field_times->getValue();
        $start_time = $time_range[0]['value'];
        $start_time = date('H:i', strtotime($start_time));
        $end_time = $time_range[0]['end_value'];
        $end_time = date('H:i', strtotime($end_time));
        if ($weekd) {
          $wd_added[$weekd] = [
            'start_time' => array_search($start_time, $time_formate),
            'end_time' => array_search($end_time, $time_formate),
          ];
        }
      }
    }
    foreach ($arr_weekdays as $day_key => $day_value) {
      $form["weekdays"]["weekdays_day_" . $day_key] = [
        "#type" => 'checkbox',
        '#title' => $day_value->__toString(),
        '#prefix' => "<div class='weekdays_wrapper'>",
      ];
      if (isset($wd_added[$day_key])) {
        $form["weekdays"]["weekdays_day_" . $day_key]['#default_value'] = 1;
      }
      $form["weekdays"]["weekdays_start_time_" . $day_key] = [
        '#type' => 'select',
        '#options' => $time_formate,
      ];
      if (isset($wd_added[$day_key]['start_time'])) {
        $form["weekdays"]["weekdays_start_time_" . $day_key]['#default_value'] = $wd_added[$day_key]['start_time'];
        $form["weekdays"]["weekdays_start_time_" . $day_key]['#attributes']['disabled'] = FALSE;
      }
      $form["weekdays"]["weekdays_end_time_" . $day_key] = [
        '#type' => 'select',
        '#options' => $time_formate,
        '#suffix' => "</div>"
      ];
      if (isset($wd_added[$day_key]['end_time'])) {

        $form["weekdays"]["weekdays_end_time_" . $day_key]['#default_value'] = $wd_added[$day_key]['end_time'];
        $form["weekdays"]["weekdays_end_time_" . $day_key]['#attributes']['disabled'] = FALSE;
      }
    }
    $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-address';
    $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-global';
    $form["submit"] = [
      "#type" => 'submit',
      "#value" => t("Apply"),
    ];
    $form['node_obj'] = [
      '#type' => 'value',
      '#value' => $node,
    ];
    $form['#attached']['library'][] = 'bs_calendar/bs-calendar-global';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    //echo date("d-m-y H:i"); die;
    $values = $form_state->getValues();
    $time_formate_array = select_list_times();
    $node = $values['node_obj'];
    $nid = $node->id();
    $wd_paragraph_item = [];
    $obj_property = Node::load($nid);
    $currentDateArrTmArr = array();
    $currentDate = isset($start_time) ? date('Y-m-d H:i:s'): '';
    $currentDateArr = explode(" ", $currentDate);
    if(isset($currentDateArr[1])){
      $currentDateArrTmArr = explode(":", $currentDateArr[1]);
    }
    $obj_property->field_availability_days->delete();

    foreach ($values as $key => $value) {
      if (strpos($key, 'weekdays_day_') !== FALSE && $value == 1) {
        $get_wd_term_array = explode("weekdays_day_", $key);
        $get_wd_term_id = $get_wd_term_array[1];
        /* start time start */
        $get_wd_st_time = isset($values['weekdays_start_time_' . $get_wd_term_id]) ? $values['weekdays_start_time_' . $get_wd_term_id]:'';
        $start_time = "0001-01-01T".$time_formate_array[$get_wd_st_time].":00";
        /* start time end */

        /* end time start */
        $get_wd_nd_time = isset($values['weekdays_end_time_' . $get_wd_term_id]) ? $values['weekdays_end_time_' . $get_wd_term_id]:'';
        $end_time = "0001-01-01T".$time_formate_array[$get_wd_nd_time].":00";

        /* end time end */
        
        /*
         ** Create paragraph items
         */
        $paragraph_items = create_paragraph_times($start_time,$end_time,$get_wd_term_id);
        $wd_paragraph_item[] = $paragraph_items;
      }
    }
    $obj_property->set("field_availability_days",$wd_paragraph_item);
    $obj_property->save();
    $space_filter_value = isset($nid) ? $nid : '';
    $uid = \Drupal::currentUser()->id();
    $user_filter_value = isset($values['user_filter']) ? $values['user_filter'] : "";
    $param = \Drupal::request()->query->all();
    $type = $param['calendar_type'];
    $path = URL::fromUserInput('/personal_area/calendar', ['query' => ['calendar_type' => $type,'space' => $nid, 'uid' => $uid]])->toString();
    $response = new RedirectResponse($path);
    $response->send();
  }

}
