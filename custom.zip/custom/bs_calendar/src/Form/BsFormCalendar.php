<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsFormCalendar.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\user\Entity\User;

/**
 * {@inheritdoc}
 */
class BsFormCalendar extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_calendar';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {
    $current_user = \Drupal::currentUser();
    $roles = $current_user->getRoles();
    $params_uid = isset($_REQUEST["uid"]) ? $_REQUEST["uid"] : "";
    $params_space_id = isset($_REQUEST["space"]) ? $_REQUEST["space"] : "";
    $calendar_type = isset($_REQUEST["calendar_type"]) ? $_REQUEST["calendar_type"] : "order";
    if (in_array("administrator", $roles)) {
      $ids = \Drupal::entityQuery('user')
        ->condition('status', 1)
        ->execute();
      $users = User::loadMultiple($ids);
      $default_uid = key($users);
      foreach ($users as $user) {
        $username = $user->get('name')->value;
        $uid = $user->get('uid')->value;
        $userlist[$uid] = $username;
        if ($params_uid == $user->get('name')->value) {
          $default_uid = $uid;
        }
      }
      $current_path = \Drupal::service('path.current')->getPath();
      $redirect_path = '';
      if($current_path == "/pricing/calendar"){
        $redirect_path = '/pricing/calendar';
      }else{
        $redirect_path = '/personal_area/calendar';
      }      
      $form["user_filter"] = [
        '#type' => 'select',
        '#title' => t("Property Owner"),
        '#options' => $userlist,
        '#default_value' => $params_uid,
      ];
    }
    $default_uid = isset($_REQUEST["uid"]) ? $_REQUEST["uid"] : $default_uid;
    $default_calendar_type = isset($_REQUEST["calendar_type"]) ? $_REQUEST["calendar_type"] : "order";

    $nids = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('type', 'ct_properties')
      ->condition('uid', $default_uid)
      ->execute();
    $nodes = Node::loadMultiple($nids);
    foreach ($nodes as $key => $node) {
      $form["property_space"][$key] = [
        '#type' => 'fieldset',
        '#title' => $node->getTitle(),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
      ];
      $property_space = $node->field_property_spaces->getValue();
      $arr_space = [];
      $default_space_id = $property_space[0]['target_id'];
      if (empty($params_space_id)) {
        $path = URL::fromUserInput($redirect_path, ['query' => ['calendar_type' => $calendar_type, 'space' => $default_space_id, 'uid' => $default_uid]])->toString();
        $response = new RedirectResponse($path);
        $response->send();
      }
      foreach ($property_space as $space_key => $space_node) {
        $space = Node::load($space_node['target_id']);
        $arr_space[$space->Id()] = $space->getTitle();
      }
      $default_space = \Drupal::request()->query->get('space');
      if(array_key_exists($default_space,$arr_space)){
          $form['property_label'] = [
            "#markup" => "<span class='default-label-cls'>".$node->getTitle()."> ".$arr_space[$default_space]."</span>",
          ];
      }
      $form['property_space'][$key]['property_space_item'] = [
        '#type' => 'radios',
        '#default_value' => $default_space,
        '#options' => $arr_space,
        '#validated' => TRUE,
      ];
      $form["submit"] = [
        "#type" => 'submit',
        "#value" => t("Apply"),
      ];
    }
    $form["redirect_path"] = [
        "#type" => 'value',
        "#value" => $current_path,
    ];
    $form["calendar_type"] = [
        "#type" => 'value',
        "#value" => $default_calendar_type,
    ];
    $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-address';
    $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-global';

    //$form['#theme'] = 'views-view-fullcalendar--calendar';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $space_filter_value = $values['property_space_item'];
    if ($values['property_space_item'] == "") {
      $space_filter_value = "All";
    }
    $user_filter_value = isset($values['user_filter']) ? $values['user_filter'] : "";
    $path = URL::fromUserInput($values['redirect_path'], ['query' => ['calendar_type'=> $values['calendar_type'], 'space' => $space_filter_value, 'uid' => $user_filter_value]])->toString();
    $response = new RedirectResponse($path);
    $response->send();
  }

}
