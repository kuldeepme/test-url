<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsCalendarBlockTime.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\CommandInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CloseModalDialogCommand;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * {@inheritdoc}
 */
class BsCalendarBlockTime extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_calendar_block_time';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, AccountInterface $user = NULL) {
    $date = '';
    $from_time = '';
    $to_time = '';
    $title = '';
    if (!empty($_REQUEST['date'])) {
      $date = $_REQUEST['date'];
      $date_default = DrupalDateTime::createFromTimestamp((int) strtotime($date));
    }
    else {
      $date_default = DrupalDateTime::createFromTimestamp(time());
    }
    if (!empty($_REQUEST['start_time'])) {
      $from_time = $_REQUEST['start_time'];
    }
    if (!empty($_REQUEST['end_time'])) {
      $to_time = $_REQUEST['end_time'];
    }
    if (!empty($_REQUEST['title'])) {
      $title = $_REQUEST['title'];
    }
    if (!empty($_REQUEST['paraId'])) {
      $para_id = $_REQUEST['paraId'];
    }
    if (!empty($_REQUEST['paraNumId'])) {
      $para_num_id = $_REQUEST['paraNumId'];
    }
    $form['pre-loader'] = [
      "#markup" => "<div id='block-pre-loader' class='hidden'>Loading.....</div>"
    ];
    $form['space_available'] = [
      "#markup" => "<div id=space_message></div>",
      '#weight' => 0,
    ];
    $form["space_paragraph_id"] = array(
      "#type" => "textfield",
      '#attributes' => [
        'class' => ["hidden submit-for-calendar"],
      ],
      '#default_value' => $para_id,
    );
    $form['space_paragraph_numid'] = [
      "#type" => 'textfield',
      '#attributes' => [
        'class' => ["hidden submit-for-calendar"],
      ],
      '#default_value' => $para_num_id,
    ];
    $form['date'] = [
      '#prefix' => '<div id="block-complete-wrapper"><div id="block-my-time"></div>',
      '#type' => 'datetime',
      '#title' => $this->t('Date'),
      '#size' => 20,
      '#date_date_element' => 'date',
      '#date_time_element' => 'none',
      '#date_time_format' => 'h:i',
      '#attributes' => [
        'class' => ["ajax-disabled bs-date-cal-time"],
      ],
      '#default_value' => $date_default,
      '#attributes' => ['min' =>  \Drupal::service('date.formatter')->format(\Drupal::time()->getRequestTime(), 'custom', 'Y-m-d'),],
    ];
    $time_formate = select_list_times();
    $form['from_time'] = [
      '#type' => 'select',
      '#title' => $this->t('Hours'),
      '#options' => $time_formate,
      '#attributes' => [
        'class' => ["bs-time-from-time"],
      ],
      '#default_value' => array_search($from_time, $time_formate),
    ];
    $form['to_time'] = [
      '#type' => 'select',
      '#options' => $time_formate,
      '#attributes' => [
        'class' => ["bs-time-to-time"],
      ],
      '#default_value' => array_search($to_time, $time_formate),
    ];
    $form['personal_note'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Add a personal note'),
      '#attributes' => [
        'placeholder' => t('Team Meeting'),
        'class' => ["bs-personal-note"],
      ],
      '#default_value' => $title,
    ];
    $form['space_id'] = [
      "#type" => 'hidden',
      "#value" => $node->id(),
    ];
    $form['bt_udpate'] = [
      "#type" => 'hidden',
      "#value" => !empty($_REQUEST['bt_update'])? $_REQUEST['bt_update']: "false",
    ];
    $form["submit"] = [
      "#type" => 'submit',
      "#value" => t("Save"),
      '#attributes' => [
        'class' => ["submit-for-calendar"],
      ],
      '#ajax' => [
        'wrapper' => 'block-my-time',
        'callback' => '::saveBlockedTime',
      ]
    ];
    if (!empty($para_id) && !empty($para_num_id)) {
      $form["delete"] = [
        "#type" => 'submit',
        "#suffix" => "</div>",
        '#attributes' => [
          'class' => ["used-for-calendar"],
        ],
        "#value" => t("Delete"),
        '#ajax' => [
          'wrapper' => 'block-my-time',
          'callback' => '::saveBlockedTime',
        ]
      ];
    }
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
   // kint($form_state->getValues()["op"]->__toString());die;
  }

  /**
   * {@inheritdoc}
   */
  public function saveBlockedTime(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $existing_entries = [];
    $response = new AjaxResponse();
    $redirect = false;
    if($values['from_time']== "" || $values['to_time'] == "" || $values['personal_note'] == ""){
      $error_message = "All fields are required";
      $validation_text = '<div data-drupal-messages=""><div class="messages__wrapper"><div class="alert alert-danger alert-dismissible" role="alert" aria-label="Error message"><button type="button" role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><h2 class="sr-only">Error message</h2><ul class="item-list item-list--messages">'.$error_message.'</ul></div></div></div>';
      $command = new HtmlCommand('#block-my-time', $validation_text);
      $response->addCommand($command);
    }
    else{
      $error_message = "";
/*      $value = str_pad($values['to_time'],2,"0",STR_PAD_LEFT);
    $opening_time = $opening_date->format("Y-m-d")." ".str_pad($values['from_time'],2,"0",STR_PAD_LEFT).":00";
    $closing_time = $opening_date->format("Y-m-d")." ".str_pad($values['to_time'],2,"0",STR_PAD_LEFT).":00";*/
    $opening_date = $values['date'];
    $from_time = get_select_list_times_from_index($values['from_time']);
    $to_time = get_select_list_times_from_index($values['to_time']);
    $opening_time = $opening_date->format("Y-m-d")." ".$from_time;
    $closing_time = $opening_date->format("Y-m-d")." ".$to_time;
    $now = date('Y-m-d H:i', time());
    if(strtotime($opening_time) < $now) {
     $error_message = $this->t('Start time should be future time.');
    }
    
    if(strtotime($opening_time) == strtotime($closing_time)){
     $error_message = $this->t('Start time and end time should not be same.');
    }

    if(strtotime($opening_time) > strtotime($closing_time)){
     $error_message = $this->t('Start time should be greater then end time');
    }
/*    $bt_udpate = $values['bt_udpate'];
    $date = $opening_date->format("Y-m-d");
    if ($bt_udpate !== "true") {
      $space_is_available = check_if_space_is_available($date, $values['from_time'], $values['to_time'], $values['space_id']);
      if (($space_is_available == FALSE || $space_is_available == "") && ($values["op"]->__toString() != "Delete")) {
        $space_error = t("Time is not available");
        $error_msg = '<div class="alert alert-danger alert-dismissible" role="alert" aria-label="Error message"><button type="button" role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>'.$space_error . '<br>' . $error_message .'</div>';
        $response->addCommand(new HtmlCommand('#space_message', $error_msg));
        return $response;
      }
      else {
        $space_error = '';
        $error_msg = '';
      }
    }*/
    if($error_message!=""){
      $validation_text = '<div data-drupal-messages=""><div class="messages__wrapper"><div class="alert alert-danger alert-dismissible" role="alert" aria-label="Error message"><button type="button" role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><h2 class="sr-only">Error message</h2><ul class="item-list item-list--messages">'.$error_message.'</ul></div></div></div>';
      $command = new HtmlCommand('#block-my-time', $validation_text);
      $response->addCommand($command);
    }
    else{
      $time_formate = select_list_times();
      $node = Node::load($values['space_id']);
      if($node->hasField("field_space_availability_close")){
        $existing_entries = $node->field_space_availability_close->getValue();
      }

      $close_date = date("Y-m-d",strtotime($values["date"]->__toString()))."T".$time_formate[$values['to_time']].":00";

      $start_date = date("Y-m-d",strtotime($values["date"]->__toString()))."T".$time_formate[$values['from_time']].":00";
      $times_para = create_paragraph_times($start_date,$close_date,null);

      if($values["space_paragraph_id"]){
        $entity = \Drupal::entityTypeManager()->getStorage('paragraph')->load($values["space_paragraph_id"]);
        if ($entity) {
          $entity->delete();
          unset($existing_entries[$values["space_paragraph_numid"]]);
        }
      }
      if($values["op"]->__toString() != "Delete"){
        $space_close_para = Paragraph::create([
          'type' => 'space_availability_close',
          'field_space_availability_close' => $times_para,
          'field_notes' => $values['personal_note'],
        ]);
        $space_close_para->validate();
        $space_close_para->save();

        $space_close_para_object = [
          'target_id' => $space_close_para->id(),
          'target_revision_id' => $space_close_para->getRevisionId(),
        ];
      }
      if(count($existing_entries)){
        $space_close_para_merged[] = $space_close_para_object;
        $space_close_para_object = array_merge($existing_entries,$space_close_para_merged);
      }
      $node->set("field_space_availability_close",$space_close_para_object);
      $node->save();
      $command = new CloseModalDialogCommand();
      $redirect = true;
    }
  }
  $response->addCommand($command);
  $response->addCommand(new InvokeCommand(NULL, 'blockTimeRedirect', [$redirect]));
  return $response;
  }
}
