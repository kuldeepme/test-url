<?php

namespace Drupal\bs_calendar\Form;

/**
 * @file
 * Contains \Drupal\bs_calendar\Form\BsCalendarEditChangePricing.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CloseModalDialogCommand;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\CommandInterface;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\taxonomy\Entity\Term;

/**
 * {@inheritdoc}
 */
class BsCalendarEditChangePricing extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_calendar_edit_change_pricing';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, AccountInterface $user = NULL) {
    $start_date = $_REQUEST["start"];
    $end_date = $_REQUEST["end"];
    $price = $_REQUEST["price"];
    $start_time = $_REQUEST["from_time"];
    $end_time = $_REQUEST["to_time"];
    $sort_by_key = TRUE;
    $arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);
    $form['success_message'] = [
        '#type' => 'markup',
        '#markup' => '<div id="success_message"></div>'
    ];
    $form['validation_message'] = [
        '#type' => 'markup',
        '#markup' => '<div id="validation_wrapper"></div>'
    ];
    $form['date_from'] = [
      '#type' => 'date',
      '#title' => t('Start Date'),
      '#size' => 20,
      '#date_time_element' => 'none',
      '#date_date_format' => 'Y-m-d',
      '#default_value' => $start_date,
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['date_until'] = [
      '#type' => 'date',
      '#title' => $this->t('End Date'),
      '#size' => 20,
      '#date_time_element' => 'none',
      '#date_date_format' => 'Y-m-d',
      '#default_value' => $start_date,
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $space_price = $node->field_price->getValue()[0]['value'];
    $form['price'] = [
      '#type' => 'textfield',
      '#title' => t('Hourly price (VAT not included)'),
      '#attributes' => [
        'placeholder' => t('0'),
      ],
      '#default_value' => $space_price,
    ];
    $form['edit_price'] = [
      '#type' => 'value',
      '#value' => $price,
    ];
/*    if (!empty($node->field_space_currencies->getValue())) {
      $default_crrency = $node->field_space_currencies->getValue()[0]['target_id'];
    }*/
    $default_crrency = get_country_details_by_space_id($node->id());
    $form["currency"] = [
      '#type' => 'textfield',
      '#size' => 20,
      '#default_value' => !empty($default_crrency['currency_code']) ? $default_crrency['currency_code'] : 'USD',
      '#attributes' => ['disabled' => 'disabled'],
    ];
    $form['advance_options'] = [
      '#type' => 'fieldset',
      '#title' => t('Advanced options'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $time_formate = select_list_times();
    $form['advance_options']['hourly_container']['from_time'] = [
      '#type' => 'select',
      '#title' => t('Hourly discount'),
      '#options' => $time_formate,
      '#default_value' => array_search($start_time, $time_formate)
    ];
    $form['advance_options']['hourly_container']['to_time'] = [
      '#type' => 'select',
      // '#title' => $this->t('Time'),
      '#options' => $time_formate,
      '#default_value' => array_search($end_time, $time_formate)
    ];
    $form['advance_options']['hourly_container']['hourly_percentage'] = [
      '#type' => 'textfield',
      '#attributes' => [
        'placeholder' => t('0'),
      ],
      '#default_value' => $price
    ];
    $form['advance_options']['hourly_container']['hourly_currency'] = [
/*      '#type' => 'select',
      '#options' => ['percent' => '%'] + $arr_currencies,
      '#default_value' => 'percent'*/
      '#type' => 'textfield',
      '#size' => 20,
      '#default_value' => !empty($default_crrency['currency_code']) ? $default_crrency['currency_code'] : 'USD',
      '#attributes' => ['disabled' => 'disabled'],
    ];
    $form['node_obj'] = [
      '#type' => 'value',
      '#value' => $node,
    ];
    $form["submit"] = [
      "#type" => 'submit',
      "#value" => t("Save"),
      '#ajax' => [
        'callback' => '::saveChangedPrice',
      ]
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function saveChangedPrice(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $validation_text = '';
    $price_added_status = false;
    if (strlen($form_state->getValue('price')) < 1) {
      $validation_text .= '<li class="item item--message">Hourly price (VAT not included) '.t('field is required').'.</li>';
    }
    if($validation_text!=""){
      $validation_text = '<div data-drupal-messages=""><div class="messages__wrapper"><div class="alert alert-danger alert-dismissible" role="alert" aria-label="Error message"><button type="button" role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><h2 class="sr-only">Error message</h2><ul class="item-list item-list--messages">'.$validation_text.'</ul></div></div></div>';
      $command = new HtmlCommand('#validation_wrapper', $validation_text);
      $response->addCommand($command);
    }
    else {
      $times_paragraph_id = [];
      $space_prices_array = [];
      $cancellation_policy = 193;
      $price_percentage = 0;
      $values = $form_state->getValues();
      $price = isset($values['price']) ? $values['price'] : 0;
      $percentage = isset($values['currency']) ? $values['currency'] : '';
      $node = $values['node_obj'];
      $nid = $node->id();
      $edit_price = $values['edit_price'];
      $date_from = isset($values['date_from']) ? $values['date_from'] : '';
      $date_to = isset($values['date_until']) ? $values['date_until'] : '';
      if (!empty($price)) {
        $node->set('field_price', $price);
        $node->save();
        $price_added_status = true;
      }
      if ($edit_price !== $values['hourly_percentage']) {
        // create all day discount paragraph
        if (!empty($values['hourly_percentage'])) {
          $time_formate = select_list_times();
          $from_time = $time_formate[$values['from_time']];
          $to_time = $time_formate[$values['to_time']];
          if ($from_time != 'none' && $to_time != 'none') {
            $date_from = date('Y-m-d', strtotime($date_from));
            $start_date = $date_from . "T" . $from_time . ":00";
            $date_to = date('Y-m-d', strtotime($date_to));
            $end_date =  $date_to . "T" . $to_time . ":00";
          }
          $price_percentage = $values['hourly_percentage'];
          $times_paragraph_id = create_paragraph_times($start_date, $end_date);
          $space_prices_array = $node->get('field_space_prices')->getValue();
          $space_prices_array[] = create_paragraph_space_prices($times_paragraph_id, $price_fixed = 0, $price_percentage, $cancellation_policy);
          $node->set('field_space_prices', $space_prices_array);
          $node->save();
          $price_added_status = true;
        }
      }
    }
    if ($price_added_status) {
      $command = new HtmlCommand('#success_message', $this->t('Changed Price added successfully.'));
    }
    else {
      $command = new HtmlCommand('#success_message', $this->t('No updation found.'));
    }
    $response->addCommand($command);
    $response->addCommand(new InvokeCommand(NULL, 'changePricingRedirect', [$price_added_status]));
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
