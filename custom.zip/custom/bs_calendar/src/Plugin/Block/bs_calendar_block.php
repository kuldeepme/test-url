<?php

namespace Drupal\bs_calendar\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_calendar form.
 *
 * @Block(
 *   id = "bs_calendar_block",
 *   admin_label = @Translation("bs_calendar_block"),
 *   category = @Translation("bs_calendar"),
 * )
 */
class bs_calendar_block extends BlockBase {
    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_calendar\Form\BsFormCalendar');
        return $form;
    }

}
