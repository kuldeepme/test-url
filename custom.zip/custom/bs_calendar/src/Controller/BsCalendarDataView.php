<?php

namespace Drupal\bs_calendar\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\views\Views;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Database\Database;

/**
 * Provides route responses for map location routing.
 */
class BsCalendarDataView extends ControllerBase {

  /**
   * Render location node content.
   */
  public function content() {
  	$default_date = date('Y-m-d');
  	$space_id = $_REQUEST["space"];
  	$space_user_id = $_REQUEST["uid"];
  	$calendar_type = "order";
  	$records = [];
    $closing_array = [];
    $space_array = [];
    $type = $_REQUEST["type"];
  	if(isset($_REQUEST["calendar_type"])){
  		$calendar_type = !empty($_REQUEST["calendar_type"]) ? $_REQUEST["calendar_type"] : "order";
  	}
  	if($calendar_type == "order"){
  		$args = [$space_user_id,$space_id];
  		$view = Views::getView('calendar');
  		if (is_object($view)) {
  			$view->setArguments($args);
  			$view->setDisplay('page_2');
  			$view->preExecute();
  			$view->execute();

  			foreach ($view->result as $key => $row) {
          if($row->_entity != NULL){
            $resrvation_price = 0;
            $resrvation_vat_price = 0;
            $start_time = "00:00";
            $end_time = "00:00";
            $first_name = "";
            $last_name = "";
            $cal_title = "";
            $resrvation_currency = "$";
            $total_price = 0;
            $para_id = "";
            $node = $row->_entity;
            $reservation_nid = $node->id();
            $space_obj = $node->field_reservation_space->entity;
            if($space_obj->hasField('field_space_availability_close')){
              $referenced_paras = $space_obj->field_space_availability_close->referencedEntities();
              foreach($referenced_paras as $keys => $referenced_para){
                $para_id = $referenced_para->id();
                $closing_notes = "";
                if($referenced_para->hasField("field_notes")){
                  $closing_notes = $referenced_para->field_notes->value;
                }
                if($referenced_para->hasField('field_space_availability_close')){
                  $timecheck = $referenced_para->field_space_availability_close->entity;
                  if($timecheck->hasField('field_times')){
                    $date_object = $timecheck->field_times->getValue();
                    $closing_array[$keys]['title'] = $closing_notes;
                    $closing_array[$keys]['start'] = $date_object[0]['value'];
                    $closing_array[$keys]['end'] = $date_object[0]['end_value'];
                    $closing_array[$keys]['paraId'] = $para_id;
                    $closing_array[$keys]['paraNumId'] = $keys;
                    $closing_array[$keys]['className'] = "res-time-blocked res-blocked-num-".$keys." res-blocked-id-".$para_id;
                    $query['date'] = date('Y-m-d', strtotime($date_object[0]['value']));
                    $query['start_time'] = date('H:i', strtotime($date_object[0]['value']));
                    $query['end_time'] = date('H:i', strtotime($date_object[0]['end_value']));
                    $query['title'] = $closing_notes;
                    $query['paraId'] = $para_id;
                    $query['paraNumId'] = $keys;
                    $qs = http_build_query($query);
                    $url = "/bs-space/".$space_id."/".$space_user_id."/update-block-time?" . $qs;
                    $closing_array[$keys]['url'] = $url;
                    // Use for node space calendar
                    //$space_array[$keys]['title'] = $closing_notes;
                    $space_array[$keys]['title'] = "Occupied";
                    $space_array[$keys]['start'] = $date_object[0]['value'];
                    $space_array[$keys]['end'] = $date_object[0]['end_value'];
                    $space_array[$keys]['className'] = "occupied time-cleaning res-time-blocked";
                    $space_array[$keys]['editable'] = false;
                  }
                }
              }
            }
            if($node->uid->entity->field_user_first_name != NULL ){
              $first_name = $node->uid->entity->field_user_first_name->getValue()[0]['value'];
            }
            if($node->uid->entity->field_user_last_name != NULL ){
              $last_name = $node->uid->entity->field_user_last_name->getValue()[0]['value'];
            }
            if(isset($node->field_reservation_time) && $node->field_reservation_time != NULL){
              $pargraph_entry = $node->field_reservation_time->entity;
              if($pargraph_entry->field_times !=NULL){
                $times = $pargraph_entry->field_times->getValue()[0];
                $start_time = $times["value"];
                $end_time = $times["end_value"];
              }
              $reservation_space_price = $node->field_reservation_space_price_br->referencedEntities();
              if ($reservation_space_price != NULL) {
                $referenced_paras = $reservation_space_price;
                foreach($referenced_paras as $keys => $referenced_para){
                   if($referenced_para->hasField('field_reservation_price_per_hour')){
                     $resrvation_price = $referenced_para->field_reservation_price_per_hour->value;
                   }
                }
              }
              if($node->field_reservation_vat_per_price != NULL ){
                $resrvation_vat_price = $node->field_reservation_vat_per_price->getValue()[0]['value'];
              }
              else {
                $resrvation_vat_price = 0;
              }
              if ($node->field_reservation_table_bs_check != NULL) {
                $checkout_id = $node->field_reservation_table_bs_check->getValue()[0]['value'];
                //Get data from DB from 'bs_checkout' table
                $query_select = \Drupal::database()->select('bs_checkout', 'c');
                $query_select->condition('c.id', $checkout_id, '=');
                $query_select->condition('c.status', 1, '=');
                $query_select->fields('c', ['number_of_people']);
                $result = $query_select->execute()->fetchAssoc();
                if ($result['number_of_people'] != null) {
                  $number_of_people_tid = $result['number_of_people'];
                }
                else {
                  $number_of_people_tid = 87;
                }
              }
              if ($node->field_reservation_currency != NULL) {
                $resrvation_currency_id = $node->field_reservation_currency->getValue()[0]['target_id'];
                if ($resrvation_currency_id && $resrvation_currency_id !=0) {
                  $term = Term::load($resrvation_currency_id);
                  $resrvation_currency = $term->field_currency_symbol->getValue()[0]['value'];
                }
                else {
                  $query_select = \Drupal::database()->select('bs_checkout_prices', 'p');
                  $query_select->condition('p.bs_checkout_id', $checkout_id, '=');
                  $query_select->fields('p', ['currency_id']);
                  $result = $query_select->execute()->fetchAssoc();
                  if ($result['currency_id'] != null) {
                    $arr_currency_details = get_currency_details_from_id($result['currency_id']);
                    $resrvation_currency = $arr_currency_details['currency_symbol'];
                  }
                }
              }
              //Calculate the price + VAT
              if($row->_entity->hasField('field_reservation_paid_price') && $row->_entity->field_reservation_paid_price->getValue()[0]["value"] != null){
                  $total_price = $row->_entity->field_reservation_paid_price->getValue()[0]["value"];
              } else {
                  $price = $row->_entity->field_reservation_price->getValue()[0]["value"];
                  $price_vat = $row->_entity->field_reservation_price_vat->getValue()[0]["value"];
                  $price_total_vat = ($price / 100) * $price_vat;
                  $total_price = $price + $price_total_vat;
              }
/*              if ($node->field_reservation_price != NULL) {
                $resrvation_price = $node->field_reservation_price->getValue()[0]['value'];
              }*/
              //$total_price = reservation_total_price($reservation_nid, $resrvation_price);
              //$total_price = $resrvation_price + $resrvation_vat_price;
              $cal_title = "";
              $price_display = t("Total price:")." ".$total_price.$resrvation_currency;
              $cal_title.= $first_name." ".$last_name;
              $records[$key]['start'] = $start_time;
              $records[$key]['end'] = $end_time;
              $node_status = $node->isPublished();
              if($node_status){
                $className = "res-confirmed";
                $cal_title.= " ".$price_display;
                $records[$key]['title'] = $cal_title;
              }else{
                $className = "res-payment-pending";
                $cal_title.= " ".t("Order not complete");
                $records[$key]['title'] = $cal_title;
              }
              $records[$key]['reservation_nid'] = $reservation_nid;
              $records[$key]['checkout_id'] = $checkout_id;
              $records[$key]['className']= $className;
              $records[$key]['people_tid'] = $number_of_people_tid;
            }
          }
        } //end foreach
      }
      if ($calendar_type == "order" && $type == "spaces") {
        foreach ($records as $key => $value) {
          $records[$key]['title'] = "Occupied";
          $records[$key]['className'] = "occupied";
          $records[$key]['editable'] = false;
          //unset($records[$key]['className']);
        }
        $final_events = array_merge($records,$space_array);
        $op = json_encode($final_events);
        print $op;
        exit;
      }
      else {
        $final_events = array_merge($records,$closing_array);
        $op = json_encode($final_events);
        print $op;
        exit;
      }
  	}

    if($calendar_type == "pricing"){
      $currency_symbol = '';
      $price_default = 0;
      $records = [];
      $start_end = [];
      $data = [];
      $query = [];
      $date = $_REQUEST["end"];
      $node_space = Node::load($space_id);
      if ($node_space->isPublished()) {
        if (!empty($date)) {
          $date = date('Y-m-d', strtotime($date));
          $week_dates = get_current_week_dates($date);
        }
        else {
          $week_dates = get_current_week_dates();
        }
/*        $min_and_max = get_space_min_and_max_opening_hours($space_id);
        $str_start_time = get_select_list_times_from_index(reset($min_and_max));
        $str_end_time = get_select_list_times_from_index(end($min_and_max));
        $start_time = $week_dates['start_time'] .'  '. $str_start_time;
        $start_time = date('Y-m-d\TH:i:s', strtotime($start_time));
        $end_time = $week_dates['end_time'] .'  '. $str_end_time;
        $end_time = date('Y-m-d\TH:i:s', strtotime($end_time));
        $records[] = get_space_prices_per_hour_for_period($space_id, $start_time, $end_time);*/
        $records[] = get_space_prices_per_hour_for_period($space_id, $week_dates["Sun"]['start_time'], $week_dates["Sat"]['end_time']);
        $data = array_merge(...$records);
        foreach ($data as $key => $value) {
          $start = date('Y-m-d', strtotime($value['start']));
          $end = date('Y-m-d', strtotime($value['end']));
          $time_from = date('h:i', strtotime($value['start']));
          $time_to = date('h:i', strtotime($value['end']));
          $price = explode("/", $value['price']);
          $price = $price[0];

          $query['start'] = $start;
          $query['end'] = $end;
          $query['from_time'] = $time_from;
          $query['to_time'] = $time_to;
          $query['price'] = preg_replace('/[^0-9.]/', '', $price);

          $qs = http_build_query($query);
          $url = "/bs-space/".$space_id."/".$space_user_id."/edit-change-pricing?" . $qs;

          $data[$key]['url'] = $url;
          $data[$key]['className'] = 'pricing-update';
        }
      }
      $op = json_encode($data);
      $op = str_replace('"price":', '"title":', $op);
      print $op;
      exit;
    }
    $op = json_encode(false);
    print $op;
    exit;
  }
}
