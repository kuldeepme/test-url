<?php

namespace Drupal\bs_calendar\Controller;


use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\views\Views;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;

/**
 * Provides route responses for map location routing.
 */
class BsCalendarOrderView extends ControllerBase {

    /**
   * Render location node content.
   */
  public function content() {
  	$default_date = date('Y-m-d');
  	$space_id = $_REQUEST["space"];
  	$space_user_id = $_REQUEST["uid"];
  	$calendar_type = "order";
    $order_actived = "";
    $price_actived = "";
  	$records = [];
  	if(isset($_REQUEST["calendar_type"])){
  		$calendar_type = !empty($_REQUEST["calendar_type"]) ? $_REQUEST["calendar_type"] : "order";
  	}

    if($calendar_type == "order"){
      $order_actived = "active";
      $res_id =  NULL;
      if(isset($_REQUEST["res_id"])){
        $node = Node::load($_REQUEST["res_id"]);
        if($node != NULL && $node instanceof NodeInterface){
          if ($node->isPublished() && $node->getType() == "ct_reservations") {
            $reservation_date = date('Y-m-d', $node->getCreatedTime());
            if($_REQUEST["op"] == "view"){
              $res_id =  '<a class="hidden cal-view-reservation" data-dialog-type="modal" data-dialog-title="modal" href="'. $_REQUEST["res_id"] .'">view</a>';
            }elseif($_REQUEST["op"] == "edit"){
              $res_id =  '<a class="hidden use-ajax cal-edit-reservation" data-dialog-type="modal" data-dialog-title="modal" href="/bs-space/edit-reservation?reservation_nid='. $_REQUEST["res_id"] .'">edit</a>';
            }
          }
        }
      }
    }else{
      $price_actived = "active";
    }
    return [
      '#theme' => 'bs_calendar_order',
      '#orders' =>[
        'calendar_type' => $calendar_type,
        'space_id' => $space_id,
        'space_user_id' => $space_user_id,
        'order_actived' => $order_actived,
        'price_actived' => $price_actived,
        'reservation_id' => $res_id,
        'reservation_date' => $reservation_date,
      ],
    ];
  }
}