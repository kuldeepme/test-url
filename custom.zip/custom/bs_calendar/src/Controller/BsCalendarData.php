<?php

namespace Drupal\bs_calendar\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\user\Entity\User;
use Drupal\file\Entity\File;
use Drupal\Core\Url;

/**
 * Provides reservation responses.
 */
class BsCalendarData extends ControllerBase {

  /**
   * Render reservation node content.
   */
  public function content() {
    $records = [];
    $arr_prices = [];
    $delete_true = '';
    $reservation_nid = $_REQUEST["reservation_nid"];
    $delete_true = $_REQUEST["delete"];
    if ($reservation_nid != NULL && $delete_true) {
      $reservation = Node::load($reservation_nid);
      $result = $reservation->get('field_reservation_time')->referencedEntities();
      if (!empty($result)) {
        foreach ($result as $paragraph) {
          $paragraph->set('field_times', NULL);
          $paragraph->save();
        }
      }
      $reservation->setPublished(FALSE);
      //save to update node
      $reservation->save();
      $order_details = TRUE;
      $op = json_encode($order_details);
      print $op;
      exit;
    }
    else if ($reservation_nid != NULL) {
      $resrvation_price = 0;
      $resrvation_vat_price = 0;
      $first_name = "";
      $last_name = "";
      $currency_symbol = "$";
      $total_price = 0;
      $order_details = bs_calendar_reservation_details($reservation_nid);
      $op = json_encode($order_details);
      print $op;
      exit;
    }
    else {
      $order_details = FALSE;
      $op = json_encode($order_details);
      print $op;
      exit;
    }
  }

}
