<?php

namespace Drupal\bs_calendar\Controller;


use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\views\Views;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides route responses for map location routing.
 */
class BsCalendarPricingView extends ControllerBase {

    /**
   * Render location node content.
   */
  public function content(NodeInterface $node, AccountInterface $user) {
    kint($node);
    kint($user);die;
    echo "Hello";die;
  }
}