var vars = {};
var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
      vars[key] = value;
    });
var minTime = drupalSettings.minTime;
var maxTime = drupalSettings.maxTime;
if (vars.calendar_type == "order") {
  var edit = true;
}
else {
  edit = false;
}
document.addEventListener('DOMContentLoaded', function() {
  var default_date = document.getElementById("data-res-date");
  if (default_date.innerHTML == null || default_date.innerHTML == "undefined" || default_date.innerHTML == '') {
    var calendar_date = new Date();
  }
  else {
    calendar_date = default_date.innerHTML;
  }
var calendarEl = document.getElementById('calendar');
var calendar = new FullCalendar.Calendar(calendarEl, {
  plugins: [ 'interaction', 'dayGrid', 'timeGrid'],
  contentHeight: "auto",
  minTime: minTime,
  maxTime: maxTime,
  defaultDate: calendar_date,
  header: {
    left: 'prev,next today',
    center: 'title',
    right: 'dayGridMonth,timeGridWeek'
  },
  dateClick: function(info) {
    //console.log(info);
  },
  eventRender: function(event) {
     var event_class = event.el.classList[4];
     if (event_class == "res-confirmed") {
       event.el.href = event.event.extendedProps.reservation_nid;
       jQuery(event.el).on({
          click: function() {
            var reservation_nid = jQuery(this).attr("href");
            if (reservation_nid){
              jQuery.ajax({
                type: 'POST',
                url: '/bs_calendar_data?reservation_nid='+reservation_nid,
                success: function (response) {
                  var obj = JSON.parse(response);
                  jQuery("#dialog").dialog({
                    autoOpen: false,
                    width: "100%",
                    heigth: "auto"
                  });
                  jQuery(".ui-dialog-titlebar .modal-title").hide();
                  reservation_details(obj);
                  jQuery('#dialog').dialog('open');
                  if (obj[0].order_no) {
/*                    var params = {
                        res_nid: reservation_nid,
                        date: obj[0].from_date_request,
                        start_time: obj[0].from_time,
                        end_time: obj[0].to_time,
                        people_tid: obj[0].no_of_people_tid
                    };
                    var edit_href = '/bs-space/'+vars.space+'/'+vars.uid+'/update-reservation?'+jQuery.param(params);*/
                    var edit_href = "/bs-space/edit-reservation?reservation_nid="+ obj[0].order_no;
                    var edit_anchor = '<a class="use-ajax edit-reservation" data-dialog-type="modal" href="'+edit_href+'" data-dialog-title="modal" id="edit-reservation'+ obj[0].order_no+'">Edit</a>'
                    jQuery("#edit-reservation").html(edit_anchor);
                  }
                  Drupal.attachBehaviors('#bs_calendar_edit_reservation');
                  jQuery('#bs_calendar_edit_reservation').ajaxForm();
                }
              });
            }
          }
       });
    }
    if (event_class == "res-time-blocked") {
      jQuery(event.el).on({
        click: function() {
          Drupal.ajax({
            url: event.el.href+"&bt_update=true"
          }).execute();
        }
      });
    }
    if (event_class == "pricing-update") {
      jQuery(event.el).on({
        click: function() {
          jQuery("#editPricingModal").dialog({
            autoOpen: false,
            width: "100%",
            heigth: "auto"
          });
          edit_pricing(event.el.href);
          jQuery('#editPricingModal').dialog('open');
        }
      });
    }
  },
  eventClick: function(calEvent, jsEvent, view) {
/*    var start_date_time = calendar.formatIso(calEvent.event.start);
    var end_date_time = calendar.formatIso(calEvent.event.end);
    var title = calEvent.event.title;
    var selected_event_class = calEvent.event.classNames[0];
    if(selected_event_class == "res-time-blocked") {
      jQuery("#block-pre-loader").removeClass("hidden");
      jQuery(".header-right #bs-block-time-link").trigger('click');
      jQuery(".block-complete-wrapper").hide();
      var str = calEvent.event.classNames[2];
      var str_new = calEvent.event.classNames[1];
      var paraId = calEvent.event.extendedProps.paraId;
      var paraNumId = calEvent.event.extendedProps.paraNumId;
      setTimeout(function(){
        var fromDate = start_date_time.split("+")[0];
        var endToDate = end_date_time.split("+")[0];
        var startdate = new Date(fromDate);
        var split_enddate = endToDate.split("T")[1];
        var split_startdate = endToDate.split("T")[0];
        var finalSplittime = split_enddate.split(":");
        var startGetMinutes = ('0'+startdate.getMinutes()).slice(-2);
        var startGetHours = ('0'+startdate.getHours()).slice(-2);

        var enddate = new Date(endToDate);
        var endGetMinutes = ('0'+enddate.getMinutes()).slice(-2);
        var endGetHours = ('0'+enddate.getHours()).slice(-2);
        jQuery('input[name="space_paragraph_id"]').val(paraId);
        jQuery('input[name="space_paragraph_numid"]').val(paraNumId);
        jQuery('.form-item-date-date .form-date').val(split_startdate);
        jQuery("#block-pre-loader").addClass("hidden");
        jQuery(".block-complete-wrapper").show();
        jQuery(".used-for-calendar").removeClass("hidden");
        jQuery(".submit-for-calendar").val(paraId);
        var start_time = startGetHours+":"+startGetMinutes;
        var end_time = finalSplittime[0]+":"+finalSplittime[1];
        var date_time = '13:00';

        if (calEvent.event.title) {
          jQuery(".select-wrapper .bs-time-from-time option").filter(function() {
            return jQuery(this).text() == start_time;
          }).attr('selected', true);

          jQuery(".select-wrapper .bs-time-to-time option").filter(function() {
            return jQuery(this).text() == end_time;
          }).attr('selected', true);

          jQuery(".form-item-personal-note .bs-personal-note").val(calEvent.event.title);
        }

      }, 1500);
    }*/
    calEvent.jsEvent.preventDefault();
    // Delete 
    jQuery("#delete-reservation").once("reservation_delete").click(function(dl){
      jQuery('#dialog').dialog('close');
      var el = this;
      // Delete id
      var nid = jQuery(this).attr("data-id");
      // Confirm box
      bootbox.confirm("Do you really want to delete record?", function(result) {
         if(result){
           // AJAX Request
           jQuery.ajax({
             url: '/bs_calendar_data?reservation_nid='+nid+'&delete=true',
             type: 'POST',
             success: function(response){
                // Removing row from HTML Table
                if(response){
                  jQuery(el).closest('tr').fadeOut(800,function(){
                    jQuery(this).remove();
                  });
                }else{
                  bootbox.alert('Record not deleted.');
                }
                setTimeout(function(){
                  location.reload();
                  jQuery('#dialog').dialog('close');
                }, 300);
             }
           });
         }
      });
      dl.preventDefault();
    });
  },
  editable: false,
  navLinks: true,
  eventLimit: true,
  selectable: true,
  select: function(arg) {
    jQuery("#createEntryModal").dialog({
      autoOpen: false,
      width: "100%",
      heigth: "auto"
    });
    //jQuery(".ui-dialog-titlebar .modal-title").hide();
    jQuery('#createEntryModal').dialog('open');
    update_entry_link(arg);
  },
  events: {
    url: '/bs_calendar_data_view?calendar_type='+vars.calendar_type+'&space='+vars.space+'&uid='+vars.uid,
    type: 'POST', // Send post data
    error: function() {
    },
    success: function(data) {
    },
  },
  defaultView: 'timeGridWeek',
  timeFormat: 'H:mm',
  eventResize: false,
  editable: edit,
  droppable: true,
  eventDrop: function(event) {
    update_reservation(event);
  }, // Event drop end
  eventResize: function(event) {
    update_reservation(event);
  }
});
calendar.render();
});

jQuery(document).ready(function () {
  jQuery('.cal-edit-reservation').trigger('click');
  jQuery('.cal-view-reservation').click(function() {
      var reservation_nid = jQuery(this).attr("href");
      if (reservation_nid){
        jQuery.ajax({
          type: 'POST',
          url: '/bs_calendar_data?reservation_nid='+reservation_nid,
          success: function (response) {
            var obj = JSON.parse(response);
            jQuery("#dialog").dialog({
              autoOpen: false,
              width: "100%",
              heigth: "auto"
            });
            jQuery(".ui-dialog-titlebar .modal-title").hide();
            reservation_details(obj);
            jQuery('#dialog').dialog('open');
            if (obj[0].order_no) {
              var edit_href = "/bs-space/edit-reservation?reservation_nid="+ obj[0].order_no;
              var edit_anchor = '<a class="use-ajax edit-reservation" data-dialog-type="modal" href="'+edit_href+'" data-dialog-title="modal" id="edit-reservation'+ obj[0].order_no+'">Edit</a>'
              jQuery("#edit-reservation").html(edit_anchor);
            }
            Drupal.attachBehaviors('#bs_calendar_edit_reservation');
            jQuery('#bs_calendar_edit_reservation').ajaxForm();
          }
        });
      }
      return false;
  });
});

// Show reservation details
function reservation_details(obj) {
  jQuery.each(obj, function(key,value) {
    if (value.status) {
      var currency = value.currency_symbol;
      jQuery("#delete-reservation").attr("data-id", value.order_no);
      jQuery("#property_title").html(value.space_property_title);
      jQuery("#from_date").html(value.from_date);
      jQuery("#from_time").html(value.from_time);
      jQuery("#to_time").html(value.to_time);
      jQuery("#no_of_people").html(value.number_of_people);
      jQuery("#space_layout").html(value.space_layout);
      jQuery("#space_layout_image").attr('src', value.space_layout_image);
      if (value.space_prices && value.space_prices.length > 0) {
        jQuery("#space_prices").html('');
        jQuery.each(value.space_prices, function(key1,value1) {
          var space = Drupal.t('Space price ');
          var hours = Drupal.t(' hours');
          var spaces = '<div class="row"><div class="col-xs-9"><span>'+ space + value1.price + ' X ' + value1.hours + hours +'</span></div>';
          spaces += '<div class="col-xs-3"><span>'+ value1.time_slot_price + currency +'</span></div></div>';
          jQuery("#space_prices").append(spaces);
        });
      }
      if (value.extra_services && value.extra_services.length > 0) {
        jQuery("#extra_services").html('');
        jQuery.each(value.extra_services, function(key2,value2) {
          var service_id = 'extra_services' + '_' + value2.service_id;
          var service_html = "<div id="+service_id+">";
          service_html+= "<div class='row services'>";
          service_html+= "<div class='col-xs-9'>"+ value2.service_name+" <span class='service_price'>"+value2.service_price+"</span> X <span class='service_quantity'>"+ value2.service_quantity+"</span> unit</div>";
          service_html+= "<div class='col-xs-3'><span class='service_total_price'>"+value2.service_total_price+"</span><span class='currency'></span></div>";
          service_html+= "</div>";
          jQuery("#extra_services").append(service_html);
        });
      }
      else {
        jQuery("#extra_services").html('');
      }
      jQuery(".currency").html(value.currency_symbol);
      jQuery("#space_price").html(value.price);
      if (value.vat == null){
        jQuery("#lbl_vat").html(0);
      }
      else {
        jQuery("#lbl_vat").html(value.vat);
      }
      if (value.vat_price == null){
        jQuery("#vat_price").html(0);
      }
      else {
        jQuery("#vat_price").html(value.vat_price);
      }
      jQuery("#total_price").html(value.total_price);
      jQuery("#guest_order_no").html(value.order_no);
      jQuery("#guest_name").html(value.name);
      jQuery("#guest_mail").html(value.email);
      jQuery("#guest_phone").html(value.user_phone);
      jQuery("#company_name").html(value.company_name);
    }
  });
}

// Update pricing.
function edit_pricing(event_href){
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var date_param  = getUrlParameter(event_href, 'end');
  var date = new Date(date_param);
  var day  = date.getDate();
  var month = monthNames[date.getMonth()];
  var price_date = day + ' ' + month;
  var price_param  = getUrlParameter(event_href, 'price');
  var from_param  = getUrlParameter(event_href, 'from_time');
  var to_param  = getUrlParameter(event_href, 'to_time');
  if (event_href) {
    var edit_anchor = '<a class="use-ajax edit-pricing" data-dialog-type="modal" href="'+event_href+'" data-dialog-title="modal">Edit</a>'
    jQuery("#edit-pricing").html(edit_anchor);
  }
  jQuery('#date-from').html(price_date);
  jQuery('#date-to').html(price_date);
  jQuery('#price').html(price_param);
  jQuery('#time-from').html(from_param);
  jQuery('#time-to').html(to_param);
  jQuery('#hourly-price').html(price_param);
  Drupal.attachBehaviors();
  jQuery('#bs_calendar_edit_change_pricing').ajaxForm();
}

// Get url parameter by name
function getUrlParameter(event_href, sParam) {
  var sPageURL = event_href,
      sURLVariables = sPageURL.split('&'),
      sParameterName,
      i;
  for (i = 0; i < sURLVariables.length; i++) {
      sParameterName = sURLVariables[i].split('=');

      if (sParameterName[0] === sParam) {
          return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
      }
  }
}

// Update entry link add additional arguments.
function format_event_datetime(event_start, event_end) {
  var event_time = {};
  var start_str = event_start;
  var end_str = event_end;
  var date = new Date(start_str);
  var start_time = new Date(start_str);
  var end_time = new Date(end_str);

  var month = date.getMonth()+1;
  var day = date.getDate();
  var full_date = date.getFullYear() + '-' +
    ((''+month).length<2 ? '0' : '') + month + '-' +
    ((''+day).length<2 ? '0' : '') + day;

  var start_hour = ((''+start_time.getHours()).length<2 ? '0' :'') + start_time.getHours();
  var start_minute = ((''+start_time.getMinutes()).length<2 ? '0' :'') + start_time.getMinutes();
  var start_time_index = start_hour + ":" + start_minute;

  var end_hour = ((''+end_time.getHours()).length<2 ? '0' :'') + end_time.getHours();
  var end_minute = ((''+end_time.getMinutes()).length<2 ? '0' :'') + end_time.getMinutes();
  var end_time_index = end_hour + ":" + end_minute;

  var d = new Date();
  var month = d.getMonth()+1;
  var day = d.getDate();
  var current_date = d.getFullYear() + '-' +
      ((''+month).length<2 ? '0' : '') + month + '-' +
      ((''+day).length<2 ? '0' : '') + day;

  event_time = {
    current_date: current_date,
    date: full_date,
    start_time: start_time_index,
    end_time: end_time_index
  };
  return event_time;
}

// Update entry link add additional arguments.
function update_entry_link(arg) {
  var start_str = arg.startStr;
  var end_str = arg.endStr;
  var event = format_event_datetime(start_str, end_str);
  var edit_anchor = '';
  if (event.current_date <= event.date) {
    jQuery.each(jQuery('#createEntryLinks a.use-ajax'), function(i, item){
      if (item.href != "undefined" && item.href != null) {
        var old_href = item.href;
        var new_href = old_href + "?date="+event.date+"&start_time="+event.start_time+"&end_time="+event.end_time+"&";
        edit_anchor += '<a class="use-ajax" data-dialog-type="modal" href="'+new_href+'" data-dialog-title="modal">'+item.text+'</a><br/>'
      }
    });
    jQuery("#drupal-modal--body").html(edit_anchor);
    Drupal.attachBehaviors();
  }
  else {
    jQuery('#createEntryModal').dialog('close');
    alert("Please select future date & time!");
  }
}

// Update reservation details
function update_reservation(event) {
  var event_class = event.el.classList[4];
  if (event_class == "res-confirmed") {
    var query_data = {};
    var res_nid  = event.event.extendedProps.reservation_nid;
    var event_data = format_event_datetime(event.event.start, event.event.end);
    var no_of_people  = event.event.extendedProps.people_tid;
    if (event_data.current_date <= event_data.date) {
      if (res_nid != null && !jQuery.isEmptyObject(event_data)) {
        var params = {
            res_nid: event.event.extendedProps.reservation_nid,
            date: event_data.date,
            start_time: event_data.start_time,
            end_time: event_data.end_time,
            people_tid: event.event.extendedProps.people_tid
        };
        var endpoint = '/bs-space/'+vars.space+'/'+vars.uid+'/update-reservation?'+jQuery.param(params);
        Drupal.ajax({
          url: endpoint
        }).execute();
      }
    }
    else {
      event.revert();
    }
  }
  else if (event_class == "res-time-blocked") {
    var para_id  = event.event.extendedProps.paraId;
    var para_num_id  = event.event.extendedProps.paraNumId;
    var event_data = format_event_datetime(event.event.start, event.event.end);
    if (event_data.current_date <= event_data.date) {
      if (para_id != null && para_num_id != null && !jQuery.isEmptyObject(event_data)) {
        var params = {
            date: event_data.date,
            start_time: event_data.start_time,
            end_time: event_data.end_time,
            title: event.event.title,
            paraId: para_id,
            paraNumId: para_num_id
        };
        var endpoint = '/bs-space/'+vars.space+'/'+vars.uid+'/update-block-time?'+jQuery.param(params);
        Drupal.ajax({
          url: endpoint
        }).execute();
      }
    }
    else {
      event.revert();
    }
  }
}

(function($) {
  Drupal.behaviors.bs_calendar_entry = {
    attach: function(context, settings) {
      setTimeout(function(){ jQuery('.cal-view-reservation').once("view-reservation").trigger('click'); }, 10);
      // Guest contact details default open
      $(".guest_head").once('guest-detail-open').trigger('click');
      // toggle Guest contact details
      $(".guest_head").once('guest-detail').click(function() {
        if ($('.guest_body').is(':visible')) {
          $(".guest_body").slideUp(300);
          $(".plusminus").text('+');
        }
        if ($(this).next(".guest_body").is(':visible')) {
          $(this).next(".guest_body").slideUp(300);
          $(this).children(".plusminus").text('+');
        } else {
          $(this).next(".guest_body").slideDown(300);
          $(this).children(".plusminus").text('-');
        }
      });
      // Close space detail modal
      $("#edit-reservation > a.edit-reservation").click(function(ed){
        $('#dialog').dialog('close');
        ed.preventDefault();
      });
      // Close add entry modal
      $('#createEntryModal', context).each(function(){
        $(this).find('a').click(function(){
          $('#createEntryModal').dialog('close');
        })
      });
      // Close change pricing modal
      $("#editPricingModal #edit-pricing > a").click(function(ep){
        $('#editPricingModal').dialog('close');
        ep.preventDefault();
      });
      // Block time submit redirect to current page
      $.fn.blockTimeRedirect = function(redirect) {
        if (redirect) {
          location.reload();
        }
        else {
          return false;
        }
      }
      // Change pricing submit redirect to current page
      $.fn.changePricingRedirect = function(redirect) {
        if (redirect) {
          location.reload();
        }
        else {
          return false;
        }
      }
    }
  };
})(jQuery);