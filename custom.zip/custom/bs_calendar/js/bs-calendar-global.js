//alert(hi);
(function($) {

    Drupal.behaviors.bs_calendar_dev = {
        attach: function(context, settings) {

            $('input[name^="weekdays_day_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("weekdays_day_");
                if($(this).prop("checked") == true){
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').removeAttr("disabled");
                }
                else if($(this).prop("checked") == false){
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').attr("disabled",true);
                    //$('select[name^="weekdays_start_time_'+getTermId[1]+'"]').val("");
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').attr("disabled",true);
                    //$('select[name^="weekdays_end_time_'+getTermId[1]+'"]').val("");
                }
            });
        }
    };
})(jQuery);

