
//alert(hi);
(function($) {


function hellotest(){
alert("Hey");
}


    Drupal.behaviors.bs_calendar_dev = {
        attach: function(context, settings) {
        $("#cal-item-clicked").once("html6").click(function(event){
          alert("Fired");
          event.stopPropagation();
        });

        $(".fc-highlight").once("html6").change(function(event){
          alert("Fired WOW");
          event.stopPropagation();
        });

        }
    };
})(jQuery);