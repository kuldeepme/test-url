<?php
namespace Drupal\bookaspace_contact_us_form_handler\Plugin\WebformHandler;

use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\Plugin\WebformHandlerBase;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Webform submission handler.
 *
 * @WebformHandler(
 *   id = "bookaspace_contact_us_form_handler",
 *   label = @Translation("Bookaspace contact us form handler"),
 *   category = @Translation("Action"),
 *   description = @Translation("contact us form handler"),
 *   cardinality = Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_SINGLE,
 *   results = Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_OPTIONAL,
 * )
 */
class ContactUsFormHandler extends WebformHandlerBase {

    /**
     * {@inheritdoc}
     * Is sent BEFORE form is saved so details are NOT stored
     */
    /*
    public function submitForm(array &$form, FormStateInterface $form_state, WebformSubmissionInterface $webform_submission) {
        header("Location: http://example.com/afterSubmitForm.php");
        die();
    }
    */


    /**
     * {@inheritdoc}
     * Is sent AFTER post is saved so details are saved in the form
     */
    public function postSave(WebformSubmissionInterface $webform_submission, $update = TRUE) {
        $full_name = $webform_submission->getElementData('full_name');
        $phone_number = $webform_submission->getElementData('phone_number');
        $note = $webform_submission->getElementData('note');
        $email_address = $webform_submission->getElementData('email_address');
        $i_need_help_with = $webform_submission->getElementData('i_need_help_with');
        $str_location = "/thankYouAfterPostSave.php&full_name=$full_name&phone_number=$phone_number&note=$note&email_address=$email_address&i_need_help_with=$i_need_help_with";
        header("Location:" . $str_location);
        die();
    }
}