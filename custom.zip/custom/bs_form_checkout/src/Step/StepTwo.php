<?php

namespace Drupal\bs_form_checkout\Step;

use Drupal\bs_form_checkout\Button\StepTwoNextButton;
use Drupal\bs_form_checkout\Button\StepTwoPreviousButton;
use Drupal\bs_form_checkout\Validator\ValidatorRequired;
use Drupal\bs_form_checkout\Validator\ValidatorRegex;
use Drupal\taxonomy\Entity\Term;
use Drupal\node\Entity\Node;


/**
 * Class StepTwo.
 *
 * @package Drupal\bs_form_checkout\Step
 */
class StepTwo extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_TWO;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepTwoPreviousButton(),
      new StepTwoNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {

      //print '<pre>';print_r($this->getValues());print '<pre/>'; die;
      //print '<pre>';print_r('ofek');print '<pre/>'; die;
      $language_id =  \Drupal::languageManager()->getCurrentLanguage()->getId();

      $form['card_owner_name'] = [
          '#type' => 'textfield',
          '#title' => t("Card owner name"),
          '#required' => TRUE,
          '#attributes' => [
              'placeholder' => array('John Doe'),
          ],
          '#default_value' => isset($this->getValues()['card_owner_name']) ? $this->getValues()['card_owner_name'] : NULL,
      ];

      $form['card_number'] = [
          '#type' => 'textfield',
          '#title' => t("Credit card number"),
          '#required' => TRUE,
          '#attributes' => [
              'placeholder' => array('0000 0000 0000 0000'),
          ],
          '#default_value' => isset($this->getValues()['card_number']) ? $this->getValues()['card_number'] : NULL,
      ];

      /*Months*/
      $arr_months = array();
      for ($i = 1; $i <= 12; $i++) {
          array_push($arr_months, $i);
      }
      $form['expiration_month'] = [
          '#type' => 'select',
          '#title' => t('Expiration date'),
          '#options' => $arr_months,
          '#default_value' => isset($this->getValues()['expiration_month']) ? $this->getValues()['expiration_month'] : [],
          '#required' => TRUE,
      ];
      /*End months*/

      /*Year*/
      $arr_years = array();
      for ($i = date("Y"); $i <= date("Y") + 30; $i++) {
          array_push($arr_years, $i);
      }
      $form['expiration_year'] = [
          '#type' => 'select',
          //'#title' => t('Expiration year'),
          '#options' => $arr_years,
          '#default_value' => isset($this->getValues()['expiration_year']) ? $this->getValues()['expiration_year'] : [],
          '#required' => TRUE,
      ];
      /*End year*/


      $form['remember'] = [
          '#type' => 'checkbox',
          '#title' => t('Remember my credit card number'),
          '#default_value' => isset($this->getValues()['remember']) ? $this->getValues()['remember'] : [],
          '#required' => FALSE,
      ];

      $form['coupon_code'] = [
          '#type' => 'textfield',
          '#title' => t("Coupon code"),
          '#required' => FALSE,
          '#attributes' => [
              'placeholder' => array('0000 0000'),
          ],
          '#default_value' => isset($this->getValues()['coupon_code']) ? $this->getValues()['coupon_code'] : NULL,
      ];


      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 2,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];
      $form['#theme'] = 'bs_form_checkout_step2';

      //print '<pre>';print_r('ofek 2');print '<pre/>'; die;

      return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {

      $arr_to_return = array('space_title',
          'space_description',
          'space_size',
          'space_size_units',
          'space_activity',
          'space_layout',
          'space_type');

      return $arr_to_return;

  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
        /*
        'space_title' => [
            new ValidatorRequired("Please insert your space title"),
        ],
        'space_size' => [
            new ValidatorRegex(t("Please use digits only in the space size field"), '^[0-9]\d*$^'),
        ],
        */
    ];
  }

}
