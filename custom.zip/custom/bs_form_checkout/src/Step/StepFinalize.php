<?php

namespace Drupal\bs_form_checkout\Step;

/**
 * Class StepFinalize.
 *
 * @package Drupal\bs_form_checkout\Step
 */
class StepFinalize extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_FINALIZE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {

    $form['completed'] = [
      '#markup' => t('You have completed the wizard, yeah'),
    ];

      $form['#theme'] = 'bs_form_checkout_step_finalize';

      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 3,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];

      //UPDATE TABLE bs_checkout
      if(isset($_REQUEST['checkout_id'])){
          //Connection to DB
          $connection = \Drupal::database();
          $connection->update('bs_checkout')
              ->fields([
                  'status' => 1
              ])
              ->condition('id', $_REQUEST['checkout_id'], '=')
              ->execute();
      }



    return $form;
  }

}
