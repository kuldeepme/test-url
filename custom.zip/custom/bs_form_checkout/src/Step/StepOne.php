<?php

namespace Drupal\bs_form_checkout\Step;

use Drupal\bs_form_checkout\Button\StepOneNextButton;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class StepOne.
 *
 * @package Drupal\bs_form_checkout\Step
 */
class StepOne extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_ONE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepOneNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {

      //Get checkout id
      $checkout_id = $_REQUEST['checkout_id'];

      //Get data from DB from 'bs_checkout' table
      $connection = \Drupal::database();
      $query = $connection->select('bs_checkout', 'c');
      $query->condition('c.id', $checkout_id, '=');
      $query->fields('c');

      //Get results
      $results = $query->execute();

      //Get all records
      $records = $results->fetchAll();

      //Get space id
      $space_id = $records[0]->space_id;
      //Load space node
      $ct_space = \Drupal\node\Entity\Node::load($space_id);


      $config = \Drupal::config('bs_admin_configuration.settings');
      //$form['#attached']['library'][] = 'bs_form_checkout/internation-telephone';


      $form['personal_detail_markup'] = [
          '#markup' => $config->get('description')['value'],
      ];

      //USER DETAILS (IF NOT LOGGED IN)
      $user = \Drupal::currentUser();
      $form["user"] = true;
      if (isset($_REQUEST['user_type']) && $_REQUEST['user_type'] == 'host') {
        $arr_currencies = get_taxonomy_term_values('currencies', TRUE);
        $form['hourly_price'] = [
          '#type' => 'textfield',
          '#title' => t('Hourly price (VAT not included)'),
          '#attributes' => [
            'placeholder' => t('0'),
          ]
        ];
        $form['hourly_currency'] = [
          '#type' => 'select',
          '#options' => $arr_currencies,
        ];
      }
      if(!$user->id()){
          //If we DO NOT have a user, display these fields
          $form["user"] = false;
          $form['email'] = [
              '#type' => 'email',
              //'#title' => t("Email"),
              '#required' => FALSE,
              '#default_value' => isset($this->getValues()['email']) ? $this->getValues()['email'] : NULL,
              '#attributes' => [
                  'placeholder' => array('john@example.com'),
              ],
              '#description' => t('Your email address'),
          ];

          $form['confirm_password'] = [
              '#type' => 'password_confirm',
              //'#title' => t(""),
              '#required' => FALSE,
          ];
          $form['first_name'] = [
              '#type' => 'textfield',
              //'#title' => t("First name"),
              '#required' => FALSE,
              '#attributes' => [
                  'placeholder' => array('John'),
              ],
              '#default_value' => isset($this->getValues()['first_name']) ? $this->getValues()['first_name'] : NULL,
          ];
          $form['last_name'] = [
              '#type' => 'textfield',
              //'#title' => t("Last name"),
              '#required' => FALSE,
              '#attributes' => [
                  'placeholder' => array('Doe'),
              ],
              '#default_value' => isset($this->getValues()['last_name']) ? $this->getValues()['last_name'] : NULL,
          ];

          $form['phone'] = [
              '#type' => 'tel',
              //'#title' => t("Phone number"),
              '#default_value' => isset($this->getValues()['phone']) ? $this->getValues()['phone'] : "+1 ",
          ];

          $form['company_name'] = [
              '#type' => 'textfield',
              //'#title' => t("Company name"),
              '#required' => FALSE,
              '#attributes' => [
                  'placeholder' => array('John Company'),
              ],
              '#default_value' => isset($this->getValues()['company_name']) ? $this->getValues()['company_name'] : NULL,
          ];
      }



      //NEW SPACE LAYOUTS
      $space_layouts = array();
      //Get all the layout of the space
      if($ct_space!=NULL && $ct_space->hasField("field_space_layouts")){
          $arr_field_space_layouts = $ct_space->get('field_space_layouts')->getValue();

          //Run on the data of the space layouts
          foreach ($arr_field_space_layouts as &$value) {
              //paragraph_id
              $paragraph_id = $value['target_id'];
              //Load space layout paragraph
              $paragraph = \Drupal\paragraphs\Entity\Paragraph::load($paragraph_id);
              //Get max_participants
              $max_participants = $paragraph->field_space_layout_max_participa->getValue()[0]['value'];
              //Get the id of the term
              $space_layouts_id = $paragraph->field_space_layout_name->getValue()[0]['target_id'];
              //Load the term
              $term_load = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($space_layouts_id);
              $space_layout_name = $term_load->getName();
              //Load the space layout image
              $fid = $term_load->field_space_layout_image->getValue()[0]['target_id'];
              $file = \Drupal\file\Entity\File::load($fid);
              if (!empty($file)) {
                  $file_uri = $file->getFileUri();
                  $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                  $real_path = $style->buildUrl($file_uri);
                  $space_layout_image = $real_path;
              }
              else {
                  $space_layout_image = "";
              }

              //$space_layouts[$paragraph_id]["space_layout_name"] = $space_layout_name;
              //$space_layouts[$paragraph_id]["max_participants"] = $max_participants;
              //$space_layouts[$paragraph_id]["space_layout_image"] = $space_layout_image;
              $space_layouts[$paragraph_id] = "<img src='$space_layout_image' /> <span>$space_layout_name</span>  | Up to $max_participants";

          }

      }

      //Create the checkbox
      $form["space_layout_wrapper"] = [
          '#type' => 'radios',
          //'#title' => t('Space layouts'), //Image and term name
          '#options' => $space_layouts,
          '#default_value' => isset($this->getValues()['space_layout_wrapper']) ? $this->getValues()['space_layout_wrapper'] : NULL,
          '#required' => TRUE,
          //'#prefix' =>'<div class="space_layout_item">', //PREFIX
      ];


      //Get currency details of the country where the property is
      $arr_country_details = get_country_details_by_space_id($space_id);
      $currency_symbol = $arr_country_details['currency_symbol'];
      $currency_tid = $arr_country_details['currency_tid'];
      $conversion_rate = 0;

      //Get user preferred currency
      $user_preferred_currency_id = get_user_preferred_currency_id();
      //If we have the user's preferred currency
      if($user_preferred_currency_id > 0){
          //If the user preferred currency is different than the currency of the country of the property
          if($currency_tid != 0 && $currency_tid != $user_preferred_currency_id){
              //Get the conversion rate, converted price, currency symbol and all
              $arr_converted_price = get_currency_conversion_rate($arr_country_details['currency_tid'], $user_preferred_currency_id);
              if(!is_null($arr_converted_price)){
                  $currency_symbol = $arr_converted_price['currency_symbol'];
                  $conversion_rate = $arr_converted_price['conversion_rate'];
                  $currency_code = $arr_converted_price['currency_code'];
              }
          }
      }



      //SERVICE PAID _ NEW CODE
      $arr_space_services_paid = array();
      //Get all paid services
      if($ct_space!=NULL && $ct_space->hasField("field_space_services_paid")){
          $arr_field_space_services = $ct_space->get('field_space_services_paid')->getValue();

          //Run on all paid services
          //$currency_id = 0;
          foreach ($arr_field_space_services as &$value) {
              //paragraph_id
              $paragraph_id = $value['target_id'];
              $p = \Drupal\paragraphs\Entity\Paragraph::load($paragraph_id);

              $description = "";
              if(isset($p->field_service_description->getValue()[0]['value'])){
                  $description = $p->field_service_description->getValue()[0]['value'];
              }
              $price = $p->field_service_price->getValue()[0]['value'];
              //$currency_id = $p->field_service_price_currency->getValue()[0]['target_id'];
              $price_type = $p->field_service_price_type->getValue()[0]['value'];
              //Get the id of the term
              $service_term_id = $p->field_space_services->getValue()[0]['target_id'];
              //Load the term
              $term_load = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($service_term_id);
              //Get the name
              $service_name = $term_load->getName();
              //Service type (stationary, electronic etc)
              $str_service_type = $term_load->field_service_type->getValue()[0]["value"];
              //Load the service image
              $fid = $term_load->field_service_icon->getValue()[0]['target_id'];
              $file = \Drupal\file\Entity\File::load($fid);
              if (!empty($file)) {
                  $file_uri = $file->getFileUri();
                  $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                  $real_path = $style->buildUrl($file_uri);
                  $service_icon = $real_path;
              }
              else {
                  $service_icon = "";
              }

              //If the user looks at it with a different currency, set the price accordingly
              if($conversion_rate > 0){
                  $price = $price * $conversion_rate;
              }


              //Create an array for this service
              $arr_space_services_paid_temp = array();
              $arr_space_services_paid_temp[$paragraph_id]["service_name"] = $service_name;
              $arr_space_services_paid_temp[$paragraph_id]["description"] = $description;
              $arr_space_services_paid_temp[$paragraph_id]["price"] = $price;
              //$arr_space_services_paid_temp[$paragraph_id]["currency_id"] = $currency_id;
              $arr_space_services_paid_temp[$paragraph_id]["currency_name"] = $currency_symbol;
              $arr_space_services_paid_temp[$paragraph_id]["price_type"] = $price_type;
              $arr_space_services_paid_temp[$paragraph_id]["service_icon"] = $service_icon;

              //Add into $arr_space_services_paid
              $arr_space_services_paid[$str_service_type][$paragraph_id] = $arr_space_services_paid_temp;
          }
      }





      //kint($arr_space_services_paid);die;



      foreach($arr_space_services_paid as $key1 => $values1) {

          //Create a HTML "fieldset" with id as machine name  ---    'service_paid_wrapper'][str_replace(" ","_",$key1)
          $form['service_paid_wrapper'][str_replace(" ","_",$key1)] = array(
              '#type' => 'fieldset',
              '#title' => t(str_replace("_"," ",$key1)),
              '#collapsible' => TRUE,
              '#collapsed' => TRUE,
          );

          //kint($values1);
          //print_r($values1);
          //echo "<br/>";


          //Create all the "fields" inside the "fieldset" with the same machine name and some more...  ----  "service_paid_wrapper"][str_replace(" ","_",$key1)]
          foreach ($values1 as $key => $arr_values) {


              $values = $arr_values[$key];

              //Create the image
              $str_icon_url = $values['service_icon'];
              $str_icon_html = "<img src='$str_icon_url' />";

              //Image
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_image_' . $key] = [
                  '#type' => 'markup',
                  '#markup' => $str_icon_html,
                  '#default_value' => isset($this->getValues()['service_paid_image_' . $key]) ? $this->getValues()['service_paid_image_' . $key] : NULL,
                  '#prefix' => '<div class="service_paid_item row table-row"><div class="image">', //PREFIX
                  '#suffix' => "</div>",
              ];

              //Name
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_name_' . $key] = [
                  '#type' => 'markup',
                  '#markup' => $values['service_name'],
                  '#prefix' => "<div class='name_desc'><p class='name'>",
                  '#suffix' => "</p>",
                  '#default_value' => isset($this->getValues()['service_paid_name_' . $key]) ? $this->getValues()['service_paid_name_' . $key] : NULL,
              ];
              //Description
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_description_' . $key] = [
                  '#type' => 'markup',
                  '#markup' => $values['description'],
                  '#suffix' => "</div>",
                  '#default_value' => isset($this->getValues()['service_paid_description_' . $key]) ? $this->getValues()['service_paid_description_' . $key] : NULL,
              ];
              //Price
              //Currency
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_currency_' . $key] = [
                  '#type' => 'markup',
                  '#markup' => $values['currency_name'],
                  '#prefix' => "<div class='currency_price'><span class='currency'>",
                  '#suffix' => '</span>',
                  '#default_value' => isset($this->getValues()['service_paid_currency_' . $key]) ? $this->getValues()['service_paid_currency_' . $key] : NULL,
              ];
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_price_' . $key] = [
                  '#type' => 'markup',
                  '#markup' => $values['price'],
                  '#prefix' => "<span class='price'>",
                  '#suffix' => "</span></div>",
                  '#default_value' => isset($this->getValues()['service_paid_price_' . $key]) ? $this->getValues()['service_paid_price_' . $key] : NULL,
              ];


              //Create the requested items field
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_requested_items_' . $key] = [
                  '#type' => 'number',
                  '#attributes' => [
                      'min' => 0,
                  ],
                  '#default_value' => isset($this->getValues()['service_paid_requested_items_' . $key]) ? $this->getValues()['service_paid_requested_items_' . $key] : 0,
                  '#suffix' => '</div>', //SUFFIX
              ];
          }
      }

      //END SERVICE PAID _ NEW CODE





      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 1,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];
      $form['#theme'] = 'bs_form_checkout_step1';
     // $form['#attached']['library'][] = 'bs_form_checkout/bookaspace-address';
     // $form['#attached']['library'][] = 'bs_form_checkout/bookaspace-global';
    return $form;
  }
    /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
        'user',
        'email',
        'confirm_password',
        'first_name',
        'last_name',
        'phone',
        'property_type',
        'property_name',
        'property_description',
        'property_logo',
        'country_code',
        'states',
        'city',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
        /*'username' => [
            new ValidatorRequired("Please choose a username"),
        ],
        'first_name' => [
            new ValidatorRequired("Please insert your first name"),
        ],
        'phone' => [
            new ValidatorRequired("Please insert your phone"),
        ],*/
    ];
  }
}
