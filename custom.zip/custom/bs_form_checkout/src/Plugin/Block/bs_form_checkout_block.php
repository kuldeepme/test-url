<?php

namespace Drupal\bs_form_checkout\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_checkout form.
 *
 * @Block(
 *   id = "bs_form_checkout_block",
 *   admin_label = @Translation("bs_form_checkout_block"),
 *   category = @Translation("bs_form_checkout"),
 * )
 */
class bs_form_checkout_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_checkout\Form\BsFormCheckout');
        return $form;
    }

}
