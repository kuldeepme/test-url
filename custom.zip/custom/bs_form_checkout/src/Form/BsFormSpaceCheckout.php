<?php

namespace Drupal\bs_form_checkout\Form;

/**
 * @file
 * Contains \Drupal\bs_form_checkout\Form\BsFormSpaceCheckout.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\user\Entity\User;

/**
 * {@inheritdoc}
 */
class BsFormSpaceCheckout extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'bs_form_space_checkout';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, $params = NULL) {

        //Get query string params to display to user if he got here with these
        $date = '';
        if(isset($_REQUEST['date'])){
            $date = $_REQUEST['date'];
        }

        $start_time_index = 0;
        if(isset($_REQUEST['start_time'])){
            $start_time_index = $_REQUEST['start_time'];
        }

        $end_time_index = 0;
        if(isset($_REQUEST['end_time'])){
            $end_time_index = $_REQUEST['end_time'];
        }

        $booking_people = 0;
        if(isset($_REQUEST['booking_people'])){
            $booking_people = $_REQUEST['booking_people'];
        }

        $param_space_id = 0;
        if(isset($_REQUEST['space_id'])){
            $param_space_id = $_REQUEST['space_id'];
        }

        $form['error_message'] = [
            '#type' => 'markup',
            '#markup' => '<div id="result_error_message"></div>'
        ];

        $node = $params['node_object'];

        $space_id = 0;

        //If it's a properties page, get all the spaces and display in the form
        $is_properties_page = false;
        if($node->getType() == "ct_properties") {
            $is_properties_page = true;
            $arr_spaces = array();
            //Number of spaces of this property
            $number_of_spaces = $node->field_property_spaces->count();
            //Run on spaces of this property
            for($i = 0; $i < $number_of_spaces; $i++){
                //Get space item
                $space_item = $node->field_property_spaces->get($i);
                //Get space id
                $temp_space_id = $space_item->getValue()['target_id'];
                //Set the space id of the first space
                if($i == 0){
                    $space_id = $temp_space_id;
                }
                //Get space node
                $node_space = Node::load($temp_space_id);
                if(isset($node_space)){
                    //Get space title
                    $node_space_title = $node_space->getTitle();
                }
                //Add space id and title to list
                $arr_spaces[$temp_space_id] = $node_space_title;
            }

            $form['container']['spaces'] = [
                '#type' => 'select',
                '#options' => $arr_spaces,
                '#title' => t("Space"),
                '#default_value' => $param_space_id,
                '#ajax' => [
                    'callback' => '::instrumentDropdownCallback',
                    'wrapper' => 'instrument-fieldset-container',
                ],
            ];
        } else {
            $space_id = $node->id();
        }

        $form['container']['is_properties_page'] = [
            "#type"=> "hidden",
            "#value" => $is_properties_page,
        ];

        $form['container']['hidden_space'] = [
            "#type"=> "hidden",
            "#value" => $space_id,
        ];

        $form['container']['date'] = [
            '#type' => 'datetime',
            '#size' => 20,
            '#date_date_element' => 'date',
            '#date_time_element' => 'none',
            '#date_time_format' => 'h:i',
            '#title' => t("Date"),
            '#default_value' => DrupalDateTime::createFromTimestamp(time() + (60 * 60 * 24)),
            '#attributes' => ['min' =>  \Drupal::service('date.formatter')->format(\Drupal::time()->getRequestTime(), 'custom', 'Y-m-d'),],
            '#ajax' => [
                'callback' => '::instrumentDropdownCallback',
                'wrapper' => 'instrument-fieldset-container',
            ],
        ];

        $arr_times = select_list_times();
        $form['container']['from_time'] = [
            '#type' => 'select',
            '#options' => array_merge(['- Select -' => '- Select -'],$arr_times),
            '#title' => t("Meeting time"),
            '#ajax' => [
              'callback' => '::instrumentDropdownCallback',
              'wrapper' => 'instrument-fieldset-container',
            ],
            '#default_value' => 20,
        ];
        $form['container']['to_time'] = [
            '#type' => 'select',
            '#options' => array_merge(['- Select -' => '- Select -'],$arr_times),
            '#ajax' => [
                'callback' => '::instrumentDropdownCallback',
                'wrapper' => 'instrument-fieldset-container',
            ],
            '#default_value' => 24,
        ];

        //$arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', FALSE);
        $arr_number_of_people = get_space_number_of_people_options($space_id);
        $form['container']['booking_people'] = [
            '#type' => 'select',
            '#options' => $arr_number_of_people,
            '#title' => t("Number of people"),
            '#default_value' => $booking_people
        ];

        //DISPLAY PRICES
        $form['container']['price_calculations'] = [
            '#type' => 'markup',
            '#markup' => '<div class="price_calculations"></div>'
        ];

        //SUBMIT
        $form['container']['action']['submit'] = [
            '#type' => 'submit',
            '#prefix' => '<div id="instrument-fieldset-container">',
            '#suffix' => "</div>",
            '#value' => t('Check availability'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg btn-check_availability']
            ],
            '#ajax' => array(
                'callback' => '::spaceCheckoutSubmit',
                'effect' => 'fade',
                'wrapper' => 'instrument-fieldset-container',
                'progress' => array(
                    'type' => 'throbber',
                    'message' => t("Please wait ......"),
                ),
            ),
        ];

        //RESERVE SUBMIT
        $form['container']['action']['reserve_submit'] = [
            '#type' => 'submit',
            '#submit' => ['::spaceCheckoutReserveSubmit'],
            '#value' => t("Reserve"),
            '#attributes' => [
                'class' => ['hidden btn-primary btn-lg btn-reserve']
            ],
        ];

        //DISPLAY CANCELLATION POLICY
        //kint($space_id); die;
        if($space_id > 0){
            $ct_space = \Drupal\node\Entity\Node::load($space_id);
            if(isset($ct_space)){
                if($ct_space->hasField('field_cancellation_policy')){
                    $tid = $ct_space->field_cancellation_policy->getValue()[0]['target_id'];
                    if(isset($tid)){
                        //Get cancellation policy text
                        $str_cancellation_policy_text = get_cancellation_policy_text($tid);

                        if($str_cancellation_policy_text != ""){
                            $str_cancellation_policy = t('Cancellation policy');
                            $str_html = '<a href="#" class="link_to_cancellation_policy" data-toggle="modal" data-target="#cancellation_policy_modal">'.$str_cancellation_policy.'</a>';
                            $form['container']['cancellation_policy_link'] = [
                                '#type' => 'markup',
                                '#markup' => $str_html
                            ];

                            $form['container']['cancellation_policy_text'] = [
                                '#type' => 'hidden',
                                '#value' => $str_cancellation_policy_text
                            ];
                        }
                    }
                }
            }
        }



        return $form;
    }

    /*
     * This function is called when date or time is changed
     */
    function instrumentDropdownCallback(array &$form, FormStateInterface $form_state){

        $ajax_response = new AjaxResponse();

        $ajax_response->addCommand(new HtmlCommand('#result_error_message', ""));
        $ajax_response->addCommand(new HtmlCommand('.price_calculations', ""));
        //Hide "Reserve" button and display "Check availability" button
        $ajax_response->addCommand(new InvokeCommand('.btn-check_availability', 'removeClass', array('hidden')));
        $ajax_response->addCommand(new InvokeCommand('.btn-reserve', 'addClass', array('hidden')));

        return $ajax_response;
    }

    /*
     * Submit the form
     */
    function spaceCheckoutSubmit(array &$form, FormStateInterface $form_state){

        $values = $form_state->getValues();

        $errors = "<ul class='bs-checkout-erros'>";
        $is_error = FALSE;
        if($values['from_time'] == "- Select -"){
            $errors.="<li>".t("From time is required.")."</li>";
            $is_error = TRUE;
        }

        if($values['to_time'] == "- Select -"){
          $errors.="<li>".t("To time is required.")."</li>";
          $is_error = TRUE;
        }

        if($values['date'] == ""){
          $errors.="<li>".t("Date is required.")."</li>";
          $is_error = TRUE;
        }

        if($values['from_time'] >= $values['to_time']){
            $errors.="<li>".t("End time must be bigger than start time")."</li>";
            $is_error = TRUE;
        }

        $errors.= "</ul>";

        if($is_error){

            //SHOW ERRORS
            $ajax_response = new AjaxResponse();
            $ajax_response->addCommand(new HtmlCommand('#result_error_message', $errors));
            //$ajax_response->addCommand(new HtmlCommand('.btn-primary', "Check availability"));
            $ajax_response->addCommand(new HtmlCommand('.price_calculations', ""));

            //Hide "Reserve" button and display "Check availability" button
            $ajax_response->addCommand(new InvokeCommand('.btn-check_availability', 'removeClass', array('hidden')));
            $ajax_response->addCommand(new InvokeCommand('.btn-reserve', 'addClass', array('hidden')));
            return $ajax_response;

        } else {

            //NO ERRORS! Get form data

            $str_date = $values['date']->format('Y-m-d');
            $start_time_index = $values['from_time'];
            $end_time_index = $values['to_time'];
            if(isset($values['spaces'])){
                $param_space_id = $values['spaces'];
            } else {
                $param_space_id = $values['hidden_space'];
            }

            //CHECK IS SPACE IS AVAILABLE
            $space_is_available = check_if_space_is_available($str_date, $start_time_index, $end_time_index, $param_space_id);

            if($space_is_available == false){

                //Space is not available
                $errors = "<ul class='bs-checkout-erros'><li>".t("Space is not available")."</li></ul>";
                $ajax_response = new AjaxResponse();
                $ajax_response->addCommand(new HtmlCommand('#result_error_message', $errors));
                $ajax_response->addCommand(new HtmlCommand('.price_calculations', ""));

                //Hide "Reserve" button and display "Check availability" button
                $ajax_response->addCommand(new InvokeCommand('.btn-check_availability', 'removeClass', array('hidden')));
                $ajax_response->addCommand(new InvokeCommand('.btn-reserve', 'addClass', array('hidden')));

                return $ajax_response;

            } else {

                //Space is available
                //Remove errors
                $ajax_response = new AjaxResponse();
                $ajax_response->addCommand(new HtmlCommand('#result_error_message', ""));

                //Change button text
                //$ajax_response->addCommand(new HtmlCommand('.btn-primary', "Reserve"));

                //CHECK PRICES FOR REQUESTED TIME
                list($arr_price_breakdown, $flt_total_price, $flt_total_hours, $flt_average_price_per_hour) = check_space_availability_prices($str_date, $start_time_index, $end_time_index, $param_space_id);

                //Get property country details
                $arr_country_details = get_country_details_by_space_id($param_space_id);
                $currency_symbol = $arr_country_details['currency_symbol'];
                //echo "<pre>"; print_r($arr_country_details);

                //Load current user to get currency details
                $conversion_rate = 0;
                $currency_code = '';


                //Get user preferred currency
                $user_preferred_currency_id = get_user_preferred_currency_id();
                //If we have the user's preferred currency
                if($user_preferred_currency_id > 0){
                    //If the user currency is different then the property currency (according to the country), get the user's currency and convert to that
                    if($arr_country_details['currency_tid'] != $user_preferred_currency_id){
                        //Get the conversion rate, converted price, currency symbol and all
                        $arr_converted_price = get_currency_conversion_rate($arr_country_details['currency_tid'], $user_preferred_currency_id);
                        if(!is_null($arr_converted_price)){
                            $currency_symbol = $arr_converted_price['currency_symbol'];
                            $conversion_rate = $arr_converted_price['conversion_rate'];
                            $currency_code = $arr_converted_price['currency_code'];
                        }
                    }
                }




                //If we have a conversion rate
                if($conversion_rate > 0){

                    //Calculate the total price
                    $flt_total_price = $flt_total_price * $conversion_rate;

                    //Run on the table of prices and convert them
                    foreach($arr_price_breakdown as $key => $value){
                        $arr_price_breakdown[$key]['price'] = $value['price'] * $conversion_rate;
                        $arr_price_breakdown[$key]['total'] = $value['total'] * $conversion_rate;
                        $arr_price_breakdown[$key]['reason'] = $value['reason'] . '. ' . $currency_code . ' ' . $arr_price_breakdown[$key]['price'] . ' converted to ' . $currency_code . ' in rate of ' . $conversion_rate;
                    }
                }

                //DISPLAY PRICES
                $str_html = '<div class="row">';

                $str_space_price = t("Space price");
                $str_hours = t("hours");

                //Prices
                foreach($arr_price_breakdown as $key => $value){
                    $str_html .= '
                    <div class="col-xs-9">' . $str_space_price . ' ' . $currency_symbol . $value['price'] . ' X ' . $value['time'] . ' ' . $str_hours . '</div>
                    <div class="col-xs-3">' . $currency_symbol . $value['total'] . '</div>';
                }
                $str_html .= '</div class="row">';
                //VAT
                //print("VAT: " . $arr_country_details['vat'] / 100 . ". ");
                //print("TOTAL PRICE: " . floatval($value['total']) . ". ");
                $float_total_vat = floatval($arr_country_details['vat'] / 100) * floatval($flt_total_price);
                $str_vat = t("VAT");
                $str_html .= '
                <div class="row">
                    <div class="col-xs-9">'.$str_vat.' (' . $arr_country_details['vat'] . '%)</div>
                    <div class="col-xs-3">' . $currency_symbol . $float_total_vat . '</div>
                </div>';
                $str_html .= '<hr/>';
                //Total
                $float_total_price_incl_vat = $flt_total_price + $float_total_vat;
                $str_total_price = t('Total price');
                $str_html .= '
                <div class="row total_price">
                            <div class="col-xs-9">'.$str_total_price.'</div>
                            <div class="col-xs-3">'.$currency_symbol . $float_total_price_incl_vat .'</div>
                </div>';
                //Remark
                $str_cancellation_text = t('The price does not include extra services');
                $str_html .= ' <div class="remark"> '.$str_cancellation_text.' </div >';

                //$str_html .= '<div class="row"><a href="" class="link_to_cancellation_policy">Cancellation policy</a></div>';

                    //Display
                $ajax_response->addCommand(new HtmlCommand('.price_calculations', "$str_html"));

                //Display "Reserve" button and hide "Check availability" button
                $ajax_response->addCommand(new InvokeCommand('.btn-check_availability', 'addClass', array('hidden')));
                $ajax_response->addCommand(new InvokeCommand('.btn-reserve', 'removeClass', array('hidden')));


                //Cancellation policy
                //$param_space_id


                return $ajax_response;
            }
        }
    }

    public function spaceCheckoutReserveSubmit(array &$form, FormStateInterface $form_state){
        $values = $form_state->getValues();

        //Get form data
        $str_date = $values['date']->format('Y-m-d');
        $start_time_index = $values['from_time'];
        $end_time_index = $values['to_time'];
        if(isset($values['spaces'])){
            $param_space_id = $values['spaces'];
        } else {
            $param_space_id = $values['hidden_space'];
        }

        //CHECK IS SPACE IS AVAILABLE
        $space_is_available = check_if_space_is_available($str_date, $start_time_index, $end_time_index, $param_space_id);
        if($space_is_available == false){
            \Drupal::messenger()->addMessage(t('Space is not available. Please try different days or times.'), 'error');
        } else {


            //Get user id
            $uid = \Drupal::currentUser()->id();

            //Get data
            $date = $values['date']->format('Y-m-d');
            $start_time_index = $values['from_time'];
            $end_time_index = $values['to_time'];
            $booking_people = $values['booking_people'];
            if(isset($values['spaces'])){
                $space_id = $values['spaces'];
            } else {
                $space_id = $values['hidden_space'];
            }

            $start_time = get_select_list_times_from_index($start_time_index);
            $end_time = get_select_list_times_from_index($end_time_index);

            //Insert data into DB and redirect to checkout page
            $connection = \Drupal::database();
            $form_date_time = $date." ".$start_time.":00";
            $to_date_time = $date." ".$end_time.":00";

            //echo date("Y-m-d H:i:s", strtotime("+10 minutes")); die;
            //print_r($dte->format('Y-m-d\TH:i:s')); die;

            //Add a record to the DB to 'bs_checkout' table
            $bs_checkout_record_id = $connection->insert('bs_checkout')
                ->fields([
                    'space_id' => $space_id,
                    'status' => 0,
                    'from_time' => $form_date_time,
                    'to_time' => $to_date_time,
                    'number_of_people' => $values['booking_people'],
                    'uid' => $uid,
                    'time_added' => date("Y-m-d H:i:s", strtotime("now")),
                    'time_expired' => date("Y-m-d H:i:s", strtotime("+10 minutes"))
                ])
                ->execute();


            //Add records to the DB to 'bs_checkout_prices' table
            //Get price breakdown
            list($arr_price_breakdown, $flt_total_price, $flt_total_hours, $flt_average_price_per_hour) = check_space_availability_prices($str_date, $start_time_index, $end_time_index, $param_space_id);

            //kint($arr_price_breakdown);die;


            //Get property country details
            $arr_country_details = get_country_details_by_space_id($space_id);
            $currency_symbol = $arr_country_details['currency_symbol'];
            $currency_tid = $arr_country_details['currency_tid'];
            //echo "<pre>"; print_r($arr_country_details);


            $conversion_rate = 0;
            $currency_code = '';
            //Get user preferred currency
            $user_preferred_currency_id = get_user_preferred_currency_id();
            //If we have the user's preferred currency
            if($user_preferred_currency_id > 0){
                //If the user currency is different then the property currency (according to the country), get the user's currency and convert to that
                if($arr_country_details['currency_tid'] != $user_preferred_currency_id){
                    //Get the conversion rate, converted price, currency symbol and all
                    $arr_converted_price = get_currency_conversion_rate($arr_country_details['currency_tid'], $user_preferred_currency_id);
                    if(!is_null($arr_converted_price)){
                        $currency_symbol = $arr_converted_price['currency_symbol'];
                        $conversion_rate = $arr_converted_price['conversion_rate'];
                        $currency_code = $arr_converted_price['currency_code'];
                        $currency_tid = $user_preferred_currency_id;
                    }
                }
            }


            //If we have a conversion rate
            if($conversion_rate > 0){

                //Calculate the total price
                $flt_total_price = $flt_total_price * $conversion_rate;

                //Run on the table of prices and convert them
                foreach($arr_price_breakdown as $key => $value){
                    $arr_price_breakdown[$key]['price'] = $value['price'] * $conversion_rate;
                    $arr_price_breakdown[$key]['total'] = $value['total'] * $conversion_rate;
                    $arr_price_breakdown[$key]['reason'] = $value['reason'] . '. ' . $currency_code . ' ' . $arr_price_breakdown[$key]['price'] . ' converted to ' . $currency_code . ' in rate of ' . $conversion_rate;
                }
            }


            foreach ($arr_price_breakdown as $key => $row) {
                $start_time_min = $row['start_time_min'];
                $end_time_min = $row['end_time_min'];
                $price = $row['price'];
                $reason = $row['reason'];

                $start_time_hi = convert_minutes_to_H_i($start_time_min);
                $start_time = $str_date . " " . $start_time_hi;

                $end_time_hi = convert_minutes_to_H_i($end_time_min);
                $end_time = $str_date . " " . $end_time_hi;

                $bs_checkout_prices_record_id = $connection->insert('bs_checkout_prices')
                    ->fields([
                        'bs_checkout_id' => $bs_checkout_record_id,
                        'from_time' => $start_time,
                        'to_time' => $end_time,
                        'price' => $price,
                        'currency_id' => $currency_tid,
                        'reason' => $reason
                    ])
                    ->execute();
            }

            $query['checkout_id'] = $bs_checkout_record_id;
            if ($uid) {
              $query['user_type'] = 'host';
            }
            $qs = http_build_query($query);
            // Redirect to the checkout page
            $redirect_path = '/checkout?'.$qs;
            $path = URL::fromUserInput($redirect_path)->toString();
            $response = new RedirectResponse($path);
            $response->send();
        }


    }


    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {

        //This function is not required as we use the AJAX function spaceCheckoutReserveSubmit()

    }

}
