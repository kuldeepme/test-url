<?php

namespace Drupal\bs_form_checkout\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\bs_form_checkout\Manager\StepManager;
use Drupal\bs_form_checkout\Step\StepsEnum;
use Drupal\file\Entity\File;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\user\Entity\User;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

use Drupal\taxonomy\Entity\Term;

/**
 * Provides multi step ajax example form.
 *
 * @package Drupal\bs_form_checkout\Form
 */
class BsFormCheckout extends FormBase {
  use StringTranslationTrait;

  /**
   * Step Id.
   *
   * @var \Drupal\bs_form_checkout\Step\StepsEnum
   */
  protected $stepId;
  protected $m_arr_currencies;

  /**
   * Multi steps of the form.
   *
   * @var \Drupal\bs_form_checkout\Step\StepInterface
   */
  protected $step;

  /**
   * Step manager instance.
   *
   * @var \Drupal\bs_form_checkout\Manager\StepManager
   */
  protected $stepManager;

  /**
   * {@inheritdoc}
   */
  public function __construct() {
    $this->stepId = StepsEnum::STEP_ONE;
    $this->stepManager = new StepManager();
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_form_checkout';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

      $form['#attached']['library'][] = 'bs_form_listaspace/internation-telephone';

    $form['wrapper-messages'] = [
      '#type' => 'container',
      '#attributes' => [
        'id' => 'messages-wrapper',
      ],
    ];
    $form['wrapper'] = [
      '#type' => 'container',
      '#attributes' => [
        'id' => 'form-wrapper',
      ],
    ];
    // Get step from step manager.
    $this->step = $this->stepManager->getStep($this->stepId);

    //print("<pre>");print_r($this->stepId); echo "<br/>"; print_r($this->step);die;

    // Attach step form elements.
    $form['wrapper'] += $this->step->buildStepFormElements();
    // Attach buttons.
    $form['wrapper']['actions']['#type'] = 'actions';
    $buttons = $this->step->getButtons();
    foreach ($buttons as $button) {
      /** @var \Drupal\bs_form_checkout\Button\ButtonInterface $button */
      $form['wrapper']['actions'][$button->getKey()] = $button->build();

      if ($button->ajaxify()) {
        // Add ajax to button.
        $form['wrapper']['actions'][$button->getKey()]['#ajax'] = [
          'callback' => [$this, 'loadStep'],
          'wrapper' => 'form-wrapper',
          'effect' => 'fade',
        ];
      }
      $callable = [$this, $button->getSubmitHandler()];
      if ($button->getSubmitHandler() && is_callable($callable)) {
        // Attach submit handler to button, so we can execute it later on..
        $form['wrapper']['actions'][$button->getKey()]['#submit_handler'] = $button->getSubmitHandler();
      }
    }


      //OFEK CODE
      $language_id =  \Drupal::languageManager()->getCurrentLanguage()->getId();

      //If no checkout id, redirect to search results page
      if(!isset($_REQUEST['checkout_id'])){
          $redirect_path = '/search_results';
          $path = URL::fromUserInput($redirect_path)->toString();
          $response = new RedirectResponse($path);
          $response->send();
      }

      //Get checkout id
      $checkout_id = $_REQUEST['checkout_id'];

      //Connection to DB
      $connection = \Drupal::database();

      //Get data from DB from 'bs_checkout' table
      $query = $connection->select('bs_checkout', 'c');
      $query->condition('c.id', $checkout_id, '=');
      if($this->stepId == 1){
          $query->condition('c.status', 0, '=');
      }
      //$query->fields('c', ['id', 'space_id', 'from_time']);
      $query->fields('c');
      //$query->range(0, 50);

      //Get results
      $results = $query->execute();

      //Get all records
      $records = $results->fetchAll();

      //Count records
      $num_results = count($records);
      if($num_results != 1){
          //die("STEP: " . $this->stepId);
          $redirect_path = '/search_results';
          $path = URL::fromUserInput($redirect_path)->toString();
          $response = new RedirectResponse($path);
          $response->send();
      }

      $table_bs_checkout_id = $records[0]->id;
      $space_id = $records[0]->space_id;
      $start_time = strtotime($records[0]->from_time);
      $start_date = date('M d, Y',$start_time);
      $start_time = date('H:i',$start_time);
      $end_time = strtotime($records[0]->to_time);
      $end_time = date('H:i',$end_time);

      //kint($start_time, $end_time);

      $user_id = $records[0]->uid;
      $time_added = $records[0]->time_added;

      //number_of_people
      $number_of_people_tid = $records[0]->number_of_people;
      if($number_of_people_tid != 0){
          $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($number_of_people_tid);
          $number_of_people = $term->getName();
      }


      //If the current user is NOT the user that saved the checkout data, leave
      if($user_id != \Drupal::currentUser()->id()){
          $redirect_path = '/search_results';
          $path = URL::fromUserInput($redirect_path)->toString();
          $response = new RedirectResponse($path);
          $response->send();
      }


      //Get country details and from there the currency and vat
      $arr_country_details = get_country_details_by_space_id($space_id);
      $currency_tid = $arr_country_details['currency_tid'];
      $currency_symbol = $arr_country_details['currency_symbol'];
      $vat = $arr_country_details['vat'];


      //PRICES
      //Get data from DB from 'bs_checkout' table
      $query = $connection->select('bs_checkout_prices', 't');
      $query->condition('t.bs_checkout_id', $checkout_id, '=');
      //$query->fields('c', ['id', 'space_id', 'from_time']);
      $query->fields('t');
      //$query->range(0, 50);

      //Get results
      $results = $query->execute();

      //Get all records
      $price_records = $results->fetchAll();

      $total_price = 0;
      $arr_prices = array();
      foreach ($price_records as $key => $price_record) {
          $from_time = $price_record->from_time;
          $to_time = $price_record->to_time;
          $price = $price_record->price;
          $currency_checkout_tid = $price_record->currency_id;
          $reason = $price_record->reason;

          $time_diff_in_hours = get_time_difference_in_hours($from_time, $to_time);
          $time_slot_price = $price * $time_diff_in_hours;
          $total_price += $time_slot_price;

          $arr_tmp = array("from_time"=>$from_time, "to_time"=>$to_time, "price"=>$price, "hours" => $time_diff_in_hours, "time_slot_price" => $time_slot_price, "currency_tid" => $currency_tid, "reason" => $reason);
          array_push($arr_prices, $arr_tmp);
      }
      //END PRICES

      //If the currency checkout tid is different then the one of the country of the property
      if($currency_checkout_tid != 0 && $currency_checkout_tid != $currency_tid){
          $currency_tid = $currency_checkout_tid;
          $arr_currency_details = get_currency_details_from_id($currency_checkout_tid);
          $currency_symbol = $arr_currency_details['currency_symbol'];
      }

      //Load space node
      $ct_space = \Drupal\node\Entity\Node::load($space_id);
      if(isset($ct_space)){
          $space_title = $ct_space->getTitle();
          $space_description = $ct_space->field_space_description->getString();

          //Get property title and address
          $space_property_id = $ct_space->field_spaces_properties->getString();

          $node_space_property = \Drupal\node\Entity\Node::load($space_property_id);
          $space_property_title = $node_space_property->getTitle();
          $space_property_address = [];

          if (isset($node_space_property->field_property_address)) {
              $space_property_address['country_code'] = $node_space_property->field_property_address->getValue()[0]['country_code'];
              $space_property_address['country_name'] = \Drupal::service('country_manager')->getList()[$space_property_address['country_code']]->__toString();
              $space_property_address['administrative_area'] = $node_space_property->field_property_address->getValue()[0]['administrative_area'];
              $space_property_address['locality'] = $node_space_property->field_property_address->getValue()[0]['locality'];
              $space_property_address['address_line1'] = $node_space_property->field_property_address->getValue()[0]['address_line1'];
              $space_property_address['string_address'] = $space_property_address['address_line1'] . ", " . $space_property_address['locality'] . ", " . $space_property_address['administrative_area']
                  . ", " . $space_property_address['administrative_area'] . ", " . $space_property_address['country_name'];
          }

          //Images
          $arr_image_url = [];
          //Get all images
          $arr_field_space_images = $ct_space->get('field_space_images')->getValue();
          //Run on array of images
          foreach ($arr_field_space_images as &$value) {
              //Get the target id of the images
              $fid = $value['target_id'];
              //Load the file
              $obj_file = \Drupal\file\Entity\File::load($fid);
              if($obj_file != NULL){
                  //Load image URI
                  $image_uri = $obj_file->getFileUri();
                  if($image_uri != NULL){
                      //Style thumbnail so we can change later from admin system
                      $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('large');
                      //$arr_image_url[$fid] = $style->buildUrl($image_uri);
                      array_push($arr_image_url, $style->buildUrl($image_uri));
                  }
              }
          }
      }


      //Get cancellation policy text
      $str_cancellation_policy_text = "";
      if(isset($ct_space->field_cancellation_policy)){
          $tid = $ct_space->field_cancellation_policy->getValue()[0]['target_id'];
          $str_cancellation_policy_text = get_cancellation_policy_text($tid);
      }




      $arr_page_data = array();
      $arr_page_data['table_bs_checkout_id'] = $table_bs_checkout_id;
      $arr_page_data['from_date'] = $start_date;
      $arr_page_data['start_time'] = $start_time;
      $arr_page_data['end_time'] = $end_time;
      $arr_page_data['number_of_people'] = $number_of_people;
      $arr_page_data['number_of_people_tid'] = $number_of_people_tid;
      $arr_page_data['time_added'] = $time_added;
      $arr_page_data['from_time'] = $from_time;
      $arr_page_data['space_id'] = $space_id;
      $arr_page_data['space_title'] = $space_title;
      $arr_page_data['space_description'] = $space_description;
      $arr_page_data['space_property_title'] = $space_property_title;
      $arr_page_data['space_property_address'] = $space_property_address;
      //$arr_page_data['space_services_paid'] = $arr_space_services_paid;
      $arr_page_data['space_images'] = $arr_image_url;
      $arr_page_data['space_prices'] = $arr_prices;
      $arr_page_data['currency_symbol'] = $currency_symbol;
      $arr_page_data['vat'] = $vat;
      $arr_page_data['cancellation_policy'] = $str_cancellation_policy_text;

      $form["page_data"] = [
          "#type"=> "hidden",
          "#value" => $arr_page_data,
      ];
      //END OFEK CODE

    return $form;
  }

  /**
   * Ajax callback to load new step.
   *
   * @param array $form
   *   Form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state interface.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response.
   */
  public function loadStep(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();

    $messages = drupal_get_messages();
    $error = '';
    if (!empty($messages)) {
      // Form did not validate, get messages and render them.
      $messages = [
        '#theme' => 'status_messages',
        '#message_list' => $messages,
        '#status_headings' => [
          'status' => $this->t('Status message'),
          'error' => $this->t('Error message'),
          'warning' => $this->t('Warning message'),
        ],
      ];

      $response->addCommand(new HtmlCommand('#messages-wrapper', $messages));
      $error = "Error";
    }
    else {
      // Remove messages.
      $response->addCommand(new HtmlCommand('#messages-wrapper', ''));
    }
     
    // Update Form.
    $response->addCommand(new HtmlCommand('#form-wrapper', $form['wrapper']));
    $response->addCommand(new \Drupal\Core\Ajax\InvokeCommand(NULL, "bs_form_after_ajax_handler", array($error)));    
    return $response;
  }
  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    // Only validate if validation doesn't have to be skipped.
    // For example on "previous" button.
    if (empty($triggering_element['#skip_validation']) && $fields_validators = $this->step->getFieldsValidators()) {
      // Validate fields.
      foreach ($fields_validators as $field => $validators) {
        // Validate all validators for field.
        $field_value = $form_state->getValue($field);
        foreach ($validators as $validator) {
          if (!$validator->validates($field_value)) {
            $form_state->setErrorByName($field, $validator->getErrorMessage());
          }
        }
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    // Save filled values to step. So we can use them as default_value later on.
    $values = [];

      //Remove as we use the next line
      /*foreach ($this->step->getFieldNames() as $name) {
        $values[$name] = $form_state->getValue($name);
      }*/
      //Added by Ofek (Arvind) - it gets all the values, also of the dynamic elements
      $values = $form_state->cleanValues()->getValues();
    $this->step->setValues($values);
    // Add step to manager.
    $this->stepManager->addStep($this->step);
    // Set step to navigate to.
    $triggering_element = $form_state->getTriggeringElement();
    $this->stepId = $triggering_element['#goto_step'];

    // If an extra submit handler is set, execute it.
    // We already tested if it is callable before.
    if (isset($triggering_element['#submit_handler'])) {
      $this->{$triggering_element['#submit_handler']}($form, $form_state);
    }    $form_state->setRebuild(TRUE);
  }


  /**
   * Submit handler for last step of form.
   *
   * @param array $form
   *   Form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state interface.
   */
  public function submitValues(array &$form, FormStateInterface $form_state) {
      // Submit all values to DB or do whatever you want on submit.
      //Get all steps
      $allSteps = $this->stepManager->getAllSteps();
      $values = array();
      //Run on all steps
      foreach ($allSteps as $step) {
          //Get values of each step
          $step_values = $step->getValues();
          $values = array_merge($values, $step_values);
      }
      $this->handle_form_results($values);
  }


    private function handle_form_results($values)
    {

        $start_time = $values['page_data']['from_time'];
        $end_time = $values['page_data']['to_time'];

        $space_title = $values['page_data']['space_title'];
        $reservation_title = "Reservation - " . $space_title . " - " . $start_time;

        $reservation_table_bs_checkout_id = $values['page_data']['table_bs_checkout_id'];

        $space_nid = $values['page_data']['space_id'];

        $space_layout = $values['space_layout_wrapper'];
        $paragraph = \Drupal\paragraphs\Entity\Paragraph::load($space_layout);
        if (isset($paragraph->field_space_layout_name)) {
            $space_layouts_id = $paragraph->field_space_layout_name->getValue()[0]['target_id'];
        }

        //Language id
        $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
        if(!isset($language)){
            $language = "en";
        }

        //Number of people
        $number_of_people_tid = $values['page_data']['number_of_people_tid'];



        //echo "<pre/>";
        //print_r($values);

        //User id and currency
        $user = \Drupal::currentUser();

        if(!$user->id()){
            //print("User is NOT authenticated!");

            $email = $values['email'];
            $password = $values['confirm_password'];
            $first_name = $values['first_name'];
            $last_name = $values['last_name'];
            $phone = $values['phone'];
            //print($email);die;


            //We don't have a user. Add a user
            $user = \Drupal\user\Entity\User::create();

            // Mandatory user creation settings
            $user->enforceIsNew();
            $user->setUsername($email); // This username must be unique and accept only a-Z,0-9, - _ @ .
            $user->setEmail($email);
            $user->setPassword($password);
            $user->set("langcode", $language);

            // Optional settings
            $user->set("init", 'email');
            $user->set("preferred_langcode", $language);
            $user->set("preferred_admin_langcode", $language);

            //Settings from form
            $user->field_user_first_name = $first_name;
            $user->field_user_last_name = $last_name;
            $user->field_user_phone = $phone;

            //User description and image - new or updated fields
            //$user->field_user_description = $user_description;
            //if($user_image_file_id > 0){
                //$user->field_user_image = $user_image_file_id;
            //}

            $user->activate();
            // Add a custom role
            $user->addRole('CustomRoleName');

            //Save user
            $user->save();
            //$user_id = $user->id();

            //Login user
            //$user = User::load($user_id);
            //user_login_finalize($user);
            $store_var = \Drupal::service('user.private_tempstore')->get('bs_form_checkout');
            $store_var->set('list_user_id', $user->id());
            //$user_destination = \Drupal::destination()->get();
            //$response = new RedirectResponse($user_destination);
            //$response->send();
        }



        //die;





        //Create times paragraph
        $str_start_date = $values['page_data']['from_date'];
        $str_start_datetime = $values['page_data']['start_time'];
        $str_end_datetime = $values['page_data']['end_time'];
        $str_start_datetime = convert_datetime_to_datetime_with_t($str_start_date . " " . $str_start_datetime);
        $str_end_datetime = convert_datetime_to_datetime_with_t($str_start_date . " " . $str_end_datetime);
        $times_paragraph_reservation = create_paragraph_times($str_start_datetime, $str_end_datetime);

        //Get space currency details
        $arr_country_details = get_country_details_by_space_id($space_nid);
        $currency_tid = $arr_country_details['currency_tid'];
        $currency_symbol = $arr_country_details['currency_symbol'];
        $vat = $arr_country_details['vat'];
        $conversion_rate = 0;

        //Get user preferred currency
        $user_preferred_currency_id = get_user_preferred_currency_id();
        //If we have the user's preferred currency
        if($user_preferred_currency_id > 0){
            //If the user preferred currency is different than the currency of the country of the property
            if($currency_tid != 0 && $currency_tid != $user_preferred_currency_id){
                $currency_tid = $user_preferred_currency_id;
                //Get the conversion rate, converted price, currency symbol and all
                $arr_converted_price = get_currency_conversion_rate($arr_country_details['currency_tid'], $user_preferred_currency_id);
                if(!is_null($arr_converted_price)){
                    $currency_symbol = $arr_converted_price['currency_symbol'];
                    $conversion_rate = $arr_converted_price['conversion_rate'];
                    $currency_code = $arr_converted_price['currency_code'];
                }
            }
        }
        //TOTAL price
        $total_price = 0;

        //HANDLE PAID SERVICES
        $space_services_paid_array = [];
        //Run on all values
        foreach ($values as $key => $value) {

            //If the key contains 'service_paid_requested_items_', it's a paid service
            if (strpos($key, 'service_paid_requested_items_') !== false) {

                //If an item was selected
                if($value > 0){

                    //get the id of the item
                    $item_array = explode("service_paid_requested_items_",$key);
                    $item_id = $item_array[1];

                    //Get number of items
                    $number_of_items = $value;

                    //Load paragraph "space services"
                    $space_services_paragraph = \Drupal\paragraphs\Entity\Paragraph::load($item_id);
                    //print_r("<pre>"); print_r($paragraph);die;
                    if (isset($space_services_paragraph->field_space_services) && isset($space_services_paragraph->field_service_price)) {
                        $service_id = $space_services_paragraph->field_space_services->getValue()[0]['target_id'];
                        $service_price = $space_services_paragraph->field_service_price->getValue()[0]['value'];

                        if($conversion_rate > 0){
                            $service_price = $service_price * $conversion_rate;
                        }

                        //Set the total price
                        $total_price += ($number_of_items * $service_price);

                        //Create a paragraph reservation_services
                        $paragraph = Paragraph::create([
                            'type' => 'reservation_services',
                            'field_reservation_service_term' => $service_id,
                            'field_reservation_service_price' => $service_price,
                            'field_reservation_service_curren' => $currency_tid,
                            'field_reservation_service_amount' => $number_of_items,
                        ]);
                        $paragraph->save();

                        //Add paragraph reservation_services to the array so we can add it later to the reservation
                        $space_services_paid_array[] = [
                            'target_id' => $paragraph->id(),
                            'target_revision_id' => $paragraph->getRevisionId(),
                        ];
                    }
                }
            }
        }

        //HANDLE PRICE BREAKDOWN
        //print_r($values['page_data']['space_prices']);die;
        $arr_reservation_space_price_breakdown = [];
        foreach ($values['page_data']['space_prices'] as $key => $value) {
            //print("<pre>");print_r($value);
            $start_time = $value["from_time"];
            $end_time = $value["to_time"];
            $time_slot_price_per_hour = $value['price'];
            $time_slot_total_price = $value['time_slot_price'];
            $time_slot_currency_tid = $value['currency_tid'];
            $reason = $value["reason"];

            //Set the total price
            $total_price += $time_slot_total_price;

            //Create times paragraph
            $str_start_datetime = convert_datetime_to_datetime_with_t($start_time);
            $str_end_datetime = convert_datetime_to_datetime_with_t($end_time);
            $times_paragraph_item = create_paragraph_times($str_start_datetime, $str_end_datetime);

            //create paragraph reservation_space_price_breakdown
            $paragraph = Paragraph::create([
                'type' => 'reservation_space_price_breakdow',
                'field_reservation_price_price' => $time_slot_total_price,
                'field_reservation_price_per_hour' => $time_slot_price_per_hour,
                'field_reservation_price_currency' => $currency_tid,
                'field_reservation_price_reason' => $reason,
                'field_reservation_price_breakdow' => $times_paragraph_item,
            ]);
            $paragraph->save();

            //Add paragraph reservation_services to the array so we can add it later to the reservation
            $arr_reservation_space_price_breakdown[] = [
                'target_id' => $paragraph->id(),
                'target_revision_id' => $paragraph->getRevisionId(),
            ];
        }

        $paid_price = $total_price + (($total_price / 100) * $vat);

        $total_vat = ($total_price * ($vat / 100));
        $total_vat = round($total_vat, 2);

        //$vat = $values['page_data']['vat'];
        //ADD RESERVATION
        $node_ct_reservations = Node::create([
            'type' => 'ct_reservations',
            'langcode' => $language,
            'uid' =>  $user->id(),
            'title' => $reservation_title,
            'field_reservation_space' => $space_nid,
            'field_reservation_space_layout' => $space_layouts_id,
            'field_reservation_table_bs_check' => $reservation_table_bs_checkout_id,
            'field_reservation_time' => $times_paragraph_reservation,
            'field_reservation_services' => $space_services_paid_array,
            'field_reservation_space_price_br' => $arr_reservation_space_price_breakdown,
            'field_reservation_price' => $total_price,
            'field_reservation_price_vat' => $vat,
            'field_reservation_vat_per_price' => $total_vat,
            'field_reservation_currency' => $currency_tid,
            'field_reservation_paid_price' => $paid_price,
            'field_reservation_number_of_peop' => $number_of_people_tid,
            'field_reservation_user' => $user->id()
        ]);

        $node_ct_reservations->setPublished(true);
        $node_ct_reservations->save();

        //get reservation id
        $reservation_id = $node_ct_reservations->id();

        //Check if the user got here from direct sales tool and if so, add new reservation record to the "bs_direct_sales_tool_kpis" table
        $direct_sales_tool_id = get_cookie('direct_sales_tool_id');
        if(isset($direct_sales_tool_id)) {
            if ($direct_sales_tool_id > 0) {

                //Add new search registration (3) to the KPIs table
                $new_record_id = add_direct_sales_tool_kpi($direct_sales_tool_id, 3, $reservation_id);
            }
        }




    }
}
