<?php

namespace Drupal\bs_form_checkout\Form;

/**
 * @file
 * Contains \Drupal\bs_form_checkout\Form\BsFormSpaceCheckout.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\node\Entity\Node;

/**
 * {@inheritdoc}
 */
class BsFormSpaceCheckout extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'bs_form_space_checkout';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, $params = NULL) {


        $node = $params['node_object'];

        //kint($node);
        //kint($node->getType()); die;
        //kint($node->getEntityType());die;

        //If it's a properties page, get all the spaces and display in the form
        $is_properties_page = false;
        if($node->getType() == "ct_properties") {
            $is_properties_page = true;
            $arr_spaces = array();
            //Number of spaces of this property
            $number_of_spaces = $node->field_property_spaces->count();
            //Run on spaces of this property
            for($i = 0; $i < $number_of_spaces; $i++){
                //Get space item
                $space_item = $node->field_property_spaces->get($i);
                //Get space id
                $space_id = $space_item->getValue()['target_id'];
                //Get space node
                $node_space = Node::load($space_id);
                //Get space title
                $node_space_title = $node_space->getTitle();
                //Add space id and title to list
                $arr_spaces[$space_id] = $node_space_title;
            }
            $form['spaces'] = [
                '#type' => 'select',
                '#required' => TRUE,
                '#options' => $arr_spaces,
                '#title' => t("Space"),
            ];
        }

        $form['is_properties_page'] = [
            "#type"=> "hidden",
            "#value" => $is_properties_page,
        ];


        $form['date'] = [
            '#type' => 'date',
            '#required' => TRUE,
            '#size' => 20,
            '#title' => t("Date"),
        ];

        $start = 0;
        $end = 23;
        $time_formate = [];
        for ($i = $start; $i <= $end; $i++) {
            if ($i <= 9) {
                $time_formate[] = '0' . $i . ":00";
            }
            else {
                $time_formate[] = $i . ":00";
            }
        }
        $form['from_time'] = [
            '#type' => 'select',
             '#required' => TRUE,
            '#options' => $time_formate,
            '#title' => t("Meeting time"),
        ];
        $form['to_time'] = [
            '#type' => 'select',
             '#required' => TRUE,
            '#options' => $time_formate,
            //'#title' => t("To time"),
        ];

        $arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', FALSE);
        $form['booking_people'] = [
            '#type' => 'select',
            '#options' => $arr_number_of_people,
            '#title' => t("Number of people"),
        ];
        $form['hidden_space'] = [
            "#type"=> "hidden",
            "#value" => $node->id(),
        ];
        $form['submit'] = [
            '#type' => 'submit',
            '#value' => t('Reserve Now'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $uid = \Drupal::currentUser()->id();

        $values = $form_state->getValues();
        $connection = \Drupal::database();
        $form_date_time = $values['date']." ".$values['from_time'].":00";
        $to_date_time = $values['date']." ".$values['to_time'].":00";
        //If it's a property page and the user selcted the space, send it. If it's a space page, send the hidden space id
        if(isset($values['spaces'])){
            $space_id = $values['spaces'];
        } else {
            $space_id = $values['hidden_space'];
        }

        //Add a record to the DB ('bs_checkout' table)
        $record_id = $connection->insert('bs_checkout')
            ->fields([
                'space_id' => $space_id,
                'from_time' => $form_date_time,
                'to_time' => $to_date_time,
                'number_of_people' => $values['booking_people'],
                'uid' => $uid
            ])
            ->execute();

        // Redirect to the checkout page
        $redirect_path = '/checkout?checkout_id='.$record_id;
        $path = URL::fromUserInput($redirect_path)->toString();
        $response = new RedirectResponse($path);
        $response->send();
    }

}
