<?php

namespace Drupal\bs_form_checkout\Validator;

/**
 * Interface ValidatorInterface.
 *
 * @package Drupal\bs_form_checkout\Validator
 */
interface ValidatorInterface {

  /**
   * Returns bool indicating if validation is ok.
   */
  public function validates($value);

  /**
   * Returns error message.
   */
  public function getErrorMessage();

}
