<?php

namespace Drupal\bs_form_checkout\Button;

use Drupal\bs_form_checkout\Step\StepsEnum;

/**
 * Class StepTwoNextButton.
 *
 * @package Drupal\bs_form_checkout\Button
 */
class StepTwoNextButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'next';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Confirm & Complete'),
      '#goto_step' => StepsEnum::STEP_FINALIZE,
      '#submit_handler' => 'submitValues',
        '#attributes' => [
            'class' => ['btn-primary btn-lg next-button']
        ],
    ];
  }

}
