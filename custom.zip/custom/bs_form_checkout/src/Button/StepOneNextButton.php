<?php

namespace Drupal\bs_form_checkout\Button;

use Drupal\bs_form_checkout\Step\StepsEnum;

/**
 * Class StepOneNextButton.
 *
 * @package Drupal\bs_form_checkout\Button
 */
class StepOneNextButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'next';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Continue to payment'),
      '#goto_step' => StepsEnum::STEP_TWO,
      '#attributes' => [
        'class' => ['btn-primary btn-lg next-button']
      ],
    ];
  }

}
