<?php

namespace Drupal\bs_form_checkout\Button;

use Drupal\bs_form_checkout\Step\StepsEnum;

/**
 * Class StepTwoPreviousButton.
 *
 * @package Drupal\bs_form_checkout\Button
 */
class StepTwoPreviousButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'previous';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Back'),
      '#goto_step' => StepsEnum::STEP_ONE,
      '#skip_validation' => TRUE,
        '#attributes' => [
            'class' => ['btn-back']
        ],
    ];
  }

}
