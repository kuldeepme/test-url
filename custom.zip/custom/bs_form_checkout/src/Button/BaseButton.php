<?php

namespace Drupal\bs_form_checkout\Button;

/**
 * Class BaseButton.
 *
 * @package Drupal\bs_form_checkout\Button
 */
abstract class BaseButton implements ButtonInterface {

  /**
   * {@inheritdoc}
   */
  public function ajaxify() {
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function getSubmitHandler() {
    return FALSE;
  }

}
