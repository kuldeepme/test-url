<?php

namespace Drupal\bs_review\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\node\Entity\Node;
use Drupal\Component\Utility\Html;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;

/**
 * BsReviewMeetYourHost form.
 */
class BsReviewMeetYourHost extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_review_meet_your_host';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, array $context = []) {
    $current_path = \Drupal::service('path.current')->getPath();
    $space_options = [];
    $space_options = space_nodes();
    if (!empty($space_options)) {
      $values = $form_state->getValues();
      if (empty($values['space_name'])) {
        // Use a default value.
        $selected_space = key($space_options);
      }
      else {
        // Get the value if it already exists.
        $selected_space = $values['space_name'];
      }
      list($total_review, $rating_markup) = array_values(fivestar_rating_details($selected_space));
      if ($total_review > 0) {
        $form['comment_statistics'] = [
          '#type' => 'container',
          '#weight' => 1,
          '#prefix' => '<div id="review-fieldset-container">',
          '#suffix' => '</div>'
        ];
        $form['comment_statistics']['reviews_about'] = [
          '#markup' => '<h4>' . $total_review . ' ' . $this->t('Reviews'). '</h4>',
          '#weight' => 2,
        ];
        $form['comment_statistics']['ratings'] = [
          '#markup' => render($rating_markup)
        ];
        $form['comment_statistics']['space_name'] = [
          '#type' => 'select',
          '#weight' => 4,
          '#options' => $space_options,
          '#default_value' => $selected_space,
          '#ajax' => [
            'callback' => '::reviewDropdownCallback',
            'wrapper' => 'review-fieldset-container',
          ],
        ];
        if (!empty($selected_space)) {
          $block = views_embed_view('comment_block', 'block_3', $selected_space);
          $form['comment_statistics']['star_reviews'] = [
            '#markup' => render($block),
            '#weight' => 5,
          ];
        }
      }
    }
    else {
      $form['review_markup'] = [
        '#markup' => '<h4>' . $this->t('No review found....!') .'</h4>',
      ];
    }
    //$form['#attached']['drupalSettings']['url'] = (string)$current_path;
    //$form['#attached']['library'][] = 'bs_review/bs_host_review';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function reviewDropdownCallback(array &$form, FormStateInterface $form_state) {
    return $form['comment_statistics'];
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
