<?php

namespace Drupal\bs_review\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\node\Entity\Node;
use Drupal\Component\Utility\Html;
use Drupal\comment\Entity\Comment;

/**
 * BsReview form.
 */
class BsReview extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_review';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, array $context = []) {

    $nids = \Drupal::entityQuery('node')->condition('type', 'ct_reservations')->execute();
    $nodes = Node::loadMultiple($nids);
    $uid = \Drupal::currentUser()->id();
    $flag = FALSE;
    $options = [];
    $options[0] = '--- Select spaces ---';
    foreach ($nodes as $nid => $node) {
      $owner_id = $node->getOwnerId();
      if ($uid == $owner_id) {
        if (isset($node->field_reservation_space->entity) && !empty($node->field_reservation_space->entity)) {
          $flag = TRUE;
          $space = $node->field_reservation_space->entity;
          $title = $space->getTitle();
          $property_name = '';
          if (isset($space->field_spaces_properties->entity) && !empty($space->field_spaces_properties->entity)) {
            $property_name = $space->field_spaces_properties->entity->getTitle();
          }
          if(isset($node->field_reservation_time) && $node->field_reservation_time != NULL){
            $pargraph_entry = $node->field_reservation_time->entity;
            if($pargraph_entry->field_times !=NULL){
              $times = $pargraph_entry->field_times->getValue()[0];
              $start_time = $times["value"];
              $end_time = $times["end_value"];
              $start = date('H:i', strtotime($start_time));
              $end = date('H:i', strtotime($end_time));
            }
          }
          $space_id = $space->id();
          $string = $property_name . ", " . $title . '- ' . $start . '-' .$end;
          $options[$space_id] = $string;
        }
      }
    }
    if ($flag && count($options) > 1) {
      $values = $form_state->getValues();

      $form['review_to_write'] = [
        '#markup' => '<div class="mainheading-block"><h4>Reviews to write</h4>
                      <p>Write a review about your visit at:</p></div>'
      ];
      $form['space_name'] = [
        '#type' => 'select',
        '#weight' => 1,
        '#options' => $options,
      ];
      $form['subject'] = [
        '#type' => 'textfield',
        '#weight' => 2,
        '#required' => TRUE,
        '#attributes' => [
          'placeholder' => t('Subject')
        ],
      ];
      $form['review'] = [
        '#type' => 'textarea',
        '#required' => TRUE,
        '#weight' => 3,
        '#attributes' => [
          'placeholder' => t('Write a short review on your visit')
        ],
      ];
      $form['review_container'] = [
        '#type' => 'container',
        '#weight' => 7,
        '#attributes' => [
          'id' => 'my-ajax-wrapper',
        ]
      ];

      $block = views_embed_view('comment_block', 'block_1');
      $form['review_container']['review_data'] = [
        '#markup' => render($block),
      ];


      $entity = \Drupal::entityManager()->getFieldDefinitions('node', 'spaces');
      $item = $entity['field_space_ratings'];
      $context = [
        'entity' => $item,
        'field_definition' => $item->getItemDefinition()->getFieldDefinition(),
        'display_settings' => $item->getSettings(),
      ];
      $entity = $context['entity'];
      $uniq_id = Html::getUniqueId('vote');
      $field_definition = $context['field_definition'];
      $field_settings = $field_definition->getSettings();
      $field_name = $field_definition->getName();
      $result_manager = \Drupal::service('fivestar.vote_result_manager');
      $voting_is_allowed = (bool) ($field_settings['rated_while'] == 'viewing');
      $form['vote'] = [
        '#type' => 'fivestar',
        '#title' => t('Rate your visit'),
        '#weight' => 5,
        '#stars' => $field_settings['stars'],
        '#allow_clear' => $field_settings['allow_clear'],
        '#allow_revote' => $field_settings['allow_revote'],
        '#allow_ownvote' => $field_settings['allow_ownvote'],
        '#widget' => $context['display_settings'],
        '#settings' => $context['display_settings'],
        '#show_static_result' => !$voting_is_allowed,
        '#attributes' => [
          'class' => ['vote'],
        ],
      ];

      $form['actions']['#type'] = 'actions';
      $form['actions']['#weight'] = 4;
      $form['actions']['submit'] = [
        '#type' => 'submit',
        '#weight' => 6,
        '#value' => t('SEND MESSAGE'),
      ];
    }
    else {
      $form['markup'] = [
        '#markup' => '<h4>' . $this->t('Space not Reserved....!') . '</h4>',
      ];
    }
    $form['#attached']['library'][] = 'bs_review/bs-review-global';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $fields = $form_state->getValues();
    $ratings = $fields['vote'];

    $nid = $fields['space_name'];
    $subject = $fields['subject'];
    $review = $fields['review'];
    $node = Node::load($nid);
    $comment = Comment::create([
      'comment_type' => 'comment',
      'langcode' => $language,
      'entity_id' => $nid,
      'entity_type' => $node->getEntityTypeId(),
      'uid' => 0,
      'subject' => $subject,
      'status' => 1,
      'field_name' => 'field_space_reviews',
      'comment_body' => [
        'summary' => '',
        'value' => '<p>' . $review . '</p>',
        'format' => 'basic_html',
      ],
      'field_msg_read' => [
        'value' => 0,
      ],
      'field_ratings' => $ratings,
    ]);
    // Save the comment.
    $comment->save();
  }

}
