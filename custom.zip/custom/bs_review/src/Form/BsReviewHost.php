<?php

namespace Drupal\bs_review\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\node\Entity\Node;
use Drupal\Component\Utility\Html;
use Drupal\comment\Entity\Comment;

/**
 * BsReviewHost form.
 */
class BsReviewHost extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_review_host';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL, array $context = []) {
    $space_options = [];
    $space_options = space_nodes();
    if (!empty($space_options)) {
      $values = $form_state->getValues();
      if (empty($values['space_name'])) {
        // Use a default value.
        $selected_space = key($space_options);
      }
      else {
        // Get the value if it already exists.
        $selected_space = $values['space_name'];
      }
      $form['space_name'] = [
        '#type' => 'select',
        '#options' => $space_options,
        '#default_value' => $selected_space,
        '#ajax' => [
          'callback' => '::reviewDropdownCallback',
          'wrapper' => 'review-fieldset-container',
        ],
      ];
      list($total_review, $rating_markup, $avg_rating, $fivestar_percent) = array_values(fivestar_rating_details($selected_space));
      if ($total_review > 0) {
        $form['comment_statistics'] = [
          '#type' => 'container',
          '#prefix' => '<div id="review-fieldset-container">',
          '#suffix' => '</div>'
        ];
        $form['comment_statistics']['bs_reviews'] = [
          '#type' => 'inline_template',
          '#template' => "<div class='reviews-container'>
                              <div class='row'>
                                    <div class='col-sm-3'>
                                        <div class='statistic-container'>
                                            <div class='bs-rating rating-markup'>".render($rating_markup)."</div>
                                            <div class='bs-number total-rating'>". $avg_rating ."</div>
                                            <div class='bs-text overall-rating'>" . $this->t('Overall rating') . "</div>
                                        </div>
                                    </div>
                                    <div class='col-sm-3'>
                                        <div class='statistic-container'>
                                            <div class='icon'></div>
                                            <div class='bs-number total-review'>". $total_review ."</div>
                                            <div class='bs-text total-review'>" . $this->t('Total reviews') . "</div>
                                        </div>
                                    </div>
                                    <div class='col-sm-3'>
                                        <div class='statistic-container'>
                                            <div class='icon'></div><div class='bs-number total-fivestar'>". $fivestar_percent ."%</div>
                                            <div class='bs-text fivestar-review'>5 star reviews</div>
                                        </div>
                                    </div>
                              </div>
                        </div>",
        ];
        $form['comment_statistics']['reviews_about'] = [
          '#markup' => '<h4>' . $this->t('Reviews about your property') . ' ('. $total_review .')</h4>',
        ];
        if (!empty($selected_space)) {
          $block = views_embed_view('comment_block', 'block_3', $selected_space);
          $form['comment_statistics']['review_markup'] = [
            '#markup' => render($block),
          ];
        }
      }
    }
    else {
      $form['review_markup'] = [
        '#markup' => '<h4>' . $this->t('No review found....!') .'</h4>',
      ];
    }
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function reviewDropdownCallback(array &$form, FormStateInterface $form_state) {
    return $form['comment_statistics'];
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
