<?php
/**
 * @file
 * Contains \Drupal\bs_chat\Form\BsChatMessages.
 */
namespace Drupal\bs_chat\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Node\NodeInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\Core\Url;

class BsChatMessages extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_chat_messages';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {

        $html = '<h2>Inbox</h2>';
        $form['mymarkup'] = array(
            '#markup' => $html,
        );


        //For the select that asks the user which language to add
        $form['new_msg'] = array(
            '#type' => 'textarea',
        );

        $form['actions'] = [
            '#type' => 'submit',
            '#value' => t('Submit'),
            '#ajax' => [
                'callback' => '::myAjaxCallback', // don't forget :: when calling a class method.
                //'disable-refocus' => FALSE, // Or TRUE to prevent re-focusing on the triggering element.
                //'event' => 'change',
                'wrapper' => 'edit-output', // This element is updated with this AJAX callback.
                'progress' => [
                    'type' => 'throbber',
                    'message' => $this->t('Verifying entry...'),
                ],
            ]
        ];

        $output = $this->load_data();


        $form['output'] = [
            '#markup' => $output,
        ];

        return $form;
    }


    // Get the value from example select field and fill the textbox with the selected text.
    public function myAjaxCallback(array &$form, FormStateInterface $form_state) {

        //Get new message
        $str_msg = $form_state->getValue('new_msg');

        //If msg is empty, leave
        if($str_msg == ""){
            return false;
        }

        //Get chat id
        $chat_id = $this->get_chat_id();

        // If we don't have a chat id, it might be a new chat.
        // Try to get (other) user id and space id from query string and if they exist, create a new chat
        $new_chat = false;
        if($chat_id == 0 || $chat_id == ""){

            //If we don't have user id or space_id, leave
            if(!isset($_GET["user"]) || !isset($_GET['space_id'])){
                return false;
            }

            //If we are here, we have (other) user id and space_id
            $other_user_id = $_GET["user"];
            $space_id = $_GET['space_id'];

            $chat_id = insert_chat($other_user_id, $space_id);

            $new_chat = true;
        }

        //Insert into the chat
        insert_message($chat_id, $str_msg);

        //If we just inserted a new chat, redirect to this page
        if($new_chat == true){
            $response = new AjaxResponse();
            $response->addCommand(new RedirectCommand('/personal_area/inbox/' . $chat_id));
            return $response;
        }

        //We are done inserting new message. Now, load data
        $output = $this->load_data();


        // Return the HTML markup we built above in a render array.
        return ['#markup' => $output];
    }


    public function load_data(){

        $chat_id = $this->get_chat_id();

        //Get chat messages
        $msg_var = get_chat_messages($chat_id);

        $current_user_id = \Drupal::currentUser()->id();

        //Run on messages
        foreach ($msg_var as $key => $msg){
            if($msg->created_by_id == $current_user_id){
                $msg->user = "this_user";
            } else {
                $msg->user = "other_user";
            }
        }

        $markup = [
            '#theme' => 'bs_chat_messages_content',
            '#msg_var' => $msg_var,
        ];

        $output = "<div id='edit-output'>".render($markup)."</div>";

        return $output;
    }


    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state) {
        parent::validateForm($form, $form_state);
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {


        $fields = $form_state->getValues();

        //kint($fields);die;

    }

    function get_chat_id(){
        $current_path = \Drupal::service('path.current')->getPath();
        $path_args = explode('/', $current_path);
        $chat_id = end($path_args);
        return $chat_id;
    }
}
