<?php
/**
 * @file
 * Contains \Drupal\bs_chat\Form\BsChat.
 */
namespace Drupal\bs_chat\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Node\NodeInterface;
use Drupal\Core\Controller\ControllerBase;

class BsChat extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_chat';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {


        $html = '<h2>Inbox</h2>';
        $form['mymarkup'] = array(
            '#markup' => $html,
        );



        //Load data of ALL the properties
        $property_id = 0;
        list($output, $arr_chats) = $this->load_data($property_id);


        //Build the DDL of the properties using the values (property id and name) of ALL chats
        $arr_properties[0] = "All";

        //Run on array of chats
        foreach ($arr_chats as $key => $arr_chat) {
            //kint($arr_chat);
            $property_id = $arr_chat['property_id'];
            $property_name = $arr_chat['property_name'];
            $arr_properties[$property_id] = $property_name;
        }

        //For the select that asks the user which language to add
        $form['properties'] = array(
            '#type' => 'select',
            //'#title' => t('Properties'),
            '#options' => $arr_properties,
            //'#default_value' => isset($language) ? $language : get_current_language()
            '#default_value' => 0,
            '#ajax' => [
                'callback' => '::myAjaxCallback', // don't forget :: when calling a class method.
                //'callback' => [$this, 'myAjaxCallback'], //alternative notation
                'disable-refocus' => FALSE, // Or TRUE to prevent re-focusing on the triggering element.
                'event' => 'change',
                'wrapper' => 'edit-output', // This element is updated with this AJAX callback.
                'progress' => [
                    'type' => 'throbber',
                    'message' => $this->t('Verifying entry...'),
                ],
            ]
        );

        // Create a textbox that will be updated
        // when the user selects an item from the select box above.
        $form['output'] = [
            '#markup' => $output,
        ];


        return $form;
    }


    // Get the value from example select field and fill the textbox with the selected text.
    public function myAjaxCallback(array &$form, FormStateInterface $form_state) {

        $property_id = $form_state->getValue('properties');
        list($output, $arr_chats) = $this->load_data($property_id);

        // Return the HTML markup we built above in a render array.
        return ['#markup' => $output];
    }


    public function load_data($property_id){

        $arr_chats = get_data_for_chat_page($property_id);

        // Don't forget to wrap your markup in a div with the #edit-output id
        // or the callback won't be able to find this target when it's called
        // more than once.
        $markup = [
            '#theme' => 'bs_chat_details',
            '#chat_var' => $arr_chats,
        ];
        $output = "<div id='edit-output'>".render($markup)."</div>";

        return [$output, $arr_chats];
    }


    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state) {
        parent::validateForm($form, $form_state);
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {


        $fields = $form_state->getValues();

        //kint($fields);die;

    }
}
