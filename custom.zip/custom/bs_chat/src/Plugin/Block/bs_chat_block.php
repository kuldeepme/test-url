<?php

namespace Drupal\bs_chat\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_chat page.
 *
 * @Block(
 *   id = "bs_chat_block",
 *   admin_label = @Translation("bs_chat_block"),
 *   category = @Translation("bs_chat"),
 * )
 */
class bs_chat_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_chat\Form\BsChat');
        return $form;
    }

}
