<?php

namespace Drupal\bs_form_edit_seller_details\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\file\Entity\File;
use CommerceGuys\Addressing\AddressFormat\AddressField;
use CommerceGuys\Addressing\AddressFormat\FieldOverride;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * Provides a form for edit seller details.
 *
 * @internal
 */
class BsFormEditSellerDetails extends FormBase
{

    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {
        return 'bs_form_edit_seller_details';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL)
    {

        //Get available genders for DDL
        $entityManager = \Drupal::service('entity_field.manager');
        $ct_seller_fields = $entityManager->getFieldStorageDefinitions('node', 'ct_seller');
        $gender_options = options_allowed_values($ct_seller_fields['field_seller_gender']);

        //Get available countries for DDL
        $country_options = get_available_countries();


        $user_id = \Drupal::currentUser()->id();

        //Load the "CT seller" node of the user
        $nodes = \Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['field_seller_user' => $user_id]);


        $first_name = "";
        $last_name = "";
        $social_id = "";
        $social_id_issue_date = "";
        $birth_date = "";
        $gender = "";
        $email = "";
        $email_2 = "";
        $phone = "+1";
        $bank_code = "";
        $bank_branch = "";
        $bank_account_number = "";
        $website_url = "";
        $merchant_name = "";
        $country = "";
        $city = "";
        $street = "";
        $house_number = "";

        //Apply reset() and this returns either the node or NULL if nothing was found
        if ($node = reset($nodes)) {

            // Found the node of that user
            if($node->hasField('field_seller_first_name')){
                $first_name = $node->field_seller_first_name->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_last_name')){
                $last_name = $node->field_seller_last_name->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_social_id')){
                $social_id = $node->field_seller_social_id->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_social_id_issue_dat')){
                $social_id_issue_date = $node->field_seller_social_id_issue_dat->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_birth_date')){
                $birth_date = $node->field_seller_birth_date->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_gender')){
                $gender = $node->field_seller_gender->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_email')){
                $email = $node->field_seller_email->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_email_2')){
                $email_2 = $node->field_seller_email_2->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_phone')){
                $phone = $node->field_seller_phone->getValue()[0]['value'];
            } else {
                $phone = "+1";
            }
            
            if($node->hasField('field_seller_bank_code')){
                $bank_code = $node->field_seller_bank_code->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_bank_branch')){
                $bank_branch = $node->field_seller_bank_branch->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_bank_account_number')){
                $bank_account_number = $node->field_seller_bank_account_number->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_website_url')){
                $website_url = $node->field_seller_website_url->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_merchant_name')){
                $merchant_name = $node->field_seller_merchant_name->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_country')){
                $country = $node->field_seller_country->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_city')){
                $city = $node->field_seller_city->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_street')){
                $street = $node->field_seller_street->getValue()[0]['value'];
            }

            if($node->hasField('field_seller_house_number')){
                $house_number = $node->field_seller_house_number->getValue()[0]['value'];
            }

            $button_text = t('Update');
        } else {
            $button_text = t('Save');
        }

        //die;








        //Build the form
        $form['#attached']['library'][] = 'bs_form_listaspace/internation-telephone';


        $form['first_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('First name'),
            '#default_value' => $first_name
        ];

        $form['last_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Last name'),
            '#default_value' => $last_name
        ];

        $form['social_id'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Social id'),
            '#default_value' => $social_id
        ];

        $form['social_id_issue'] = array(
            '#type' => 'date',
            '#title' => t('Social id issue date'),
            '#required' => TRUE,
            '#format' => 'm/d/Y',
            '#description' => t('i.e. 12/31/2019'),
            '#default_value' => $social_id_issue_date
        );

        $form['birth_date'] = array(
            '#type' => 'date',
            '#title' => t('Birth date'),
            '#required' => TRUE,
            '#format' => 'm/d/Y',
            '#description' => t('i.e. 12/31/1999'),
            '#default_value' => $birth_date
        );

        $form['gender'] = array(
            '#required' => TRUE,
            '#type' => 'select',
            '#title' => t('Gender'),
            '#options' => $gender_options,
            '#default_value' => $gender
        );

        $form['email'] = [
            '#type' => 'email',
            '#required' => TRUE,
            '#title' => t('Email address'),
            '#default_value' => $email
        ];

        $form['email_2'] = [
            '#type' => 'email',
            '#required' => FALSE,
            '#title' => t('Second email address'),
            '#default_value' => $email_2
        ];

        $form['phone'] = [
            '#required' => TRUE,
            '#type' => 'tel',
            '#title' => t("Phone number"),
            '#default_value' => $phone,
        ];

        $form['bank_code'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Bank code'),
            '#default_value' => $bank_code
        ];

        $form['bank_branch'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Bank branch'),
            '#default_value' => $bank_branch
        ];

        $form['bank_account_number'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Bank account number'),
            '#default_value' => $bank_account_number
        ];

        $form['website_url'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Website URL'),
            '#default_value' => $website_url
        ];

        $form['merchant_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Merchant name'),
            '#default_value' => $merchant_name
        ];

        $form['Country'] = array(
            '#required' => TRUE,
            '#type' => 'select',
            '#title' => t('Country'),
            '#options' => $country_options,
            '#default_value' => $country
        );

        $form['city'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('City'),
            '#default_value' => $city
        ];

        $form['street'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Street'),
            '#default_value' => $street
        ];

        $form['house_number'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('House number'),
            '#default_value' => $house_number
        ];

        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => $button_text,
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];

        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        $fields = $form_state->getValues();

        //USER
        $user_id = \Drupal::currentUser()->id();

        //Load the "CT seller" node of the user
        $nodes = \Drupal::entityTypeManager()
            ->getStorage('node')
            ->loadByProperties(['field_seller_user' => $user_id]);


        //Apply reset() and this returns either the node or NULL if nothing was found
        if ($node_ct_seller = reset($nodes)) {

            //If we are here, update an existing node.

        } else {

            //If we are here, create a new node

            //Language
            $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
            if(!isset($language)){
                $language = "en";
            }

            $node_ct_seller = Node::create([
                // The node entity bundle.
                'type' => 'ct_seller',
                'langcode' => $language,
                'title' => $fields['merchant_name'],
                'field_seller_user' => $user_id]);

            $node_ct_seller->setPublished(true);
            $node_ct_seller->save();
        }


        $node_ct_seller -> field_seller_user = $user_id;
        $node_ct_seller -> field_seller_first_name = $fields['first_name'];
        $node_ct_seller -> field_seller_last_name = $fields['last_name'];
        $node_ct_seller -> field_seller_social_id = $fields['social_id'];
        $node_ct_seller -> field_seller_social_id_issue_dat = $fields['social_id_issue'];
        $node_ct_seller -> field_seller_birth_date = $fields['birth_date'];
        $node_ct_seller -> field_seller_gender = $fields['gender'];
        $node_ct_seller -> field_seller_email = $fields['email'];
        $node_ct_seller -> field_seller_email_2 = $fields['email_2'];
        $node_ct_seller -> field_seller_phone = $fields['phone'];
        $node_ct_seller -> field_seller_bank_code = $fields['bank_code'];
        $node_ct_seller -> field_seller_bank_branch = $fields['bank_branch'];
        $node_ct_seller -> field_seller_bank_account_number = $fields['bank_account_number'];
        $node_ct_seller -> field_seller_website_url = $fields['website_url'];
        $node_ct_seller -> field_seller_merchant_name = $fields['merchant_name'];
        $node_ct_seller -> field_seller_country = $fields['Country'];
        $node_ct_seller -> field_seller_city = $fields['city'];
        $node_ct_seller -> field_seller_street = $fields['street'];
        $node_ct_seller -> field_seller_house_number = $fields['house_number'];



        /*
        //Create a new one
        $node_ct_seller = Node::create([
            // The node entity bundle.
            'type' => 'ct_seller',
            'langcode' => $language,
            'title' => $fields['merchant_name'],
            'field_seller_user' => $user_id,
            'field_seller_first_name' => $fields['first_name'],
            'field_seller_last_name' => $fields['last_name'],
            'field_seller_social_id' => $fields['social_id'],
            'field_seller_social_id_issue_dat' => $fields['social_id_issue'],
            'field_seller_birth_date' => $fields['birth_date'],
            'field_seller_gender' => $fields['gender'],
            'field_seller_email' => $fields['email'],
            'field_seller_email_2' => $fields['email_2'],
            'field_seller_phone' => $fields['phone'],
            'field_seller_bank_code' => $fields['bank_code'],
            'field_seller_bank_branch' => $fields['bank_branch'],
            'field_seller_bank_account_number' => $fields['bank_account_number'],
            'field_seller_website_url' => $fields['website_url'],
            'field_seller_merchant_name' => $fields['merchant_name'],
            'field_seller_country' => $fields['Country'],
            'field_seller_city' => $fields['city'],
            'field_seller_street' => $fields['street'],
            'field_seller_house_number' => $fields['house_number'],
        ]);
        */


        $node_ct_seller->setPublished(true);
        $node_ct_seller->save();




    }

}
