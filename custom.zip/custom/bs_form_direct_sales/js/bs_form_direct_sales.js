jQuery(function($) {'use strict';
    $(document).ready(function(){


        var arr_property_ids = [];
        $('#edit-properties option').each(function() {
            var val =  $(this).val();
            arr_property_ids.push(val);
        });

        //Make the multi select with checkboxes - https://www.jqueryscript.net/form/jQuery-Plugin-For-Multiple-Select-With-Checkboxes-multi-select-js.html
        $('#edit-properties').multiSelect();
        /*$('#edit-properties').multiSelect({
            'noneText': '-- Select --',
            'allText': 'All properties',
            presets: [
                {
                    name: 'None',
                    options: []
                },
                {
                    name: 'All',
                    options: arr_property_ids
                }
            ]
        });*/

        //SET THE DISPLAY AREA
        //Minimum date for display area
        document.getElementById("edit-date-date").min = new Date().toISOString().split("T")[0];

        //Get times and populate on the display area
        var str_times = $("input[name='arr_times']").val();
        var arr_times = str_times.split(" ");
        var my_select = $('.time');
        $.each(arr_times, function(val, text) {
            my_select.append(
                $('<option></option>').val(val).html(text)
            );
        });

        //Get number of people and populate on the display area
        var str_people = $("input[name='arr_people']").val();
        var arr_people = str_people.split(" ");
        var my_select = $('#people');
        $.each(arr_people, function(val, text) {
            my_select.append(
                $('<option></option>').val(val).html(text)
            );
        });

        //Get number of people and populate on the display area
        var str_activities = $("input[name='arr_activities']").val();
        var arr_activities = str_activities.split(" ");
        var my_select = $('#sel_activity');
        $.each(arr_activities, function(val, text) {
            my_select.append(
                $('<option></option>').val(val).html(text)
            );
        });

        update_display();
        //END SET THE DISPLAY AREA

        //Change language
        $("#edit-language").on("change",function(){
            update_display();
        });

        //Change from vertical to horizontal
        $('#edit-widget-display').change(function() {
            update_display();
        });

        //Change the widget type
        $('#edit-widget-type').change(function() {
            update_display();
        });

        //Change the properties on the display area
        $('#edit-property').change(function() {
            update_display();
        });

        //Change the font color
        $("#edit-font-color").on("change",function(){
            update_display();
        });

        //Change the bg color
        $("#edit-bg-color").on("change",function(){
            update_display();
        });

        //Change the button color
        $("#edit-button-color").on("change",function(){
            update_display();
        });

        $("#edit-button-text").on("change",function(){
            update_display();
        });
    });




    //Update the display area. We put this function here so we can call it when there is a change and also on page load
    function update_display(){

        //Language
        var lang = $("#edit-language").val();
        //alert(lang);
        if(lang == "he"){
            //Hebrew
            $('#direct_sales_tool_display').css("direction", "rtl");
            $('#direct_sales_tool_display .float_right').css("float", "left");
            $('#direct_sales_tool_display .header').text('הזמנת חדר פגישות שמתאים לצרכיכם');
            $('#direct_sales_tool_display .lbl_property').text('נכס');
            $('#direct_sales_tool_display .lbl_date').text('תאריך');
            $('#direct_sales_tool_display .lbl_meeting_time').text('מועד הזמנה');
            $('#direct_sales_tool_display .lbl_people').text('אנשים');
            $('#direct_sales_tool_display .lbl_activities').text('פעילות');
        } else {
            //English
            $('#direct_sales_tool_display').css("direction", "ltr");
            $('#direct_sales_tool_display .float_right').css("float", "right");
            $('#direct_sales_tool_display .header').text('Book a meeting room that fits your needs');
            $('#direct_sales_tool_display .lbl_property').text('Property');
            $('#direct_sales_tool_display .lbl_date').text('Date');
            $('#direct_sales_tool_display .lbl_meeting_time').text('Meeting time');
            $('#direct_sales_tool_display .lbl_people').text('People');
            $('#direct_sales_tool_display .lbl_activities').text('Activities');
        }


        //Change from vertical to horizontal
        var display_type = '';
        $("#edit-widget-display option:selected").each(function() {
            display_type =  $( this ).val();
            if(display_type == "Vertical"){
                $('#direct_sales_tool_display').removeClass('horizontal');
                $('.non_button').removeClass('hidden');
                $('.button_only').addClass('hidden');
            } else if(display_type == "Horizontal"){
                $('#direct_sales_tool_display').addClass('horizontal');
                $('.non_button').removeClass('hidden');
                $('.button_only').addClass('hidden');
            } else if(display_type == "Button"){
                $('#direct_sales_tool_display').removeClass('horizontal');
                $('.non_button').addClass('hidden');
                $('.button_only').removeClass('hidden');
            }
        });

        //Change the button text
        var button_text = $("#edit-button-text").val();
        $(".btn_find_a_space").text(button_text);

        //Change the widget type
        $("#edit-widget-type option:selected").each(function() {
            var val =  $( this ).val();
            if(val == "Date"){
                $('#date_type').show();
                $('#activity_type').hide();
                $('#direct_sales_tool_display').addClass('date');
                $('#direct_sales_tool_display').removeClass('activity');
            } else if(val == "Activity"){
                $('#activity_type').show();
                $('#date_type').hide();
                $('#direct_sales_tool_display').addClass('activity');
                $('#direct_sales_tool_display').removeClass('date');
            }
        });

        //Change the properties on the display area
        $("#sel_properties").find('option').remove();//Remove all properties
        $("#edit-property option:selected").each(function() {
            var val =  $(this).val();
            var text =  $(this).text();
            alert(val);

            //Add new option
            $("#sel_properties").append(
                $('<option></option>').val(val).html(text)
            );
        });

        //Change the font color
        var color = $("#edit-font-color").val();
        $(".gray_border").css("color", color);

        //Change the bg color
        if(display_type == "Button"){
            var color = '#FAFAFA';
            $(".gray_border").css("background-color", color);
        } else {
            var color = $("#edit-bg-color").val();
            $(".gray_border").css("background-color", color);
        }


        //Change the button color
        var color = $("#edit-button-color").val();
        $(".btn_find_a_space").css("background-color", color);
    }
});