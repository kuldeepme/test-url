<?php

namespace Drupal\bs_form_direct_sales\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_direct_sales_kpi_select form.
 *
 * @Block(
 *   id = "bs_form_direct_sales_kpi_select_block",
 *   admin_label = @Translation("bs_form_direct_sales_kpi_select_block"),
 *   category = @Translation("bs_form_direct_sales_kpi_select"),
 * )
 */
class bs_form_direct_sales_kpi_select_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_direct_sales\Form\BsFormDirectSalesKpiSelect');
        return $form;
    }

}
