<?php

namespace Drupal\bs_form_direct_sales\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_direct_sales form.
 *
 * @Block(
 *   id = "bs_form_direct_sales_block",
 *   admin_label = @Translation("bs_form_direct_sales_block"),
 *   category = @Translation("bs_form_direct_sales"),
 * )
 */
class bs_form_direct_sales_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_direct_sales\Form\BsFormDirectSales');
        return $form;
    }

}
