<?php
/**
 * @file
 * Contains \Drupal\bs_form_direct_sales\Form\BsFormDirectSales.
 */
namespace Drupal\bs_form_direct_sales\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;

class BsFormDirectSales extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_form_direct_sales';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {

        $btn_text = t('CREATE MY BOOKING ENGINE');

        //Get id in case we edit
        if(isset($_REQUEST['id'])){
            $edit_id = $_REQUEST['id'];
            $ct_direct_sales = Node::load($edit_id);

            if(isset($ct_direct_sales)) {
                $language = $ct_direct_sales->langcode->getString();
                $title = $ct_direct_sales->getTitle();
                $button_text = $ct_direct_sales->field_button_text->getString();
                $website_url = $ct_direct_sales->field_website_url->getString();
                $site_name = $ct_direct_sales->field_site_name->getString();
                $widget_display_type = $ct_direct_sales->field_widget_display_type->getString();
                $widget_content_type = $ct_direct_sales->field_widget_content_type->getString();
                $font_color = $ct_direct_sales->field_font_color->getString();
                $background_color = $ct_direct_sales->field_background_color->getString();
                $button_color = $ct_direct_sales->field_button_color->getString();
                $field_logo = $ct_direct_sales->field_logo->getValue()[0]['target_id'];

                $arr_properties_default_values = [];

                $arr_field_properties = $ct_direct_sales->field_properties;
                foreach($arr_field_properties as $key => $value){
                    array_push($arr_properties_default_values, $value->getValue()['target_id']);
                }
            }

            $btn_text = t('UPDATE MY BOOKING ENGINE');
        }

        //For the select that asks the user which language to add
        $form['language'] = array(
            '#type' => 'select',
            '#title' => t('Preferred language'),
            '#options' => get_system_languages_for_ddl(),
            '#default_value' => isset($language) ? $language : get_current_language()
        );

        $form['title'] = [
            '#type' => 'textfield',
            '#title' => t("Title"),
            '#required' => TRUE,
            '#attributes' => [
                'placeholder' => array('My London offices'),
            ],
            '#default_value' => isset($title) ? $title : NULL,
        ];

        $form['button_text'] = [
            '#type' => 'textfield',
            '#title' => t("Text on button"),
            '#required' => TRUE,
            '#attributes' => [
                'placeholder' => array('FIND A SPACE'),
            ],
            '#default_value' => isset($button_text) ? $button_text : "FIND A SPACE",
            '#maxlength' => 15,
        ];


        $arr_properties = get_current_user_properties();
        $form['properties'] = [
            '#type' => 'select',
            '#title' => t("Choose your properties"),
            '#required' => TRUE,
            '#options' => $arr_properties,
            '#multiple' => TRUE,
            '#attributes' => array(
                'multiple' => TRUE
            ),
            '#default_value' => $arr_properties_default_values
        ];

        $form['website'] = [
            '#type' => 'textfield',
            '#title' => t("Your website domain"),
            '#required' => TRUE,
            '#attributes' => [
                'placeholder' => array('yourwebsite.com'),
            ],
            '#default_value' => isset($website_url) ? $website_url : NULL,
        ];

        $form['website_name'] = [
            '#type' => 'textfield',
            '#title' => t("Site name"),
            '#required' => TRUE,
            '#attributes' => [
                'placeholder' => array('Your venue name'),
            ],
            '#default_value' => isset($site_name) ? $site_name : NULL,
        ];

        $form['property_logo'] = [
            '#type' => 'managed_file',
            '#title' => t("Choose your logo"),
            '#upload_location' => 'public://direct-sales-tool-images/',
            '#default_value' => isset($field_logo) ? array($field_logo) : NULL,
        ];

        $arr_widget_display = ["Vertical" => "Vertical", "Horizontal" => "Horizontal", "Button" => "Button"];
        $form['widget_display'] = [
            '#type' => 'select',
            '#required' => FALSE,
            '#options' => $arr_widget_display,
            '#default_value' => isset($widget_display_type) ? $widget_display_type : NULL,
        ];


        $arr_widget_types = ["Date" => "Time & Date", "Activity" => "Activity"];
        $form['widget_type'] = [
            '#type' => 'select',
            '#required' => FALSE,
            '#options' => $arr_widget_types,
            '#default_value' => isset($widget_content_type) ? $widget_content_type : NULL,
        ];


        $form['font_color'] = array(
            '#type' => 'color',
            '#title' => $this->t('Font color'),
            '#default_value' => isset($font_color) ? $font_color : '#000',
        );

        $form['bg_color'] = array(
            '#type' => 'color',
            '#title' => $this->t('Background color'),
            '#default_value' => isset($background_color) ? $background_color : '#ffffff',
        );

        $form['button_color'] = array(
            '#type' => 'color',
            '#title' => $this->t('Button color'),
            '#default_value' => isset($button_color) ? $button_color : '#ce1644',
        );







        //FOR THE DISPLAY SECTION
        //Get times for the display area. We put it in a hidden field and copy to the display section by jQuery on bs_form_direct_sales.js
        $arr_times = select_list_times();
        $form['arr_times'] = [
            '#type' => 'hidden',
            '#value' => $arr_times,
        ];

        //Get number of people for the display area. We put it in a hidden field and copy to the display section by jQuery on bs_form_direct_sales.js
        $arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', false);
        $arr_number_of_people = [0 => 'Any'] + $arr_number_of_people;
        $form['arr_people'] = [
            '#type' => 'hidden',
            '#value' => $arr_number_of_people,
        ];

        //Create an array of space activities
        $arr_activities = [];
        $arr_space_activities = get_space_activities_values();
        foreach($arr_space_activities as $key => $category){
            array_push($arr_activities, $key);
            foreach($category as $key_cat => $value){
                array_push($arr_activities, $value);
            }
        }
        $form['arr_activities'] = [
            '#type' => 'hidden',
            '#value' => $arr_activities,
        ];


        $form['#attached']['library'][] = 'bs_form_direct_sales/bs_form_direct_sales';
        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => $btn_text,
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        $form['node_obj'] = array(
            '#type' => 'value',
            '#value' => $node,
        );
        return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {


        $fields = $form_state->getValues();

        //kint($fields);die;

        $language = $fields['language'];
        $title = $fields['title'];
        $button_text = $fields['button_text'];
        $properties = $fields['properties'];
        $website = $fields['website'];
        $website_name = $fields['website_name'];
        $widget_display = $fields['widget_display'];
        $widget_type = $fields['widget_type'];
        $font_color = $fields['font_color'];
        $bg_color = $fields['bg_color'];
        $button_color = $fields['button_color'];


        //Handle the property logo image: get the file id and save it permanently - drupal adds it on tables file_uses OR file_managed
        if(isset($fields["property_logo"][0])){
            $property_logo_file_id = $fields["property_logo"][0];
            //kint($property_logo_file_id);die;
            $file1 = File::load($property_logo_file_id);
            $file1->setPermanent();
            $file1->save();
        }


        //$language = \Drupal::languageManager()->getCurrentLanguage()->getId();
        //if(!isset($language)){
            //$language = "en";
        //}
        //USER
        $user = \Drupal::currentUser();


        if(isset($_REQUEST['id'])) {

            //If we are here to update
            $edit_id = $_REQUEST['id'];
            $ct_direct_sales = Node::load($edit_id);
            $ct_direct_sales -> langcode = $language;
            $ct_direct_sales -> title = $title;
            $ct_direct_sales -> field_button_text = $button_text;
            $ct_direct_sales -> field_properties = $properties;
            $ct_direct_sales -> field_website_url = $website;
            $ct_direct_sales -> field_site_name = $website_name;
            $ct_direct_sales -> field_widget_display_type = $widget_display;
            $ct_direct_sales -> field_widget_content_type = $widget_type;
            $ct_direct_sales -> field_font_color = $font_color;
            $ct_direct_sales -> field_background_color = $bg_color;
            $ct_direct_sales -> field_button_color = $button_color;
            $ct_direct_sales -> field_logo = $property_logo_file_id;
            $ct_direct_sales -> save();

        } else {

            //Create a new one
            $node_ct_direct_sales_tool = Node::create([
                // The node entity bundle.
                'type' => 'ct_direct_sales_tool',
                'langcode' => $language,
                'uid' => $user->id(),
                'title' => $title,
                'field_button_text' => $button_text,
                'field_properties' => $properties,
                'field_website_url' => $website,
                'field_site_name' => $website_name,
                'field_widget_display_type' => $widget_display,
                'field_widget_content_type' => $widget_type,
                'field_font_color' => $font_color,
                'field_background_color' => $bg_color,
                'field_button_color' => $button_color,
                'field_logo' => $property_logo_file_id,
            ]);
            $node_ct_direct_sales_tool->setPublished(true);
            $node_ct_direct_sales_tool->save();
        }

        $redirect_path = '/personal_area/direct_sales_tool';
        $path = URL::fromUserInput($redirect_path)->toString();
        $response = new RedirectResponse($path);
        $response->send();
    }
}
