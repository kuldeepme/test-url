<?php
/**
 * @file
 * Contains \Drupal\bs_form_direct_sales\Form\BsFormDirectSales.
 */
namespace Drupal\bs_form_direct_sales\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;

class BsFormDirectSalesKpiSelect extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_form_direct_sales_kpi_select';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {

        //Build array of 10 to 120 days
        $arr_options = [];
        for($i=10; $i <= 120; $i += 10){
            $arr_options[$i] = "KPI's for the last $i days";
        }

        $int_days = 30;
        if(isset($_SESSION["direct_sales_tool_kpi_days"])){
            $int_days = $_SESSION["direct_sales_tool_kpi_days"];
        }

        $form['kpi'] = [
            '#type' => 'select',
            '#required' => FALSE,
            '#options' => $arr_options,
            '#attributes' => array('onchange' => 'this.form.submit();'),
            '#default_value' => $int_days,
        ];
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => "Submit",
            '#attributes' => [
                'class' => ['hidden']
            ],
        ];
        return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {

        $fields = $form_state->getValues();
        $int_days = $fields['kpi'];
        $_SESSION["direct_sales_tool_kpi_days"] = $int_days;
    }
}
