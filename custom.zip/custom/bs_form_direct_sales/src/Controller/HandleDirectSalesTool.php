<?php

namespace Drupal\bs_form_direct_sales\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\language\Plugin\LanguageNegotiation;


/**
 * Provides handling for the direct sales tool click
 */
class HandleDirectSalesTool extends ControllerBase {

    /**
     * Render location node content.
     */
    /*public function content() {
        $id = $_REQUEST["id"];
        echo $id . "<br/>";

        $edit_id = $_REQUEST['id'];
        $ct_direct_sales = Node::load($edit_id);
        kint($ct_direct_sales);

        die('HELLO');

        //Return the page with everything around..
        //$build = [
            //'#markup' => $this->t($id),
        //];
        //return $build;
    }*/

    public function content(NodeInterface $node) {


        $language = $node->langcode->getString();

        $redirect_path = get_language_domains($language);

        //Add new search results record (2) to the KPIs
        $new_record_id = add_direct_sales_tool_kpi($node->id(), 2);

        $time_cookie_expire = 60; //60 minutes - 1 hour

        //Save in the SESSION that the user is “DIRECT_SALES”
        create_cookie('direct_sales_tool_id', $node->id(), $time_cookie_expire);
        //create_cookie('direct_sales_tool_id', 0); //REMOVE COOKIE!!!

        //Get BG color and font color and save in SESSION
        $bg_color = $node->field_background_color->getValue()[0]["value"];
        $font_color = $node->field_font_color->getValue()[0]["value"];
        create_cookie('bg_color', $bg_color, $time_cookie_expire);
        create_cookie('font_color', $font_color, $time_cookie_expire);








        $property_id = $_REQUEST["property"];
        if (strpos($property_id, ',') !== false) {

            //$property_ids = urlencode($property_id);
            $property_ids = urldecode($property_id);
            //kint($property_ids); die;
            //This is a CSV of properties. Redirect to search_results page
            $redirect_path .= "/search_results?properties=$property_ids&";


        } else {

            //this is a single property. Check if it has single or multiple spaces
            $property = $node::load($property_id);
            if($property){
                if($property->hasField('field_property_spaces')){
                    $arr_properties = $property->field_property_spaces->getValue();

                    if(count($arr_properties) > 1){

                        //The property has more then 1 spaces so redirect to the property page
                        $redirect_path .= "/node/$property_id?";
                    } else {

                        //The property has 1 space so get this space id and redirect there
                        $space_id = $arr_properties[0]["target_id"];
                        $redirect_path .= "/node/$space_id?";
                    }
                }
            }
        }

        $activity_id = $_REQUEST["activities"];
        if($activity_id != "undefined"){
            $redirect_path .= "activities=$activity_id";
        }

        $date = $_REQUEST["date"];
        if($date != "undefined"){
            $redirect_path .= "&date=$date";
        }

        $from_time = $_REQUEST["start_time"];
        if($from_time != "undefined"){
            $redirect_path .= "&start_time=$from_time";
        }

        $to_time = $_REQUEST["end_time"];
        if($to_time != "undefined"){
            $redirect_path .= "&end_time=$to_time";
        }

        $people = $_REQUEST["people"];
        if($people != "undefined"){
            $redirect_path .= "&booking_people=$people";
        }

        if(!$redirect_path || $redirect_path == ""){
            $redirect_path .= "/search_results";
        }

        //$path = URL::fromUserInput($redirect_path)->toString();
        //$response = new RedirectResponse($path);
        $response = new RedirectResponse($redirect_path);
        $response->send();
        die;
    }

}
