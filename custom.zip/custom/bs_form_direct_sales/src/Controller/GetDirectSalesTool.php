<?php

namespace Drupal\bs_form_direct_sales\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;


/**
 * Provides route responses for map location routing.
 */
class GetDirectSalesTool extends ControllerBase {

    /**
     * Render location node content.
     */
    /*public function content() {
        $id = $_REQUEST["id"];
        echo $id . "<br/>";

        $edit_id = $_REQUEST['id'];
        $ct_direct_sales = Node::load($edit_id);
        kint($ct_direct_sales);

        die('HELLO');

        //Return the page with everything around..
        //$build = [
            //'#markup' => $this->t($id),
        //];
        //return $build;
    }*/

    public function content(NodeInterface $node) {

        //$build = [
            //'#markup' => $this->t("hello"),
        //];
        //return $build;




        //Header to allow CORS
        header('Access-Control-Allow-Origin: *');



        //kint($node);
        //$title = $node->getTitle();



        //Make sure that the referer URL, that contains the code, is allowed. If not, show a msg and die
        $website_url = $node->field_website_url->getValue()[0]['value'];
        $base_url = parse_url($_SERVER["HTTP_REFERER"], PHP_URL_HOST);
        if ($base_url != "" && strpos($website_url, $base_url) === false) {
            echo('Accessing from URL "' . $base_url . '" is not allowed!');
            die;
        }


        $language = $node->langcode->getValue()[0]['value'];
        $widget_display_type = $node->field_widget_display_type->getValue()[0]['value'];
        $widget_content_type = $node->field_widget_content_type->getValue()[0]['value'];
        $background_color = $node->field_background_color->getValue()[0]['value'];
        $font_color = $node->field_font_color->getValue()[0]['value'];
        $button_color = $node->field_button_color->getValue()[0]['value'];
        $button_text = $node->field_button_text->getValue()[0]['value'];

        switch ($language) {

            case "en":
                $style_direction = "ltr";
                $lbl_header = 'Book a meeting room that fits your needs';
                $lbl_property = 'Property';
                $lbl_date = 'Date';
                $lbl_meeting_time = 'Meeting time';
                $lbl_people = 'People';
                $lbl_activities = 'Activities';
                $lbl_all = 'All';
                break;
            case "he":
                $style_direction = "rtl";
                $lbl_header = 'הזמנת חדר פגישות שמתאים לצרכיכם';
                $lbl_property = 'נכס';
                $lbl_date = 'תאריך';
                $lbl_meeting_time = 'מועד הזמנה';
                $lbl_people = 'אנשים';
                $lbl_activities = 'פעילות';
                $lbl_all = 'הכל';
                break;
        }


        //Arr number of people
        $arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', false);

        //get times
        $arr_times = select_list_times();

        //Get array of property ids
        $arr_property_ids = $node->field_properties->getValue();
        $csv_property_ids = "";
        $arr_tmp_property_ids = array();
        foreach($arr_property_ids as $property_id){
            array_push($arr_tmp_property_ids, $property_id['target_id']);

            //Build CSV of space ids for the button option
            if($csv_property_ids != ""){
                $csv_property_ids .= ",";
            }
            $csv_property_ids .= $property_id['target_id'];
        }

        //Load array of properties
        $arr_properties = \Drupal\node\Entity\Node::loadMultiple($arr_tmp_property_ids);
        //kint($arr_properties);

        //Run on array of properties and get the spaces of each
        $arr_spaces_ids = [];
        foreach($arr_properties as $nid => $property){
            $arr_spaces = $property->field_property_spaces->getValue();

            //Run on array of spaces and create a list of all spaces
            foreach($arr_spaces as $space_id => $space){
                array_push($arr_spaces_ids, $space["target_id"]);
            }
        }

        //Now, load all spaces and get their activities
        $arr_spaces = \Drupal\node\Entity\Node::loadMultiple($arr_spaces_ids);

        $arr_tmp_activity_ids = [];
        foreach($arr_spaces as $space){
            //kint($space);
            if(isset($space->field_space_activities)){
                $arr_activity_ids = $space->field_space_activities->getValue();
                //kint($arr_activity_ids);
                foreach($arr_activity_ids as $activity_id){
                    if($activity_id["target_id"] > 0){
                        array_push($arr_tmp_activity_ids, $activity_id["target_id"]);
                    }
                }
            }
        }

        $terms = Term::loadMultiple($arr_tmp_activity_ids);


        //$host = \Drupal::request()->getHost();
        //\Drupal::request()->getBasePath();
        //kint(\Drupal::request());
        $host = \Drupal::request()->getHttpHost();
        $full_schema_host = \Drupal::request()->getSchemeAndHttpHost();


        //Create the CUSTOM CSS
        $str_css = "<style>";
        $str_css .= ".bookaspace_direct_sales_tool > div{background-color: $background_color; padding:20px;}";
        $str_css .= ".bookaspace_direct_sales_tool{color: $font_color;}";
        $str_css .= ".bookaspace_direct_sales_tool button{background-color: $button_color; color:$font_color;}";
        $str_css .= "</style>";

        //Create the HTML
        $str_html = $str_css;
        $str_html .= '<link rel="stylesheet" href="'. $full_schema_host .'/themes/bookaspace/css/direct_sales_tool.css">';
        $str_html .= '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>';
        $str_html .= '<script src="'. $full_schema_host .'/themes/bookaspace/js/direct_sales_tool.js"></script>';

        if($widget_display_type == "Button"){

            //BUTTON ONLY WIDGET
            $str_html .= "<div class='bookaspace_direct_sales_tool $style_direction' style='direction:$style_direction;'><button onclick='click_handler(" . $node->id() . ", \"$host\", \"$csv_property_ids\");'>".$button_text."</button></div>";
        } else {

            //NON BUTTON WIDGET
            $str_html .= "<div class='bookaspace_direct_sales_tool $style_direction' style='direction:$style_direction;'>";
            $str_html .= "<div>"; //Inner div so the background color will be here and not in the button

            //Title
            $str_html .= "<div class='title'>$lbl_header</div>";

            $str_html .= "<div class='$widget_display_type $widget_content_type'>";

            //Property DDL
            $str_html .= "<div class='property_wrapper'>";
            $str_html .= "<label>$lbl_property</label>";
            $str_html .= "<select id='sel_properties'>";

            $str_html .= "<option value='0'>$lbl_all</option>";

            //Fill up properties
            foreach($arr_properties as $nid=>$property){
                $str_html .= "<option value='$nid'>" . $property->getTitle() . "</option>";
            }
            $str_html .= "</select>";
            $str_html .= "</div>";

            //Other fields according to widget_content_type "Activity" OR "Date"
            if($widget_content_type == "Activity"){

                //ACTIVITY FIELDS
                $str_html .= "<div class='activity_wrapper'>";
                $str_html .= "<label>$lbl_activities</label>";
                $str_html .= "<select id='sel_activities'>";

                $str_html .= "<option value='0'>$lbl_all</option>";

                //Fill up activities of all spaces of all properties
                foreach($terms as $key => $term){
                    $str_html .= "<option value='$key'>" . $term->getName() . "</option>";
                }

                $str_html .= "</select>";
                $str_html .= "</div>";

                //Button
                $str_html .= "<div class='button_wrapper'>";
                $str_html .= "<button onclick='click_handler(" . $node->id() . ", \"$host\");'>".$button_text."</button>";
                $str_html .= "</div>";

            } else if($widget_content_type == "Date"){

                //DATE & TIME FIELDS
                $str_html .= "<div class='date_time_wrapper'>";

                //First line when vertical
                $str_html .= "<div class='first_line'>";
                $str_html .= "<div class='date_wrapper'>";
                $str_html .= "<label>$lbl_date</label>";
                $str_html .= "<input id='input_date' type='date' min='" . date("Y-m-d") . "'>";
                $str_html .= "</div>";

                $str_html .= "<div class='meeting_time'>";
                $str_html .= "<label>$lbl_meeting_time</label>";
                $str_html .= "<select id='sel_start_time'>";
                foreach($arr_times as $key => $term){
                    $str_html .= "<option value='$key'>" . $term . "</option>";
                }
                $str_html .= "</select>";
                $str_html .= "<select id='sel_end_time'>";
                foreach($arr_times as $key => $term){
                    $str_html .= "<option value='$key'>" . $term . "</option>";
                }
                $str_html .= "</select>";
                $str_html .= "</div>";
                $str_html .= "</div>";

                //Second line when vertical
                $str_html .= "<div class='second_line'>";
                $str_html .= "<div class='people_wrapper'>";
                $str_html .= "<label class='people'>$lbl_people</label>";
                $str_html .= "<select id='sel_people'>";
                foreach($arr_number_of_people as $key => $term){
                    $str_html .= "<option value='$key'>" . $term . "</option>";
                }
                $str_html .= "</select>";
                $str_html .= "</div>";

                //Button
                $str_html .= "<div class='button_wrapper'>";
                $str_html .= "<button onclick='click_handler(" . $node->id() . ", \"$host\");'>".$button_text."</button>";
                $str_html .= "</div>";

                $str_html .= "</div>";

                $str_html .= "</div>";

            }



            $str_html .= "</div>";

            $str_html .= "</div>";

            $str_html .= "</div>";
        }




        //Add new view record (1) to the KPIs
        $new_record_id = add_direct_sales_tool_kpi($node->id(), 1);


        echo $str_html;
        die();

        //die;
    }

}
