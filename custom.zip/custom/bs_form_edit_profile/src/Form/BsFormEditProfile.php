<?php

namespace Drupal\bs_form_edit_profile\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\file\Entity\File;
use CommerceGuys\Addressing\AddressFormat\AddressField;
use CommerceGuys\Addressing\AddressFormat\FieldOverride;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * Provides a form for edit property.
 *
 * @internal
 */
class BsFormEditProfile extends FormBase
{

    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {
        return 'bs_form_edit_profile';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL)
    {

        //Get user details
        $user = get_user_details();
        //kint($user);

        $email = "";
        if(isset($user->mail->getValue()[0]['value'])){
            $email = $user->mail->getValue()[0]['value'];
        }


        if(isset($user->field_user_preferred_currency->getValue()[0]['target_id'])){
            $currency = $user->field_user_preferred_currency->getValue()[0]['target_id'];
        }

        $first_name = "";
        if(isset($user->field_user_first_name->getValue()[0]['value'])){
            $first_name = $user->field_user_first_name->getValue()[0]['value'];
        }

        $last_name = "";
        if(isset($user->field_user_last_name->getValue()[0]['value'])){
            $last_name = $user->field_user_last_name->getValue()[0]['value'];
        }

        $description = "";
        if(isset($user->field_user_description->getValue()[0]['value'])){
            $description = $user->field_user_description->getValue()[0]['value'];
            $description = remove_p_tag($description);
        }

        $phone = "+1";
        if(isset($user->field_user_phone->getValue()[0]['value'])){
            $phone = $user->field_user_phone->getValue()[0]['value'];
        }

        $lang = "en";
        if(isset($user->preferred_langcode->getValue()[0]['value'])){
            $lang = $user->preferred_langcode->getValue()[0]['value'];
        }

        $user_image = "";
        if(isset($user->field_user_image->getValue()[0]['target_id'])){
            $user_image = $user->field_user_image->getValue()[0]['target_id'];
        }
        //kint($user_image);die;




        //Build the form
        $form['#attached']['library'][] = 'bs_form_listaspace/internation-telephone';

        $form['email'] = [
            '#type' => 'email',
            '#required' => TRUE,
            '#title' => t('Email address'),
            '#default_value' => $email
        ];

        $form['first_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('First name'),
            '#default_value' => $first_name
        ];

        $form['last_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#title' => t('Last name'),
            '#default_value' => $last_name
        ];

        $form['description'] = [
            '#type' => 'textarea',
            '#required' => TRUE,
            '#title' => t('Description'),
            '#default_value' => $description
        ];

        $form['phone'] = [
            '#type' => 'tel',
            '#title' => t("Phone number"),
            '#default_value' => $phone,
        ];


        $form['language'] = array(
            '#type' => 'select',
            '#title' => t('Preferred language'),
            '#options' => get_system_languages_for_ddl(),
            '#default_value' => $lang
        );

        $form['currency'] = array(
            '#type' => 'select',
            '#title' => t('Preferred currency'),
            '#options' => get_system_currencies(),
            '#default_value' => $currency
        );

        $form['user_image'] = [
            '#type' => 'managed_file',
            '#title' => t("Profile picture"),
            '#upload_location' => 'public://property-images/',
            '#default_value' => [$user_image]
        ];

        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => t('Save'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];

        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        $fields = $form_state->getValues();
        //kint($fields);
        //kint($fields['first_name']);

        //kint($fields['language']);
        //die;


        //Load existing user
        $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());

        $user->setEmail($fields['email']);
        $user->set("langcode", $fields['language']);
        $user->preferred_langcode = $fields['language'];

        $user->field_user_first_name = $fields['first_name'];
        $user->field_user_last_name = $fields['last_name'];
        $user->field_user_description = $fields['description'];
        $user->field_user_phone = $fields['phone'];
        $user->field_user_preferred_currency = $fields['currency'];

        //User image
        if (isset($fields["user_image"][0])) {
            $user_image_file_id = $fields["user_image"][0];
            $file = File::load($user_image_file_id);
            $file->setPermanent();
            $file->save();
            //kint($user_image_file_id);
            //die;
            $user->field_user_image = $user_image_file_id;
        }

        //Save user
        $user->save();


    }

}
