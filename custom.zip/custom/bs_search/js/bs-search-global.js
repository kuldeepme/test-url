(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.LotusBehavior = {
    attach: function (context, settings) {
     /* var pickupautocomplete = new google.maps.places.Autocomplete(
        document.getElementById('edit-map-search-box'), {types: ['(regions)']});*/
$("#edit-map-view-control").once("html6").change(function() {
    if(this.checked) {
      if(drupalSettings.mapUrl){        
        SearchInitMap(drupalSettings.mapUrl,'search-map-block');
      }
    }
});
        $( "#slider-range" ).slider({
          range: true,
          min: 0,
          max: 1000,
          values: [ 200, 600 ],
          slide: function( event, ui ) {
            jQuery('#min-price-value').val(ui.values[ 0 ]);
            jQuery('#max-price-value').val(ui.values[ 1 ]);
          }
        });

        $("#lets_fins_a_space").click(function() {
          $("html, body").animate({ scrollTop: 0 }, "slow");
          return false;
        });

        $(".bssf-element-dfv").once("html5").click(function() {
          $(".section-mrooms, #map-block").toggleClass("sec-overlay");
          $(this).parent().find(".dynamic-item").toggleClass('hidden');
          $(this).parent().siblings().find(".dynamic-item").addClass('hidden');
          if (!$(this).parent().find('.dynamic-item').hasClass("hidden")) {
            $(".section-mrooms, #map-block").addClass("sec-overlay");
          }
        });   
        
        $(".view-more").once("html5").click(function(){
          $(".view-more").parent().toggleClass("min-six");
        });

        $('#bs-search a.reset-search-filter', context).on('click', function(event) {
          event.preventDefault();
          var wrapper = $(this).closest('div.bssf-element');
          clearForm(wrapper);
        });

        $('.view-search-property.view-display-id-page_1 nav.pager-nav .pagination > li > a').on('click', function(event) {
          $('#bs-search-view-ajax').remove();
          drupalSettings.mapUrl = $(this).attr('href');
        });

        $('form#bs-search .map-view-control-button', context).on('change', function(event) {
          manageMapContentWidth($(this));
        });

        $('#bs-search a.search-filter', context).on('click', function(event) {
          $('#bs-search-view-ajax').remove();
          event.preventDefault();
          var fields_string = $(this).attr('data-stuff');
          var fields_obj = eval("new Array(" + fields_string + ")");
          var formdata = getFormDataById($('form#bs-search'));
          var params = {};
          var querystring = '';
          
          filterSetLabel();
          clearForm('#views-exposed-form-search-property-page-1');

          $.each(fields_obj, function (index, value) {
            var name = value.name;
            var name2 = value.view_field_name;
            var type = value.type;
            if (name in formdata) {
              if (typeof(formdata[name]) == 'object') {
                var obfieldval = [];
                $.each(formdata[name], function (index1, value1) {
                  if (typeof value1  !== "undefined") {
                    obfieldval.push(value1);
                    if (type == 'select') {
                      $('form#views-exposed-form-search-property-page-1 select[name^="'+name2+'"] option[value="'+value1+'"]').prop("selected", true);
                    }
                    else if(type == 'checkbox' || type == 'radio') {
                      $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"]').prop("checkbox", true);
                    }
                    else {
                      if (type == 'text') {
                        $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"]').val(value1);
                      }
                    }
                  }
                })
                params[name2] = obfieldval;
              }
              else {
                params[name2] = formdata[name];
                if (type == 'select') {
                  $('form#views-exposed-form-search-property-page-1 select[name^="'+name2+'"] option[value="'+formdata[name]+'"]').prop("selected", true);
                }
                else if(type == 'checkbox' || type == 'radio') {
                  $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"]').prop("checkbox", true);
                }
/*                else if (type == 'text') {
                  if (name == 'map_search_box' && formdata[name] != '') {
                    $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"], form#views-exposed-form-search-property-page-1 input[name^="field_property_address_address_line1"]').val(formdata[name]);
                    params['field_property_address_address_line1'] = formdata[name];
                    var country_list = drupalSettings.country_list;
                    var search_string = formdata[name].toLowerCase().replace(/\b[a-z]/g, function(letter) {
                      return letter.toUpperCase();
                    });
                    var country_code = getKeyByValue(country_list, search_string);
                    if (typeof country_code != 'undefined' && country_code) {
                      $('form#views-exposed-form-search-property-page-1 select[name^="field_property_address_country_code"] option[value="'+country_code+'"]').prop("selected", true);
                      params['field_property_address_country_code'] = country_code;
                    }
                  }
                  else {
                    $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"]').val(formdata[name]);
                  }
                }*/
                else if (type == 'text') {
                  if (name == 'map_search_box') {
                    var country_code = $("form#bs-search select[name^=map_search_box] option:selected").val();
                    $("form#bs-search select[name^=map_search_box]").change(function(){
                      country_code = $(this).children("option:selected").val();
                    });
                    if (typeof country_code != 'undefined' && country_code) {
                      var country_code_arr = country_code.split("|");
                      $('form#views-exposed-form-search-property-page-1 select[name^="field_property_address_country_code"] option[value="'+country_code_arr[0]+'"]').prop("selected", "selected");
                      params['field_property_address_country_code'] = country_code_arr[0];
                      $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"], form#views-exposed-form-search-property-page-1 input[name^="field_property_address_address_line1"]').val(country_code_arr[1]);
                      params['field_property_address_address_line1'] = formdata[name];
                    }
                  }
                  else {
                    $('form#views-exposed-form-search-property-page-1 input[name^="'+name2+'"]').val(formdata[name]);
                  }
                }
              }
            }
          });
          var booking_people = $(".form-item-booking-people input[name='booking_people']:checked").val();
          if(typeof booking_people !== "undefined"){
            var booking_people_vals = booking_people.split("-");
            if(booking_people_vals[0]){
              var min_vals = booking_people_vals[0];
              if(booking_people_vals[0] == "101+"){
                $("form#views-exposed-form-search-property-page-1 input[name='field_space_layout_max_participa_value[min]']").val(101);
              }else{
                $("form#views-exposed-form-search-property-page-1 input[name='field_space_layout_max_participa_value[min]']").val(booking_people_vals[0]);
              }
            }
            if(booking_people_vals[1]){
              $("form#views-exposed-form-search-property-page-1 input[name='field_space_layout_max_participa_value[max]']").val(booking_people_vals[1]);           
            }
          }
          // Near by
/*          var parking = $("form#bs-search input[name^=more_filters_parking]:checked").val();
          if(typeof parking !== "undefined"){
            $("form#views-exposed-form-search-property-page-1 select[name^=field_near_by_type_target_id]").val($("form#views-exposed-form-search-property-page-1 select[name^=field_near_by_type_target_id] option:first").val());
          }
          else {
            $("form#views-exposed-form-search-property-page-1 select[name^=field_near_by_type_target_id]").val();
          }*/
          // Parking
          var parking = $("form#bs-search input[name^=more_filters_parking]:checked").val();
          if(typeof parking !== "undefined"){
            $("form#views-exposed-form-search-property-page-1 select[name^=field_property_parking_value]").val($("form#views-exposed-form-search-property-page-1 select[name^=field_property_parking_value] option:last").val());
          }
          else {
            $("form#views-exposed-form-search-property-page-1 select[name^=field_property_parking_value]").val();
          }
          // Restaurant
          var restaurant = $("form#bs-search input[name^=more_filters_restaurant]:checked").val();
          if(typeof restaurant !== "undefined"){
            $("form#views-exposed-form-search-property-page-1 select[name^=field_property_restaurant_value]").val($("form#views-exposed-form-search-property-page-1 select[name^=field_property_restaurant_value] option:last").val());
          }
          else {
            $("form#views-exposed-form-search-property-page-1 select[name^=field_property_restaurant_value]").val();
          }
          var urlParams = new URLSearchParams(window.location.search);
          if (urlParams.has('properties')) {
            var nids = urlParams.get('properties');
            $("form#views-exposed-form-search-property-page-1 input[name^=properties]").val(nids);
            params['properties'] = nids;
          }
          else {
            $("form#views-exposed-form-search-property-page-1 input[name^=properties]").val();
            params['properties'] = "";
          }

          drupalSettings.mapUrl = '?' + $.param(params, true);
          $('form#views-exposed-form-search-property-page-1 button[type="submit"]').trigger( "click" );
          $("form#bs-search .section-mrooms,#bs-search #map-block").removeClass("sec-overlay");
          $("form#bs-search .bssf-element").find(".dynamic-item").addClass("hidden");
        });
        /*$(document, context).once('weberAjaxViews').ajaxSuccess(function (event, data) {
          //alert("basseach");
          if (drupalSettings && drupalSettings.views && drupalSettings.views.ajaxViews) {
            var ajaxViews = drupalSettings.views.ajaxViews;
            Object.keys(ajaxViews || {}).forEach(function (i) {
              if (ajaxViews[i]['view_name'] == 'search_property' &&  ajaxViews[i]['view_display_id'] == 'page_1') {
                if (!$('body').hasClass("fully-loaded")) {
                  $("body").addClass("fully-loaded");
                  setTimeout(function(){ SearchInitMap(drupalSettings.mapUrl);
                      $(".content-wrapper").removeClass("hidden");
                      $(".map-wrapper").removeClass("hidden");
                      $(".loader").addClass("hidden");
                  }, 3000);
                }else{
                    $(".content-wrapper").removeClass("hidden");
                    $(".map-wrapper").removeClass("hidden");
                    $(".loader").addClass("hidden");
                }
              }
            })
          }
        });*/
      $(document).once('mymodule-ajax').ajaxComplete(function (e, xhr, settings) {
        //if(settings.url.indexOf("/en/views/ajax?") != -1){
        if(settings.url.indexOf("/views/ajax?") != -1){
          $(".content-wrapper").removeClass("hidden");
          $(".map-wrapper").removeClass("hidden");
          $(".loader").addClass("hidden");
          var show_map = $('form#bs-search .map-view-control-button');
          manageMapContentWidth(show_map);
          if (show_map.is(':checked')) {
            SearchInitMap(drupalSettings.mapUrl,'search-map-block');
          }
        }
      });
      function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
      };

      function getFormDataById(form) {
        var data = {};
        
        form.find("input, select").map(function() {
          var el  = $(this),
          name = el.attr("name");
          
          if (/radio|checkbox/i.test(el.attr('type')) && !el.prop('checked'))return;

          if(name.indexOf('[') > -1) {
            var name_ar = name.split(']').join('').split('['),
            name    = name_ar[0],
            index   = name_ar[1];

            data[name]  = data[name] || [];
            data[name][index] = el.val();
          }
          else data[name] = el.val();
        });

        return data;
      }

      function clearForm(form) {
        // iterate over all of the inputs for the form
        // element that was passed in
        $(':input', form).each(function() {
          var type = this.type;
          var tag = this.tagName.toLowerCase(); // normalize case
          // it's ok to reset the value attr of text inputs,
          // password inputs, and textareas
          if (type == 'text' || type == 'password' || tag == 'textarea' || type == 'number')
            this.value = "";
          // checkboxes and radios need to have their checked state cleared
          // but should *not* have their 'value' changed
          else if (type == 'checkbox' || type == 'radio')
            this.checked = false;
          // select elements need to have their 'selectedIndex' property set to -1
          // (this works for both single and multiple select elements)
          else if (tag == 'select')
            this.selectedIndex = -1;
        });
      }

      function getKeyByValue(object, value) {
        return Object.keys(object).find(key => object[key] === value);
      }
      function filterSetLabel() {
        var fields = {};
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var formattedDate = new Date();
        var d = formattedDate.getDate();
        var m =  monthNames[formattedDate.getMonth()];
        var y = formattedDate.getFullYear().toString().substr(-2);
        fields.area = {'name' : 'map_search_box', 'label' : 'bssf-area', 'default' : 'In the area of'};
        fields.date = {'name' : 'date', 'label' : 'bssf-date', 'default' : 'Dates'};
        fields.from_time = {'name' : 'from_time', 'label' : 'bssf-from-time', 'default' : 'From Time'};
        fields.to_time = {'name' : 'to_time', 'label' : 'bssf-to-time', 'default' : 'To Time'};
        fields.guest = {'name' : 'booking_people', 'label' : 'bssf-guests', 'default' : 'Guests'};
        fields.price = {'name' : ['min_price_value', 'max_price_value'], 'label' : 'bssf-price', 'default' : 'Price'};
        fields.more = {'name' : ['all_categories', 'more_filters_amenities', 'more_filters_space_types', 'more_filters_parking', 'more_filters_restaurant', 'more_filters_space_size'], 'label' : 'bssf-more-filters', 'default' : 'More Filters'};
        

        $.each(fields, function( key, value ) {

          switch (key) {
            case 'date':
              var val = $('form#bs-search input[name^="'+value.name+'"]').val();
              if (typeof val != 'undefined' && val) {
                formattedDate = new Date(val);
                d = formattedDate.getDate();
                m =  monthNames[formattedDate.getMonth()];
                y = formattedDate.getFullYear().toString();
                $('form#bs-search .bssf-element .' + value.label).text(m + ' ' + d + ', ' + y);
                $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
              }
              else {
                $('form#bs-search .bssf-element .' + value.label).text(value.default);
                $('form#bs-search .bssf-element .' + value.label).addClass('empty');
              }
            break;
          case 'price':
            var min_price = $('form#bs-search [name^="'+value.name[0]+'"]').val();
            var max_price = $('form#bs-search [name^="'+value.name[1]+'"]').val();

            if ((typeof min_price != 'undefined' && min_price) && (typeof max_price != 'undefined' && max_price)) {
              var currency_symbol = drupalSettings.currencySymbol;
              var min_max_price = currency_symbol + min_price + ' - ' + currency_symbol + max_price;
              $('form#bs-search .bssf-element .' + value.label).text(min_max_price);
              $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
            }
            else {
              $('form#bs-search .bssf-element .' + value.label).text(value.default);
              $('form#bs-search .bssf-element .' + value.label).addClass('empty');
            }

            break;
          case 'more':
            var count = 0;
            $.each(value.name, function( morekey, morevalue ) {
              var type = $('form#bs-search [name^="'+morevalue+'"]').attr('type');
              if (type == 'checkbox') {
                 if ($('form#bs-search [name^="'+morevalue+'"]:checked').length > 0) {
                   count++;
                 }
              }
              else if(type == 'number') {
                var val = $('form#bs-search [name^="'+morevalue+'"]').val();
                if (typeof val != 'undefined' && val) {
                  count++;
                }
              }
            });

            if (count) {
             $('form#bs-search .bssf-element .' + value.label).text(value.default + ' ' + count);
             $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
            }
            else {
             $('form#bs-search .bssf-element .' + value.label).text(value.default); 
             $('form#bs-search .bssf-element .' + value.label).addClass('empty');
            }


            break;
          default:
            var type = $('form#bs-search [name^="'+value.name+'"]').attr('type');
            var tag = $('form#bs-search [name^="'+value.name+'"]')[0];
            if (typeof tag != 'undefined' && tag) {
              tag = tag.tagName.toLowerCase();
            }
            if (type == 'text') {
              var val = $('form#bs-search [name^="'+value.name+'"]').val();
              if (typeof val != 'undefined' && val) {
                $('form#bs-search .bssf-element .' + value.label).text(val);
                $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
              }
              else {
                $('form#bs-search .bssf-element .' + value.label).text(value.default);
                $('form#bs-search .bssf-element .' + value.label).addClass('empty');
              }              
            }
            else if (tag == 'select') {
              var val = $('form#bs-search [name^="'+value.name+'"]').val();
              if (typeof val != 'undefined' && val!='0' && val ) {
              var selectoptionlabel = $('form#bs-search [name^="'+value.name+'"] option:selected').text();
                $('form#bs-search .bssf-element .' + value.label).text(selectoptionlabel);
                $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
              }
              else {
                $('form#bs-search .bssf-element .' + value.label).text(value.default);
                $('form#bs-search .bssf-element .' + value.label).addClass('empty');
              }
            }
            else if (type == 'radio') {
              var val = $('form#bs-search [name^="'+value.name+'"]:checked').val();
              if (typeof val != 'undefined' && val != 'All') {
              var radiolabel = $('form#bs-search [name^="'+value.name+'"]:checked').parent('label').text();
                $('form#bs-search .bssf-element .' + value.label).text(radiolabel);
                $('form#bs-search .bssf-element .' + value.label).removeClass('empty');
              }
              else {
                $('form#bs-search .bssf-element .' + value.label).text(value.default);
                $('form#bs-search .bssf-element .' + value.label).addClass('empty');
              }
            }
          }
        });
      }

      function manageMapContentWidth(element) {
        var wrapper_remove_class = 'col-xs-12 col-sm-7 col-md-7';
        var wrapper_add_class = 'col-xs-12 col-sm-12 col-md-12';
        var content_remove_class = 'col-xs-6 col-sm-12 col-md-6 col-lg-6';
        var content_add_class = 'col-xs-6 col-sm-6 col-md-3 col-lg-3';
        if (element.is(":checked")) {
          $('.view-search-property .map-wrapper').show();
          $('.view-search-property .content-wrapper').removeClass(wrapper_add_class);
          $('.view-search-property .content-wrapper').addClass(wrapper_remove_class);
          $('.view-search-property .content-wrapper .view-content .views-row article > div').each(function(i, obj) {
            $(this).addClass(content_remove_class);
            $(this).removeClass(content_add_class);
            $(this).closest('.views-row').removeClass('map-view');
          });
        }
        else {
          $('.view-search-property .map-wrapper').hide();
          $('.view-search-property .content-wrapper').removeClass(wrapper_remove_class);
          $('.view-search-property .content-wrapper').addClass(wrapper_add_class);
          $('.view-search-property .content-wrapper .view-content .views-row article > div').each(function(i, obj) {
            $(this).removeClass(content_remove_class);
            $(this).addClass(content_add_class);
            $(this).closest('.views-row').addClass('map-view');
          });
        }
      }

      window.onload = function() {
        $('#bs-search a.search-filter').trigger( "click" );
      }

      function loadContentView() {
        setTimeout(function() {
          var show_map = $('form#bs-search .map-view-control-button');
          $(".view-id-search_property.view-display-id-page_1 .loader").hide();
          $(".view-id-search_property.view-display-id-page_1 .content-wrapper, .view-id-search_property.view-display-id-page_1 .map-wrapper").show();
          if (show_map.is(':checked')) {
            $(".view-id-search_property.view-display-id-page_1 .map-wrapper").show();
          }
          else {
            $(".view-id-search_property.view-display-id-page_1 .map-wrapper").hide();
            manageMapContentWidth(show_map);
          }
        }, 200);
      }

    }
  };
})(jQuery, Drupal, drupalSettings);