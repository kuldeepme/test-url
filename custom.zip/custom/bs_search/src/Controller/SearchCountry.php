<?php
/**
 * @file
 * @author Rakesh James
 * Contains \Drupal\bs_search\Controller\ExampleController.
 * Please place this file under your example(module_root_folder)/src/Controller/
 */
namespace Drupal\bs_search\Controller;

use Drupal\Core\Controller\ControllerBase;
/**
 * Provides route responses for the Example module.
 */
class SearchCountry {
  /**
   * Returns a simple page.
   *
   * @return array
   *   A simple renderable array.
   */
  public function search($string) {
    $string = trim($string);
    $country_code = 'All';

    if (!empty($string)) {
      $country_list = \Drupal::service('country_manager')->getList();
      $country_name = ucwords($string);
      $code = array_search($country_name, $country_list);
      if (!empty($code)) {
        $country_code = $code;
      }
    }

    print ($country_code);
    exit();  
  }
}
?>