<?php

namespace Drupal\bs_search\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_search form.
 *
 * @Block(
 *   id = "bs_search_block",
 *   admin_label = @Translation("bs_search_block"),
 *   category = @Translation("bs_search"),
 * )
 */
class bs_search_block extends BlockBase {
    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_search\Form\BsSearchFilterForm');
        return $form;
    }

}
