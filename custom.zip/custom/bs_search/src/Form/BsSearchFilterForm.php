<?php

namespace Drupal\bs_search\Form;
use Drupal\taxonomy\Entity\Term;

/**
 * @file
 * Contains \Drupal\bs_search\Form\BsSearchFilterForm.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Drupal\Core\Link;

use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * {@inheritdoc}
 */
class BsSearchFilterForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'bs_search';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {
    // $field_instance = \Drupal::entityTypeManager()->getStorage('field_config')->load('node.ct_properties.field_property_address');
    // kint($field_instance);die();
    $default_area = "";
    $default_date = "";
    $default_from_time = "";
    $default_to_time = "";
    $default_booking_people = "";
    $default_min_price = "";
    $default_max_price = "";
    $default_categories = "";
    $default_amenities = "";
    $default_space_types = "";
    $default_more_filters_parking = "";
    $default_more_filters_restaurant = "";
    $default_more_filters_space_size = "";

    $params = $_REQUEST;

    // if (isset($_REQUEST["map_search_box"])) {
    //   $default_area = $_REQUEST["map_search_box"];
    // }
    // if (isset($_REQUEST["date"])) {
    //   $default_date = $_REQUEST["date"];
    // }
    // if (isset($_REQUEST["from_time"])) {
    //   $default_from_time = $_REQUEST["from_time"];
    // }
    // if (isset($_REQUEST["to_time"])) {
    //   $default_to_time = $_REQUEST["to_time"];
    // }
    // if (isset($_REQUEST["booking_people"])) {
    //   $default_booking_people = $_REQUEST["booking_people"];
    // }
    // if (isset($_REQUEST["field_price_value"]["min"]) && $_REQUEST["field_price_value"]["min"]) {
    //   $default_min_price = $_REQUEST["field_price_value"]["min"];
    // }
    // if (isset($_REQUEST["field_price_value"]["max"]) && $_REQUEST["field_price_value"]["max"]) {
    //   $default_max_price = $_REQUEST["field_price_value"]["max"];
    // }
    // if (isset($_REQUEST["field_space_activities_target_id"])) {
    //   $default_all_categories = $_REQUEST["field_space_activities_target_id"];
    // }
    // if (isset($_REQUEST["field_space_services_target_id"])) {
    //   $default_more_filters_amenities = $_REQUEST["field_space_services_target_id"];
    // }
    // if (isset($_REQUEST["field_property_types_target_id"])) {
    //   $default_more_filters_space_types = $_REQUEST["field_property_types_target_id"];
    // }

    // if (isset($_REQUEST["field_property_near_by"])) {
    //   $default_more_filters_parking = $_REQUEST["field_property_near_by"];
    // }
    // if (isset($_REQUEST["field_space_size_value"])) {
    //   $default_more_filters_space_size = $_REQUEST["field_space_size_value"];
    // }

    $url = Url::fromUserInput('#');
    $link = Link::fromTextAndUrl(t('Apply'), $url)->toRenderable();
    $link['#attributes'] = ['class' => ['search-filter']];
    $link['#attributes']['data-stuff'] = "{'name' : 'map_search_box', 'view_field_name' : 'area', 'type' : 'text'}, {'name' : 'date', 'view_field_name' : 'nid', 'type' : 'text'}, {'name' : 'from_time', 'view_field_name' : 'field_start_time_value', 'type' : 'text'}, {'name' : 'to_time', 'view_field_name' : 'field_end_time_value', 'type' : 'text'}, {'name' : 'min_price_value', 'view_field_name' : 'field_price_value[min]', 'type' : 'text'}, {'name' : 'max_price_value', 'view_field_name' : 'field_price_value[max]', 'type' : 'text'}, {'name' : 'all_categories', 'view_field_name' : 'field_space_activities_target_id[]', 'type' : 'select'}, {'name' : 'more_filters_amenities', 'view_field_name' : 'field_space_services_target_id[]', 'type' : 'select'}, {'name' : 'more_filters_space_types', 'view_field_name' : 'field_property_types_target_id[]', 'type' : 'select'}, {'name' : 'more_filters_parking', 'view_field_name' : 'field_property_parking_value', 'type' : 'text'}, {'name' : 'more_filters_restaurant', 'view_field_name' : 'field_property_restaurant_value', 'type' : 'text'} ,{'name' : 'more_filters_space_size', 'view_field_name' : 'field_space_size_value', 'type' : 'text'}";

    $filter_reset_url = Url::fromUserInput('#');
    $filter_reset_link = Link::fromTextAndUrl(t('Clear'), $filter_reset_url)->toRenderable();
    $filter_reset_link['#attributes'] = ['class' => ['reset-search-filter']];

    $arr_cities_countries = get_all_properties_cities_and_countries();

/*    $form['map_search_box'] = [
      '#type' => 'textfield',
      '#default_value' => isset($params['map_search_box']) ? $params['map_search_box'] : '',
      '#suffix' => render($link) .' '. render($filter_reset_link),
    ];*/
    $form['map_search_box'] = [
      '#type' => 'select',
      '#options' => $arr_cities_countries,
      '#default_value' => isset($params['location']) ? $params['location'] : "IL|Tel Aviv",
      '#suffix' => render($link),
      '#empty_value' => '',
    ];

    $form['date'] = [
      '#type' => 'date',
      '#size' => 20,
      '#default_value' => isset($params['date']) ? $params['date'] : '',
      '#suffix' => render($link) .' '. render($filter_reset_link),
    ];

    $arr_times = select_list_times();
    $form['from_time'] = [
      '#type' => 'select',
      '#options' => $arr_times,
      '#default_value' => isset($params['start_time']) ? (int)$params['start_time'] : '',
      '#suffix' => render($link) .' '. render($filter_reset_link),
    ];
    $form['to_time'] = [
      '#type' => 'select',
      '#options' => $arr_times,
      '#default_value' => isset($params['end_time']) ? (int)$params['end_time'] : '',
      '#suffix' => render($link) .' '. render($filter_reset_link),
    ];

    $arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', FALSE,TRUE);
    $arr_number_of_people = ["All" => 'Any'] + $arr_number_of_people;
    if($params['booking_people']){
        $vid = 'booking_number_of_guests';
        $terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
        foreach ($terms as $term) {
          if($term->tid == $params['booking_people']){
              $default_booking_people = $term->name;
          }
       }
    }
    $form['booking_people'] = [
      '#type' => 'radios',
      '#options' => $arr_number_of_people,
      '#default_value' => isset($params['booking_people']) ? $default_booking_people : '',
      '#suffix' => render($link) .' '. render($filter_reset_link),
    ];
    $form['min_price'] = [
      '#type' => 'range',
      '#default_value' => $default_min_price,
      '#attributes' => [
        'placeholder' => t('Price'),
      ],
      '#max' => 500,
      '#min' => 0,
    ];
    $form['max_price'] = [
      '#type' => 'range',
      '#default_value' => $default_max_price,
      '#attributes' => [
        'placeholder' => t('Price'),
      ],
      '#max' => 1000,
      '#min' => 501,
    ];
    $arr_categories = get_taxonomy_term_values('space_activities', 0, NULL, FALSE);
    $arr_amenities = get_taxonomy_term_values('services', FALSE);
    $arr_space_types = get_taxonomy_term_values('property_types', FALSE);
    $arr_space_unit = get_taxonomy_term_values('space_size_units', FALSE);
    $currency_tid = get_user_preferred_currency_id();
    if (!empty($currency_tid)) {
      $term = Term::load($currency_tid);
      //$preferred_currency = $term->getName();
      $currency_symbol = $term->field_currency_symbol->getValue()[0]['value'];
    }
    if (empty($currency_symbol)) {
      $currency_symbol = '$';
    }
    if($params['activities']){
        $vid = 'space_activities';
        $terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
        $activities = explode(',', $params['activities']);
        foreach ($activities as $activity) {
          foreach ($terms as $term) {
            if($term->tid == $activity){
              $default_arr_category[] = $term->tid;
            }
         }
        }
    }
    $form['all_categories'] = [
      '#type' => 'checkboxes',
      '#options' => $arr_categories,
      '#default_value' => isset($params['activities']) ? $default_arr_category : [],
      '#multiple'=> TRUE,
      '#attributes' => [
        'placeholder' => t('All categories'),
      ],
    ];
    $form['more_filters_amenities'] = [
      '#type' => 'checkboxes',
      '#options' => $arr_amenities,
      '#default_value' => $default_more_filters_amenities,
      '#attributes' => [
        'placeholder' => t('More filters'),
      ],
    ];
    $form['more_filters_space_types'] = [
      '#type' => 'checkboxes',
      '#options' => $arr_space_types,
      '#default_value' => $default_more_filters_space_types,
    ];
    $form['more_filters_parking'] = [
      '#type' => 'checkboxes',
      '#options' => [1 => t('Inclusive')],
      '#default_value' => $default_more_filters_parking,
    ];
    $form['more_filters_restaurant'] = [
      '#type' => 'checkboxes',
      '#options' => [1 => t('Inclusive')],
      '#default_value' => $default_more_filters_restaurant,
    ];
    $form['more_filters_space_size'] = [
      '#type' => 'number',
      '#default_value' => $default_more_filters_space_size,
    ];

    $form['area_default'] = [
      "#markup" => $default_area ? $default_area : t("In the area of"),
    ];
    $form['date_default'] = [
      "#markup" => $default_date ? date('M d - y', strtotime($default_date)) : date("M d - y"),
    ];
    if ($default_from_time <= 9) {
      $form['from_time_default'] = [
        "#markup" => $default_from_time ? '0' . $default_from_time . ":00" : t("From Time"),
      ];
    }
    else {
      $form['from_time_default'] = [
        "#markup" => $default_from_time ? $default_from_time . ":00" : t("From Time"),
      ];
    }
    if ($default_to_time <= 9) {
      $form['to_time_default'] = [
        "#markup" => $default_to_time ? '0' . $default_to_time . ":00" : t("To Time"),
      ];
    }
    else {
      $form['to_time_default'] = [
        "#markup" => $default_to_time ? $default_to_time . ":00" : t("To Time"),
      ];
    }

    $form['booking_people_default'] = [
      "#markup" => $default_booking_people ? $arr_number_of_people[$default_booking_people] : t("Guests"),
    ];

    $price_display = NULL;
    if ($default_min_price !== '' || $default_max_price !== '') {
      $price_display = $default_min_price . "$";
      $price_display .= '-' . $default_max_price . "$";
    }
    $form['price_display'] = [
      "#markup" => !is_null($price_display) ? $price_display : t("Price"),
    ];
    $form['preferred_currency'] = [
      "#markup" => !is_null($currency_symbol) ? $currency_symbol : '$',
    ];
    $form['min_price_box_display'] = [
      "#markup" => $default_min_price,
    ];

    $form['max_price_box_display'] = [
      "#markup" => $default_max_price,
    ];

    $form['update_filter_response'] = [
      "#markup" => '<div class="hidden" id="update-filter-response">Hello</div>',
    ];

/*     $form['map_view_control'] = [
      '#markup' => '<div class="show-map-wrapper"><label class="switch">
           <input name="show_map" type="checkbox" class="primary">
           <span class="slider round"></span>
         </label></div>'
     ];*/

    $form['map_view_control'] = [
      '#type' => 'checkbox',
      '#title' => t('Show Map'),
      '#attributes' => ['class' => ['map-view-control-button']],
      '#prefix' => '<div class="map-view-control-wrapper">',
      '#suffix' => '</div>',
      '#default_value' => FALSE,
      '#field_suffix' => '<span class="map-view-control-slider"></span>',
      '#suffix' => "<div id='bs-search-view-ajax'></div>"
    ];
    
    // $form['submit'] = [
    //   '#type' => 'submit',
    //   '#value' => t('Apply'),
    // ];

    // $form['reset'] = [
    //   '#title' => t('clear'),
    //   '#type' => 'link',
    //   '#url' => Url::fromUri('internal:/search_results'),
    //   '#attributes' => ['class' => ['btn btn-danger']],
    // ];

    $country_list = \Drupal::service('country_manager')->getList();

    $form['#attached']['library'][] = 'bs_search/bs-search-global';
    $form['#attached']['drupalSettings']['country_list'] = $country_list;
    $form['#attached']['drupalSettings']['mapUrl'] = '';
    $form['#attached']['drupalSettings']['currencySymbol'] = $currency_symbol;
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $data = [];

    if (!empty($values['map_search_box'])) {
      $country_list = \Drupal::service('country_manager')->getList();
      $data['area'] = $values['map_search_box'];
      $data['field_property_address_address_line1'] = $values['map_search_box'];
      $data['field_property_address_country_code'] = 'All';
      $country_name = ucwords($values['map_search_box']);
      $country_code = array_search($country_name, $country_list);
      if (!empty($country_code)) $data['field_property_address_country_code'] = $country_code;
    }

    if ((int) $values['min_price']) {
      $data['field_price_value']['min'] = (int) $values['min_price'];
    }
    if ((int) $values['max_price']) {
      $data['field_price_value']['max'] = (int) $values['max_price'];
    }
    if (!empty($values['booking_people'])) {
      $data['field_number_of_guests_target_id'] = $values['booking_people'];
    }
    $all_categories = array_values(array_filter($values['all_categories']));
    if (!empty($all_categories)) {
      foreach ($all_categories as $value) {
        $data['field_space_activities_target_id'][] = $value;
      }
    }
    $amenities = array_values(array_filter($values['more_filters_amenities']));
    if (!empty($amenities)) {
      foreach ($amenities as $value) {
        $data['field_space_services_target_id'][] = $value;
      }
    }
    $space_types = array_values(array_filter($values['more_filters_space_types']));
    if (!empty($space_types)) {
      foreach ($space_types as $value) {
        $data['field_property_types_target_id'][] = $value;
      }
    }
    if (!empty($values['more_filters_parking'][1])) {
      $data['field_property_parking_value'] = $values['more_filters_parking'];
    }
    if (!empty($values['more_filters_restaurant'][1])) {
      $data['field_property_restaurant_value'] = $values['more_filters_restaurant'];
    }
    if (!empty($values['more_filters_space_size'])) {
      $data['field_space_size_value'] = $values['more_filters_space_size'];
    }

    $query = http_build_query($data);
    $redirect_path = '/search_results?' . $query;
    $path = URL::fromUserInput($redirect_path)->toString();
    $response = new RedirectResponse($path);
    $response->send();
  }

}
