<?php

namespace Drupal\bs_form_listaspace\Button;

use Drupal\bs_form_listaspace\Step\StepsEnum;

/**
 * Class StepOneNextButton.
 *
 * @package Drupal\bs_form_listaspace\Button
 */
class StepOneNextButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'next';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Next'),
      '#goto_step' => StepsEnum::STEP_TWO,
      '#attributes' => [
        'class' => ['btn-primary btn-lg next-button']
      ],
    ];
  }

}
