<?php

namespace Drupal\bs_form_listaspace\Button;

use Drupal\bs_form_listaspace\Step\StepsEnum;

/**
 * Class StepFourNextButton.
 *
 * @package Drupal\bs_form_listaspace\Button
 */
class StepFourNextButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'finish';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Finish!'),
      '#goto_step' => StepsEnum::STEP_FINALIZE,
      '#submit_handler' => 'submitValues',
        '#attributes' => [
            'class' => ['btn-primary btn-lg next-button']
        ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getSubmitHandler() {
    return 'submitIntake';
  }

}
