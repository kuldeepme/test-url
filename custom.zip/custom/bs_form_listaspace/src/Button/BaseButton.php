<?php

namespace Drupal\bs_form_listaspace\Button;

/**
 * Class BaseButton.
 *
 * @package Drupal\bs_form_listaspace\Button
 */
abstract class BaseButton implements ButtonInterface {

  /**
   * {@inheritdoc}
   */
  public function ajaxify() {
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function getSubmitHandler() {
    return FALSE;
  }

}
