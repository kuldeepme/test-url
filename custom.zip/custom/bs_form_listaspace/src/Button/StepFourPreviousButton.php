<?php

namespace Drupal\bs_form_listaspace\Button;

use Drupal\bs_form_listaspace\Step\StepsEnum;

/**
 * Class StepFourPreviousButton.
 *
 * @package Drupal\bs_form_listaspace\Button
 */
class StepFourPreviousButton extends BaseButton {

  /**
   * {@inheritdoc}
   */
  public function getKey() {
    return 'previous';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'submit',
      '#value' => t('Back'),
      '#goto_step' => StepsEnum::STEP_THREE,
      '#skip_validation' => TRUE,
        '#attributes' => [
            'class' => ['btn-back']
        ],
    ];
  }

}
