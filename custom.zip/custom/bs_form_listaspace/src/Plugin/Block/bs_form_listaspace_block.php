<?php

namespace Drupal\bs_form_listaspace\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_listaspace form.
 *
 * @Block(
 *   id = "bs_form_listaspace_block",
 *   admin_label = @Translation("bs_form_listaspace_block"),
 *   category = @Translation("bs_form_listaspace"),
 * )
 */
class bs_form_listaspace_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_listaspace\Form\BsFormListaspace');
        return $form;
    }

}
