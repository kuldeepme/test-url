<?php

namespace Drupal\bs_form_listaspace\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\bs_form_listaspace\Manager\StepManager;
use Drupal\bs_form_listaspace\Step\StepsEnum;
use Drupal\file\Entity\File;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Datetime;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;

/**
 * Provides multi step ajax example form.
 *
 * @package Drupal\bs_form_listaspace\Form
 */
class BsFormListaspace extends FormBase
{
    use StringTranslationTrait;

    /**
     * Step Id.
     *
     * @var \Drupal\bs_form_listaspace\Step\StepsEnum
     */
    protected $stepId;
    protected $m_arr_currencies;

    /**
     * Multi steps of the form.
     *
     * @var \Drupal\bs_form_listaspace\Step\StepInterface
     */
    protected $step;

    /**
     * Step manager instance.
     *
     * @var \Drupal\bs_form_listaspace\Manager\StepManager
     */
    protected $stepManager;

    /**
     * {@inheritdoc}
     */
    public function __construct()
    {
        $this->stepId = StepsEnum::STEP_ONE;
        $this->stepManager = new StepManager();
    }

    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {
        return 'bs_form_listaspace';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state)
    {

        $property_id = isset($_REQUEST['property_id']) ? $_REQUEST['property_id'] : 0;

        if ($property_id) {
            $flag = TRUE;
            $logged_in_user_id = \Drupal::currentUser()->id();
            if ($logged_in_user_id) {
                $property_node = node_load($property_id);
                if (!empty($property_node)) {
                    $author_id = $property_node->getOwnerId();
                    if ($author_id == $logged_in_user_id) {
                        $this->stepId = ($this->stepId == 1) ? StepsEnum::STEP_TWO : $this->stepId;
                        $form['property_id'] = ['#type' => 'hidden', '#value' => $property_id];

                    } else {
                        $flag = FALSE;
                        drupal_set_message(t('You are not allowed to add space for the property.'), 'error');
                    }
                } else {
                    $flag = FALSE;
                    drupal_set_message(t('Property Not Found.'), 'error');
                }
            }
            if (!$flag) {
                return new RedirectResponse(Url::fromRoute('view.my_properties.page_1')->toString());
            }
        }


        $form['wrapper-messages'] = [
            '#type' => 'container',
            '#attributes' => [
                'id' => 'messages-wrapper',
            ],
        ];
        $form['wrapper'] = [
            '#type' => 'container',
            '#attributes' => [
                'id' => 'form-wrapper',
            ],
        ];
        // Get step from step manager.
        $this->step = $this->stepManager->getStep($this->stepId);

        // Attach step form elements.
        $form['wrapper'] += $this->step->buildStepFormElements($form_state);
        // Attach buttons.
        $form['wrapper']['actions']['#type'] = 'actions';
        $buttons = $this->step->getButtons();

        foreach ($buttons as $button) {
            if ($property_id && $this->stepId == 2 && $button->getKey() == 'previous') {
                continue;
            }
            /** @var \Drupal\bs_form_listaspace\Button\ButtonInterface $button */
            $form['wrapper']['actions'][$button->getKey()] = $button->build();

            if ($button->ajaxify()) {
                // Add ajax to button.
                $form['wrapper']['actions'][$button->getKey()]['#ajax'] = [
                    'callback' => [$this, 'loadStep'],
                    'wrapper' => 'form-wrapper',
                    'effect' => 'fade',
                ];
            }
            $callable = [$this, $button->getSubmitHandler()];
            if ($button->getSubmitHandler() && is_callable($callable)) {
                // Attach submit handler to button, so we can execute it later on..
                $form['wrapper']['actions'][$button->getKey()]['#submit_handler'] = $button->getSubmitHandler();
            }
        }

        $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-global';
        $form['#attached']['library'][] = 'bs_form_listaspace/internation-telephone';

        return $form;
    }

    /**
     * Ajax callback to load new step.
     *
     * @param array $form
     *   Form array.
     * @param \Drupal\Core\Form\FormStateInterface $form_state
     *   Form state interface.
     *
     * @return \Drupal\Core\Ajax\AjaxResponse
     *   Ajax response.
     */
    public function loadStep(array &$form, FormStateInterface $form_state)
    {
        $response = new AjaxResponse();

        $messages = drupal_get_messages();
        $error = '';
        if (!empty($messages)) {
            // Form did not validate, get messages and render them.
            $messages = [
                '#theme' => 'status_messages',
                '#message_list' => $messages,
                '#status_headings' => [
                    'status' => $this->t('Status message'),
                    'error' => $this->t('Error message'),
                    'warning' => $this->t('Warning message'),
                ],
            ];

            $response->addCommand(new HtmlCommand('#messages-wrapper', $messages));
            $error = "Error";
        } else {
            // Remove messages.
            $response->addCommand(new HtmlCommand('#messages-wrapper', ''));
        }

        // Update Form.
        $response->addCommand(new HtmlCommand('#form-wrapper', $form['wrapper']));
        $response->addCommand(new \Drupal\Core\Ajax\InvokeCommand(NULL, "bs_form_after_ajax_handler", array($error)));
        return $response;
    }

    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state)
    {

        $triggering_element = $form_state->getTriggeringElement();

        //print '<pre>';print_r($form_state->getValue('weekdays_start_time_72'));die('sdf');

        //Validate weekdays
        $arr_weekdays = get_taxonomy_term_values('weekdays_', true);
        //Run on the selected weekdays
        foreach ($arr_weekdays as $day_key => $day_value) {
            $start_time = $form_state->getValue('weekdays_start_time_' . $day_key);
            $end_time = $form_state->getValue('weekdays_end_time_' . $day_key);

            //Check that the checkbox was checked
            if ($start_time == "0" || $end_time == "0") {
                $form_state->setErrorByName('weekdays_start_time_' . $day_key, "Please select a start and end time");
            }

            //Convert to int
            $start_time = (int)$start_time;
            $end_time = (int)$end_time;

            //Validate that the end time bigger than the start time
            if (is_numeric($start_time) && is_numeric($end_time) && $start_time > 0 && $end_time > 0) {
                if ($end_time <= $start_time) {
                    $form_state->setErrorByName('weekdays_start_time_' . $day_key, "End time must be bigger then start time");
                }
            }
        }
        //END Validate weekdays

        // Only validate if validation doesn't have to be skipped.
        // For example on "previous" button.
        if (empty($triggering_element['#skip_validation']) && $fields_validators = $this->step->getFieldsValidators()) {
            // Validate fields.
            foreach ($fields_validators as $field => $validators) {
                // Validate all validators for field.
                $field_value = $form_state->getValue($field);
                foreach ($validators as $validator) {
                    if (!$validator->validates($field_value)) {
                        $form_state->setErrorByName($field, $validator->getErrorMessage());
                    }
                }
            }
        }
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        // Save filled values to step. So we can use them as default_value later on.
        $values = [];

        //Remove as we use the next line
        /*foreach ($this->step->getFieldNames() as $name) {
          $values[$name] = $form_state->getValue($name);
        }*/
        //Added by Ofek (Arvind) - it gets all the values, also of the dynamic elements
        $values = $form_state->cleanValues()->getValues();
        /**/


        /***********/


        //*************/

        $this->step->setValues($values);
        // Add step to manager.
        $this->stepManager->addStep($this->step);
        // Set step to navigate to.
        $triggering_element = $form_state->getTriggeringElement();
        $this->stepId = $triggering_element['#goto_step'];

        // If an extra submit handler is set, execute it.
        // We already tested if it is callable before.
        if (isset($triggering_element['#submit_handler'])) {
            $this->{$triggering_element['#submit_handler']}($form, $form_state);
        }
        $form_state->setRebuild(TRUE);
    }

    /**
     * Submit handler for last step of form.
     *
     * @param array $form
     *   Form array.
     * @param \Drupal\Core\Form\FormStateInterface $form_state
     *   Form state interface.
     */
    public function submitValues(array &$form, FormStateInterface $form_state)
    {
        // Submit all values to DB or do whatever you want on submit.
        //Get all steps
        $allSteps = $this->stepManager->getAllSteps();
        $values = array();
        //Run on all steps
        foreach ($allSteps as $step) {
            //Get values of each step
            $step_values = $step->getValues();
            $values = array_merge($values, $step_values);
        }
        $this->handle_form_results($values);
    }


    private function handle_form_results($values)
    {
        //get details from the form
        //User
        $password = $values["confirm_password"];
        $first_name = $values["first_name"];
        $last_name = $values["last_name"];
        $email = $values["email"];
        $phone = $values["phone"];
        $arr_space_image_ids = $values["space_images"]; //Step 3 - array of space images
        $user_image_file_id = 0;
        if (isset($values["user_image"][0])) {
            $user_image_file_id = $values["user_image"][0]; //Step 3
        }
        $user_description = $values["user_description"]; //Step 3

        //Property
        $property_name = $values["property_name"];
        $property_description = $values["property_description"];
        if (isset($values["property_logo"][0])) {
            $property_logo_file_id = $values["property_logo"][0];
        }
        $property_type = $values["property_type"];
        //Space
        $space_title = $values["space_title"];
        $space_description = $values["space_description"];
        $space_type = $values["space_type"];
        $space_size = $values["space_size"];
        //$space_size_units = $values["space_size_units"];

        //Space activity
        //$arr_space_activity = $values["space_activity"];
        $arr_space_activity = [];
        foreach ($values as $key => $value) {
            //Run on all "services_" lists of checkboxes ("stationary", "electronic", "other").. If this is a "services_" list of checkboxes...
            if (strpos($key, 'space_activity_') !== false) {
                //debug($value);die;
                //Run on the checkboxes and if is checked...
                foreach ($value as $key1 => $value1) {
                    if ($value1 > 0) {
                        array_push($arr_space_activity, $value1);
                    }
                }
            }
        }

        $cancellation_policy = $values["cancellation_policies"];

        //Run on all values and organize data for SPACE LAYOUTS (term & max capacity)
        $space_layout_paragraph = [];
        foreach ($values as $key => $value) {

            //If this is space_layout_item and is checked ($value == 1)
            if (strpos($key, 'space_layout_item_') !== false && $value == 1) {
                $get_term_array = explode("space_layout_item_", $key);
                $get_term_id = $get_term_array[1];

                //Create a paragraph
                $paragraph = Paragraph::create([
                    'type' => 'space_layouts',
                    'field_space_layout_max_participa' => $values['space_max_capacity_' . $get_term_id],
                    'field_space_layout_name' => $get_term_id,
                ]);
                $paragraph->save();

                $space_layout_paragraph[] = [
                    'target_id' => $paragraph->id(),
                    'target_revision_id' => $paragraph->getRevisionId(),
                ];
            }
        }


        //Run on all values and organize the weekdays
        foreach ($values as $key => $value) {

            if (strpos($key, 'weekdays_day_') !== false && $value == 1) {

                $get_wd_term_array = explode("weekdays_day_", $key);
                $get_wd_term_id = $get_wd_term_array[1];

                $start_time_index = $values['weekdays_start_time_' . $get_wd_term_id];
                $end_time_index = $values['weekdays_end_time_' . $get_wd_term_id];

                $start_time = select_list_times_to_string($start_time_index);
                $end_time = select_list_times_to_string($end_time_index);

                $times_paragraph_id = create_paragraph_times($start_time, $end_time, $get_wd_term_id);
                $wd_paragraph_item[] = $times_paragraph_id;
            }
        }


        //Organize data for SERVICE ARRAY
        $space_services_array = [];
        foreach ($values as $key => $value) {
            //Run on all "services_" lists of checkboxes ("stationary", "electronic", "other").. If this is a "services_" list of checkboxes...
            if (strpos($key, 'services_') !== false) {

                //Run on the checkboxes and if is checked...
                foreach ($value as $key1 => $value1) {
                    if ($value1 > 0) {

                        //Create a paragraph
                        $paragraph = Paragraph::create([
                            'type' => 'space_services',
                            'field_space_services' => $value1,
                        ]);
                        $paragraph->save();

                        $space_services_array[] = [
                            'target_id' => $paragraph->id(),
                            'target_revision_id' => $paragraph->getRevisionId(),
                        ];
                    }
                }
            }
        }
        //Organize data for PAID SERVICE ARRAY
        $space_services_paid_array = [];
        foreach ($values as $key => $value) {
            //Run on all "service_paid_item_" checkboxes
            if (strpos($key, 'service_paid_item_') !== false) {

                //If the checkbox is checked
                if ($value > 0) {

                    //get the id of the item
                    $item_array = explode("service_paid_item_", $key);
                    $item_id = $item_array[1];

                    //Get the description, price and currency
                    $str_description = $values["service_paid_description_" . $item_id];
                    $int_price = $values["service_paid_price_" . $item_id];
                    $int_currency_id = $values["service_paid_currency_" . $item_id];

                    //Create a paragraph
                    $paragraph = Paragraph::create([
                        'type' => 'space_services',
                        'field_space_services' => $item_id,
                        'field_service_description' => $str_description,
                        'field_service_price' => $int_price,
                        'field_service_price_currency' => $int_currency_id
                    ]);
                    $paragraph->save();

                    $space_services_paid_array[] = [
                        'target_id' => $paragraph->id(),
                        'target_revision_id' => $paragraph->getRevisionId(),
                    ];

                }
            }
        }
        //A different content type
        $arr_weekdays = $values["weekdays"];
        $price = $values["price"];
        //$currencies = $values["currencies"];

        //Have to connect stationary, electronic and other without knowing their names..


        //Handle the property logo image: get the file id and save it permanently - drupal adds it on tables file_uses OR file_managed
        if (isset($property_logo_file_id)) {
            $file1 = File::load($property_logo_file_id);
            $file1->setPermanent();
            $file1->save();
        }

        //Handle the user image: get the file id and save it permanently - drupal adds it on tables file_uses OR file_managed
        if ($user_image_file_id > 0) {
            $file2 = File::load($user_image_file_id);
            $file2->setPermanent();
            $file2->save();
        }

        foreach ($arr_space_image_ids as $image_id) {
            $file2 = File::load($image_id);
            $file2->setPermanent();
            $file2->save();
        }
        $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
        if (!isset($language)) {
            $language = "en";
        }
        //kint($language);die;
        //USER
        $user = \Drupal::currentUser();
        //debug($user->id());
        if (!$user->id()) {
            //We don't have a user. Add a user
            $user = \Drupal\user\Entity\User::create();

            // Mandatory user creation settings
            $user->enforceIsNew();
            $user->setUsername($email); // This username must be unique and accept only a-Z,0-9, - _ @ .
            $user->setEmail($email);
            $user->setPassword($password);
            $user->set("langcode", $language);

            // Optional settings
            $user->set("init", 'email');
            $user->set("preferred_langcode", $language);
            $user->set("preferred_admin_langcode", $language);

            //Settings from form
            $user->field_user_first_name = $first_name;
            $user->field_user_last_name = $last_name;
            $user->field_user_phone = $phone;

            //User description and image - new or updated fields
            $user->field_user_description = $user_description;
            if ($user_image_file_id > 0) {
                $user->field_user_image = $user_image_file_id;
            }

            $user->activate();
            // Add a custom role
            $user->addRole('CustomRoleName');

            //Save user
            $user->save();
            $tempstore = \Drupal::service('user.private_tempstore')->get('bs_form_listaspace');
            $tempstore->set('list_user_id', $user->id());
            //user_login_finalize($user);

        } else {
            //Load existing user
            $user = \Drupal\user\Entity\User::load($user->id());

        }

        $user_id = $user->id();

        $parking = $values["property_parking"];
        $restaurant = $values["property_restaurant"];

        $country_code = $values['address']['country_code'];
        $state = $values['address']['administrative_area'];
        $city = $values['address']['locality'];
        $street = $values['address']['address_line1'];

        $address = [
            'country_code' => $country_code,
            'administrative_area' => $state,
            'locality' => $city,
            'address_line1' => $street,
        ];

        //Find the term id of taxonomy country_details according to the country selected, according to the $country_code
        $country_details_tid = get_countries_details_tid_from_country_code($country_code);

        if (isset($values['property_id']) && $values['property_id']) {
            $node_ct_properties = node_load($values['property_id']);
        } else {
            //ADD PROPERTY
            $node_ct_properties = Node::create([
                // The node entity bundle.
                'type' => 'ct_properties',
                'langcode' => $language,
                //'created' => $created_date,
                //'changed' => $created_date,
                // The user ID.
                'uid' => $user_id,
                //'moderation_state' => 'published',
                'title' => $property_name,
                'moderation_state' => 'draft',
                'field_property_host' => $user_id,
                'field_property_creator' => $user_id,
                'field_property_manager' => $user_id,
                'field_property_title' => $property_name,
                'field_property_name' => $property_name,
                'field_property_description' => $property_description,
                'field_property_types' => $property_type,
                'field_property_logo' => $property_logo_file_id,
                'field_property_address' => $address,
                'field_property_country_details' => $country_details_tid,
                'field_property_parking' => $parking,
                'field_property_restaurant' => $restaurant
            ]);
            $node_ct_properties->setPublished(FALSE);
            $node_ct_properties->save();
        }


        //get property id
        $property_id = $node_ct_properties->id();

        //ADD SPACE
        $node_ct_spaces = Node::create([
            // The node entity bundle.
            'type' => 'spaces',
            'langcode' => $language,
            //'created' => $created_date,
            //'changed' => $created_date,
            // The user ID.
            'uid' => $user_id,
            //'moderation_state' => 'published',
            'moderation_state' => 'draft',
            'title' => $space_title,
            'field_space_name' => $space_title,
            'field_space_description' => $space_description,
            'field_spaces_properties' => $property_id,
            'field_space_activities' => $arr_space_activity,
            'field_space_size' => $space_size,
            //'field_space_size_units' => $space_size_units,
            'field_space_host' => $user_id,
            'field_space_manager' => $user_id,
            'field_space_creator' => $user_id,
            'field_space_type' => $space_type,
            'field_space_layouts' => $space_layout_paragraph,
            'field_space_services' => $space_services_array,
            'field_space_images' => $arr_space_image_ids,
            'field_space_services_paid' => $space_services_paid_array,
            //'field_week_availability' => $wd_paragraph_item,
            'field_availability_days' => $wd_paragraph_item,
            'field_price' => $price,
            //'field_space_currencies' => $currencies,
            'field_cancellation_policy' => $cancellation_policy
        ]);
        $node_ct_spaces->setPublished(FALSE);
        $node_ct_spaces->save();
        $space_id = $node_ct_spaces->id();

        //Add the space to the property
        //\Drupal::logger('my_module')->notice("Space id: " . $space_id);
        // $node_ct_properties->set('field_property_spaces', $space_id);
        $node_ct_properties->field_property_spaces[] = ['target_id' => $space_id];

        /***************/
        $country_code = $values['address']['country_code'];
        $state = $values['address']['administrative_area'];
        $city = $values['address']['locality'];
        $street = $values['address']['address_line1'];
        $complete_address = $street . "," . $state . "," . $city . "," . $country_code;
        $get_address_cordinates = json_decode(get_address_cordinates($complete_address));
        $cordinates_array = [
            "lat" => $get_address_cordinates->lat ? $get_address_cordinates->lat : 0,
            "lng" => $get_address_cordinates->lng ? $get_address_cordinates->lng : 0,
        ];
        $nearby_obj = get_address_nearby($cordinates_array, true);
        $nearby_obj_array = json_decode($nearby_obj);

        $vid = 'nearby';
        $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
        $tid = [];
        $parking_key = "";
        $restaurant_key = "";
        foreach ($terms as $key => $entity) {
            if ($entity->name == "Parking") {
                $parking_key = $entity->tid;
            }
            if ($entity->name == "Restaurant & Coffee Shops") {
                $restaurant_key = $entity->tid;
            }
        }

        if (isset($nearby_obj_array->parking_item_obj)) {
            foreach ($nearby_obj_array->parking_item_obj as $key => $value) {
                if ($key < 3) {
                    $paragraph_near_by = Paragraph::create([
                        'type' => 'near_by',
                        'field_near_by_title' => $value->name,
                        'field_near_by_description' => $value->vicinity,
                        'field_near_by_type' => $parking_key,
                    ]);
                    $paragraph_near_by->save();
                    $node_ct_properties->field_property_near_by[] = $paragraph_near_by;
                }
            }
        }

        if ($nearby_obj_array->restaurant_item_obj) {
            foreach ($nearby_obj_array->restaurant_item_obj as $key => $value) {
                if ($key < 3) {
                    $paragraph_near_by2 = Paragraph::create([
                        'type' => 'near_by',
                        'field_near_by_title' => $value->name,
                        'field_near_by_description' => $value->vicinity,
                        'field_near_by_type' => $restaurant_key,
                    ]);
                    $paragraph_near_by2->save();
                    $node_ct_properties->field_property_near_by[] = $paragraph_near_by2;
                }
            }
        }
        //************/
        $node_ct_properties->save();
    }
}
