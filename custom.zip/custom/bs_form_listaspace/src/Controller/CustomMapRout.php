<?php

namespace Drupal\bs_form_listaspace\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\views\Views;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\HttpFoundation\Request;

/**
 * Provides route responses for map location routing.
 */
class CustomMapRout extends ControllerBase {

  /**
   * Render location node content.
   */
  public function content() {
    $address = $_GET['address'];
    $output = get_address_cordinates($address);    
    print_r($output);
    exit();
  }

  /**
   * Render location node content.
   */
  public function getLocation() {
    $params = $_GET;
    $view_id = 'search_property';
    $display_id = 'page_1';
    $filters = $params;

    $view = Views::getView($view_id);
    $view->setDisplay($display_id);

    // Here comes the part that did the trick for my REST JSON request.
    // Create a new request with your filters / url query and set that.
    $request = new Request($filters);
    $view->setRequest($request);
    $view->execute();
    $output = [];    
    
    foreach ($view->result as $result) {
      $nid = $result->_entity->id();
      $price = 0;
      if (isset($result->_entity->field_property_spaces->entity)) {
        $total_spaces = $result->_entity->field_property_spaces->getValue();
        $price_array = [];
        foreach($total_spaces as $key=>$value){
          if(isset($result->_entity->field_property_spaces[$key]->entity->field_price)){
              if(isset($result->_entity->field_property_spaces[$key]->entity->field_price->getValue()[0])){
                  $price_array[] = $result->_entity->field_property_spaces[$key]->entity->field_price->getValue()[0]['value'];
              }
          }
        }
        if (sizeof($price_array)) {
          $price = min($price_array);
        }
        else {
          $price = 0;
        }
        /***/
        $arr_country_details = get_country_details_by_property_id($nid);
      $currency_symbol = $arr_country_details['currency_symbol'];
      $currency_tid = $arr_country_details['currency_tid'];

      //Get user preferred currency
      $user_preferred_currency_id = get_user_preferred_currency_id();

      //If we have the user's preferred currency
      if($user_preferred_currency_id > 0){
          //If the user currency is different then the property currency (according to the country), get the user's currency and convert to that
          if($currency_tid != $user_preferred_currency_id){
              //Get the conversion rate, converted price, currency symbol and all
              $arr_converted_price = currency_conversion($arr_country_details['currency_tid'], $user_preferred_currency_id, $price);
              if(!is_null($arr_converted_price)){                  
                  $price = $arr_converted_price['currency_symbol'].$arr_converted_price['price'];
                  $currency_symbol = $arr_converted_price['currency_symbol'];
              }else{
                  $symbol = get_currency_details_from_id($user_preferred_currency_id);
                  $price = $symbol['currency_symbol']."0";
              }
          }
      }
 
        /***/
      }
      $property_address = '';
      if (isset($result->_entity)) {
        $property_address = $result->_entity->field_property_address->getValue();
      }
      $address_str = $property_address[0]['address_line1'] . ',' . $property_address[0]['locality'] . ',' . $property_address[0]['administrative_area'] . '+' . $property_address[0]['country_code'];
      $location = _get_latlngfrom_address($address_str);
      $output[] = [
        'location' => $location,
        'price' => $price,
        'nid' => $nid,
      ];
    } //die;
    $output = json_encode($output);
    print_r($output);
    exit();
  }

  /**
   * Render location node content.
   */
  public function showLocation() {
    $nid = $_GET['nid'];
    if ($nid) {
      $output = [];
      $node = node_load($nid);
      $spaces_image = '';
      if (isset($node->field_property_spaces->entity)) {
        $spaces_image = $node->field_property_spaces->entity->field_space_images->getValue()[0]['target_id'];
      }
      $space_file = \Drupal\file\Entity\File::load($spaces_image);
      if (!empty($space_file)) {
        $space_file_uri = $space_file->getFileUri();
        $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('large');
        $space_file_url = $style->buildUrl($space_file_uri);
        $output['space_image'] = $space_file_url;
      }
      else {
        $theme_path = drupal_get_path('theme', 'bookaspace');
        $image_path = "/" . $theme_path . "/images/dummyproperty-54.jpg";
        $output['space_image'] = $image_path;
      }
      $property_type = '';
      if (isset($node->field_property_types)) {
        $property_type = $node->field_property_types->getValue()[0]['target_id'];
      }

      $sort_by_key = TRUE;
      $arr_property_types = get_taxonomy_term_values('property_types', $sort_by_key);
      $property_type_name = $arr_property_types[$property_type];
      if (!empty($property_type_name)) {
        $output['property_type_name'] = $property_type_name->__toString();
      }
      else {
        $output['property_type_name'] = "";
      }

      $output['space_id'] = $node->field_property_spaces->entity->id();
      $output['space_name'] = '';
      if (isset($node->field_property_spaces->entity)) {
        $output['space_name'] = $node->field_property_spaces->entity->field_space_name->getValue()[0]['value'];
      }
      $output['property_title'] = '';
      if (isset($node->field_property_title)) {
        $output['property_title'] = $node->field_property_title->getValue()[0]['value'];
      }
      $output['address'] = '';
      if (isset($node->field_property_address)) {
        $address['country_code'] = $node->field_property_address->getValue()[0]['country_code'];
        $address['administrative_area'] = $node->field_property_address->getValue()[0]['administrative_area'];
        $address['locality'] = $node->field_property_address->getValue()[0]['locality'];
        $address['address_line1'] = $node->field_property_address->getValue()[0]['address_line1'];
        $address_str = $address['address_line1'] . ',' . $address['locality'] . ',' . $address['administrative_area'] . '+' . $address['country_code'];
        $output['address'] = $address_str;
      }
      $output['space_layout_max_participant'] = '';
      if (isset($node->field_property_spaces->entity)) {
        $space_layouts_max = $node->field_property_spaces->entity->field_space_layouts->getValue();
        foreach ($space_layouts_max as $key => $data) {
          $paragraph = Paragraph::load($data['target_id']);
          if (isset($paragraph->field_space_layout_max_participa)) {
            $space_layout_max_participant[] = $paragraph->field_space_layout_max_participa->getValue()[0]['value'];
          }
        }
        $output['space_layout_max_participant'] = max($space_layout_max_participant);
      }
      $output['price'] = '';
      $total_spaces = $node->field_property_spaces->getValue();
      $price_array = [];
      foreach($total_spaces as $key=>$value){
        if($node->field_property_spaces[$key]->entity->field_price != NULL){
          $price_array[] = $node->field_property_spaces[$key]->entity->field_price->getValue()[0]['value'];
        }
      }
      $arr_country_details = get_country_details_by_property_id($nid);
      $currency_symbol = $arr_country_details['currency_symbol'];
      $currency_tid = $arr_country_details['currency_tid'];

      if (sizeof($price_array)) {        
        $price = min($price_array).$currency_symbol;
      }
      else {
        $price = "0".$currency_symbol;
      }
      $user_preferred_currency_id = get_user_preferred_currency_id();
      if($user_preferred_currency_id > 0){
          if($currency_tid != $user_preferred_currency_id){
              $arr_converted_price = currency_conversion($arr_country_details['currency_tid'], $user_preferred_currency_id, $price);
              if(!is_null($arr_converted_price)){
                  $price = $arr_converted_price['price'];
                  $currency_symbol = $arr_converted_price['currency_symbol'];
              }
          }
      }
      $output['price'] = $currency_symbol.$price;
      $output = json_encode($output);
      print_r($output);
      exit();
    }
  }
}
