<?php

namespace Drupal\bs_form_listaspace\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Provides route responses for map location routing.
 */
class NearBy extends ControllerBase {

  /**
   * Render location node content.
   */
  public function content() {
    $cordinate_array = [
      "lat" => $_REQUEST["lat"],
      "lng" => $_REQUEST["lng"]
    ];
    $output = get_address_nearby($cordinate_array);
    print_r($output);
    exit();
  }

}
