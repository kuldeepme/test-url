<?php

namespace Drupal\bs_form_listaspace\Validator;

/**
 * Interface ValidatorInterface.
 *
 * @package Drupal\bs_form_listaspace\Validator
 */
interface ValidatorInterface {

  /**
   * Returns bool indicating if validation is ok.
   */
  public function validates($value);

  /**
   * Returns error message.
   */
  public function getErrorMessage();

}
