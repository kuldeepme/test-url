<?php

namespace Drupal\bs_form_listaspace\Validator;

/**
 * Class ValidatorRequired.
 *
 * @package Drupal\bs_form_listaspace\Validator
 */
class ValidatorRequired extends BaseValidator {

  /**
   * {@inheritdoc}
   */
  public function validates($value) {
    return is_array($value) ? !empty(array_filter($value)) : !empty($value);
  }

}
