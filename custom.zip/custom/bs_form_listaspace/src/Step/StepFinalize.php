<?php

namespace Drupal\bs_form_listaspace\Step;

/**
 * Class StepFinalize.
 *
 * @package Drupal\bs_form_listaspace\Step
 */
class StepFinalize extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_FINALIZE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {

    $form['completed'] = [
      '#markup' => t('You have completed the wizard, yeah!111!'),
    ];

      $form['#theme'] = 'bs_form_listaspace_step_finalize';

      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 5,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];


    return $form;
  }

}
