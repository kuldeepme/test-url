<?php

namespace Drupal\bs_form_listaspace\Step;

use Drupal\bs_form_listaspace\Button\StepOneNextButton;
use Drupal\bs_form_listaspace\Validator\ValidatorRequired;
use CommerceGuys\Addressing\AddressFormat\AddressField;
use CommerceGuys\Addressing\AddressFormat\FieldOverride;
use Drupal\taxonomy\Entity\Term;

/**
 * Class StepOne.
 *
 * @package Drupal\bs_form_listaspace\Step
 */
class StepOne extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_ONE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepOneNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements($form_state = null) {


      /*
      $arr_space_activities = get_space_activities_values();
      //kint($arr_space_activities);die;

      foreach($arr_space_activities as $key => $values) {

          $form['space_activity']['space_activity_' . $key] = [
              '#type' => 'checkboxes',
              '#title' => t($key),
              '#options' => $values,
              '#default_value' => isset($this->getValues()[$key]) ? $this->getValues()[$key] : [],
              '#required' => FALSE,
              '#prefix' => '<div>',
              '#suffix' => '</div>'
          ];
      }
      */

/*********************************************/
//$get_address_cordinates = get_address_cordinates();
/*********************************************/

      $config = \Drupal::config('bs_admin_configuration.settings');
      $form['#attached']['library'][] = 'bs_form_listaspace/internation-telephone';

      $sort_by_key = true;
      $arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);

      //Load property types
      $arr_property_types = get_taxonomy_term_values('property_types', $sort_by_key);
     
      $form['personal_detail_markup'] = [
          '#markup' => $config->get('description')['value'],
      ];
      $user = \Drupal::currentUser();
      $form["user"] = true;
      if(!$user->id()){
          //If we DO NOT have a user, display these fields
          $form["user"] = false;
          $form['email'] = [
              '#type' => 'email',
              //'#title' => t("Email"),
              '#required' => FALSE,
              '#default_value' => isset($this->getValues()['email']) ? $this->getValues()['email'] : NULL,
              '#attributes' => [
                  'placeholder' => array('john@example.com'),
              ],
              '#description' => t('Your email address'),
          ];

          $form['confirm_password'] = [
              '#type' => 'password_confirm',
              '#title' => t(""),
              '#required' => FALSE,
          ];
          $form['first_name'] = [
              '#type' => 'textfield',
              //'#title' => t("First name"),
              '#required' => FALSE,
              '#attributes' => [
                  'placeholder' => array('John'),
              ],
              '#default_value' => isset($this->getValues()['first_name']) ? $this->getValues()['first_name'] : NULL,
          ];
          $form['last_name'] = [
              '#type' => 'textfield',
              //'#title' => t("Last name"),
              '#required' => FALSE,
              '#attributes' => [
                  'placeholder' => array('Doe'),
              ],
              '#default_value' => isset($this->getValues()['last_name']) ? $this->getValues()['last_name'] : NULL,
          ];

          $form['phone'] = [
              '#type' => 'tel',
              //'#title' => t("Telephone number"),
              '#default_value' => isset($this->getValues()['phone']) ? $this->getValues()['phone'] : "+1 ",
          ];
      }
      $form['property_type'] = array(
          '#type' => 'select',
          //'#title' => t('Propertry type'),
          '#options' => $arr_property_types,
      );

      $form['property_name'] = [
          '#type' => 'textfield',
          '#required' => TRUE,
          '#title' => t("Property name"),
          '#default_value' => isset($this->getValues()['property_name']) ? $this->getValues()['property_name'] : NULL,
          //'#field_suffix' => '<a href="#" title="" class="my_tooltip" data-toggle="tooltip" data-original-title="The logo should be at minmum size of 800 px width ">?</a>'
      ];

      $form['property_description'] = [
          '#type' => 'textarea',
          //'#title' => t("Property description"),
          '#attributes' => [
              'placeholder' => array(t('Describe what your are doing and highlight unique information like location special services and attention to interior design.')),
          ],
          '#default_value' => isset($this->getValues()['property_description']) ? $this->getValues()['property_description'] : NULL,
      ];

      $form['property_logo'] = [
          '#type' => 'managed_file',
          //'#title' => t("Property logo"),
          '#upload_location' => 'public://property-images/',
      ];


      //Property internal parking
      $form["property_parking"] = [
          '#type' => 'checkbox',
          //'#title' => t('Internal parking'), //Image and term name
          '#default_value' => isset($this->getValues()[property_parking]) ? $this->getValues()[property_parking] : [],
          '#required' => FALSE,
      ];


      //Property internal restaurant
      $form["property_restaurant"] = [
          '#type' => 'checkbox',
          //'#title' => t('Internal parking'), //Image and term name
          '#default_value' => isset($this->getValues()[property_restaurant]) ? $this->getValues()[property_restaurant] : [],
          '#required' => FALSE,
      ];
      
      //$countries = \Drupal::service('address.country_repository')->getList();
      $countries = get_available_countries();

      //print_r($countries);die();
      $country_code = isset($this->getValues()['address']['country_code']) ? $this->getValues()['address']['country_code'] : 'IL';
      $street = isset($this->getValues()['address']['address_line1']) ? $this->getValues()['address']['address_line1'] : '';
      $city = isset($this->getValues()['address']['locality']) ? $this->getValues()['address']['locality'] : '';
      $state = isset($this->getValues()['address']['administrative_area']) ? $this->getValues()['address']['administrative_area'] : '';

        $form['space_layout_address_wrapper']['address'] = [
         '#type' => 'address',
         '#default_value' => [
           'address_line1' => $street,
           //'postal_code' => '94043',
           'locality' => $city,
           'administrative_area' => $state,
           'country_code' => $country_code,
           'langcode' => 'en',
         ],
         '#field_overrides' => [
           AddressField::ORGANIZATION => FieldOverride::HIDDEN,
           AddressField::ADDRESS_LINE2 => FieldOverride::HIDDEN,
           AddressField::POSTAL_CODE => FieldOverride::HIDDEN,
           AddressField::GIVEN_NAME => FieldOverride::HIDDEN,
           AddressField::FAMILY_NAME => FieldOverride::HIDDEN,
         ],
         '#available_countries' => array_keys($countries),
       ];
      $form['gmap'] = [
        '#markup' => ' <div id="map"></div>',
      ];
      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 1,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];

      $form['#theme'] = 'bs_form_listaspace_step1';
      $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-address';
    return $form;
  }
    /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
        'username',
        'confirm_password',
        'first_name',
        'last_name',
        'email',
        'phone',
        'property_type',
        'property_name',
        'property_description',
        'property_logo',
        'country_code',
        'states',
        'city',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
        /*'username' => [
            new ValidatorRequired("Please choose a username"),
        ],
        'first_name' => [
            new ValidatorRequired("Please insert your first name"),
        ],
        'phone' => [
            new ValidatorRequired("Please insert your phone"),
        ],*/
    ];
  }
}
