<?php

namespace Drupal\bs_form_listaspace\Step;

use Drupal\bs_form_listaspace\Button\StepThreeNextButton;
use Drupal\bs_form_listaspace\Button\StepThreePreviousButton;
use Drupal\bs_form_listaspace\Validator\ValidatorRegex;
use Drupal\bs_form_listaspace\Validator\ValidatorRequired;

/**
 * Class StepThree.
 *
 * @package Drupal\bs_form_listaspace\Step
 */
class StepThree extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_THREE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepThreePreviousButton(),
      new StepThreeNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements($form_state = null) {

      $country_code = $form_state->getValues()['address']['country_code'];
      $form['country_code'] = [
          '#type' => 'hidden',
          '#default_value' => $country_code,
      ];

      $form['space_images'] = [
          '#type' => 'managed_file',
          //'#title' => t("Space images"),
          '#upload_location' => 'public://property-images/',
          '#attributes' => [
              'class' => ['multiple-file-upload']
          ],
          '#multiple' => true,
      ];



      $user = \Drupal::currentUser();
      $form["user"] = true;
      if(!$user->id()) {
          $form["user"] = false;
          $form['user_image'] = [
              '#type' => 'managed_file',
              '#title' => t("Profile picture"),
              '#upload_location' => 'public://property-images/',
          ];

          $form['user_description'] = [
              '#type' => 'textarea',
              '#title' => t("User description"),
              '#default_value' => isset($this->getValues()['user_description']) ? $this->getValues()['user_description'] : NULL,
              '#attributes' => [
                  'placeholder' => array('My space has... You will love my space because... The space suitable for meeting... etc'),
              ],
          ];
      }

      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 3,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];
      $form['#theme'] = 'bs_form_listaspace_step3';

      return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
        'space_images',
        'user_image',
        'user_description'
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    /*return [
      'linkedin' => [
        new ValidatorRequired("Tell me where I can find your LinkedIn please."),
        new ValidatorRegex(t("I don't think this is a valid LinkedIn URL..."), '/(ftp|http|https):\/\/(.*)linkedin(.*)/'),
      ],
    ];*/
  }

}
