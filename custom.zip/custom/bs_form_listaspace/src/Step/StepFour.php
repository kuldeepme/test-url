<?php

namespace Drupal\bs_form_listaspace\Step;

use Drupal\bs_form_listaspace\Button\StepFourNextButton;
use Drupal\bs_form_listaspace\Button\StepFourPreviousButton;
use Drupal\bs_form_listaspace\Validator\ValidatorRegex;
use Drupal\bs_form_listaspace\Validator\ValidatorRequired;
use Drupal\taxonomy\Entity\Term;

/**
 * Class StepThree.
 *
 * @package Drupal\bs_form_listaspace\Step
 */
class StepFour extends BaseStep {

    //Create array to hold all inner arrays, each for a category
    private $arr_services_paid;

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_FOUR;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepFourPreviousButton(),
      new StepFourNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements($form_state = null) {

      //Load currencies
      $sort_by_key = true;

      //Load weekdays
      $arr_times = select_list_times();
      //array_unshift($arr_times, "Select");
      $sort_by_key = true;
      $arr_weekdays = get_taxonomy_term_values('weekdays_', $sort_by_key);
      foreach($arr_weekdays as $day_key=>$day_value){
          $form["weekdays"]["weekdays_day_".$day_key ] = [
              "#type" => 'checkbox',
              '#title' => $day_value->__toString(),
              '#prefix' => "<div class='weekdays_wrapper'>",
          ];
          $form["weekdays"]["weekdays_start_time_".$day_key ] = [
              '#type' => 'select',
              '#options' => $arr_times,
              '#attributes' => [
                  'disabled' => true,
              ]
          ];
          $form["weekdays"]["weekdays_end_time_".$day_key ] = [
              '#type' => 'select',
              '#options' => $arr_times,
              '#attributes' => [
                  'disabled' => true,
              ],
              '#suffix' => "</div>"
          ];
      }



      $form['price'] = [
          '#type' => 'number',
          //'#title' => t("Hourly price (VAT not included)"),
          '#required' => TRUE,
          '#required_error' => t('Price is required'),
          '#default_value' => isset($this->getValues()['price']) ? $this->getValues()['price'] : 0,
      ];

      //Get country code from step 1, passed to here by hidden fields - this was the only way it worked.
      $country_code = $form_state->getValues()['country_code'];


      //Get country details by country code
      $arr_country_details = get_country_details_by_country_code($country_code);
      //print_r($arr_country_details);die;
      $form["currencies"] = [
          '#prefix' => '<div class="currency_symbol">',
          '#markup' => $arr_country_details['currency_symbol'],
          '#suffix' => '</div>',
      ];


      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 4,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];






      //SERVICES - PAID

      //Get all the services terms
      $arr_all_services =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('services');

      $language_id =  \Drupal::languageManager()->getCurrentLanguage()->getId();

      //build array
      foreach($arr_all_services as $service) {

          $obj_service_fields = Term::load($service->tid);


          //Service name
          //$str_service_name = $obj_service_fields->getName();//OLD CODE: NOT TRANSLATED
          //retrieve the translated taxonomy term in specified language ($curr_langcode) with fallback to default language if translation not exists
          $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($obj_service_fields, $language_id);
          $str_service_name = $taxonomy_term_trans->getName();


          //Service paid for - boolean - whether it's paid for (then its extra service) or not (and then it's amenity)
          $bln_service_paid = $obj_service_fields->field_service_paid->getValue()[0]["value"];


          //Service category (spaces or properties)
          $str_service_category = $obj_service_fields->field_service_category->getValue()[0]["value"];
          //echo $str_service_category . "<br/>";

          //Service type (stationary, electronic etc.)
          $str_service_type = $obj_service_fields->field_service_type->getValue()[0]["value"];
          //echo $str_service_type . "<br/>";

          //If the service IS PAID for ("extra service") and the service category is "spaces"
          if ($obj_service_fields != NULL && isset($obj_service_fields->get('field_service_icon')->entity) && $bln_service_paid == true && $str_service_category == "spaces" && $obj_service_fields->hasField('field_service_icon')) {

              //Load image URI
              $image_uri = $obj_service_fields->get('field_service_icon')->entity->getFileUri();

              //Style thumbnail so we can change later from admin system
              $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
              $url = $style->buildUrl($image_uri);



              //Add into $this->arr_services_paid:
              if(!isset($this->arr_services_paid[$str_service_type])){

                  //If we don't have an array for this service type, create one and add it to arr_services_paid
                  //Add the image AND the term name to the array
                  $arr_services_paid_temp = [];
                  $arr_services_paid_temp[$service->tid]['service_name'] = "<img src=".$url."/>".$str_service_name;
                  //Add str_service_type to the array
                  $arr_services_paid_temp[$service->tid]['category'] = $str_service_type;
                  $this->arr_services_paid[$str_service_type] = $arr_services_paid_temp;
              } else {

                  //If we have an array for this service type, get it, add a new item and add it back into arr_services_paid
                  $tmp_array = $this->arr_services_paid[$str_service_type];
                  $tmp_array[$service->tid]['service_name'] = "<img src=".$url."/>".$str_service_name;
                  $tmp_array[$service->tid]['category'] = $str_service_type;
                  $this->arr_services_paid[$str_service_type] = $tmp_array;
              }
          }
      }

      foreach($this->arr_services_paid as $key1 => $values1) {

          //print '<pre>'; echo $key1; print_r($values1);die;

          //Create a HTML "fieldset" with id as machine name  ---    'service_paid_wrapper'][str_replace(" ","_",$key1)
          $form['service_paid_wrapper'][str_replace(" ","_",$key1)] = array(
              '#type' => 'fieldset',
              '#title' => t(str_replace("_"," ",$key1)),
              '#collapsible' => TRUE,
              '#collapsed' => TRUE,
          );


          //Create all the "fields" inside the "fieldset" with the same machine name and some more...  ----  "service_paid_wrapper"][str_replace(" ","_",$key1)]
          foreach ($values1 as $key => $values) {
              $final_arr_services_paid = [];
              $final_arr_services_paid[$key] = $values['service_name'];

              //Create the checkbox
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_item_' . $key] = [
                  '#type' => 'checkbox',
                  '#title' => $values['service_name'], //Image and term name
                  //'#options' => $final_arr_space_layout,
                  '#default_value' => isset($this->getValues()['service_paid_item_' . $key]) ? $this->getValues()['service_paid_item_' . $key] : [],
                  '#required' => FALSE,
                  '#prefix' => '<div class="service_paid_item row table-row">', //PREFIX
              ];

              //Create the description field
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_description_' . $key] = [
                  '#type' => 'textarea',
                  '#attributes' => [
                      'disabled' => true,
                      'placeholder' => array(t('Describe this product')),
                  ],
                  '#default_value' => isset($this->getValues()['service_paid_description_' . $key]) ? $this->getValues()['service_paid_description_' . $key] : NULL,
              ];

              //Create the price field
              $form["service_paid_wrapper"][str_replace(" ","_",$key1)]['service_paid_price_' . $key] = [
                  '#type' => 'number',
                  '#attributes' => [
                      'disabled' => true,
                  ],
                  '#default_value' => isset($this->getValues()['service_paid_price_' . $key]) ? $this->getValues()['service_paid_price_' . $key] : 0,
              ];


              if(isset($arr_country_details)){
                  $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_currency_' . $key] = [
                      '#prefix' => '<div class="currency_symbol">',
                      '#markup' => $arr_country_details['currency_symbol'],
                      '#suffix' => '</div></div>',
                  ];
              }
          }
      }
      //END SERVICES - PAID




      //CANCELLATION POLICIES
      $sort_by_key = false;
      $arr_cancellation_policies = get_taxonomy_term_values('cancellation_policy', $sort_by_key);

      //build array
      $arr_cancellation_policies_organized = array();
      foreach($arr_cancellation_policies as $key => $policy) {
          $str_html = get_cancellation_policy_html($key);
          $arr_cancellation_policies_organized[$key] = $str_html;
      }

      $free_cancellation = t("Free cancellation");
      $cancellation_fee = t("Cancellation fee");
      $none_refundable = t("None refundable");

      $form["cancellation_policies"] = [
          '#type' => 'radios',
          '#options' => $arr_cancellation_policies_organized,
          '#default_value' => isset($this->getValues()['cancellation_policies']) ? $this->getValues()['cancellation_policies'] : NULL,
          '#required' => TRUE,
          '#prefix' =>'<div class="cancellation_fee_header"><div>&nbsp;</div><div>' . $free_cancellation . '</div><div>'.$cancellation_fee.'</div><div>'.$none_refundable.'</div></div>',
      ];
      //END CANCELLATION POLICIES




      $form['#theme'] = 'bs_form_listaspace_step4';

      return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
        'weekdays',
        'price',
        'currencies',
        'cancellation_policies'
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
      return [
          'cancellation_policies' => [
              new ValidatorRequired("Cancellation policy is required 11"),
          ],
          'price' => [
              new ValidatorRequired(t("Price is required")),
              new ValidatorRegex(t("Price must be greater then 0"), '/^[1-9]\d*$/'),
          ],
      ];
  }
}
