<?php

namespace Drupal\bs_form_listaspace\Step;

use Drupal\bs_form_listaspace\Button\StepTwoNextButton;
use Drupal\bs_form_listaspace\Button\StepTwoPreviousButton;
use Drupal\bs_form_listaspace\Validator\ValidatorRequired;
use Drupal\bs_form_listaspace\Validator\ValidatorRegex;
use Drupal\taxonomy\Entity\Term;
use Drupal\node\Entity\Node;
use Drupal\bs_form_listaspace\Manager\StepManager;


/**
 * Class StepTwo.
 *
 * @package Drupal\bs_form_listaspace\Step
 */
class StepTwo extends BaseStep {

    //Create array to hold all inner arrays, each for a category
    private $arr_amenities;

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_TWO;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepTwoPreviousButton(),
      new StepTwoNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements($form_state = null) {

      $language_id =  \Drupal::languageManager()->getCurrentLanguage()->getId();

      //Load space_activities values
      $arr_space_activities = get_space_activities_values();

      //Load space_types values
      $arr_space_types = get_taxonomy_term_values('space_types');



      $form['space_title'] = [
          '#type' => 'textfield',
          //'#title' => t("Space title"),
          '#required' => FALSE,
          '#default_value' => isset($this->getValues()['space_title']) ? $this->getValues()['space_title'] : NULL,
          '#attributes' => [
              'placeholder' => array(t('A great space in the soho')),
          ],
      ];

      $form['space_description'] = [
          '#type' => 'textarea',
          //'#title' => t("Space description"),
          '#default_value' => isset($this->getValues()['space_description']) ? $this->getValues()['space_description'] : NULL,
          '#attributes' => [
              'placeholder' => array(t('My space has... You will love my space because... The space suitable for meeting... etc')),
          ],
      ];

      $form['space_type'] = [
          '#type' => 'select',
          //'#title' => t("Space type"),
          '#required' => FALSE,
          '#options' => $arr_space_types,
          '#default_value' => isset($this->getValues()['space_type']) ? $this->getValues()['space_type'] : NULL,
      ];




      $form['space_size'] = [
          '#type' => 'number',
          //'#title' => t("Space size"),
          '#required' => FALSE,
          '#default_value' => isset($this->getValues()['space_size']) ? $this->getValues()['space_size'] : 0,
          '#min' => 0,
          '#max' => 10000
      ];

      //get country code from step 1
      $country_code = $form_state->getValues()['address']['country_code'];
      if(!isset($country_code)){
          //$country_code = $form_state->getValues()['country_code'];
          $property_id = isset($_REQUEST['property_id']) ? $_REQUEST['property_id'] : 0;

          if ($property_id) {
              $property_node = node_load($property_id);
              if (!empty($property_node)) {
                  //Get the country code of the property
                  $country_code = $property_node->field_property_address->getValue()[0]['country_code'];
              }
          }
      }
      //kint($country_code); die();

      //Get country details by country code
      $arr_country_details = get_country_details_by_country_code($country_code);
      //print_r($arr_country_details);die;
      $form["space_size_units"] = [
          '#prefix' => '<div class="space_size_unit">',
          '#markup' => $arr_country_details['measure_units'],
          '#suffix' => '</div>',
      ];


      $form['country_code'] = [
          '#type' => 'hidden',
          '#default_value' => $country_code,
      ];




      foreach($arr_space_activities as $key => $values) {

          $form['space_activity']['space_activity_' . $key] = [
              '#type' => 'checkboxes',
              '#title' => t($key),
              '#options' => $values,
              '#default_value' => isset($this->getValues()['space_activity_' . $key]) ? $this->getValues()['space_activity_' . $key] : [],
              '#required' => FALSE,
              '#prefix' => '<div class="space_activities_section">',
              '#suffix' => '</div>'
          ];
      }


      //SPACE LAYOUT
      //Get all the space_layout terms
      $terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree("space_layout");

      //build array
      $arr_space_layout = array();
      $arr_values = array();

      //Run on the space_layout terms and load and handle each of them
      foreach ($terms as $term) {
          $arr_values[$term->tid] = $term->name;
          $term_obj = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term->tid);
          if($term_obj != NULL){

              //Load image URI
              $image_uri = $term_obj->get('field_space_layout_image')->entity->getFileUri();
              if($image_uri != NULL){

                  //$image_path = file_create_url($image_uri);

                  //Style thumbnail so we can change later from admin system
                  $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                  $url = $style->buildUrl($image_uri);

                  //Add the image AND the translated term name to the array
                  $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($term_obj, $language_id);
                  $str_name = $taxonomy_term_trans->getName();

                  $arr_space_layout[$term->tid]['term_name'] = "<img src=".$url."/>".$str_name;

                  //Add max_capacity to the array
                  $arr_space_layout[$term->tid]['capacity'] = $term_obj->field_space_layout_max_participa->getValue();
              }
          }
      }

      //Run on the array created
      foreach($arr_space_layout as $key=>$values){
          $final_arr_space_layout = [];
          $final_arr_space_layout[$key] = $values['term_name'];

          //Create the checkbox
          $form["space_layout_wrapper"]['space_layout_item_'.$key] = [
              '#type' => 'checkbox',
              '#title' => $values['term_name'], //Image and term name
              //'#options' => $final_arr_space_layout,
              '#default_value' => isset($this->getValues()['space_layout_item_'.$key]) ? $this->getValues()['space_layout_item_'.$key] : [],
              '#required' => FALSE,
              '#prefix' =>'<div class="space_layout_item">', //PREFIX
          ];

          //Create the numeric field
          $form["space_layout_wrapper"]['space_max_capacity_'.$key] = [
              '#type' => 'number',
              '#suffix' =>'</div>', //SUFFIX
              '#attributes' => [
                  //'placeholder' => $values['capacity'][0]['value'],
                  'disabled' => true,
              ],
              '#default_value' => isset($this->getValues()['space_max_capicity_'.$key]) ? $this->getValues()['space_max_capicity_'.$key] : NULL,
          ];
      }
      //END SPACE LAYOUT







      //Amenities
      //First, get all services which includes also paid for (those are "extra services") and services for properties
      $arr_services =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('services');

      //MOVED OUTSIDE OF FUNTION SO WE CAN USE IT ON FUNCTION getFieldName()
      //Create array to hold all inner arrays, each for a category
      $this->arr_amenities = array();

      //Run on all services
      foreach($arr_services as $service) {

          $tid = $service->tid;

          //Load the service fields (field_service_category, field_service_icon, field_service_paid, field_service_type)
          $obj_service_fields = Term::load($service->tid);

          //Service name
          //$str_name = $service->name; //OLD CODE - NOT TRANSLATED
          //retrieve the translated taxonomy term in specified language ($curr_langcode) with fallback to default language if translation not exists
          $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($obj_service_fields, $language_id);
          $str_name = $taxonomy_term_trans->getName();

          //Service paid for - boolean - whether it's paid for (then its extra service) or not (and then it's amenity)
          $bln_service_paid = $obj_service_fields->field_service_paid->getValue()[0]["value"];

          //Service category (spaces or properties)
          $str_service_category = $obj_service_fields->field_service_category->getValue()[0]["value"];

          //Service type (stationary, electronic etc.)
          $str_service_type = $obj_service_fields->field_service_type->getValue()[0]["value"];


          //If the service is not paid for and the service category is "spaces"
          if($bln_service_paid == false && $str_service_category == "spaces"){

              //Add into $arr_amenities:
              if(!isset($this->arr_amenities[$str_service_type])){

                  //If we don't have an array for this service type, create one and add it to $arr_amenities
                  $tmp_array = array($tid => $str_name);
                  $this->arr_amenities[$str_service_type] = $tmp_array;
              } else {

                  //If we have an array for this service type, get it, add a new item and add it back into $arr_amenities
                  $tmp_array = $this->arr_amenities[$str_service_type];
                  $tmp_array[$tid] = $str_name;
                  $this->arr_amenities[$str_service_type] = $tmp_array;
              }
          }
      }

      //debug($this->arr_amenities);

      //Run on $arr_amenities and add a checkbox list for each of the arrays (categories) inside
      foreach($this->arr_amenities as $key => $values) {
          $form['services_type']['services_' . $key] = [
              '#type' => 'checkboxes',
              '#title' => t($key),
              '#options' => $values,
              '#default_value' => isset($this->getValues()['services_' . $key]) ? $this->getValues()['services_' . $key] : [],
              '#required' => FALSE,
              '#prefix' => '<div>',
              '#suffix' => '</div>'
          ];
      }
      //END Amenities

      $form["bs_current_step"] = [
          "#type" => 'hidden',
          "#value" => 2,
          "#attributes" => [
              "class" => ["bs-current-step"]
          ],
      ];
      $form['#theme'] = 'bs_form_listaspace_step2';

      return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {

      /*
      return [
          'space_title',
          'space_description',
          'space_size',
          'space_size_units',
          'space_activity',
          'space_layout'
      ];
      */

      $arr_to_return = array('space_title',
          'space_description',
          'space_size',
          'space_size_units',
          'space_activity',
          'space_layout',
          'space_type');

      //Add values from $this->arr_amenities so we save these values as well
      foreach($this->arr_amenities as $key => $values) {
          array_push($arr_to_return, $key);
      }

      return $arr_to_return;

  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
        'space_title' => [
            new ValidatorRequired("Please insert your space title"),
        ],
        'space_size' => [
            new ValidatorRegex(t("Please use digits only in the space size field"), '^[0-9]\d*$^'),
        ],
    ];
  }

}
