<?php

namespace Drupal\bs_property_workflow\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\file\Entity\File;
use CommerceGuys\Addressing\AddressFormat\AddressField;
use CommerceGuys\Addressing\AddressFormat\FieldOverride;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * Provides a form for edit property.
 *
 * @internal
 */
class BsPropertyEditForm extends FormBase
{

    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {
        return 'bs_property_edit_form';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL)
    {
        // Load property types.
        $sort_by_key = TRUE;
        $arr_property_types = get_taxonomy_term_values('property_types', $sort_by_key);
        // Load values from DB.
        $property_name = "";
        if (!$node->get('field_property_name')->isEmpty()) {
            $property_name = $node->get('field_property_name')->getValue()[0]["value"];
        }
        $property_description = "";
        if (!$node->get('field_property_description')->isEmpty()) {
            $property_description = $node->get('field_property_description')->getValue()[0]["value"];
        }
        $property_type = "";
        if (!$node->get('field_property_types')->isEmpty()) {
            $property_type = $node->get('field_property_types')->getValue()[0]["target_id"];
        }
        $property_logo_file_id = "";
        if (!$node->get('field_property_logo')->isEmpty()) {
            $property_logo_file_id = $node->get('field_property_logo')->getValue()[0]["target_id"];
        }

        $property_parking = "";
        if (!$node->get('field_property_parking')->isEmpty()) {
            $property_parking = $node->get('field_property_parking')->getValue()[0]["value"];
        }

        $property_restaurant = "";
        if (!$node->get('field_property_restaurant')->isEmpty()) {
            $property_restaurant = $node->get('field_property_restaurant')->getValue()[0]["value"];
        }

        $country_code = "";
        $administrative_area = "";
        $locality = "";
        $address = "";
        if (!$node->get('field_property_address')->isEmpty()) {
            $country_code = $node->get('field_property_address')->getValue()[0]['country_code'];
            if (!$node->get('field_property_address')->isEmpty()) {
                $administrative_area = $node->get('field_property_address')->getValue()[0]['administrative_area'];
            }
            if (!$node->get('field_property_address')->isEmpty()) {
                $locality = $node->get('field_property_address')->getValue()[0]['locality'];
            }
            if (!$node->get('field_property_address')->isEmpty()) {
                $address = $node->get('field_property_address')->getValue()[0]['address_line1'];
            }
        }




        //NEAR BY AUTO OR MANUALLY
        $near_by_auto = true;
        if($node->hasField('field_near_by_auto')){
            $near_by_auto = $node->get('field_near_by_auto')->getValue()[0]["value"];
        }
        //kint($near_by_auto);
        $form['near_by_auto'] = [
            '#type' => 'checkbox',
            '#default_value' => $near_by_auto,
            //'#attributes' => array('class' => "toggle_switch")
            '#field_prefix' => '<div class="toggle_switch">',
            '#field_suffix' => '<span class="slider round ofek"></span></div>',
        ];


        //For hidden fields for edit
        $form['parking'] = [
            '#type' => 'fieldset',
            //'#title' => $this->t('Parking'),
        ];

        $form['restaurant'] = [
            '#type' => 'fieldset',
            //'#title' => $this->t('Restaurant'),
        ];

        //NEAR BY
        $int_parking_edit_elements = 0;
        $int_restaurant_edit_elements = 0;
        $property_existing_nearby = "";
        if (!$node->get('field_property_near_by')->isEmpty()) {
            $property_existing_nearby = $node->get('field_property_near_by')->getValue();
        }
        foreach ($property_existing_nearby as $key => $value) {
            $pid = $value['target_id'];

            $paragraph = Paragraph::load($pid);
            if ($paragraph != NULL) {
                $title = "";
                if (!$paragraph->get('field_near_by_title')->isEmpty()) {
                    $title = $paragraph->get('field_near_by_title')->getValue()[0]['value'];
                }
                $description = "";
                if (!$paragraph->get('field_near_by_description')->isEmpty()) {
                    $description = $paragraph->get('field_near_by_description')->getValue()[0]['value'];
                }

                if (!$paragraph->get('field_near_by_minutes')->isEmpty()) {
                    $minutes = $paragraph->get('field_near_by_minutes')->getValue()[0]['value'];
                } else {
                    $minutes = 2; //default
                }
                $field_near_by_type = "";
                if (!$paragraph->get('field_near_by_type')->isEmpty()) {
                    $field_near_by_type = $paragraph->get('field_near_by_type')->getValue();
                }
                $tid = $field_near_by_type[0]['target_id'];
                $term = \Drupal\taxonomy\Entity\Term::load($tid);
                $type = "";
                if ($term != NULL) {
                    $type = $term->getName();
                }
                $property_nearby[] = [
                    'type' => $type,
                    'title' => $title,
                    'description' => $description,
                    'minutes' => $minutes,
                ];


                //For the edit
                if($type == "Parking"){
                    $str_name = "parking";
                    $int_element_id = $int_parking_edit_elements;
                    $int_parking_edit_elements += 1;
                } else {
                    $str_name = "restaurant";
                    $int_element_id = $int_restaurant_edit_elements;
                    $int_restaurant_edit_elements += 1;
                }
                $form[$str_name][$str_name . '_name_' . $int_element_id] = [
                    '#type' => 'textfield',
                    '#default_value' => $title,
                    '#prefix' => '<div class="nearby_location col-sm-4">',
                ];
                $form[$str_name][$str_name . '_description_' . $int_element_id] = [
                    '#type' => 'textfield',
                    '#default_value' => remove_p_tag($description)
                ];
                $form[$str_name][$str_name . '_minutes_' . $int_element_id] = [
                    '#type' => 'textfield',
                    '#default_value' => $minutes,
                    '#attributes' => array('class' => array('minutes')),
                    '#field_suffix' => '<label>minutes walk</label>',
                    '#suffix' => '</div>',
                ];
            }
        }


        //If there are less then 3 parking edit fields, add more, up to 3
        for ($i = $int_parking_edit_elements; $i < 3; $i++) {
            $str_name = "parking";
            $form[$str_name][$str_name . '_name_' . $i] = [
                '#type' => 'textfield',
                '#prefix' => '<div class="nearby_location col-sm-4">',
            ];
            $form[$str_name][$str_name . '_description_' . $i] = [
                '#type' => 'textfield',
            ];
            $form[$str_name][$str_name . '_minutes_'. $i] = [
                '#type' => 'textfield',
                '#default_value' => 2,
                '#attributes' => array('class' => array('minutes')),
                '#field_suffix' => '<label>minutes walk</label>',
                '#suffix' => '</div>',
            ];
        }

        //If there are less then 3 restaurants edit fields, add more, up to 3
        for ($i = $int_restaurant_edit_elements; $i < 3; $i++) {
            $str_name = "restaurant";
            $form[$str_name][$str_name . '_name_' . $i] = [
                '#type' => 'textfield',
                '#prefix' => '<div class="nearby_location col-sm-4">',
            ];
            $form[$str_name][$str_name . '_description_' . $i] = [
                '#type' => 'textfield',
            ];
            $form[$str_name][$str_name . '_minutes_'. $i] = [
                '#type' => 'textfield',
                '#default_value' => 2,
                '#attributes' => array('class' => array('minutes')),
                '#field_suffix' => '<label>minutes walk</label>',
                '#suffix' => '</div>',
            ];
        }

        //For the display
        $form['property_nearby'] = $property_nearby;


        /*
        //For hidden fields for edit
        $form['parking'] = [
            '#type' => 'fieldset',
            //'#title' => $this->t('Parking'),
            //'#collapsible' => FALSE,
        ];

        $form['parking']['parking_name'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[0]['title']
        ];
        $form['parking']['parking_description'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[0]['description'])
        ];
        $form['parking']['minutes'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[0]['minutes'])
        ];

        $form['parking']['parking_name1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[1]['title']
        ];
        $form['parking']['parking_description1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[1]['description'])
        ];
        $form['parking']['minutes1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[1]['minutes'])
        ];

        $form['parking']['parking_name2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[2]['title']
        ];
        $form['parking']['parking_description2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[2]['description'])
        ];
        $form['parking']['minutes2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[2]['minutes'])
        ];

        $form['restaurant'] = [
            '#type' => 'fieldset',
            //'#title' => $this->t('Restaurant'),
        ];


        $form['restaurant']['restaurant_name'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[3]['title']
        ];
        $form['restaurant']['restaurant_description'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[3]['description'])
        ];
        $form['restaurant']['minutes'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[3]['minutes'])
        ];

        $form['restaurant']['restaurant_name1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[4]['title']
        ];
        $form['restaurant']['restaurant_description1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[4]['description'])
        ];
        $form['restaurant']['minutes1'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[4]['minutes'])
        ];

        $form['restaurant']['restaurant_name2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Name'),
            '#default_value' => $property_nearby[5]['title']
        ];
        $form['restaurant']['restaurant_description2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Description'),
            '#default_value' => strip_tags($property_nearby[5]['description'])
        ];
        $form['restaurant']['minutes2'] = [
            '#type' => 'textfield',
            //'#title' => $this->t('Minutes'),
            '#default_value' => strip_tags($property_nearby[5]['minutes'])
        ];
        */
        //END NEAR BY



        $form['header_property_name'] = $property_name;
        $form['property_type'] = [
            '#type' => 'select',
            '#options' => $arr_property_types,
            '#default_value' => $property_type
        ];

        $form['property_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#default_value' => $property_name
        ];

        $form['property_description'] = [
            '#type' => 'textarea',
            '#default_value' => strip_tags($property_description)
        ];




        //TRANSLATIONS
        $other_languages = get_system_other_languages();

        //Create an array for the select that asks the user which language to add
        $arr_other_languages = [];
        foreach($other_languages as $key => $values) {

            //Create an array for the select that asks the user which language to add
            $arr_other_languages[$key] = $values->getName();

            $property_name = "";
            $property_description = "";
            $hidden_class = "hide";

            if($node->hasTranslation($key)) {

                //Other languages
                $obj_property_translated = $node->getTranslation($key);
                $property_name = $obj_property_translated->getTitle();
                $property_description = $obj_property_translated->get('field_property_description')->getValue()[0]["value"];
                $hidden_class = "";
            }


            $form['property_name_languages']['property_name_languages_' . $key] = [
                '#type' => 'textfield',
                '#title' => t('Property name in ') . $values->getName(),
                '#default_value' => $property_name,
                '#prefix' => '<div class="div_language_'.$key.' '.$hidden_class.'">',
                '#suffix' => '</div>'
            ];

            $form['property_description_languages']['property_description_languages_' . $key] = [
                '#type' => 'textarea',
                '#title' => t('Property description in ') . $values->getName(),
                '#default_value' => strip_tags($property_description),
                '#prefix' => '<div class="div_language_'.$key.' '.$hidden_class.'">',
                '#suffix' => '</div>'
            ];
        }

        //For the select that asks the user which language to add
        $form['other_languages'] = [
            '#type' => 'select',
            '#options' => $arr_other_languages
        ];
        //END TRANSLATIONS

        $form['property_logo'] = [
            '#type' => 'managed_file',
            '#upload_location' => 'public://property-images/',
            '#default_value' => [$property_logo_file_id],
        ];



        //Property internal parking
        $form["property_parking"] = [
            '#type' => 'checkbox',
            //'#title' => t('Internal parking'), //Image and term name
            '#default_value' => $property_parking,
            '#required' => FALSE,
        ];

        //Property internal restaurant
        $form["property_restaurant"] = [
            '#type' => 'checkbox',
            //'#title' => t('Internal parking'), //Image and term name
            '#default_value' => $property_restaurant,
            '#required' => FALSE,
        ];


        //$countries = \Drupal::service('address.country_repository')->getList();
        $countries = get_available_countries();

        $form['space_layout_address_wrapper']['address'] = [
            '#type' => 'address',
            '#default_value' => [
                // street.
                'address_line1' => $address,
                // city.
                'locality' => $locality,
                // state.
                'administrative_area' => $administrative_area,
                // country.
                'country_code' => isset($country_code) ? $country_code : 'GB',
                'langcode' => 'en',
            ],
            '#field_overrides' => [
                AddressField::ORGANIZATION => FieldOverride::HIDDEN,
                AddressField::ADDRESS_LINE2 => FieldOverride::HIDDEN,
                AddressField::POSTAL_CODE => FieldOverride::HIDDEN,
                AddressField::GIVEN_NAME => FieldOverride::HIDDEN,
                AddressField::FAMILY_NAME => FieldOverride::HIDDEN,
            ],
            '#available_countries' => array_keys($countries),
        ];
        $form['gmap'] = [
            '#markup' => ' <div id="map"></div>',
        ];


        $form['#theme'] = 'form__bs_property_edit_form';
        $form['#attached']['library'][] = 'bs_form_listaspace/bookaspace-map-near-by';
        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => t('Save'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        $form['node_obj'] = [
            '#type' => 'value',
            '#value' => $node,
        ];
        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        $field = $form_state->getValues();
        $node = $field['node_obj'];
        $nid = $node->id();
        $property_type = $field['property_type'];
        $property_name = $field['property_name'];
        $property_description = $field['property_description'];
        $property_parking = $field['property_parking'];
        $property_restaurant = $field['property_restaurant'];


        //get translated values into an array
        $arr_languages = [];
        foreach ($field as $key => $value) {

            //Run on all fields of the form
            //If we have a translated field of "property name", get the language and add to an array
            if (strpos($key, 'property_name_languages_') !== false && $value != "") {
                $langauge_array = explode("property_name_languages_", $key);
                $language = $langauge_array[1];
                $arr_languages[$language]['field_property_name'] = $value;
            }

            //If we have a translated field of "property description", get the language and add to an array
            if (strpos($key, 'property_description_languages_') !== false  && $value != "") {
                $langauge_array = explode("property_description_languages_", $key);
                $language = $langauge_array[1];
                $arr_languages[$language]['field_property_description'] = $value;
            }
        }



        $property_logo_file_id = $field['property_logo'][0];
        $country_code = $field['country_code'];
        $state = $field['states'];
        $city = $field['city'];
        $street_address = $field['street_address'];
        $address = $field['address'];
        $near_by_auto_new = $field['near_by_auto'];

        // Find the term id of taxonomy country_details according to the country selected, according to the $country_code.
        //$country_details_tid = get_countries_details_tid_from_country_code($country_code);

        //NEAR BY
        //Create an array of parking
        $parking = [
            '0' => [
                'parking_name' => $field['parking_name_0'],
                'parking_description' => $field['parking_description_0'],
                'parking_minutes' => $field['parking_minutes_0'],
            ],
            '1' => [
                'parking_name' => $field['parking_name_1'],
                'parking_description' => $field['parking_description_1'],
                'parking_minutes' => $field['parking_minutes_1'],
            ],
            '2' => [
                'parking_name' => $field['parking_name_2'],
                'parking_description' => $field['parking_description_2'],
                'parking_minutes' => $field['parking_minutes_2'],

            ],
        ];

        //Create an array of restaurants
        $restaurant = [
            '0' => [
                'restaurant_name' => $field['restaurant_name_0'],
                'restaurant_description' => $field['restaurant_description_0'],
                'restaurant_minutes' => $field['restaurant_minutes_0'],
            ],
            '1' => [
                'restaurant_name' => $field['restaurant_name_1'],
                'restaurant_description' => $field['restaurant_description_1'],
                'restaurant_minutes' => $field['restaurant_minutes_1'],
            ],
            '2' => [
                'restaurant_name' => $field['restaurant_name_2'],
                'restaurant_description' => $field['restaurant_description_2'],
                'restaurant_minutes' => $field['restaurant_minutes_2'],
            ],
        ];

        //Set keys of parking and restaurants
        $vid = 'nearby';
        $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
        $tid = [];
        $parking_key = "";
        $restaurant_key = "";
        foreach ($terms as $key => $entity) {
            if ($entity->name == "Parking") {
                $parking_key = $entity->tid;
            }
            if ($entity->name == "Restaurant & Coffee Shops") {
                $restaurant_key = $entity->tid;
            }
        }


        //Load property
        $obj_property = Node::load($nid);

        //Check the currenct status of nearby (auto or manual)
        $near_by_auto_current = $node->get('field_near_by_auto')->getValue()[0]["value"];

        //If the user just changed the near by from manual to auto
        if((int)$near_by_auto_current == 0 && (int)$near_by_auto_new == 1){

            //JUST CHANGED TO AUTO. GET DATA FROM GOOGLE MAPS API

            //Empty old near by
            $obj_property->set('field_property_near_by', array());
            $obj_property->save();

            //Set address correctly
            $country_code = $address['country_code'];
            $state = $address['administrative_area'];
            $city = $address['locality'];
            $street = $address['address_line1'];
            $complete_address = $street . "," . $state . "," . $city . "," . $country_code;

            //Get address coordinates
            $get_address_cordinates = json_decode(get_address_cordinates($complete_address));
            $cordinates_array = [
                "lat" => $get_address_cordinates->lat ? $get_address_cordinates->lat : 0,
                "lng" => $get_address_cordinates->lng ? $get_address_cordinates->lng : 0,
            ];

            //Get near by parking and restaurants fron Goolge maps API
            $nearby_obj = get_address_nearby($cordinates_array, true);

            //Decode data
            $nearby_obj_array = json_decode($nearby_obj);

            //Find the keys for the taxonomies
            $vid = 'nearby';
            $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
            $tid = [];
            $parking_key = "";
            $restaurant_key = "";
            foreach ($terms as $key => $entity) {
                if ($entity->name == "Parking") {
                    $parking_key = $entity->tid;
                }
                if ($entity->name == "Restaurant & Coffee Shops") {
                    $restaurant_key = $entity->tid;
                }
            }

            //Add 3 parking to the property object
            if (isset($nearby_obj_array->parking_item_obj)) {
                foreach ($nearby_obj_array->parking_item_obj as $key => $value) {
                    if ($key < 3) {
                        $paragraph_near_by = Paragraph::create([
                            'type' => 'near_by',
                            'field_near_by_title' => $value->name,
                            'field_near_by_description' => $value->vicinity,
                            'field_near_by_type' => $parking_key,
                        ]);
                        $paragraph_near_by->save();
                        $obj_property->field_property_near_by[] = $paragraph_near_by;
                    }
                }
            }

            //Add 3 restaurants to the property object
            if ($nearby_obj_array->restaurant_item_obj) {
                foreach ($nearby_obj_array->restaurant_item_obj as $key => $value) {
                    if ($key < 3) {
                        $paragraph_near_by2 = Paragraph::create([
                            'type' => 'near_by',
                            'field_near_by_title' => $value->name,
                            'field_near_by_description' => $value->vicinity,
                            'field_near_by_type' => $restaurant_key,
                        ]);
                        $paragraph_near_by->save();
                        $obj_property->field_property_near_by[] = $paragraph_near_by2;
                    }
                }
            }

        } else if($near_by_auto_new == 0){

            //IF WE ARE ON MANUAL

            //Empty old near by
            $obj_property->set('field_property_near_by', array());
            $obj_property->save();

            //Add parking
            foreach ($parking as $key => $value) {
                if (!empty($value['parking_name'])) {
                    $paragraph_near_by_parking = Paragraph::create([
                        'type' => 'near_by',
                        'field_near_by_title' => $value['parking_name'],
                        'field_near_by_description' => $value['parking_description'],
                        'field_near_by_minutes' => $value['parking_minutes'],
                        'field_near_by_type' => $parking_key,
                    ]);
                    $paragraph_near_by_parking->save();
                    $obj_property->field_property_near_by[] = $paragraph_near_by_parking;
                }
            }

            //Add restaurant
            foreach ($restaurant as $key => $value) {
                if (!empty($value['restaurant_name'])) {
                    $paragraph_near_by_rest = Paragraph::create([
                        'type' => 'near_by',
                        'field_near_by_title' => $value['restaurant_name'],
                        'field_near_by_description' => $value['restaurant_description'],
                        'field_near_by_minutes' => $value['restaurant_minutes'],
                        'field_near_by_type' => $restaurant_key,
                    ]);
                    $paragraph_near_by_rest->save();
                    $obj_property->field_property_near_by[] = $paragraph_near_by_rest;
                }
            }
        }
        //END NEAR BY


        $obj_property->field_property_types = $property_type;
        $obj_property->title = $property_name;
        $obj_property->field_property_name = $property_name;
        $obj_property->field_property_title = $property_name;
        $obj_property->field_property_description = $property_description;
        $obj_property->field_property_parking = $property_parking;
        $obj_property->field_property_restaurant = $property_restaurant;

        // Handle the property logo image: get the file id and save it permanently - drupal adds it on tables file_uses OR file_managed.
        if (isset($property_logo_file_id)) {

        }

        if (isset($property_logo_file_id)) {

            $file1 = File::load($property_logo_file_id);
            $file1->setPermanent();
            $file1->save();

            $property_logo_file_id = [
                'target_id' => $file1->id(),
                'alt' => $property_name,
                'title' => $property_name,
            ];

            $obj_property->field_property_logo = $property_logo_file_id;
        }
        $obj_property->field_property_address = $address;
        $obj_property->field_near_by_auto = $near_by_auto_new;
        //$obj_property->field_property_country_details = $country_details_tid;
        $obj_property->save();


        //TRANSLATE:
        //Run on array languages
        foreach ($arr_languages as $key => $arr_values) {

            //FOR EACH LANGUAGE

            //If we have translation, get it. If not, create a new translation.
            if($node->hasTranslation($key)){
                $obj_property_translated = $node->getTranslation($key);
            }  else {
                $obj_property_translated = $node->addTranslation($key);

                //Duplicate all the fields from the original language
                $obj_property_translated->field_property_types = $obj_property->field_property_types;
                $obj_property_translated->field_property_parking = $obj_property->field_property_parking;
                $obj_property_translated->field_property_restaurant = $obj_property->field_property_restaurant;
                $obj_property_translated->field_property_address = $obj_property->field_property_address;
                $obj_property_translated->field_property_near_by = $obj_property->field_property_near_by;
                $obj_property_translated->field_property_by_bus = $obj_property->field_property_by_bus;
                $obj_property_translated->field_property_by_car = $obj_property->field_property_by_car;
                $obj_property_translated->field_property_by_foot = $obj_property->field_property_by_foot;
                $obj_property_translated->field_property_by_train = $obj_property->field_property_by_train;
                $obj_property_translated->field_property_creator = $obj_property->field_property_creator;
                $obj_property_translated->field_property_host = $obj_property->field_property_host;
                $obj_property_translated->field_property_manager = $obj_property->field_property_manager;
                $obj_property_translated->field_property_email = $obj_property->field_property_email;
                $obj_property_translated->field_property_notes = $obj_property->field_property_notes;
                $obj_property_translated->field_property_phone = $obj_property->field_property_phone;
                $obj_property_translated->field_space_services = $obj_property->field_space_services;
                $obj_property_translated->field_property_social_links = $obj_property->field_property_social_links;
                $obj_property_translated->field_property_spaces = $obj_property->field_property_spaces;
                $obj_property_translated->field_property_status = $obj_property->field_property_status;
                $obj_property_translated->field_property_website = $obj_property->field_property_website;
                $obj_property_translated->field_property_logo = $property_logo_file_id;
            }

            //Update the translated fields
            foreach ($arr_values as $key1 => $value1) {

                //If it's the property name, assign it to few fields
                if($key1 == "field_property_name"){
                    $obj_property_translated->title = $value1;
                    $obj_property_translated->field_property_name = $value1;
                    $obj_property_translated->field_property_title = $value1;
                } else if($key1 == "field_property_description"){
                    $obj_property_translated->field_property_description = $value1;
                }
            }

            //Save the translated version
            $obj_property_translated->save();
        }



    }

}
