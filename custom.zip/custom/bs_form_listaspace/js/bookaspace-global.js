(function($) {
    
  $.fn.bs_form_after_ajax_handler = function(data) {
    $("html, body").animate({ scrollTop: 0 }, "slow");
    if(data == ""){
        //No error

        //Remove "done" and "current" classes
        $( "div.bs-region--left ul li" ).removeClass("done current");

        //Get current step
        var step = $('input[name^="bs_current_step"]').val();

        //Mark current step with class "current"
        $( "div.bs-region--left ul li:nth-child(" + step + ")" ).addClass( "current" );

        //Add class "done" on previous steps
        var i;
        for (i = 1; i < step; i++) {
            $( "div.bs-region--left ul li:nth-child(" + i + ")" ).addClass( "done" );
        }

    } else {
        //There is an error on submitting the form
        //alert("There is an error 34343 " + data);

        //If we are on the weekdays form, enable the chedcked ones
        $('input[name^="weekdays_day_"]').each(function( index,element ) {
            if($(this).prop("checked") == true) {
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("weekdays_day_");
                $('select[name^="weekdays_start_time_' + getTermId[1] + '"]').removeAttr("disabled");
                $('select[name^="weekdays_end_time_' + getTermId[1] + '"]').removeAttr("disabled");
            }
        });
    }
    var step = $('input[name^="bs_current_step"]').val();
    //alert(step);
     if (step == 1) {
      //alert(step);
        var country_code = $('select[name="address[country_code]"]').val();
        var state = $('select[name="address[administrative_area]"] option:selected').text();
        var city = $('input[name="address[locality]"]').val();
        var street = $('input[name="address[address_line1]"]').val();
        street = street.replace(' ', '+');
        state = state.replace(' ', '+');
        city = city.replace(' ', '+');
        var address = street  + ',' + city + ',' + state + '+' + country_code;
        console.log("address: " + address);
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 15);
          }
        });
      }                                                                                      
  };
})(jQuery);


jQuery(function($) {'use strict';
    $(document).ready(function(){
            //Load the map
       if($("#map").length){
           initMap();
       }
      //$('.address-line1').trigger("change");
      var step = 1;
      if ($('input[name^="bs_current_step"]').length > 0) {
        step = $('input[name^="bs_current_step"]').val();
      }

      //On form listaspace, mark the first step, on the left, as the current step
      $( "div.bs-region--left ul li:nth-child(" + step + ")" ).addClass( "current" );
      //When changing the toggle button on the edit-property page
      $('#toggle_1').change(function() {
        alert($(this).prop('checked'));
      });
      /*var pickupautocomplete = new google.maps.places.Autocomplete(
      document.getElementById('edit-map-search-box'), {types: ['(regions)']}); */
    });       
});