jQuery(function($) {'use strict';
    $(document).ready(function(){
      //Load the map
       if($("#map").length){
           initMap();
       }
      $('.address-line1').trigger("change");

    });       
});

var map;
function initMap(lat, lng, zoom_level = 5,context) {
  if(!lat && !lng){
    // If no lat and lng, set to London.
    lat = 51.5074;
    lng = 0.1278;
  }
  map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: lat, lng: lng},
    width: 800,
    zoom: zoom_level
  });
  var marker = new google.maps.Marker({
    position: {lat: lat, lng: lng},
    map: map,
  });
}

function get_parking_updates(lat,lng){
  jQuery.ajax({
    url: '/nearby-places',
    method: 'GET',
    data: {
       lat:lat,
       lng:lng
    },
    success:function(data){
      data = jQuery.parseJSON(data);    
      jQuery('#parking-container .row').html(data.parking_item);
      jQuery('#restaurant-container .row').html(data.restaurant_item);     
      jQuery( "#parking-container .title" ).each( function( index, element ){
        var title = jQuery( this ).text();
        var key = index;
        if(key == 0) {
          key = '';
        }
        jQuery('input[name=parking_name' + key + ']').val(title);
      });
      jQuery( "#parking-container .address" ).each( function( index, element ){
        var address = jQuery( this ).text();
        var key = index;
        if(key == 0) {
          key = '';
        }
        jQuery('input[name=parking_description' + key + ']').val(address);
      });      
      jQuery( "#restaurant-container .title" ).each( function( index, element ){
        var title = jQuery( this ).text();
        var key = index;
        if(key == 0) {
          key = '';
        }
        jQuery('input[name=restaurant_name' + key + ']').val(title);
      });
      jQuery( "#restaurant-container .address" ).each( function( index, element ){
        var address = jQuery( this ).text();
        var key = index;
        if(key == 0) {
          key = '';
        }
        jQuery('input[name=restaurant_description' + key + ']').val(address);
      });
    }
  });
}

(function($) {
  Drupal.behaviors.bs_form_listaspace = {
    attach: function(context, settings) {
      $('select[name="address[country_code]"]',context).once("Html6").change(function(){
        $('.address-city').val('');
        $('.address-line1').val('');
        var country_code = $('select[name="address[country_code]"] option:selected').text();
        var address = country_code;
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 5);
            //get_parking_updates(lat, lng, 5);
          }
        });
      });
      $('select[name="address[administrative_area]"]',context).once("Html7").change(function(){
        $('.address-city').val('');
        $('.address-line1').val('');
          var country_code = $('select[name="address[country_code]"]').val();
          var state = $('select[name="address[administrative_area]"]').val();
          var address = state + '+' + country_code;
          console.log("address: " + address);
          $.ajax({
            url: '/location',
            method: 'GET',
            data: {
              address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 7);
            //get_parking_updates(lat, lng, 7);
          }
        });
      });
      $('.locality',context).once("Html6").change(function() {
        var country_code = $('select[name="address[country_code]"]').val();
        var state = $('select[name="address[administrative_area]"] option:selected').text();
        var city = $('input[name="address[locality]"]').val();
        state = state.replace(' ', '+');
        city = city.replace(' ', '+');
        var address = city + ',' + state + '+' + country_code;
        console.log("address: " + address);
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 12);
            //get_parking_updates(lat, lng, 12);
          }
        });
      });
      $('.address-line1',context).once("Html2").change(function() {
        var country_code = $('select[name="address[country_code]"]').val();
        var state = $('select[name="address[administrative_area]"] option:selected').text();
        var city = $('input[name="address[locality]"]').val();
        var street = $('input[name="address[address_line1]"]').val();
        street = street.replace(' ', '+');
        state = state.replace(' ', '+');
        city = city.replace(' ', '+');
        var address = street  + ',' + city + ',' + state + '+' + country_code;
        console.log("address: " + address);
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 15);
            //get_parking_updates(lat, lng, 15);
          }
        });
      });
    }
  };
})(jQuery);


