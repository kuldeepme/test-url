jQuery(function($) {'use strict';

$(document).ready(function(){
    //var input = document.querySelector("#edit-phone");
    var input = document.querySelector(".form-tel");

  window.intlTelInput(input, {
    // allowDropdown: false,
    // autoHideDialCode: false,
    // autoPlaceholder: "off",
    dropdownContainer: document.body,
    // excludeCountries: ["us"],
    // formatOnDisplay: false,
    // geoIpLookup: function(callback) {
    //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
    //     var countryCode = (resp && resp.country) ? resp.country : "";
    //     callback(countryCode);
    //   });
    // },
    // hiddenInput: "full_number",
    // initialCountry: "auto",
    // localizedCountries: { 'de': 'Deutschland' },
    // nationalMode: false,
    // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
    // placeholderNumberType: "MOBILE",
    // preferredCountries: ['cn', 'jp'],
    // separateDialCode: true,
    utilsScript: "/bookaspace/modules/custom/bs_form_listaspace/js/utils.js",

  });
});
});


(function($) {

    Drupal.behaviors.bs_form_listaspace_dev = {
        attach: function(context, settings) {
            //document.body.scrollTop = 0; // For Safari
            //document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
          jQuery("#bs-form-listaspace").on('submit', function(event) {
            document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
            event.preventDefault();
            alert( "Handler for .submit() called." );
          });

           //Enable/disable when checking space_layout_item
            $('input[name^="space_layout_item_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("space_layout_item_");
                if($(this).prop("checked") == true){
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').removeAttr("disabled");
                }
                else if($(this).prop("checked") == false){
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').attr("disabled",true);
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').val("");
                }
            });

            //Enable/disable weekdays
            $('input[name^="weekdays_day_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("weekdays_day_");
                if($(this).prop("checked") == true){
                    //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').removeAttr("disabled");
                    //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').removeAttr("disabled");

                    //Blur event to validate data
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').blur(function() {
                        var elem_start_time = $('select[name^="weekdays_start_time_'+getTermId[1]+'"]');
                        var elem_end_time = $('select[name^="weekdays_end_time_'+getTermId[1]+'"]');
                        var current_element = "start_time";
                        //validate_time_range(elem_start_time, elem_end_time, current_element);
                    });
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').blur(function() {
                        var elem_start_time = $('select[name^="weekdays_start_time_'+getTermId[1]+'"]');
                        var elem_end_time = $('select[name^="weekdays_end_time_'+getTermId[1]+'"]');
                        var current_element = "end_time";
                        //validate_time_range(elem_start_time, elem_end_time, current_element);
                    });
                }
                else if($(this).prop("checked") == false){
                    //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').attr("disabled",true);
                    //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').val("");
                    //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').attr("disabled",true);
                    //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').val("");
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').attr("disabled",true);
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').prop('selectedIndex',0);
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').attr("disabled",true);
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').prop('selectedIndex',0);
                    //Turn off the blur event
                    $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').off("blur");
                    $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').off("blur");
                }
            });


            //Enable/disable when checking paid services
            $('input[name^="service_paid_item_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("service_paid_item_");
                if($(this).prop("checked") == true){
                    $('textarea[name^="service_paid_description_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('input[name^="service_paid_price_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('select[name^="service_paid_currency_'+getTermId[1]+'"]').removeAttr("disabled");
                }
                else if($(this).prop("checked") == false){
                    $('textarea[name^="service_paid_description_'+getTermId[1]+'"]').attr("disabled",true).val("");
                    $('input[name^="service_paid_price_'+getTermId[1]+'"]').attr("disabled",true).val("");
                    $('select[name^="service_paid_currency_'+getTermId[1]+'"]').attr("disabled",true);
                }
            });


            //Show/hide password
            //Add it after the password
            $( "#edit-confirm-password-pass1", context ).after( '<i id="show_hide_password" class="fa fa-eye-slash" aria-hidden="true"></i>');
            //Activate it onclick
            $("#show_hide_password").once("html5").click( function(event) {
                event.preventDefault();
                if($('#edit-confirm-password-pass1').attr("type") == "text"){
                    $('#edit-confirm-password-pass1').attr('type', 'password');
                    $('#show_hide_password').addClass( "fa-eye-slash" );
                    $('#show_hide_password').removeClass( "fa-eye" );
                }else if($('#edit-confirm-password-pass1').attr("type") == "password"){
                    $('#edit-confirm-password-pass1').attr('type', 'text');
                    $('#show_hide_password').removeClass( "fa-eye-slash" );
                    $('#show_hide_password').addClass( "fa-eye" );
                }
            });

            //alert('1');
            //enale_chacked_weekdays();


        }
    };

    /*
     * current_element = "start_time" or "end_time"
     */
    function validate_time_range(elem_start_time, elem_end_time, current_element)
    {
        var start_time_val = $(elem_start_time).val();
        var end_time_val = $(elem_end_time).val();

        if(current_element == "start_time"){
            //If we left the "start_time" element...
            if(start_time_val == 0){
                //If no value was selected, alert and focus
                alert("Please select a value here");
                $(elem_start_time).focus();
                return -1;
            } else {
                //If value was selected, set focus to end time
                $(elem_end_time).focus();
            }
        } else if(current_element == "end_time") {
            //If we left the "end_time" element...
            if (end_time_val == 0) {
                //If no value was selected, alert and focus
                alert("Please select a value here");
                $(elem_end_time).focus();
                return -1;
            } else if (start_time_val == 0) {
                //If no value was selected on start time, alert and focus
                alert("Please select a start time");
                $(elem_start_time).focus();
                return -1;
            } else {
                //Check if the end_time is smaller then the start time
                if(end_time_val <= start_time_val){
                    alert("End time must be bigger then start time");
                    $(elem_end_time).focus();
                    return -1;
                }
            }
        }
    }



})(jQuery);


