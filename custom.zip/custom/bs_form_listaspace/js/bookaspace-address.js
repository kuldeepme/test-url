var map;
function initMap(lat, lng, zoom_level = 7,context) { 
  //alert("hey");
  if(!lat && !lng){
    // If no lat and lng, set to London.
    lat = 32.0853;
    lng = 34.7818;
  }
  map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: lat, lng: lng},
    width: 800,
    zoom: zoom_level
  });
  var marker = new google.maps.Marker({
    position: {lat: lat, lng: lng},
    map: map,
  });
}

(function($) {
  Drupal.behaviors.bs_form_listaspace = { 
    attach: function(context, settings) {
      $('select[name="address[country_code]"]',context).once("html6").change(function(){
        $('.address-city').val('');
        $('.address-line1').val('');
        var country_code = $('select[name="address[country_code]"] option:selected').text();
        var address = country_code;
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            console.log(lat);
            console.log(lng);
            initMap(lat, lng, 5);
            
          }
        });
      });
      $('select[name="address[administrative_area]"]',context).once("html7").change(function(){
        $('.address-city').val('');
        $('.address-line1').val('');
          var country_code = $('select[name="address[country_code]"]').val();
          var state = $('select[name="address[administrative_area]"]').val();
          var address = state + '+' + country_code;
          console.log("address: " + address);
          $.ajax({
            url: '/location',
            method: 'GET',
            data: {
              address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 7);
          }
        });
      });
      $('.locality',context).once("html7").change(function() {
        var country_code = $('select[name="address[country_code]"]').val();
        var state = $('select[name="address[administrative_area]"] option:selected').text();
        var city = $('input[name="address[locality]"]').val();
        state = state.replace(' ', '+');
        city = city.replace(' ', '+');
        var address = city + ',' + state + '+' + country_code;
        console.log("address: " + address);
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            console.log(data)
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 12);
          }
        });
      });
      $('.address-line1',context).once("html7").change(function() {
        var country_code = $('select[name="address[country_code]"]').val();
        var state = $('select[name="address[administrative_area]"] option:selected').text();
        var city = $('input[name="address[locality]"]').val();
        var street = $('input[name="address[address_line1]"]').val();
        street = street.replace(' ', '+');
        state = state.replace(' ', '+');
        city = city.replace(' ', '+');
        var address = street  + ',' + city + ',' + state + '+' + country_code;
        console.log("address: " + address);
        $.ajax({
          url: '/location',
          method: 'GET',
          data: {
            address: address,
          },
          success:function(data){
            data = jQuery.parseJSON(data);
            var lat = data.lat;
            var lng = data.lng;
            initMap(lat, lng, 15);
          }
        });
      });
    }
  };
})(jQuery);


