(function($) {
    Drupal.behaviors.bs_space_worflow = {
        attach: function(context, settings) {

            //Enable/disable when checking space_layout_item
            $('input[name^="space_layout_item_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("space_layout_item_");
                if($(this).prop("checked") == true){
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').removeAttr("disabled");
                }
                else if($(this).prop("checked") == false){
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').attr("disabled",true);
                    $('input[name^="space_max_capacity_'+getTermId[1]+'"]').val("");
                }
            });

            //Enable/disable when checking paid services
            $('input[name^="service_paid_item_"]').once("html5").click(function(){
                var getCheckboxId = $(this).attr("name");
                var getTermId = getCheckboxId.split("service_paid_item_");
                if($(this).prop("checked") == true){
                    $('textarea[name^="service_paid_description_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('input[name^="service_paid_price_'+getTermId[1]+'"]').removeAttr("disabled");
                    $('select[name^="service_paid_currency_'+getTermId[1]+'"]').removeAttr("disabled");
                }
                else if($(this).prop("checked") == false){
                    $('textarea[name^="service_paid_description_'+getTermId[1]+'"]').attr("disabled",true).val("");
                    $('input[name^="service_paid_price_'+getTermId[1]+'"]').attr("disabled",true).val("");
                    $('select[name^="service_paid_currency_'+getTermId[1]+'"]').attr("disabled",true);
                }
            });

        }
    };
})(jQuery);
