<?php
/**
 * @file
 * Contains \Drupal\bs_property_workflow\Form\BsPropertyEditForm.
 */
namespace Drupal\bs_space_workflow\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\file\Entity\File;
use Drupal\taxonomy\Entity\Term;
use Drupal\paragraphs\Entity\Paragraph;

class BsSpaceEditForm extends FormBase
{
    /**
     * {@inheritdoc}
     */
    public function getFormId()
    {

        return 'bs_space_edit_form';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL)
    {

        $language_id = \Drupal::languageManager()->getCurrentLanguage()->getId();

        // Load space size units with translation.
        //$arr_space_size_units = get_taxonomy_terms_by_language('space_size_units');
        // Load space_layout values.
        //$sort_by_key = TRUE;
        //$arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);


        // GET AND ORGANIZE DATA.
        $space_host_id = $node->get('field_space_host')->getValue()[0]["target_id"];
        $space_name = $node->get('field_space_name')->getValue()[0]["value"];
        $space_description = $node->get('field_space_description')->getValue()[0]["value"];
        $space_size = $node->get('field_space_size')->getValue()[0]["value"];
        //$space_size_units = $node->get('field_space_size_units')->getValue()[0]["target_id"];
        // Get space property.
        $space_property_id = $node->get('field_spaces_properties')->getValue()[0]["target_id"];
        $obj_space_property = Node::load($space_property_id);
        $str_space_property_title = $obj_space_property->getTitle();
        $arr_field_space_layouts = $node->get('field_space_layouts')->getValue();
        $cancellation_policy = $node->get('field_cancellation_policy')->getValue()[0]["target_id"];

        // Services (amenities)
        $arr_space_services = [];

        //Load country details of the property
        if (isset($obj_space_property->field_property_country_details)) {
            $country_details_tid = $obj_space_property->field_property_country_details->getValue()[0]['target_id'];
            $arr_country_details = get_countries_details_by_tid($country_details_tid);
        } else {
            $arr_country_details = get_countries_details_by_tid(0);
        }


        $arr_field_space_services = $node->get('field_space_services')->getValue();
        foreach ($arr_field_space_services as &$value) {
            $p = \Drupal\paragraphs\Entity\Paragraph::load($value['target_id']);
            $target_id = $p->field_space_services->getValue()[0]['target_id'];
            array_push($arr_space_services, $target_id);
        }


        // Images.
        $arr_image_url = [];
        $arr_image_ids = [];
        $arr_field_space_images = $node->get('field_space_images')->getValue();
        //kint($arr_field_space_images);
        foreach ($arr_field_space_images as &$value) {
            $fid = $value['target_id'];
            array_push($arr_image_ids, $fid);
            $obj_file = File::load($fid);
            if ($obj_file != NULL) {
                // Load image URI.
                $image_uri = $obj_file->getFileUri();
                if ($image_uri != NULL) {
                    // Style thumbnail so we can change later from admin system.
                    $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                    $arr_image_url[$fid] = $style->buildUrl($image_uri);
                }
            }
        }

        //// This is a "hook_theme". Create an array with the TWIG name ('bs_image_url_template') and send parameters (arr_image_url).
        //$image_collection = [
        //'#theme' => 'bs_image_url_template',
        //'#arr_image_url' => $arr_image_url,
        //];
        //// Create a TWIG file, send parameters and render as HTML.
        //$image_output = \Drupal::service('renderer')->render($image_collection);

        //kint($arr_image_url);

        $form['space_images'] = [
            '#type' => 'managed_file',
            '#upload_location' => 'public://property-images/',
            '#default_value' => $arr_image_ids,
            '#attributes' => [
                'class' => ['multiple-file-upload']
            ],
            '#multiple' => true,
        ];


        // Paid (extra) services.
        $arr_space_services_paid = [];
        $arr_field_space_services_paid = $node->get('field_space_services_paid')->getValue();
        foreach ($arr_field_space_services_paid as &$value) {
            $p = \Drupal\paragraphs\Entity\Paragraph::load($value['target_id']);
            $target_id = $p->field_space_services->getValue()[0]['target_id'];
            $description = $p->field_service_description->getValue()[0]['value'];
            $price = $p->field_service_price->getValue()[0]['value'];
            $currency_id = $p->field_service_price_currency->getValue()[0]['target_id'];
            $price_type = $p->field_service_price_type->getValue()[0]['value'];

            $arr_space_services_paid[$target_id]['id'] = $target_id;
            $arr_space_services_paid[$target_id]['description'] = $description;
            $arr_space_services_paid[$target_id]['price'] = $price;
            $arr_space_services_paid[$target_id]['currency_id'] = $currency_id;
            $arr_space_services_paid[$target_id]['price_type'] = $price_type;
        }
        $form['space_name'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
            '#default_value' => $space_name
        ];
        $form['header_space_property_name'] = $str_space_property_title;
        $form['header_space_name'] = $space_name;
        $form['space_description'] = [
            '#type' => 'textarea',
            '#default_value' => isset($space_description) ? strip_tags($space_description) : NULL,
            '#attributes' => [
                'placeholder' => ['My space has... You will love my space because... The space suitable for meeting... etc'],
            ],
        ];
        $form['space_size'] = [
            '#type' => 'number',
            '#required' => FALSE,
            '#default_value' => isset($space_size) ? $space_size : NULL,
        ];

        //Space size units
        /*
      $form['space_size_units'] = [
        '#type' => 'select',
        '#required' => FALSE,
        '#options' => $arr_space_size_units,
        '#default_value' => isset($space_size_units) ? $space_size_units : NULL,
      ];
        */

        if (isset($arr_country_details)) {
            $form['space_size_unit'] = [
                '#type' => 'label',
                '#value' => $arr_country_details['measure_units'],
            ];
        }


        // SPACE ACTIVITIES
        // Load space_activities that were configured in the admin section to display on "list a space" page (and here)
        $arr_space_activities = get_space_activities_values();
        // Load activities of this specific space.
        $arr_field_space_activities = $node->get('field_space_activities')->getValue();
        $this_space_activities = [];
        foreach ($arr_field_space_activities as &$value) {
            array_push($this_space_activities, $value["target_id"]);
        }
        foreach ($arr_space_activities as $key => $values) {
            $form['space_activity']['space_activity_' . $key] = [
                '#type' => 'checkboxes',
                '#title' => t($key),
                '#options' => $values,
                '#default_value' => isset($this_space_activities) ? $this_space_activities : [],
                '#required' => FALSE,
                '#prefix' => '<div class="space_activities_section">',
                '#suffix' => '</div>'
            ];
        }
        // END SPACE ACTIVITIES


        // SPACE LAYOUT
        // Get all the space_layout terms.
        $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree("space_layout");
        // build array.
        $arr_space_layout = array();
        $arr_values = array();
        // Run on the space_layout terms and load and handle each of them.
        foreach ($terms as $term) {
            $arr_values[$term->tid] = $term->name;
            $term_obj = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term->tid);
            if ($term_obj != NULL) {
                // Load image URI.
                $image_uri = $term_obj->get('field_space_layout_image')->entity->getFileUri();
                if ($image_uri != NULL) {
                    // Style thumbnail so we can change later from admin system.
                    $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                    $url = $style->buildUrl($image_uri);
                    // Add the image AND the translated term name to the array.
                    $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($term_obj, $language_id);
                    $str_name = $taxonomy_term_trans->getName();
                    // Add the image AND the term name to the array.
                    $arr_space_layout[$term->tid]['term_name'] = "<img src=" . $url . "/>" . $str_name;
                    // Add max_capacity to the array.
                    $arr_space_layout[$term->tid]['capacity'] = $term_obj->field_space_layout_max_participa->getValue();
                    // Mark all as not checked.
                    $arr_space_layout[$term->tid]['is_checked'] = 0;
                    // Mark all as disabled.
                    $arr_space_layout[$term->tid]['disabled'] = TRUE;
                }
            }
        }
        // Run on the data from the DB and add values that were added and their max_participants.
        foreach ($arr_field_space_layouts as &$value) {
            $p = \Drupal\paragraphs\Entity\Paragraph::load($value['target_id']);
            $target_id = $p->field_space_layout_name->getValue()[0]['target_id'];
            $max_participants = $p->field_space_layout_max_participa->getValue()[0]['value'];
            // Marked that it is checked.
            $arr_space_layout[$target_id]['is_checked'] = 1;
            // Mark max participants.
            $arr_space_layout[$target_id]['max_participants'] = $max_participants;
            $arr_space_layout[$target_id]['disabled'] = FALSE;
        }
        // Run on the array created.
        foreach ($arr_space_layout as $key => $values) {
            // Create the checkbox.
            $form["space_layout_wrapper"]['space_layout_item_' . $key] = [
                '#type' => 'checkbox',
                // Image and term name.
                '#title' => $values['term_name'],
                '#default_value' => $values['is_checked'],
                '#required' => FALSE,
                '#prefix' => '<div class="space_layout_item">',
            ];
            // Create the numeric field.
            $form["space_layout_wrapper"]['space_max_capacity_' . $key] = [
                '#type' => 'number',
                '#default_value' => $values['max_participants'],
                '#suffix' => '</div>',
                '#attributes' => [
                    //'placeholder' => $values['capacity'][0]['value'],
                    'disabled' => $values['disabled'],
                ],
            ];
        }
        // END SPACE LAYOUT.


        // Amenities.
        // First, get all services which includes also paid for (those are "extra services") and services for properties.
        $arr_services = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('services');
        // MOVED OUTSIDE OF FUNTION SO WE CAN USE IT ON FUNCTION getFieldName()
        // Create array to hold all inner arrays, each for a category.
        $this->arr_amenities = array();
        // Run on all services.
        foreach ($arr_services as $service) {
            // Service name.
            $tid = $service->tid;
            // Load the service fields (field_service_category, field_service_icon, field_service_paid, field_service_type).
            $obj_service_fields = Term::load($service->tid);
            // Add the image AND the translated term name to the array.
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($obj_service_fields, $language_id);
            $str_name = $taxonomy_term_trans->getName();
            // Service paid for - boolean - whether it's paid for (then its extra service) or not (and then it's amenity).
            $bln_service_paid = $obj_service_fields->field_service_paid->getValue()[0]["value"];
            // Service category (spaces or properties).
            $str_service_category = $obj_service_fields->field_service_category->getValue()[0]["value"];
            // Service type (stationary, electronic etc.).
            $str_service_type = $obj_service_fields->field_service_type->getValue()[0]["value"];
            // If the service is not paid for and the service category is "spaces".
            if ($bln_service_paid == FALSE && $str_service_category == "spaces") {
                // Add into $arr_amenities:
                if (!isset($this->arr_amenities[$str_service_type])) {
                    // If we don't have an array for this service type, create one and add it to $arr_amenities.
                    $tmp_array = [$tid => $str_name];
                    $this->arr_amenities[$str_service_type] = $tmp_array;
                } else {
                    // If we have an array for this service type, get it, add a new item and add it back into $arr_amenities.
                    $tmp_array = $this->arr_amenities[$str_service_type];
                    $tmp_array[$tid] = $str_name;
                    $this->arr_amenities[$str_service_type] = $tmp_array;
                }
            }
        }
        // Run on $arr_amenities and add a checkbox list for each of the arrays (categories) inside.
        foreach ($this->arr_amenities as $key => $values) {
            $form['services_type']['services_' . $key] = [
                '#type' => 'checkboxes',
                '#title' => t($key),
                '#options' => $values,
                '#default_value' => isset($arr_space_services) ? $arr_space_services : [],
                '#required' => FALSE,
                '#prefix' => '<div>',
                '#suffix' => '</div>'
            ];
        }
        // END Amenities.
        // Output image HTML from inside the form.
        //$form['space_image_markup'] = [
        //'#markup' => $image_output,
        //];


        //WEEKDAYS
        //Load all the availability days of the space
        $arr_field_availability_days_default = array();
        $arr_field_availability_days = $node->get('field_availability_days')->getValue();
        foreach ($arr_field_availability_days as $day_key => $day_value) {
            $times_pid = $day_value['target_id'];

            //Get ids of day, start_time and end_time
            $arr_times = get_paragraph_times_ids($times_pid);
            array_push($arr_field_availability_days_default, $arr_times);
        }


        //Load array of weekdays so we can create the checkboxes
        $sort_by_key = true;
        $arr_weekdays = get_taxonomy_term_values('weekdays_', $sort_by_key);

        //Load array of times for the select
        $arr_times = select_list_times();
        //array_unshift($arr_times, "Select");

        //Run on the weekdays and for each create a checkbox and two selects (star and end times)
        foreach ($arr_weekdays as $day_key => $day_value) {


            $day_default_value = false;
            $start_time_default_value = 0;
            $end_time_default_value = 0;

            //Check if this day is selected and if so, get the start and end times
            foreach ($arr_field_availability_days_default as $key => $values) {

                if ($day_key == $values["weekday_id"]) {
                    //If this day selected as an available day, check it and get the start and end time id
                    $day_default_value = true;
                    $start_time_default_value = $values["start_time_id"];
                    $end_time_default_value = $values["end_time_id"];
                }
            }

            $form["weekdays"]["weekdays_day_" . $day_key] = [
                "#type" => 'checkbox',
                '#title' => $day_value->__toString(),
                '#prefix' => "<div class='weekdays_wrapper'>",
                '#default_value' => $day_default_value
            ];
            $form["weekdays"]["weekdays_start_time_" . $day_key] = [
                '#type' => 'select',
                '#options' => $arr_times,
                '#attributes' => [
                    'disabled' => !$day_default_value,
                ],
                '#default_value' => $start_time_default_value
            ];
            $form["weekdays"]["weekdays_end_time_" . $day_key] = [
                '#type' => 'select',
                '#options' => $arr_times,
                '#attributes' => [
                    'disabled' => !$day_default_value,
                ],
                '#default_value' => $end_time_default_value,
                '#suffix' => "</div>"
            ];
        }
        //END WEEKDAYS


        // SERVICES - PAID.
        // Get all the services terms.
        $arr_all_services = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('services');
        $arr_services_paid = [];
        // build array.
        foreach ($arr_all_services as $service) {
            $obj_service_fields = Term::load($service->tid);
            // Service name.
            // Add the image AND the translated term name to the array.
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($obj_service_fields, $language_id);
            $str_service_name = $taxonomy_term_trans->getName();
            // Service paid for - boolean - whether it's paid for (then its extra service) or not (and then it's amenity).
            $bln_service_paid = $obj_service_fields->field_service_paid->getValue()[0]["value"];
            // Service category (spaces or properties).
            $str_service_category = $obj_service_fields->field_service_category->getValue()[0]["value"];
            // Service type (stationary, electronic etc.).
            $str_service_type = $obj_service_fields->field_service_type->getValue()[0]["value"];
            // If the service IS PAID for ("extra service") and the service category is "spaces".
            if ($obj_service_fields != NULL && isset($obj_service_fields->get('field_service_icon')->entity) && $bln_service_paid == TRUE && $str_service_category == "spaces" && $obj_service_fields->hasField('field_service_icon')) {
                // Load image URI.
                $image_uri = $obj_service_fields->get('field_service_icon')->entity->getFileUri();
                // Style thumbnail so we can change later from admin system.
                $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('thumbnail');
                $url = $style->buildUrl($image_uri);
                if (!isset($arr_services_paid[$str_service_type])) {
                    // If we don't have an array for this service type (stationary, food and drinks, electronics), create one.
                    $arr_services_paid_temp = [];
                } else {
                    // If we have an array for this service type (stationary, food and drinks, electronics), get it.
                    $arr_services_paid_temp = $arr_services_paid[$str_service_type];
                }
                $arr_services_paid_temp[$service->tid]['service_name'] = "<img src=" . $url . "/>" . $str_service_name;
                $arr_services_paid_temp[$service->tid]['category'] = $str_service_type;
                $arr_services_paid_temp[$service->tid]['is_checked'] = FALSE;
                // Run on the data from the DB and add values that were added, their prices, description etc.
                foreach ($arr_space_services_paid as &$value) {
                    if ($value['id'] == $service->tid) {
                        $arr_services_paid_temp[$service->tid]['description'] = $value['description'];
                        $arr_services_paid_temp[$service->tid]['price'] = $value['price'];
                        $arr_services_paid_temp[$service->tid]['currency_id'] = $value['currency_id'];
                        $arr_services_paid_temp[$service->tid]['price_type'] = $value['price_type'];
                        $arr_services_paid_temp[$service->tid]['is_checked'] = TRUE;
                    }
                }
                $arr_services_paid[$str_service_type] = $arr_services_paid_temp;
            }
        }
        foreach ($arr_services_paid as $key1 => $values1) {
            // Create a HTML "fieldset" with id as machine name  ---    'service_paid_wrapper'][str_replace(" ","_",$key1).
            $form['service_paid_wrapper'][str_replace(" ", "_", $key1)] = [
                '#type' => 'fieldset',
                '#title' => t(str_replace("_", " ", $key1)),
                '#collapsible' => TRUE,
                '#collapsed' => TRUE,
            ];
            // Create all the "fields" inside the "fieldset" with the same machine name and some more...  ----  "service_paid_wrapper"][str_replace(" ","_",$key1)].
            foreach ($values1 as $key => $values) {
                $final_arr_services_paid = [];
                $final_arr_services_paid[$key] = $values['service_name'];
                // Create the checkbox.
                $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_item_' . $key] = [
                    '#type' => 'checkbox',
                    '#title' => $values['service_name'],
                    '#default_value' => isset($values['is_checked']) ? $values['is_checked'] : [],
                    '#required' => FALSE,
                    '#prefix' => '<div class="service_paid_item row table-row">',
                ];
                // Create the description field.
                $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_description_' . $key] = [
                    '#type' => 'textarea',
                    '#attributes' => [
                        'disabled' => !$values['is_checked'],
                        'placeholder' => [t('Describe this product')],
                    ],
                    '#default_value' => isset($values['description']) ? strip_tags($values['description']) : NULL,
                ];
                // Create the price field.
                $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_price_' . $key] = [
                    '#type' => 'number',
                    '#attributes' => [
                        'disabled' => !$values['is_checked'],
                    ],
                    '#default_value' => isset($values['price']) ? $values['price'] : NULL,
                ];
                // Create the price field currency.
                /*
              $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_currency_' . $key] = [
                '#type' => 'select',
                '#options' => $arr_currencies,
                '#suffix' => '</div>',
                '#attributes' => [
                  'disabled' => !$values['is_checked'],
                ],
                '#default_value' => isset($values['currency_id']) ? $values['currency_id'] : NULL,
              ];*/

                //kint($arr_country_details['currency_symbol']);die;

                if (isset($arr_country_details)) {
                    $form["service_paid_wrapper"][str_replace(" ", "_", $key1)]['service_paid_currency_' . $key] = [
                        '#prefix' => '<div class="currency_symbol">',
                        '#markup' => $arr_country_details['currency_symbol'],
                        '#suffix' => '</div></div>',
                    ];
                }
            }
        }
        // END SERVICES - PAID.




        //CANCELLATION POLICIES
        $sort_by_key = false;
        $arr_cancellation_policies = get_taxonomy_term_values('cancellation_policy', $sort_by_key);

        //build array
        $arr_cancellation_policies_organized = array();
        foreach ($arr_cancellation_policies as $key => $policy) {

            $str_html = get_cancellation_policy_html($key);

            $arr_cancellation_policies_organized[$key] = $str_html;

        }

        $form["cancellation_policies"] = [
            '#type' => 'radios',
            '#options' => $arr_cancellation_policies_organized,
            '#default_value' => isset($cancellation_policy) ? $cancellation_policy : NULL,
            '#required' => TRUE,
            '#prefix' => '<div class="cancellation_fee_header"><div>&nbsp;</div><div>Free cancellation</div><div>Cancellation fee</div><div>None refundable</div></div>',
        ];
        //END CANCELLATION POLICIES



        //TRANSLATIONS
        $other_languages = get_system_other_languages();

        //Create an array for the select that asks the user which language to add
        $arr_other_languages = [];
        foreach($other_languages as $key => $values) {

            //Create an array for the select that asks the user which language to add
            $arr_other_languages[$key] = $values->getName();

            $space_name = "";
            $space_description = "";
            $hidden_class = "hide";

            if($node->hasTranslation($key)) {

                //Other languages
                $obj_space_translated = $node->getTranslation($key);
                $space_name = $obj_space_translated->getTitle();
                $space_description = $obj_space_translated->get('field_space_description')->getValue()[0]["value"];
                $hidden_class = "";
            }

            $form['space_name_languages']['space_name_languages_' . $key] = [
                '#type' => 'textfield',
                '#title' => t('Space name in ') . $values->getName(),
                '#default_value' => $space_name,
                '#prefix' => '<div class="div_language_'.$key.' '.$hidden_class.'">',
                '#suffix' => '</div>'
            ];

            $form['space_description_languages']['space_description_languages_' . $key] = [
                '#type' => 'textarea',
                '#title' => t('Space description in ') . $values->getName(),
                '#default_value' => strip_tags($space_description),
                '#prefix' => '<div class="div_language_'.$key.' '.$hidden_class.'">',
                '#suffix' => '</div>'
            ];
        }

        //For the select that asks the user which language to add
        $form['other_languages'] = [
            '#type' => 'select',
            '#options' => $arr_other_languages
        ];
        //END TRANSLATIONS



        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => t('Save'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        $form['node_obj'] = [
            '#type' => 'value',
            '#value' => $node,
        ];
        $form['space_host_id'] = [
            '#type' => 'value',
            '#value' => $space_host_id,
        ];
        $form['#attached']['library'][] = 'bs_space_workflow/bs-space-workflow';
        return $form;
    }


    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state)
    {

        $triggering_element = $form_state->getTriggeringElement();

        //Validate weekdays
        $arr_weekdays = get_taxonomy_term_values('weekdays_', true);
        //kint($arr_weekdays); die;
        //Run on the selected weekdays
        foreach ($arr_weekdays as $day_key => $day_value) {
            $start_time = $form_state->getValue('weekdays_start_time_' . $day_key);
            $end_time = $form_state->getValue('weekdays_end_time_' . $day_key);

            //Check that a value was inserted
            //if($start_time == "0" || $end_time == "0"){
            //$form_state->setErrorByName('weekdays_start_time_'.$day_key, "Please select a start and end time");
            //}

            //Convert to int
            $start_time = (int)$start_time;
            $end_time = (int)$end_time;

            //Validate that the end time bigger than the start time
            if (is_numeric($start_time) && is_numeric($end_time) && $start_time > 0 && $end_time > 0) {
                if ($end_time <= $start_time) {
                    $form_state->setErrorByName('weekdays_start_time_' . $day_key, "End time must be bigger then start time");
                }
            }
        }
        //END Validate weekdays
    }


    public function submitForm(array &$form, FormStateInterface $form_state)
    {

        $field = $form_state->getValues();
        $node = $field['node_obj'];
        $nid = $node->id();
        $space_name = $field['space_name'];
        $space_description = $field['space_description'];
        $space_size = $field['space_size'];
        //$space_size_units = $field['space_size_units'];
        $user_description = $field['user_description'];
        $space_host_id = 0;
        $arr_space_image_ids = $field['space_images'];
        $cancellation_policy = $field['cancellation_policies'];

        /*
        foreach ($arr_space_image_ids as $image_id) {
            $file1 = File::load($image_id);
            $file1->setPermanent();
            $file1->save();
        }
        */


        //get translated values into an array
        $arr_languages = [];
        foreach ($field as $key => $value) {

            //Run on all fields of the form
            //If we have a translated field of "property name", get the language and add to an array
            if (strpos($key, 'space_name_languages_') !== false && $value != "") {
                $langauge_array = explode("space_name_languages_", $key);
                $language = $langauge_array[1];
                $arr_languages[$language]['field_space_name'] = $value;
            }

            //If we have a translated field of "property description", get the language and add to an array
            if (strpos($key, 'space_description_languages_') !== false  && $value != "") {
                $langauge_array = explode("space_description_languages_", $key);
                $language = $langauge_array[1];
                $arr_languages[$language]['field_space_description'] = $value;
            }
        }


        //Load country details of the property
        $space_property_id = $node->get('field_spaces_properties')->getValue()[0]["target_id"];
        $obj_space_property = Node::load($space_property_id);
        if (isset($obj_space_property->field_property_country_details)) {
            $country_details_tid = $obj_space_property->field_property_country_details->getValue()[0]['target_id'];
            $arr_country_details = get_countries_details_by_tid($country_details_tid);
        } else {
            $arr_country_details = get_countries_details_by_tid(0);
        }

        if ($field['space_host_id']) {
            $space_host_id = $field['space_host_id'];
        }
        if ($field['user_image'] && $field['user_image'][0]) {
            $img_user_image = $field['user_image'][0];

            $img_user = File::load($img_user_image);
            $img_user->setPermanent();
            $img_user->save();
        }
        // SPACE ACTIVITY.
        $arr_space_activity = [];
        foreach ($field as $key => $value) {
            // Run on all "fields" of the form. If this is a "space_activity_" list of checkboxes...
            if (strpos($key, 'space_activity_') !== FALSE) {
                // Run on the checkboxes and if is checked...
                foreach ($value as $key1 => $value1) {
                    if ($value1 > 0) {
                        array_push($arr_space_activity, $value1);
                    }
                }
            }
        }
        // Space layout.
        $space_layout_paragraph = [];
        foreach ($field as $key => $value) {
            // If this is space_layout_item and is checked ($value == 1).
            if (strpos($key, 'space_layout_item_') !== FALSE && $value == 1) {
                $get_term_array = explode("space_layout_item_", $key);
                $get_term_id = $get_term_array[1];
                // Create a paragraph.
                $paragraph = Paragraph::create([
                    'type' => 'space_layouts',
                    'field_space_layout_max_participa' => $field['space_max_capacity_' . $get_term_id],
                    'field_space_layout_name' => $get_term_id,
                ]);
                $paragraph->save();
                $space_layout_paragraph[] = [
                    'target_id' => $paragraph->id(),
                    'target_revision_id' => $paragraph->getRevisionId(),
                ];
            }
        }
        // Organize data for SERVICE ARRAY.
        $space_services_array = [];
        foreach ($field as $key => $value) {
            // Run on all "services_" lists of checkboxes ("stationary", "electronic", "other").. If this is a "services_" list of checkboxes...
            if (strpos($key, 'services_') !== FALSE) {
                // Run on the checkboxes and if is checked...
                foreach ($value as $key1 => $value1) {
                    if ($value1 > 0) {
                        // Create a paragraph.
                        $paragraph = Paragraph::create([
                            'type' => 'space_services',
                            'field_space_services' => $value1,
                        ]);
                        $paragraph->save();
                        $space_services_array[] = [
                            'target_id' => $paragraph->id(),
                            'target_revision_id' => $paragraph->getRevisionId(),
                        ];
                    }
                }
            }
        }


        // Organize data for PAID SERVICE ARRAY.
        $space_services_paid_array = [];
        foreach ($field as $key => $value) {
            // Run on all "service_paid_item_" checkboxes.
            if (strpos($key, 'service_paid_item_') !== FALSE) {
                // If the checkbox is checked.
                if ($value > 0) {
                    // get the id of the item.
                    $item_array = explode("service_paid_item_", $key);
                    $item_id = $item_array[1];
                    // Get the description, price and currency.
                    $str_description = $field["service_paid_description_" . $item_id];
                    $int_price = $field["service_paid_price_" . $item_id];
                    $int_currency_id = $field["service_paid_currency_" . $item_id];
                    //kint($int_currency_id);die;
                    // Create a paragraph.
                    $paragraph = Paragraph::create([
                        'type' => 'space_services',
                        'field_space_services' => $item_id,
                        'field_service_description' => $str_description,
                        'field_service_price' => $int_price,
                        'field_service_price_currency' => $arr_country_details['currency_tid']
                    ]);
                    $paragraph->save();
                    $space_services_paid_array[] = [
                        'target_id' => $paragraph->id(),
                        'target_revision_id' => $paragraph->getRevisionId(),
                    ];
                }
            }
        }


        //WEEKDAYS
        //First, run on all the existing paragraphs of the space and delete them so they don't just hang there
        $arr_field_availability_days = $node->get('field_availability_days')->getValue();
        foreach ($arr_field_availability_days as $day_key => $day_value) {
            $times_pid = $day_value['target_id'];

            $paragraph = Paragraph::load($times_pid);
            if ($paragraph) {
                $paragraph->delete();
            }
        }

        //Run on all values and organize the weekdays
        foreach ($field as $key => $value) {

            //If it's a field that hold a weekdays day (example: 'weekdays_day_72')
            if (strpos($key, 'weekdays_day_') !== false && $value == 1) {

                //Get the id of the day (example: 72)
                $get_wd_term_array = explode("weekdays_day_", $key);
                $get_wd_term_id = $get_wd_term_array[1];

                //get the start and end time of the fields (example field names: 'weekdays_start_time_72' and 'weekdays_end_time_72')
                $start_time_index = $field['weekdays_start_time_' . $get_wd_term_id];
                $end_time_index = $field['weekdays_end_time_' . $get_wd_term_id];

                //Get the times in string datetime format (example: 2100-01-01T10:00:00)
                $start_time = select_list_times_to_string($start_time_index);
                $end_time = select_list_times_to_string($end_time_index);

                //Create a new paragraph
                $times_paragraph_id = create_paragraph_times($start_time, $end_time, $get_wd_term_id);
                $wd_paragraph_item[] = $times_paragraph_id;
            }
        }

        //kint($arr_space_image_ids);
        //kint($wd_paragraph_item);

        $obj_space = Node::load($nid);
        $obj_space->title = $space_name;
        $obj_space->field_space_name = $space_name;
        $obj_space->field_space_description = $space_description;
        $obj_space->field_space_activities = $arr_space_activity;
        $obj_space->field_space_size = $space_size;
        //$obj_space->field_space_size_units = $space_size_units;
        $obj_space->field_space_layouts = $space_layout_paragraph;
        $obj_space->field_space_services = $space_services_array;
        $obj_space->field_space_services_paid = $space_services_paid_array;
        $obj_space->field_availability_days = $wd_paragraph_item;
        $obj_space->field_cancellation_policy = $cancellation_policy;

        if(isset($arr_space_image_ids)){
            foreach ($arr_space_image_ids as $image_id) {
                $file1 = File::load($image_id);
                $file1->setPermanent();
                $file1->save();

                $arr_field_space_images[] = [
                    'target_id' => $file1->id(),
                    'alt' => $space_name,
                    'title' => $space_name,
                ];
            }
            $obj_space->field_space_images = $arr_field_space_images;
        }
        $obj_space->save();



        //TRANSLATE:
        //Run on array languages
        foreach ($arr_languages as $key => $arr_values) {

            //FOR EACH LANGUAGE

            //If we have translation, get it. If not, create a new translation.
            if($node->hasTranslation($key)){
                $obj_space_translated = $obj_space->getTranslation($key);
            }  else {
                $obj_space_translated = $obj_space->addTranslation($key);

                //Duplicate all the fields from the original language
                $obj_space_translated->field_price = $obj_space->field_price;
                $obj_space_translated->field_space_ratings = $obj_space->field_space_ratings;
                $obj_space_translated->field_space_reviews = $obj_space->field_space_reviews;
                $obj_space_translated->field_space_activities = $obj_space->field_space_activities;
                $obj_space_translated->field_space_creator = $obj_space->field_space_creator;
                $obj_space_translated->field_space_host = $obj_space->field_space_host;
                $obj_space_translated->field_space_layouts = $obj_space->field_space_layouts;
                $obj_space_translated->field_space_manager = $obj_space->field_space_manager;
                $obj_space_translated->field_space_preparation_time_aft = $obj_space->field_space_preparation_time_aft;
                $obj_space_translated->field_space_preparation_time_bef = $obj_space->field_space_preparation_time_bef;
                $obj_space_translated->field_space_services = $obj_space->field_space_services;
                $obj_space_translated->field_space_services_paid = $obj_space->field_space_services_paid;
                $obj_space_translated->field_space_size = $obj_space->field_space_size;
                $obj_space_translated->field_spaces_properties = $obj_space->field_spaces_properties;
                $obj_space_translated->field_space_status = $obj_space->field_space_status;
                $obj_space_translated->field_space_type = $obj_space->field_space_type;
                $obj_space_translated->field_space_availability_close = $obj_space->field_space_availability_close;
                $obj_space_translated->field_space_prices = $obj_space->field_space_prices;
                $obj_space_translated->field_space_images = $arr_field_space_images;
            }


            //Update the translated fields
            foreach ($arr_values as $key1 => $value1) {

                //If it's the property name, assign it to few fields
                if($key1 == "field_space_name"){
                    $obj_space_translated->title = $value1;
                    $obj_space_translated->field_space_name = $value1;
                } else if($key1 == "field_space_description"){
                    $obj_space_translated->field_space_description = $value1;
                }
            }

            //Save the translated version
            $obj_space_translated->save();
        }


    }

}
