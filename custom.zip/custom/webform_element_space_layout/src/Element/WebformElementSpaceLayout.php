<?php

namespace Drupal\webform_element_space_layout\Element;

use Drupal\Component\Utility\Html;
use Drupal\webform\Element\WebformCompositeBase;

/**
 * Provides a 'webform_element_space_layout'.
 *
 * Webform composites contain a group of sub-elements.
 *
 *
 * IMPORTANT:
 * Webform composite can not contain multiple value elements (i.e. checkboxes)
 * or composites (i.e. webform_address)
 *
 * @FormElement("webform_element_space_layout")
 *
 * @see \Drupal\webform\Element\WebformCompositeBase
 * @see \Drupal\webform_element_space_layout\Element\WebformExampleComposite
 */
class WebformElementSpaceLayout extends WebformCompositeBase {

  /**
   * {@inheritdoc}
   */
  public function getInfo() {
    return parent::getInfo() + ['#theme' => 'webform_element_space_layout'];
  }

  /**
   * {@inheritdoc}
   */
  public static function getCompositeElements(array $element) {
    // Generate an unique ID that can be used by #states.
    $html_id = Html::getUniqueId('webform_element_space_layout');

    $elements = [];
    $elements['checkbox'] = [
      '#type' => 'checkbox',
      '#title' => t('Check'),
      '#attributes' => ['data-webform-composite-id' => $html_id . '--checkbox'],
    ];
    $properties = ['#label', '#labels', '#min_items', '#empty_items', '#add_more_items'];
    $elements['images'] = array_intersect_key($element, array_combine($properties, $properties)) + [
          '#type' => 'webform_multiple',
          '#key' => 'value',
          '#header' => [
              ['data' => t('Image value'), 'width' => '25%'],
              ['data' => t('Image text'), 'width' => '25%'],
              ['data' => t('Image src'), 'width' => '50%'],
          ],
          '#element' => [
              'value' => [
                  '#type' => 'textfield',
                  '#title' => t('Image value'),
                  '#title_display' => 'invisible',
                  '#placeholder' => t('Enter value…'),
                  '#error_no_message' => TRUE,
                  '#attributes' => ['class' => ['js-webform-options-sync']],
              ],
              'text' => [
                  '#type' => 'textfield',
                  '#title' => t('Image text'),
                  '#title_display' => 'invisible',
                  '#placeholder' => t('Enter text…'),
                  '#error_no_message' => TRUE,
              ],
              'src' => [
                  '#type' => 'textfield',
                  '#title' => t('Image src'),
                  '#title_display' => 'invisible',
                  '#placeholder' => t('Enter image src…'),
                  '#error_no_message' => TRUE,
              ],
          ],
          '#error_no_message' => TRUE,
          '#add_more_input_label' => t('more images'),
          '#default_value' => (isset($element['#default_value'])) ? $element['#default_value'] : [],
    ];
    $elements['first_name'] = [
      '#type' => 'textfield',
      '#title' => t('First name'),
      '#attributes' => ['data-webform-composite-id' => $html_id . '--first_name'],
    ];
    $elements['last_name'] = [
      '#type' => 'textfield',
      '#title' => t('Last name'),
      '#attributes' => ['data-webform-composite-id' => $html_id . '--last_name'],
    ];
    $elements['date_of_birth'] = [
      '#type' => 'date',
      '#title' => t('Date of birth'),
      // Add .js-form-wrapper to wrapper (ie td) to prevent #states API from
      // disabling the entire table row when this element is disabled.
      '#wrapper_attributes' => ['class' => 'js-form-wrapper'],
      '#states' => [
        'enabled' => [
          '[data-webform-composite-id="' . $html_id . '--first_name"]' => ['filled' => TRUE],
          '[data-webform-composite-id="' . $html_id . '--last_name"]' => ['filled' => TRUE],
        ],
      ],
    ];
    $elements['gender'] = [
      '#type' => 'select',
      '#title' => t('Gender'),
      '#options' => 'gender',
      // Add .js-form-wrapper to wrapper (ie td) to prevent #states API from
      // disabling the entire table row when this element is disabled.
      '#wrapper_attributes' => ['class' => 'js-form-wrapper'],
      '#states' => [
        'enabled' => [
          '[data-webform-composite-id="' . $html_id . '--first_name"]' => ['filled' => TRUE],
          '[data-webform-composite-id="' . $html_id . '--last_name"]' => ['filled' => TRUE],
        ],
      ],
    ];
    return $elements;
  }

}
