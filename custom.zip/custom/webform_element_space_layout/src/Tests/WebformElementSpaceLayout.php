<?php

namespace Drupal\webform_element_space_layout\Tests;

use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;
use Drupal\webform\Tests\WebformTestBase;

/**
 * Tests for Webform Element Space Layout.
 *
 * @group Webform
 */
class WebformElementSpaceLayoutTest extends WebformTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  public static $modules = ['webform_element_space_layout'];

  /**
   * Tests webform example element.
   */
  public function testWebformElementSpaceLayout() {
    $webform = Webform::load('webform_element_space_layout');

    // Check form element rendering.
    $this->drupalGet('/webform/webform_element_space_layout');
    // NOTE:
    // This is a very lazy but easy way to check that the element is rendering
    // as expected.
    $this->assertRaw('<label for="edit-webform_element_space_layout-first-name">First name</label>');
    $this->assertFieldById('edit-webform-example-composite-first-name');
    $this->assertRaw('<label for="edit-webform_element_space_layout-last-name">Last name</label>');
    $this->assertFieldById('edit-webform-example-composite-last-name');
    $this->assertRaw('<label for="edit-webform_element_space_layout-date-of-birth">Date of birth</label>');
    $this->assertFieldById('edit-webform-example-composite-date-of-birth');
    $this->assertRaw('<label for="edit-webform_element_space_layout-gender">Gender</label>');
    $this->assertFieldById('edit-webform_element_space_layout-gender');

    // Check webform element submission.
    $edit = [
      'webform_element_space_layout[first_name]' => 'John',
      'webform_element_space_layout[last_name]' => 'Smith',
      'webform_element_space_layout[gender]' => 'Male',
      'webform_element_space_layout[date_of_birth]' => '1910-01-01',
      'webform_element_space_layout_multiple[items][0][first_name]' => 'Jane',
      'webform_element_space_layout_multiple[items][0][last_name]' => 'Doe',
      'webform_element_space_layout_multiple[items][0][gender]' => 'Female',
      'webform_element_space_layout_multiple[items][0][date_of_birth]' => '1920-12-01',
    ];
    $sid = $this->postSubmission($webform, $edit);
    $webform_submission = WebformSubmission::load($sid);
    $this->assertEqual($webform_submission->getElementData('webform_element_space_layout'), [
      'first_name' => 'John',
      'last_name' => 'Smith',
      'gender' => 'Male',
      'date_of_birth' => '1910-01-01',
    ]);
    $this->assertEqual($webform_submission->getElementData('webform_element_space_layout_multiple'), [
      [
        'first_name' => 'Jane',
        'last_name' => 'Doe',
        'gender' => 'Female',
        'date_of_birth' => '1920-12-01',
      ],
    ]);
  }

}
