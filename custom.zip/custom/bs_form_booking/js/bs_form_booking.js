jQuery(function($) {'use strict';
    $(document).ready(function(){
        $("#edit-submit").click(function(){
            var from_time = $('#edit-from-time').val();
            var to_time = $('#edit-to-time').val();
            if(parseInt(from_time) >= parseInt(to_time)){
                $("#form_msg_validation").text("End time must be bigger than start time");
                return false;
            }
        });
        $("#lets_fins_a_space").click(function() {
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        });
    });
});