<?php

namespace Drupal\bs_form_booking\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_booking_by_activity form.
 *
 * @Block(
 *   id = "bs_form_booking_by_activity_block",
 *   admin_label = @Translation("bs_form_booking_by_activity_block"),
 *   category = @Translation("bs_form_booking_by_activity"),
 * )
 */
class bs_form_booking_by_activity_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_booking\Form\BsFormBookingByActivity');
        return $form;
    }

}
