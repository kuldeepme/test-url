<?php

namespace Drupal\bs_form_booking\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_form_booking form.
 *
 * @Block(
 *   id = "bs_form_booking_block",
 *   admin_label = @Translation("bs_form_booking_block"),
 *   category = @Translation("bs_form_booking"),
 * )
 */
class bs_form_booking_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_form_booking\Form\BsFormBooking');
        return $form;
    }

}
