<?php
/**
 * @file
 * Contains \Drupal\bs_form_booking_by_activity\Form\BsFormBookingByActivity.
 */
namespace Drupal\bs_form_booking\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\Core\Datetime\DrupalDateTime;

class BsFormBookingByActivity extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_form_booking_by_activity';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {


        $arr_cities_countries = get_all_properties_cities_and_countries();
        $form['location'] = [
            '#type' => 'select',
            '#required' => TRUE,
            '#options' => $arr_cities_countries,
            '#default_value' => 'IL|Tel Aviv'
        ];


        $arr_space_activities = get_space_activities_values();
        $form['activities'] = [
            '#type' => 'select',
            '#required' => TRUE,
            '#options' => $arr_space_activities,
        ];

        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => t('Find A Space'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        $form['node_obj'] = array(
            '#type' => 'value',
            '#value' => $node,
        );
        return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $data = [];
        $fields = $form_state->getValues();
        // Create the query string.
        $data['location'] = $fields['location'];
        $data['activities'] = $fields['activities'];

        $qs = http_build_query($data);
        $redirect_path = '/search_results?' . $qs;
        $path = URL::fromUserInput($redirect_path)->toString();
        $response = new RedirectResponse($path);
        $response->send();
    }
}
