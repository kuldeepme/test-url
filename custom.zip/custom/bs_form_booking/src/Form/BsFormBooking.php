<?php
/**
 * @file
 * Contains \Drupal\bs_form_booking\Form\BsFormBooking.
 */
namespace Drupal\bs_form_booking\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\Core\Datetime\DrupalDateTime;

class BsFormBooking extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
       return 'bs_form_booking';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {
        /*$form['map_search_box'] = [
            '#type' => 'textfield',
            '#required' => TRUE,
        ];*/

        $arr_cities_countries = get_all_properties_cities_and_countries();

        $form['location'] = [
            '#type' => 'select',
            '#required' => TRUE,
            '#options' => $arr_cities_countries,
            '#default_value' => 'IL|Tel Aviv'
        ];
        $form['date'] = [
            '#type' => 'datetime',
            '#required' => TRUE,
            '#size' => 20,
            '#date_date_element' => 'date',
            '#attributes' => ['min' =>  \Drupal::service('date.formatter')->format(\Drupal::time()->getRequestTime(), 'custom', 'Y-m-d'),],
            '#date_time_element' => 'none',
            '#date_time_format' => 'h:i',
            '#default_value' => DrupalDateTime::createFromTimestamp(time() + (60 * 60 * 24)),
        ];

        $arr_times = select_list_times();
        $form['start_time'] = [
            '#type' => 'select',
            '#required' => TRUE,
            '#options' => $arr_times,
            '#default_value' => 20,
        ];
        $form['end_time'] = [
            '#type' => 'select',
            '#required' => TRUE,
            '#options' => $arr_times,
            '#default_value' => 24,
        ];
        $arr_number_of_people = get_taxonomy_term_values('booking_number_of_guests', false);
        $arr_number_of_people = [0 => 'Any'] + $arr_number_of_people;
        $form['booking_people'] = [
            '#type' => 'select',
            '#options' => $arr_number_of_people,
        ];
        $form['#attached']['library'][] = 'bs_form_booking/bs_form_booking';
        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => t('Find A Space'),
            '#attributes' => [
                'class' => ['btn-primary btn-lg']
            ],
        ];
        $form['node_obj'] = array(
            '#type' => 'value',
            '#value' => $node,
        );
        return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $data = [];
        $fields = $form_state->getValues();
        // Create the query string.
        $data['date'] = $fields['date']->format('Y-m-d');
        $data['start_time'] = $fields['start_time'];
        $data['end_time'] = $fields['end_time'];
        $data['booking_people'] = $fields['booking_people'];
        $data['location'] = $fields['location'];

        $qs = http_build_query($data);
        $redirect_path = '/search_results?' . $qs;
        $path = URL::fromUserInput($redirect_path)->toString();
        $response = new RedirectResponse($path);
        $response->send();
    }
}
