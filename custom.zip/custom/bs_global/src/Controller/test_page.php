<?php

namespace Drupal\bs_global\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\bs_global;

/**
 * Provides route responses for map location routing.
 */
class test_page extends ControllerBase {

    /**
     * Loads the page
     */
    public function content() {


        //payme_create_seller();

        $records = get_chat_messages(4);
        kint($records);


        //$user_id = 1;
        //$user_type = "host";
        ////$property_id = 218;
        //$property_id = 0;
        //$arr_chats = get_data_for_chat_page($property_id);
        //kint($arr_chats);


        //cancel_reservation(388);

        //$total = get_total_space_reservations_last_days(219, 30);
        //kint($total);


        //list($min_start_time, $max_end_time) = get_space_min_and_max_opening_hours(219);
        //kint($min_start_time, $max_end_time);
        //kint(get_select_list_times_from_index($min_start_time));
        //kint(get_select_list_times_from_index($max_end_time));

        //$arr_available_countries = get_available_countries();
        //kint($arr_available_countries);

        //$arr_country_details = get_country_details_by_country_code("IL");
        //kint($arr_country_details);


        //$space_tid = 219;
        //$str_start_time = date('Y-m-d\TH:i:s');
        //$str_end_time = date('Y-m-d\TH:i:s', strtotime("+7 day"));
        //kint($str_start_time, $str_end_time);
        //$prices = get_space_prices_per_hour_for_period($space_tid, $str_start_time, $str_end_time);
        //kint($prices);





        /*
        if(isset($_REQUEST["id"])){
            $id = $_REQUEST["id"];
            echo $id . "<br/>";
        }
        */

        //die('test_page');



        //$edit_id = $_REQUEST['id'];
        //$ct_direct_sales = Node::load($edit_id);
        //kint($ct_direct_sales);



        //Return the page with everything around..
        //$build = [
            //'#markup' => $this->t($id),
        //];
        //return $build;
    }


    /**
     * Loads the page when the path in the routing file is (example) path: '/test_page/{node}'.
     * It loads the node automatically and says "The requested page could not be found" if the node does not exist
     */
    /*public function content(NodeInterface $node) {

        //$build = [
        //'#markup' => $this->t("hello"),
        //];
        //return $build;

        //kint($node);die;



        //DEBUG HOURS PROBLEM (daylight saving time)
        if ($node->hasField('field_space_prices')) {
            $space_prices = $node->field_space_prices->getValue();

            //print_r($space_prices);die;

            //Run on all space prices and handle the weekdays
            foreach ($space_prices as $key => $price) {
                $prices_pid = $price['target_id'];
                if($prices_pid == 573){
                    //Load paragraph space_prices
                    $p_space_prices = Paragraph::load($prices_pid);

                    //Get the paragraph id of the "Times" paragraph
                    $times_pid = $p_space_prices->field_price_time->getValue()[0]["target_id"];

                    $arr_times = get_paragraph_times($times_pid);
                    kint($arr_times);

                    //Load data from paragraph "Times"
                    $paragraph_times = Paragraph::load($times_pid);
                    kint($paragraph_times);


                    //$date = new DrupalDateTime($paragraph_times->field_times->getValue()[0]['end_value'], 'UTC');
                    //$timezone = drupal_get_user_timezone();
                    //$date->setTimeZone(timezone_open($timezone));
                    //print "<pre>";print_r($date->format('H a'));die('Test');

                    //$space_start_time = new DrupalDateTime($paragraph_times->field_times->getValue()[0]['value'], 'UTC');
                    //$space_end_time = new DrupalDateTime($paragraph_times->field_times->getValue()[0]['end_value'], 'UTC');
                    //$timezone = drupal_get_user_timezone();
                    //$space_start_time->setTimeZone(timezone_open($timezone));
                    //$space_end_time->setTimeZone(timezone_open($timezone));

                    $space_start_time = remove_timezone_from_drupal_time($paragraph_times->field_times->getValue()[0]['value']);
                    $space_end_time = remove_timezone_from_drupal_time($paragraph_times->field_times->getValue()[0]['end_value']);

                    //REMOVE COMMENT TO SEE PROBLEM WITH DAYLIGHT SAVING TIME:
                    //A good example is when getting the April price of “Office near the ocean”, it shows dates “2019-03-31T23:00:00 - 2019-04-30T23:00:00"
                    echo("Start time: " . $space_start_time . "<br/>End time: " . $space_end_time . "<br/>");

                    //$dte_start = date($space_start_time);
                    $dte_start  = \Drupal::service('date.formatter')->format(strtotime($space_start_time), 'date_text');
                    echo($dte_start . "<br/>");

                    //$dte_end = date($space_end_time);
                    $dte_end  = \Drupal::service('date.formatter')->format(strtotime($space_end_time), 'date_text');
                    echo($dte_end);

                    echo "<br/><br/>";
                }
            }
        }
    }*/


}
