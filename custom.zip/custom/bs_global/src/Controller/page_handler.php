<?php

namespace Drupal\bs_global\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\bs_global;

/**
 * Provides route responses for map location routing.
 */
class page_handler extends ControllerBase {

    /**
     * Loads the page
     */
    public function content()
    {
        $action = $_GET['action'];
        switch($action){
            case "set_user_type":
                $user_type = $_GET['user_type'];
                set_user_type($user_type);
                $url = $_SERVER['HTTP_REFERER'];
                if ((strpos($url,'reviews-host') !== false) || (strpos($url,'reviews') !== false)) {
                  if ($user_type == 'property_owner') {
                    $newurl = dirname($url);
                    $newurl = $newurl.'/reviews-host';
                    header("Location: " . $newurl);
                  }
                  else {
                    $newurl = dirname($url);
                    $newurl = $newurl.'/reviews';
                    header("Location: " . $newurl);
                  }
                }
                else {
                  header("Location: " . $url);
                }
                //header("Location: " . $_SERVER['HTTP_REFERER']);
                die();
                break;

            case "res_cancel":
                //CANCEL RESERVATION
                $res_id = $_GET['res_id'];
                $status = cancel_reservation($res_id);
                if($status == 1){

                    //Reservation canceled. Refresh the page
                    //header("Location: " . $_SERVER['HTTP_REFERER']);
                    //die();

                    $element = array(
                        '#title' => "Reservation canceled!",
                        '#markup' => "Reservation $res_id canceled successfully!",
                    );
                    return $element;

                } else {

                    //Failed to canceled reservation
                    $element = array(
                        '#title' => "Reservation cancellation failed!",
                        '#markup' => "Reservation $res_id failed to cancel!",
                    );
                    return $element;
                }
                break;

            case "res_request_to_cancel":

                //REQUEST TO RESERVATION
                $res_id = $_GET['res_id'];
                $status = request_to_cancel_reservation($res_id);
                if($status == 1){

                    $element = array(
                        '#title' => "Request to cancel was sent!",
                        '#markup' => "Request to cancel reservation $res_id was sent. You will be contacted by the host is a few days!",
                    );
                    return $element;

                } else {

                    //Failed to canceled reservation
                    $element = array(
                        '#title' => "Request to cancel failed!",
                        '#markup' => "Request to cancel reservation $res_id failed to sent to the host! Please try to contact the host using the email address or phone number listed below",
                    );
                    return $element;
                }
                break;

            default:
                //Do nothing
        }
    }
}
