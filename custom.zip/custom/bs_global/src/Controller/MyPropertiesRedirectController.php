<?php

namespace Drupal\bs_global\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Redirect to My Properties Page.
 */
class MyPropertiesRedirectController extends ControllerBase {

    /**
     * Loads the page
     */
    public function content() {
      $response = new RedirectResponse(Url::fromRoute('view.my_properties.page_1')->toString());
      $response->send();
    }
}
