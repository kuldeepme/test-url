<?php

namespace Drupal\bs_global\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a Block for the bs_global form.
 *
 * @Block(
 *   id = "bs_global_currecny_block",
 *   admin_label = @Translation("bs_global_currecny_block"),
 *   category = @Translation("bs_global"),
 * )
 */
class bs_global_currecny_block extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\bs_global\Form\BsFormCurrency');
        return $form;
    }

}
