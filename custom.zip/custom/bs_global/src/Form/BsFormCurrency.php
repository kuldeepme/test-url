<?php

namespace Drupal\bs_global\Form;

/**
 * @file
 * Contains \Drupal\bs_global\Form\BsFormCurrency.
 */

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Ajax\RedirectCommand;

/**
 * {@inheritdoc}
 */
class BsFormCurrency extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'bs_form_currency';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, NodeInterface $node = NULL) {

        $form['container']["markup"] = [
            "#markup" => "<div id='instrument-fieldset-currency-container'></div>",
        ];

        //Get all currencies
        $sort_by_key = true;
        $arr_currencies = get_taxonomy_term_values('currencies', $sort_by_key);

        //get user's preferred currency id
        $user_preferred_currency_id = get_user_preferred_currency_id();

        $form['container']['currency'] = [
            '#type' => 'select',
            '#options' => $arr_currencies,
            '#default_value' => $user_preferred_currency_id,
            //'#title' => t("Currency"),
            '#ajax' => [
                'callback' => '::instrumentDropdownCallback',
                'wrapper' => 'instrument-fieldset-currency-container',
            ],
        ];

        $form['container']['#cache'] = [
            'max-age' => 0
        ];

        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        //$values = $form_state->getValues();
    }

    /*
     * This function is called when date or time is changed
     */
    function instrumentDropdownCallback(array &$form, FormStateInterface $form_state){

        $values = $form_state->getValues();

        $currency_tid = $values['currency'];
        set_user_preferred_currency_id($currency_tid);

        $form_state->setRebuild(TRUE);

        $response = new AjaxResponse();
        $currentURL = Url::fromRoute('<current>');
        $response->addCommand(new RedirectCommand($currentURL->toString()));

        return $response;

        //Redirect to the same page
        //header("Location: " . $_SERVER['PHP_SELF']);
        //die();

        //$ajax_response = new AjaxResponse();
        //$ajax_response->addCommand(new HtmlCommand('#result_error_message', ""));
        //$ajax_response->addCommand(new HtmlCommand('.price_calculations', ""));
        ////Hide "Reserve" button and display "Check availability" button
        //$ajax_response->addCommand(new InvokeCommand('.btn-check_availability', 'removeClass', array('hidden')));
        //$ajax_response->addCommand(new InvokeCommand('.btn-reserve', 'addClass', array('hidden')));
        //return $ajax_response;
    }

}
