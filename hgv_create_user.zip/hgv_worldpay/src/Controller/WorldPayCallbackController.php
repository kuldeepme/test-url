<?php

namespace Drupal\hgv_worldpay\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\Response;


/**
 * WorldPayCallbackController class.
 */
class WorldPayCallbackController extends ControllerBase {

  /**
   * WorldPay Callback.
   */
  public function worldPayCallback() {
    $response = new Response('', 200);
      
    $nodeid = \Drupal::request()->request->get('MC_nodeid');
    $transId = \Drupal::request()->request->get('transId');
    $transStatus = \Drupal::request()->request->get('transStatus');

    if (!empty($transId) && ($transStatus == 'Y')) {
      $node = Node::load($nodeid);
      $field_status = $node->get('field_status')->value;
      if ($field_status == 'Expired') {
        $date_of_job = strtotime(date('Y-m-d H:i:s'));
        $date_of_job = strtotime('+7 days', $date_of_job);
        $job_expired_date = date('Y-m-d', $date_of_job);
        $node->set('field_job_expired_date', $job_expired_date);
        $node->set('field_status', 'New');
      }
      $node->setPublished(TRUE);
      $node->save();
    } 
    
    \Drupal::logger('hgv_worldpay')->notice("<pre>" . print_r($_POST, TRUE) . "</pre>");
    
    return $response;
  }

}
