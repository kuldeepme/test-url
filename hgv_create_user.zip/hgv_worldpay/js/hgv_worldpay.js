jQuery(document).ready(function ($) {
  //$("#worldpay_paynow").trigger("click");
});
