<?php

namespace Drupal\hgv_jobs\Controller;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilder;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;

/**
 * QuotePopupController class.
 */
class QuotePopupController extends ControllerBase {

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * {@inheritdoc}
   */
  public function __construct(FormBuilder $formBuilder, AccountInterface $user) {
    $this->formBuilder = $formBuilder;
    $this->user = $user;
  }

  /**
   * {@inheritdoc}
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The Drupal service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('form_builder'),
      $container->get('current_user')
    );
  }

  /**
   * Callback for opening the modal form.
   */
  public function quoteModal() {
    $response = new AjaxResponse();

    // Get the modal form using the form builder.
    $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\QuoteForm');
    // Add an AJAX command to open a modal dialog with the form as the content.
    $response->addCommand(new OpenModalDialogCommand('Quote a Job', $modal_form, ['width' => '500']));

    return $response;
  }

  /**
   * My job access callback..
   */
  public function access() {
    $user_roles = $this->user->getRoles();
   
    $roles = ['administrator','driver'];
   
    if(count(array_intersect($user_roles, $roles)) >0 ){
        return AccessResult::allowed();
    }
    return AccessResult::forbidden('Permission denied.');
  }

}
