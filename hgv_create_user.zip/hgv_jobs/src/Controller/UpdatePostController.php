<?php

namespace Drupal\hgv_jobs\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Form\FormBuilder;

/**
 * UpdatePostController controller.
 */
class UpdatePostController extends ControllerBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user, FormBuilder $formBuilder) {
    $this->user = $user;
    $this->formBuilder = $formBuilder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('form_builder')
    );
  }

  /**
   * Update job.
   */
  public function updatePost() {
    $response = new AjaxResponse();
    $route_match = \Drupal::service('current_route_match');
    $nid = $route_match->getParameter('nid');
    $status = $route_match->getParameter('status');
    if ($status == 2) {
      $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\JobUpdateForm');
      $response->addCommand(new OpenModalDialogCommand('Update Job', $modal_form, ['width' => '500']));
    }
    return $response;
  }

  /**
   * My job access callback..
   */
  public function access() {
    $user_roles = $this->user->getRoles();
    $roles = ['dispatcher'];
    if (!array_intersect($roles, $user_roles)) {
      return AccessResult::forbidden('Permission denied.');
    }
    return AccessResult::allowed();
  }

}
