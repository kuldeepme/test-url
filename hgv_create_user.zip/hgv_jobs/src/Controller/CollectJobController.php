<?php

namespace Drupal\hgv_jobs\Controller;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilder;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;

/**
 * CollectJobController class.
 */
class CollectJobController extends ControllerBase {

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * The current user.
   *
   * @var Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The JobReviewController constructor.
   *
   * @param \Drupal\Core\Form\FormBuilder $formBuilder
   *   The form builder.
   * @param \Drupal\Core\Session\AccountInterface $user
   *   The current user.
   */
  public function __construct(FormBuilder $formBuilder, AccountInterface $user) {
    $this->formBuilder = $formBuilder;
    $this->user = $user;
  }

  /**
   * {@inheritdoc}
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The Drupal service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('form_builder'),
      $container->get('current_user')
    );
  }

  /**
   * Callback for opening the modal form.
   */
  public function collectJobStatus() {
    $user_roles = \Drupal::currentUser()->getRoles();
    $response = new AjaxResponse();
    if (in_array("dispatcher", $user_roles)) {
      // Get the modal form using the form builder.
      $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\DispatcherCollectJobForm');
      // Add an AJAX command to open a modal dialog with the form as the content.
      $response->addCommand(new OpenModalDialogCommand('Collect Job', $modal_form, ['width' => '600']));
    }
/*    elseif (in_array("driver", $user_roles)) {
      // Get the modal form using the form builder.
      $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\DriverDeliveryForm');
      // Add an AJAX command to open a modal dialog with the form as the content.
      $response->addCommand(new OpenModalDialogCommand('Delivery Status', $modal_form, ['width' => '600']));
    }*/
    return $response;
  }

  /**
   * My job access callback.
   */
  public function access() {
    $user_roles = $this->user->getRoles();
    $roles = ['administrator', 'dispatcher'];
    if (!array_intersect($roles, $user_roles)) {
      return AccessResult::forbidden('Permission denied.');
    }
    return AccessResult::allowed();
  }

}
