<?php

namespace Drupal\hgv_jobs\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Form\FormBuilder;
use Drupal\node\Entity\Node;

/**
 * User QuoteJobUpdateController controller.
 */
class QuoteJobUpdateController extends ControllerBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user, FormBuilder $formBuilder) {
    $this->user = $user;
    $this->formBuilder = $formBuilder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('form_builder')
    );
  }

  /**
   * Update job.
   */
  public function updateJob() {
    $connection = \Drupal::database();
    $route_match = \Drupal::service('current_route_match');
    $id = $route_match->getParameter('id');
    $uid = $route_match->getParameter('uid');
    $status = $route_match->getParameter('status');
    $nid = $route_match->getParameter('nid');
    $query = $connection->update('my_jobs');
    $query->fields([
      'status' => $status,
    ]);
    $query->condition('id', $id);
    $query->condition('uid', $uid);
    $result = $query->execute();
    $node = Node::load($nid);
    $node->set('field_status', ['In-Progress']);
    $node->save();
    $job_id = get_jobs_status($nid);
    if ($status == 0) {
      if (!empty($job_id)) {
        $response = new AjaxResponse();
        foreach ($job_id as $value) {
          $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\JobRejectForm', $value->id, $this->user);
        }
        $response->addCommand(new OpenModalDialogCommand('Reject a Job', $modal_form, ['width' => '500']));
        return $response;
      }
    }

    // $url = Url::fromRoute('hgv_jobs.my_jobs');
    // $response = new RedirectResponse($url->toString());
    $response = new RedirectResponse(Url::fromRoute('view.all_jobs.page_1')->toString());
    if ($result) {
      $response->send();
      drupal_set_message(t('Successfully active job!'), 'status', TRUE);
    }
    else {
      $response->send();
      drupal_set_message(t('Something went wrong, please try again!'), 'status', TRUE);
    }
    return $response;
  }

  /**
   * My job access callback..
   */
  public function access() {
    $user_roles = $this->user->getRoles();
    $roles = ['dispatcher'];
    if (!array_intersect($roles, $user_roles)) {
      return AccessResult::forbidden('Permission denied.');
    }
    return AccessResult::allowed();
  }

}
