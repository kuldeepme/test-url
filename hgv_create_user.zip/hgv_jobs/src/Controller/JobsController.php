<?php

namespace Drupal\hgv_jobs\Controller;

/**
 * @file
 * HGV jobs controller.
 */

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\Core\Render\Renderer;
use Drupal\file\Entity\File;
use Drupal\Core\Form\FormBuilder;

/**
 * User JobsController controller.
 */
class JobsController extends ControllerBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $render;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user, Renderer $render, FormBuilder $formBuilder) {
    $this->user = $user;
    $this->render = $render;
    $this->formBuilder = $formBuilder;
  }

  /**
   * Creates new mock file finder objects.
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('renderer'),
      $container->get('form_builder')
    );
  }

  /**
   * List all jobs associated to current user.
   */
  public function myJobs() {
    $build = [];
    $rows = [];
    $collected_output = '';
    $delivered_output = '';
    $invoice_output = '';
    $invoice = '';
    $result = '';
    $uid = $this->user->id();
    $connection = \Drupal::database();
    $user_roles = \Drupal::currentUser()->getRoles();
    $dispatcher_roles = ['administrator', 'dispatcher'];
    if (array_intersect($dispatcher_roles, $user_roles)) {

      $quotes_form_list = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\DispatcherMyJobsForm');

      return [
        '#type' => 'markup',
        '#markup' => render($quotes_form_list),
      ];
    }
    elseif (in_array("driver", $user_roles)) {
      $result_driver = $connection->select('my_jobs', 't')
        ->fields('t', [])
        ->condition('uid', $uid)
        ->execute()
        ->fetchAll();
      if (!empty($result_driver)) {
        foreach ($result_driver as $row => $content) {
          $node = Node::load($content->nid);
          $mesaage_id = $content->nid;
          $message = '<a class="btn btn-lg btn-primary job-messages" href="/job/' . $mesaage_id . '/message"> Message </a>';
          if ($content->status == 1) {
            $status = 'In-Progress';
          }
          elseif ($content->status == 0) {
            $status = 'Pending';
          }
          if (!$node->get('field_start_location')->isEmpty()) {
            $start_location = $node->field_start_location->view(['full', 'label' => 'hidden']);
            $start_location = $this->render->renderRoot($start_location);
          }
          if (!$node->get('field_end_location')->isEmpty()) {
            $end_location = $node->field_end_location->view(['full', 'label' => 'hidden']);
            $end_location = $this->render->renderRoot($end_location);
          }
          if (!$node->get('field_time_frame')->isEmpty()) {
            $time_frame = $node->field_time_frame->view(['full', 'label' => 'hidden']);
            $time_frame = $this->render->renderRoot($time_frame);
          }
          else {
            $time_frame = '';
          }
          $collected_url = Url::fromRoute('hgv_jobs.job_status', [
            'status' => 'collected',
            'nid' => $content->nid,
            'id' => $content->id,
          ]);
          $collected_url = Link::fromTextAndUrl(t('Collect'), $collected_url);
          $collected = $collected_url->toRenderable();
          $collected['#attributes'] = ['class' => ['use-ajax', 'button']];

          $delivered_url = Url::fromRoute('hgv_jobs.delivery_status', [
            'id' => $content->id,
            'uid' => $uid,
            'nid' => $content->nid,
          ]);
          $delivered_url = Link::fromTextAndUrl(t('Deliver'), $delivered_url);
          $delivered = $delivered_url->toRenderable();
          $delivered['#attributes'] = ['class' => ['use-ajax', 'button']];

          if ($status == 'In-Progress' && $content->uid == $uid) {
            if (!empty($content->deliver_job_fid)) {
              $file = File::load($content->deliver_job_fid);
              if (!empty($file)) {
                  $path = $file->url();
                  $delivered_url = Url::fromUri($path);
                  $delivered_url = Link::fromTextAndUrl(t('View Receipt'), $delivered_url);
                  $delivered_url = $delivered_url->toRenderable();
                  $delivered_url['#attributes'] = array('target' => array('_blank'),'class'=>array('btn btn-sm btn-primary'));
                  $delivered_output = $this->render->renderRoot($delivered_url);
              }
              $delivered_output .= $this->render->renderRoot($delivered);
            }
            else {
              $delivered_output = $delivered;
            }              
            if (!empty($content->collected_job_fid)) {
              $file = File::load($content->collected_job_fid);
              if (!empty($file)) {
                  $path = $file->url();
                  $collected_url = Url::fromUri($path);
                  $collected_url = Link::fromTextAndUrl(t('View Receipt'), $collected_url);
                  $collected_url = $collected_url->toRenderable();
                  $collected_url['#attributes'] = array('target' => array('_blank'),'class'=>array('btn btn-sm btn-primary'));
                  $collected_output = $this->render->renderRoot($collected_url);
              }
              $collected_output .= $this->render->renderRoot($collected);
            }
            else {
              $collected_output = $collected;
            }
            if (isset($content->name_person_pod)) {
              $invoice_url = Url::fromRoute('hgv_jobs.send_invoice', [
                'status' => 'invoice',
                'nid' => $content->nid,
                'id' => $content->id,
              ]);
              $invoice_url = Link::fromTextAndUrl(t('Invoice'), $invoice_url);
              $invoice = $invoice_url->toRenderable();
              $invoice['#attributes'] = ['class' => ['use-ajax', 'button']];
            }
            else {
              $invoice = '';
            }
            if (!empty($content->invoice_job_fid)) {
              $status = "Completed";
              if (!empty($content->driver_review)) {
                $review_form = '';
                $review_url = Url::fromRoute('hgv_jobs.job_review',
                  [
                    'id' => $content->id,
                    'uid' => $content->job_author,
                    'nid' => $content->nid,
                  ]);
                $review_url = Link::fromTextAndUrl(t('Update Review'), $review_url);
                $review = $review_url->toRenderable();
                $review['#attributes'] = ['class' => ['use-ajax', 'button']];
                $review_form = $this->render->renderRoot($review);
                $review_form = render($review_form);
              }
              else {
                $review_form = '';
                $review_url = Url::fromRoute('hgv_jobs.job_review',
                  [
                    'id' => $content->id,
                    'uid' => $content->job_author,
                    'nid' => $content->nid,
                  ]);
                $review_url = Link::fromTextAndUrl(t('Write Review'), $review_url);
                $review = $review_url->toRenderable();
                $review['#attributes'] = ['class' => ['use-ajax', 'button']];
                $review_form = $this->render->renderRoot($review);
              }
              if (!empty($content->review)) {
                $rate_by_dispatcher = '';
                $driver_review_form = $this->formBuilder->getForm('\Drupal\hgv_jobs\Form\DriverReviewForm', $content->id, $content->nid);
                $rate_by_dispatcher = render($driver_review_form);
              }
              else {
                $rate_by_dispatcher = '';
              }
            }
            else {
              // $invoice = ''; !
              $review_form = '';
              $rate_by_dispatcher = '';
            }
            // print_r($content); exit; //
            $driver_review_form = render($review_form);
            $rows[] = [
              $node->getTitle(),
              $start_location,
              $end_location,
              $time_frame,
              $content->amount,
              $status,
              $content->date,
              $collected_output,
              $delivered_output,
              $invoice,
              $driver_review_form,
              $message,
              $rate_by_dispatcher,
            ];
          }
          elseif ($status == 'Pending' && $content->uid == $uid) {
            $rows[] = [
              $node->getTitle(),
              $start_location,
              $end_location,
              $time_frame,
              $content->amount,
              $status,
              $content->date,
              '', '', '', '', $message, '',
            ];
          }
        }
        $header = [
          t('Job'),
          t('Start Location'),
          t('End Location'),
          t('Time Frame'),
          t('Quote Amount'),
          t('Status'),
          t('Date'),
          t('Collect Job'),
          t('Deliver Job'),
          t('Send invoice'),
          t('Review'),
          t('Message'),
          t('Rate By Dispatcher'),
        ];
        $build['table'] = [
          '#type'    => 'tableselect',
          '#header' => $header,
          '#options'   => $rows,
          'empty' => 'No record found',
        ];
        $build['pager'] = [
          '#type' => 'pager',
        ];
        return [
          '#theme' => 'hgv_my_jobs_driver',
          '#content' => $build,
          '#cache' => ['max-age' => 0],
        ];
      }
      else {
        return [
          '#type' => 'markup',
          '#markup' => t('No data available'),
          '#cache' => ['max-age' => 0],
        ];
      }
    }
  }
  
  /**
   * List all jobs associated to current user.
   */
 public function driverCompletedJobs() {
    $uid = $this->user->id();
    $connection = \Drupal::database();
    $user_roles = \Drupal::currentUser()->getRoles();
    if (in_array("driver", $user_roles)) {
      $result_driver = $connection->select('my_jobs', 't')
        ->fields('t', [])
        ->condition('uid', $uid)
        ->condition('invoice_job_fid', '', '<>')
        ->execute()
        ->fetchAll();
      if (!empty($result_driver)) {
        foreach ($result_driver as $row => $content) {
               $node = Node::load($content->nid);
               $dispatcher =  $content->job_author;
               $account = \Drupal\user\Entity\User::load($dispatcher);
               $dispatcher_name = $account->getUsername();
               if (!$node->get('field_start_location')->isEmpty()) {
                $start_location = $node->field_start_location->view(['full', 'label' => 'hidden']);
            $start_location = $this->render->renderRoot($start_location);
          }
          if (!$node->get('field_end_location')->isEmpty()) {
            $end_location = $node->field_end_location->view(['full', 'label' => 'hidden']);
            $end_location = $this->render->renderRoot($end_location);
          }
            $rows[] = [
              $node->getTitle(),
              $dispatcher_name,
              'Completed',
              $start_location,
              $end_location
              
            ];
           
        }
        $header = [  t('Job Title'),
                    t('Dispatcher'),
                    t('Status'),
                    t('Start Location'),
                    t('End Location'),
                 ];
       $build['table'] = [
            '#type'    => 'table',
            '#header' => $header,
            '#options'   => $rows,
            'empty' => 'No record found',
            ];
       return [
          '#theme' => 'hgv_my_jobs_driver',
          '#content' => $build,
          '#cache' => ['max-age' => 0],
        ];
      }
       else {
        return [
          '#type' => 'markup',
          '#markup' => t('No data available'),
          '#cache' => ['max-age' => 0],
        ];
      }
      
    }
    
  }
      
  /**
   * Quote access callback.
   */
  /*public function AllQuote($jobid) {
  if (array_intersect($dispatcher_roles, $user_roles)) {

      $quotes_form_list = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\DispatcherQuoteForm');

      return [
        '#type' => 'markup',
        '#markup' => render($quotes_form_list),
      ];
    }
  }*/
  
  /**
   * My job access callback.
   */
  public function access() {
    $user_roles = $this->user->getRoles();
    $roles = ['administrator', 'dispatcher', 'driver'];
    if (!array_intersect($roles, $user_roles)) {
      return AccessResult::forbidden('Permission denied.');
    }
    return AccessResult::allowed();
  }
  
  /**
   * My job get distance callback.
   */
  public function getdistance() {
    // print_r($_POST);
  }

}
