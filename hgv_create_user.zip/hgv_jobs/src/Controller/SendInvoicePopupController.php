<?php

namespace Drupal\hgv_jobs\Controller;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilder;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;

/**
 * SendInvoicePopupController class.
 */
class SendInvoicePopupController extends ControllerBase {

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * {@inheritdoc}
   */
  public function __construct(FormBuilder $formBuilder, AccountInterface $user) {
    $this->formBuilder = $formBuilder;
    $this->user = $user;
  }

  /**
   * {@inheritdoc}
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The Drupal service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('form_builder'),
      $container->get('current_user')
    );
  }

  /**
   * Callback for opening the modal form.
   */
  public function sendInvoiceModal() {
    $response = new AjaxResponse();

    // Get the modal form using the form builder.
    $modal_form = $this->formBuilder->getForm('Drupal\hgv_jobs\Form\InvoiceForm');
    // Add an AJAX command to open a modal dialog with the form as the content.
    $response->addCommand(new OpenModalDialogCommand('Receipt', $modal_form, ['width' => '500']));

    return $response;
  }

  /**
   * My job access callback..
   */
  public function access() {
    $user_roles = $this->user->getRoles();
    $roles = ['driver'];
    if (!array_intersect($roles, $user_roles)) {
      return AccessResult::forbidden('Permission denied.');
    }
    return AccessResult::allowed();
  }

}
