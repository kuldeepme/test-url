<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Connection;
use Drupal\node\Entity\Node;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Render\Renderer;
use Drupal\Core\Form\FormBuilder;

/**
 * DispatcherMyJobsForm class.
 */
class DispatcherQuoteForm extends FormBase {
  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The database service.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $render;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user, Connection $connection, Renderer $render, FormBuilder $formBuilder) {
    $this->user = $user;
    $this->database = $connection;
    $this->render = $render;
    $this->formBuilder = $formBuilder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('database'),
      $container->get('renderer'),
      $container->get('form_builder')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_dispatcher_myjobs_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $jobid = NULL) {
    $output = [];
    $result = '';
    $uid = $this->user->id();
    $header = array(
      'title' => t('Job'),
      'username' => t('Username'),
      'amount' => ['data' => 'Amount', 'field' => 't.amount', 'sort' => 'desc'],
    // 'amount' => t('Quote Amount'),
      'status' => t('Status'),
      'action' => t('Action'),
      'update_post' => t('Update Post'),
      'collect_job' => t('Collect Job'),
      'delivery_status' => t('Delivery Status'),
      'view_invoice' => t('View Invoice'),
      'review_output' => t('Review'),
      'review_form' => t('Rate By Driver'),
      'message' => t('Message'),
    );
    /*
    print_r($header); exit;

    $header = [

    ['data' => t('Job'), 'field' => 't.title'],
    ['data' => t('Amount'), 'field' => 't.amount', 'sort' => 'desc'],
    ['data' => t('Status'), 'field' => 't.status'],
    ['data' => t('Action'), 'field' => 't.action'],
    ['data' => t('Update Post'), 'field' => 't.update_post'],
    ['data' => t('Delivery Status'), 'field' => 't.delivery_status'],
    ['data' => t('View Invoice'), 'field' => 't.view_invoice'],
    ['data' => t('Review'), 'field' => 't.review_output'],
    ['data' => t('Rate By Driver'), 'field' => 't.review_form'],
    ['data' => t('Message'), 'field' => 't.message'],
    ];
     */


    $query = $this->database->select('my_jobs', 't')
      ->extend('Drupal\Core\Database\Query\TableSortExtender');
    $query->fields('t');
    $query->condition('job_author', $uid);
    $query->condition('nid', $jobid);

    // Don't forget to tell the query object how to find the header information.
    $result = $query
      ->orderByHeader($header)
      ->execute()
      ->fetchAll();

    /* print_r($result); exit;


    $result = $this->database->select('my_jobs', 'd')
    ->fields('d', [])
    ->condition('job_author', $uid)
    ->condition('nid', $jobid)
    ->orderByHeader($header_row)
    ->execute()
    ->fetchAll();

     */
    if (!empty($result)) {
      $i = 0;
      foreach ($result as $row => $content) {
        $node = Node::load($content->nid);
        $mesaage_id = $content->nid;
        global $base_url;
        $message_link = $base_url . '/job/' . $mesaage_id . '/message';
        $options['attributes']['class'] =  array('btn', 'btn-lg', 'btn-primary','job-messages');

        $message = Link::fromTextAndUrl('Message', Url::fromUri($message_link, $options))->toString();
        
        $account = \Drupal\user\Entity\User::load($content->uid);
        $name = $account->getUsername();

        $user_id = $base_url.'/user/'.$content->uid;
        $user_link = Link::fromTextAndUrl($name, Url::fromUri($user_id))->toString();
        
        if ($content->status == 1) {
          $status = 'In-Progress';
        }
        elseif ($content->status == 2) {
          $status = 'Under-Dispute';
        }
        else {
          $status = 'Pending';
        }
        if ($status == "In-Progress" && $content->job_author == $uid) {
          $generated_url = Url::fromRoute('hgv_jobs.quote_status_update',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 0,
              'nid' => $content->nid,
            ]);
          $generated_url = Link::fromTextAndUrl(t('Reject'), $generated_url);
          $action = $generated_url->toRenderable();
          $action['#attributes'] = ['class' => ['btn btn-sm btn-danger use-ajax']];
          $update_post_url = Url::fromRoute('hgv_jobs.update_post',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 2,
              'nid' => $content->nid,
            ]);
          $update_post_url = Link::fromTextAndUrl(t('Status'), $update_post_url);
          $update_post = $update_post_url->toRenderable();
          $update_post['#attributes'] = ['class' => ['use-ajax', 'button']];
/*          $collected_url = Url::fromRoute('hgv_jobs.job_status', [
            'status' => 'collected',
            'nid' => $content->nid,
            'id' => $content->id,
          ]);
          $collected_url = Link::fromTextAndUrl(t('Collect'), $collected_url);
          $collected = $collected_url->toRenderable();
          $collected['#attributes'] = ['class' => ['use-ajax', 'button']];*/          
            if (!empty($content->arrived_time)) {
                $collect_job = '';
                $collect_status_url = Url::fromRoute('hgv_jobs.dispatcher_collect_job',
                  [
                    'id' => $content->id,
                    'uid' => $content->job_author,
                    'nid' => $content->nid,
                  ]);
                $collect_status_url = Link::fromTextAndUrl(t('Collect Job'), $collect_status_url);
                $collect = $collect_status_url->toRenderable();
                $collect['#attributes'] = ['class' => ['use-ajax']];
                $collect_output = $this->render->renderRoot($collect);
                $output[$content->id]['collect_job'] = render($collect_output);                
/*              $file = File::load($content->collected_job_fid);
              if (!empty($file)) {
                  $path = $file->url();
                  $collected_url = Url::fromUri($path);
                  $collected_url = Link::fromTextAndUrl(t('Collect Job'), $collected_url);
                  $collected_url = $collected_url->toRenderable();
                  $collected_url['#attributes'] = array('target' => array('_blank'),'class'=>array('btn btn-sm btn-primary'));
                  $collect_job = $this->render->renderRoot($collected_url);
                  $output[$content->id]['collect_job'] = render($collect_job);
              }
              $collect_job .= $this->render->renderRoot($collected);*/
            }
            else {
              //$collect_job = $collected;
              $output[$content->id]['collect_job'] = '';
            }          
          if (!empty($content->name_person_pod)) {
            $delivery_status = '';
            $delivery_status_url = Url::fromRoute('hgv_jobs.delivery_status',
              [
                'id' => $content->id,
                'uid' => $content->job_author,
                'nid' => $content->nid,
              ]);
            $delivery_status_url = Link::fromTextAndUrl(t('Delivery Status'), $delivery_status_url);
            $delivery = $delivery_status_url->toRenderable();
            $delivery['#attributes'] = ['class' => ['use-ajax']];
            $delivery_output = $this->render->renderRoot($delivery);
            $output[$content->id]['delivery_status'] = render($delivery_output);
          }
          else {
            $output[$content->id]['delivery_status'] = '';
          }
          if (!empty($content->invoice_job_fid)) {
            $status = 'Completed';
            $file = File::load($content->invoice_job_fid);
            $path = $file->url();
            $view_invoice = Url::fromUri($path);
            $view_invoice = Link::fromTextAndUrl(t('View Invoice'), $view_invoice);
            $view_invoice = $view_invoice->toRenderable();
            $view_invoice['#attributes'] = array('target' => array('_blank'));
            if (!empty($content->review)) {
              $review_output = '';
              $review_url = Url::fromRoute('hgv_jobs.job_review',
                [
                  'id' => $content->id,
                  'uid' => $content->job_author,
                  'nid' => $content->nid,
                ]);
              $review_url = Link::fromTextAndUrl(t('Update Review'), $review_url);
              $review = $review_url->toRenderable();
              $review['#attributes'] = ['class' => ['use-ajax', 'button']];
              $review_output = $this->render->renderRoot($review);
              $output[$content->id]['view_invoice'] = render($view_invoice);
              $output[$content->id]['review_output'] = render($review_output);
            }
            else {
              $review_output = '';
              $review_url = Url::fromRoute('hgv_jobs.job_review',
                [
                  'id' => $content->id,
                  'uid' => $content->job_author,
                  'nid' => $content->nid,
                ]);
              $review_url = Link::fromTextAndUrl(t('Write Review'), $review_url);
              $review = $review_url->toRenderable();
              $review['#attributes'] = ['class' => ['use-ajax', 'button']];
              $review_output = $this->render->renderRoot($review);
              // $output[$content->id]['view_invoice'] = ''; !
              $output[$content->id]['review_output'] = '';
            }
            if (!empty($content->driver_review)) {
              $review_form = '';
              $review_form = $this->formBuilder->getForm('\Drupal\hgv_jobs\Form\ReviewForm', $content->id, $content->nid);
              $output[$content->id]['review_form'] = render($review_form);
            }
            else {
              $output[$content->id]['review_form'] = '';
            }
            $output[$content->id]['view_invoice'] = render($view_invoice);
            $output[$content->id]['review_output'] = render($review_output);
            // $output[$content->id]['review_form'] = render($review_form); !
          }
          else {
            $output[$content->id]['view_invoice'] = '';
            $output[$content->id]['review_output'] = '';
            $output[$content->id]['review_form'] = '';
          }
          $output[$content->id]['title'] = $node->getTitle();
          $output[$content->id]['username'] = render($user_link);
          $output[$content->id]['amount'] = !empty($content->amount) ? $content->amount : '888';
          $output[$content->id]['status'] = $status;
          $output[$content->id]['action'] = render($action);
          $output[$content->id]['update_post'] = render($update_post);
          //$output[$content->id]['collect_job'] = render($collect_job);
          $output[$content->id]['message'] = render($message);
        }
        else {
          $view_invoice = '';
          $review_form = '';
          $review_output = '';

          $generated_url = Url::fromRoute('hgv_jobs.quote_status_update', [
            'id' => $content->id,
            'uid' => $content->uid,
            'status' => 1,
            'nid' => $content->nid,
          ]);
          $generated_url = Link::fromTextAndUrl(t('Accept'), $generated_url);
          $accept_btn = $generated_url->toRenderable();
          $accept_btn['#attributes'] = ['class' => ['btn btn-sm btn-success']];
          $action[] = $accept_btn;

          $generated_url1 = Url::fromRoute('hgv_jobs.quote_status_update',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 0,
              'nid' => $content->nid,
            ]);
          $generated_url1 = Link::fromTextAndUrl(t('Reject'), $generated_url1);
          $reject_btn = $generated_url1->toRenderable();
          $reject_btn['#attributes'] = ['class' => ['btn btn-sm btn-danger use-ajax reject']];

          $action[] = $reject_btn;
          $update_post_url1 = Url::fromRoute('hgv_jobs.update_post',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 2,
              'nid' => $content->nid,
            ]);

          $action_links = render($action);
          
          
          $output[$content->id]['title'] = $node->getTitle();
          $output[$content->id]['username'] = render($user_link);
          $output[$content->id]['amount'] = $content->amount;
          $output[$content->id]['status'] = $status;
          $output[$content->id]['action'] = $action_links;
          $output[$content->id]['update_post'] = '';
          $output[$content->id]['collect_job'] = '';
          $output[$content->id]['delivery_status'] = '';
          $output[$content->id]['view_invoice'] = '';
          $output[$content->id]['review_output'] = '';
          $output[$content->id]['review_form'] = '';
          $output[$content->id]['message'] = render($message);
        }
        $i++;
      }
    }
    if (empty($default) && isset($header['sort']) && ($header['sort'] == 'asc' || $header['sort'] == 'desc')) {
      $default = $header;
    }
    $url = Url::fromUri('internal:/node/add/post_ad');
    $link_options = array(
      'attributes' => array(
        'class' => array(
          'button',
        ),
      ),
    );
    $url->setOptions($link_options);
    $post_job = Link::fromTextAndUrl(t('Post Job'), $url)->toString();

    $form['table'] = array(
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => $output,
      '#multiple' => TRUE,
      '#empty' => t('No data availables'),
      '#prefix' => $post_job,
      '#attributes' => array('class' => array('table')),
    );
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Delete'),

    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $ids = $form_state->getValues()['table'];
    foreach ($ids as $id) {
      $job_deleted = $this->database->delete('my_jobs')
        ->condition('id', $id)
        ->execute();
    }
   /* $url = Url::fromRoute('hgv_jobs.my_jobs');
    $form_state->setRedirectUrl($url);*/
    $form_state->setRedirect('view.all_jobs.page_1');
    drupal_set_message($this->t('Job successfully deleted.'));
  }

}
