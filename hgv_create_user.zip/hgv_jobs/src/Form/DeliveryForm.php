<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Render\Renderer;

/**
 * DeliveryForm class.
 */
class DeliveryForm extends FormBase {

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $render;

  /**
   * {@inheritdoc}
   */
  public function __construct(Renderer $render) {
    $this->render = $render;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('renderer')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_delivery_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $route_match = \Drupal::service('current_route_match');
    $current_user = \Drupal::currentUser();
    $id = $route_match->getParameter('id');
    $nid = $route_match->getParameter('nid');
    $uid = $current_user->id();
    $output = get_delivery_status($id, $nid, $uid);
    $arrived_time = isset($output['arrived_time']) ? $output['arrived_time'] : '';
    $left_time = isset($output['left_time']) ? $output['left_time'] : '';
    $eta = isset($output['eta_to_delivery']) ? $output['eta_to_delivery'] : '';
    $eta = explode(':', $eta);
    $actual_time = isset($output['actual_delivery_time']) ? $output['actual_delivery_time'] : '';
    $actual_time = explode(':', $actual_time);
    $name_person_pod = isset($output['name_person_pod']) ? $output['name_person_pod'] : '';
    if (!empty($output['deliver_job_fid'])) {
          $file = File::load($output['deliver_job_fid']);
          if (!empty($file)) {
              $path = $file->url();
              $deliver_url = Url::fromUri($path);
              $deliver_url = Link::fromTextAndUrl(t('View Receipt'), $deliver_url);
              $deliver_url = $deliver_url->toRenderable();
              $deliver_url['#attributes'] = array('target' => array('_blank'),'class'=>array('btn btn-sm btn-primary'));
              $deliver_job = $this->render->renderRoot($deliver_url);
              $deliver_job = render($deliver_job);
          }
    }    
    $form['collection_point_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('Collection Point'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['collection_point_markup']['arrived_time_markup'] = [
      '#type' => 'textfield',
      '#title' => t('Arrived Time'),
      '#default_value' => $arrived_time,
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['collection_point_markup']['left_time_markup'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Left Time'),
      '#default_value' => $left_time,
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['delivery_eta_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('ETA to Delivery'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['delivery_eta_markup']['eta_h_markup'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#default_value' => $eta[0],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['delivery_eta_markup']['eta_m_markup'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $eta[1],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['actual_time_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('Actual Delivery Time'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['actual_time_markup']['actual_time_h_markup'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#default_value' => $actual_time[0],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['actual_time_markup']['actual_time_m_markup'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $actual_time[1],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['name_pod_markup'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name of Person(Signing the POD)'),
      '#default_value' => $name_person_pod,
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['deliver_receipt_markup'] = [
      '#markup' => $deliver_job,
    ];
    $form['#cache'] = ['max-age' => 0];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
