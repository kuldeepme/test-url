<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * DriverDeliveryForm class.
 */
class DriverDeliveryForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_driver_delivery_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $options = NULL) {
     
    $route_match = \Drupal::service('current_route_match');
    $current_user = \Drupal::currentUser();
    $status = $route_match->getParameter('status');
    $id = $route_match->getParameter('id');
    $nid = $route_match->getParameter('nid');
    $uid = $current_user->id();
    $output = get_driver_delivery_status($id, $nid, $uid);
    // $time = DrupalDateTime::createFromTimestamp(time());
    // if (!empty($output['arrived_time'])) {
    //   $arrived_time_str = strtotime($output['arrived_time']);
    //   $arrived_time = DrupalDateTime::createFromTimestamp($arrived_time_str);
    // }
    // else {
    //   $arrived_time = $time;
    // }
    // if (!empty($output['left_time'])) {
    //   $left_time_str = strtotime($output['left_time']);
    //   $left_time = DrupalDateTime::createFromTimestamp($left_time_str);
    // }
    // else {
    //   $left_time = $time;
    // }
    $eta = isset($output['eta_to_delivery']) ? $output['eta_to_delivery'] : '';
    $eta = explode(':', $eta);
    $actual_time = isset($output['actual_delivery_time']) ? $output['actual_delivery_time'] : '';
    $actual_time = explode(':', $actual_time);
    $name_person_pod = isset($output['name_person_pod']) ? $output['name_person_pod'] : '';
    $deliver_job_fid = isset($output['deliver_job_fid']) ? [$output['deliver_job_fid']] : [];
    $node = Node::load($nid);
    $title = $node->getTitle();
    $author = $node->getOwnerId();
    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();
    $form['#prefix'] = '<div id="driver_delivery_form">';
    $form['#suffix'] = '</div>';

    // The status messages that will contain any form errors.
    $form['status_messages'] = [
      '#type' => 'status_messages',
      '#weight' => -10,
    ];
    $form['nid'] = [
      '#type' => 'hidden',
      '#default_value' => $nid,
    ];
    $form['id'] = [
      '#type' => 'hidden',
      '#default_value' => $id,
    ];
    $form['uid'] = [
      '#type' => 'hidden',
      '#default_value' => $uid,
    ];
    $form['author'] = [
      '#type' => 'hidden',
      '#default_value' => $author,
    ];
    
    // $form['collection_point'] = [
    //   '#type' => 'fieldset',
    //   '#title' => t('Collection Point'),
    //   '#collapsible' => TRUE,
    //   '#collapsed' => FALSE,
    // ];
    // $form['collection_point']['arrived_time'] = [
    //   '#type' => 'datetime',
    //   '#title' => t('Arrived Time'),
    //   '#required' => TRUE,
    //   '#default_value' => $arrived_time,
    // ];
    // $form['collection_point']['left_time'] = [
    //   '#type' => 'datetime',
    //   '#title' => $this->t('Left Time'),
    //   '#size' => 20,
    //   '#required' => TRUE,
    //   '#date_date_element' => 'none',
    //   '#date_time_element' => 'time',
    //   '#default_value' => $left_time,
    // ];
    // $form['delivery_eta'] = [
    //   '#type' => 'fieldset',
    //   '#title' => t('ETA to Delivery'),
    //   '#collapsible' => TRUE,
    //   '#collapsed' => FALSE,
    // ];
    // $form['delivery_eta']['eta_h'] = [
    //   '#title' => $this->t('Hour'),
    //   '#type' => 'number',
    //   '#required' => TRUE,
    //   '#default_value' => $eta[0],
    //   '#min' => 0,
    // ];
    // $form['delivery_eta']['eta_m'] = [
    //   '#title' => $this->t('Minute'),
    //   '#type' => 'number',
    //   '#default_value' => $eta[1],
    //   '#min' => 0,
    // ];
    $form['actual_time'] = [
      '#type' => 'fieldset',
      '#title' => t('Actual Delivery Time'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['actual_time']['actual_time_h'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#required' => TRUE,
      '#default_value' => $actual_time[0],
      '#min' => 0,
    ];
    $form['actual_time']['actual_time_m'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $actual_time[1],
      '#min' => 0,
    ];
    $form['name_pod'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name of Person(Signing the POD)'),
      '#size' => 60,
      '#maxlength' => 128,
      '#default_value' => $name_person_pod,
      '#required' => TRUE,
    ];
    $form['collect_job'] = [
      '#type' => 'managed_file',
      '#description' => $this->t('Upload doc should be JPEG, PNG or PDF format'),
      '#title' => $this->t('Upload'),
      '#upload_location' => 'public://collect_job',
      '#upload_validators' => [
        'file_validate_extensions' => ['jpg jpeg png pdf'],
      ],
      '#required' => TRUE,
      '#default_value' => $deliver_job_fid,
    ];
    $form['#cache'] = ['max-age' => 0];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#ajax' => [
        'callback' => [$this, 'submitDriverDeliveryFormAjax'],
        'event' => 'click',
      ],
    ];

    return $form;
  }

  /**
   * AJAX callback handler that displays any errors or a success message.
   */
  public function submitDriverDeliveryFormAjax(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    // If there are any form errors, re-display the form.
    if ($form_state->hasAnyErrors()) {
      $response->addCommand(new ReplaceCommand('#driver_delivery_form', $form));
    }
    else {
      //$response->addCommand(new RedirectCommand(Url::fromRoute('hgv_jobs.my_jobs')->toString()));
      $response->addCommand(new RedirectCommand(Url::fromRoute('view.all_jobs.page_1')->toString()));
    }
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $eta_time = '';
    $actual_time = '';
    $nid = $form_state->getValue('nid');
    $uid = $form_state->getValue('uid');
    $id = $form_state->getValue('id');
    $author = $form_state->getValue('author');
    $collect_fid = $form_state->getValue('collect_job');
    if (isset($collect_fid[0]) && !empty($collect_fid[0])) {
      $file = File::load($collect_fid[0]);
      $file->setPermanent();
      $file->save();
      $collect_fid = $collect_fid[0];
    }
    
    //$arrived_time = $form_state->getValue('arrived_time')->format("Y-m-d H:i:s A");
   // $left_time = $form_state->getValue('left_time')->format("H:i A");
    //$eta_h = $form_state->getValue('eta_h');
   // $eta_m = $form_state->getValue('eta_m');
   // if (!empty($eta_m)) {
    //  $eta_time = $eta_h . ':' . $eta_m;
   // }
   // else {
    //  $eta_time = $eta_h . ': 0';
   // }
   
    $actual_time_h = $form_state->getValue('actual_time_h');
    $actual_time_m = $form_state->getValue('actual_time_m');
    if (!empty($actual_time_m)) {
      $actual_time = $actual_time_h . ':' . $actual_time_m;
    }
    else {
      $actual_time = $actual_time_h . ': 0';
    }
    $name_pod = $form_state->getValue('name_pod');
    //$output = update_deliver_status($id, $nid, $uid, $author, $arrived_time, $left_time, $eta_time, $actual_time, $name_pod);
    
    $output = update_deliver_status($id, $nid, $uid, $author, $actual_time, $name_pod, $collect_fid);
    
    if ($output) {
      /*$url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Delivery information saved successfully!'));
    }
    else {
      /*$url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Try again!'));
    }
  }

}
