<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\Core\Ajax\RedirectCommand;

/**
 * ModalForm class.
 */
class QuoteForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_quote_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $options = NULL) {
    $route_match = \Drupal::service('current_route_match');
    $nid = $route_match->getParameter('nid');
    $node = Node::load($nid);
    $title = $node->getTitle();
    $author = $node->getOwnerId();
    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();

    $form['#prefix'] = '<div id="quote_form">';
    $form['#suffix'] = '</div>';

    // The status messages that will contain any form errors.
    $form['status_messages'] = [
      '#type' => 'status_messages',
      '#weight' => -10,
    ];
    $form['amount'] = [
      '#type' => 'number',
      '#title' => $this->t('Amount'),
      '#description' => $this->t('Enter quote amount'),
      '#required' => TRUE,
    ];
    $form['title'] = [
      '#type' => 'hidden',
      '#default_value' => $title,
    ];
    $form['id'] = [
      '#type' => 'hidden',
      '#default_value' => $nid,
    ];
    $form['uid'] = [
      '#type' => 'hidden',
      '#default_value' => $uid,
    ];
    $form['author'] = [
      '#type' => 'hidden',
      '#default_value' => $author,
    ];
    $form['#cache'] = ['max-age' => 0];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#ajax' => [
        'callback' => [$this, 'submitQuoteFormAjax'],
        'event' => 'click',
      ],
    ];

    return $form;
  }

  /**
   * AJAX callback handler that displays any errors or a success message.
   */
  public function submitQuoteFormAjax(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();

    // If there are any form errors, re-display the form.
    if ($form_state->hasAnyErrors()) {
      $response->addCommand(new ReplaceCommand('#quote_form', $form));
    }
    else {
      //$response->addCommand(new RedirectCommand(Url::fromUserInput('/all-jobs')->toString()));
      $response->addCommand(new RedirectCommand(Url::fromRoute('view.all_jobs.page_1')->toString()));
    }
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $uid = $form_state->getValue('uid');
    $nid = $form_state->getValue('id');
    $quotes_count = get_jobs_quote_count($nid, $uid);
    if ($quotes_count > 2) {
      $form_state->setErrorByName('amount', t("You can't submit Quote for this job more than three times."));
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $amount = $form_state->getValue('amount');
    $title = $form_state->getValue('title');
    $nid = $form_state->getValue('id');
    $uid = $form_state->getValue('uid');
    $user_data = get_user_data($uid);
    $driver_name = $user_data[0]->name;
    $author = $form_state->getValue('author');
    $author_data = get_user_data($author);
    $author_email = $author_data[0]->mail;
    $output = insert_data_to_myjobs($nid, $uid, $amount, $title, $author);
    if ($output) {
      $url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);
      $author_mail = $value->email;
      $body = '';
      $body .= t('@driver (Driver) submit a quotes for this job @title .', array('@title' => $title, '@driver' => $driver_name));
      $mailManager = \Drupal::service('plugin.manager.mail');
      $module = 'hgv_jobs';
      $key = 'hgv_jobs_send_mail';
      $to = $author_email;
      $params['message'] = $body;
      $params['title'] = 'Submit a Quotes from ' . $driver_name;
      $langcode = \Drupal::currentUser()->getPreferredLangcode();
      $send = TRUE;
      $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
      drupal_set_message($this->t('Successfully submitted quote'));
    }
  }

}
