<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Url;
use Drupal\Core\Ajax\RedirectCommand;

/**
 * DriverJobReviewForm class.
 */
class DriverJobReviewForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_driver_job_review_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $options = NULL, array $context = []) {
    $route_match = \Drupal::service('current_route_match');
    $id = $route_match->getParameter('id');
    $nid = $route_match->getParameter('nid');
    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();
    $output = get_review($id, $nid, $uid);
    $driver_rating = isset($output['driver_rating']) ? $output['driver_rating'] : 1;
    $driver_review = isset($output['driver_review']) ? $output['driver_review'] : '';
    $form['#prefix'] = '<div id="driver_job_review_form">';
    $form['#suffix'] = '</div>';
    $form['status_messages'] = [
      '#type' => 'status_messages',
      '#weight' => -10,
    ];
    $form['job_id'] = [
      '#type' => 'hidden',
      '#default_value' => $id,
    ];
    $form['uid'] = [
      '#type' => 'hidden',
      '#default_value' => $uid,
    ];
    $form['nid'] = [
      '#type' => 'hidden',
      '#default_value' => $nid,
    ];
    $select = [
      '#type' => 'select',
      '#options' => [
        1 => t('Poor'),
        2 => t('Not so poor'),
        3 => t('Average'),
        4 => t('Good'),
        5 => t('very good'),
      ],
      '#default_value' => $driver_rating,
    ];
    $form['driver_rating'] = [
      '#type' => 'fivestar',
      '#attributes' => [
        'class' => ['vote'],
      ],
      'value' => $select,
      '#default_value' => $driver_rating,
    ];
    $form['driver_review'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Write review for dispatcher'),
      '#required' => TRUE,
      '#default_value' => $driver_review,
    ];
    $form['#cache'] = ['max-age' => 0];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];
    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#ajax' => [
        'callback' => [$this, 'submitDriverJobReviewFormAjax'],
        'event' => 'click',
      ],
    ];
    return $form;
  }

  /**
   * AJAX callback handler that displays any errors or a success message.
   */
  public function submitDriverJobReviewFormAjax(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();

    // If there are any form errors, re-display the form.
    if ($form_state->hasAnyErrors()) {
      $response->addCommand(new ReplaceCommand('#driver_job_review_form', $form));
    }
    else {
      //$response->addCommand(new RedirectCommand(Url::fromRoute('hgv_jobs.my_jobs')->toString()));
      $response->addCommand(new RedirectCommand(Url::fromRoute('view.all_jobs.page_1')->toString()));
    }
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $job_id = $form_state->getValue('job_id');
    $nid = $form_state->getValue('nid');
    $uid = $form_state->getValue('uid');
    $rating = $form_state->getValue('value');
    $review = $form_state->getValue('driver_review');
    $output = driver_review($job_id, $nid, $uid, $rating, $review);
    if ($output) {
      /*$url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Review added succefully!'));
    }
    else {
      /*$url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Something went wrong try again!'), $type = 'error');
    }
  }

}
