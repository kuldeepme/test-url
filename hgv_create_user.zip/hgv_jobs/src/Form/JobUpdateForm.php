<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Url;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\node\Entity\Node;

/**
 * JobUpdateForm class.
 */
class JobUpdateForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_job_update_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $route_match = \Drupal::service('current_route_match');
    $id = $route_match->getParameter('id');
    $uid = $route_match->getParameter('uid');
    $nid = $route_match->getParameter('nid');
    $options = [];
    $form['#prefix'] = '<div id="job_update_form">';
    $form['#suffix'] = '</div>';

    // The status messages that will contain any form errors.
    $form['status_messages'] = [
      '#type' => 'status_messages',
      '#weight' => -10,
    ];
    $form['id'] = [
      '#type' => 'hidden',
      '#default_value' => $id,
    ];
    $form['nid'] = [
      '#type' => 'hidden',
      '#default_value' => $nid,
    ];
    $form['uid'] = [
      '#type' => 'hidden',
      '#default_value' => $uid,
    ];
    $options["2"] = "Yes";
    $options["1"] = "No";
    $form['dispute'] = [
      '#title' => t('Do you want to "Dispute" this Job ?'),
      '#type' => 'radios',
      '#options' => $options,
      '#required' => TRUE,
    ];
    $form['#cache'] = ['max-age' => 0];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#ajax' => [
        'callback' => [$this, 'jobUpdateFormAjax'],
        'event' => 'click',
      ],
    ];

    return $form;
  }

  /**
   * AJAX callback handler that displays any errors or a success message.
   */
  public function jobUpdateFormAjax(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();

    // If there are any form errors, re-display the form.
    if ($form_state->hasAnyErrors()) {
      $response->addCommand(new ReplaceCommand('#job_update_form', $form));
    }
    else {
      //$response->addCommand(new RedirectCommand(Url::fromRoute('hgv_jobs.my_jobs')->toString()));
        $response->addCommand(new RedirectCommand(Url::fromRoute('view.all_jobs.page_1')->toString()));
    }     
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $id = $form_state->getValue('id');
    $uid = $form_state->getValue('uid');
    $nid = $form_state->getValue('nid');
    $dispute = $form_state->getValue('dispute');
    $result = update_dispute_jobs_status($id, $uid, $dispute);
    $url = Url::fromRoute('hgv_jobs.my_jobs');    
    if ($result) {
      $node = Node::load($nid);
      $node->set('field_status', ['Under-Dispute']);
      $node->save();
      //$form_state->setRedirectUrl($url);
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message(t('Successfully update job status!'), 'status', TRUE);
    }
    else {
      //$form_state->setRedirectUrl($url);
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message(t('Something went wrong, please try again!'), 'error', TRUE);
    }
    return $response;
  }

}
