<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Render\Renderer;

/**
 * DispatcherCollectJobForm class.
 */
class DispatcherCollectJobForm extends FormBase {

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $render;

  /**
   * {@inheritdoc}
   */
  public function __construct(Renderer $render) {
    $this->render = $render;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('renderer')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_dispatcher_collect_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $route_match = \Drupal::service('current_route_match');
    $current_user = \Drupal::currentUser();
    $id = $route_match->getParameter('id');
    $nid = $route_match->getParameter('nid');
    $uid = $current_user->id();
    $output = get_delivery_status($id, $nid, $uid);
    $arrived_time = isset($output['arrived_time']) ? $output['arrived_time'] : '';
    $left_time = isset($output['left_time']) ? $output['left_time'] : '';
    $eta = isset($output['eta_to_delivery']) ? $output['eta_to_delivery'] : '';
    $eta = explode(':', $eta);
    $actual_time = isset($output['actual_delivery_time']) ? $output['actual_delivery_time'] : '';
    $actual_time = explode(':', $actual_time);
    $name_person_pod = isset($output['name_person_pod']) ? $output['name_person_pod'] : '';
    if (!empty($output['collected_job_fid'])) {
          $file = File::load($output['collected_job_fid']);
          if (!empty($file)) {
              $path = $file->url();
              $collected_url = Url::fromUri($path);
              $collected_url = Link::fromTextAndUrl(t('View Receipt'), $collected_url);
              $collected_url = $collected_url->toRenderable();
              $collected_url['#attributes'] = array('target' => array('_blank'),'class'=>array('btn btn-sm btn-primary'));
              $collect_job = $this->render->renderRoot($collected_url);
              $collect_job = render($collect_job);
          }
    }
    $form['collection_point_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('Collection Point'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['collection_point_markup']['arrived_time_markup'] = [
      '#type' => 'textfield',
      '#title' => t('Arrived Time'),
      '#default_value' => $arrived_time,
      '#attributes' => ['readonly' => 'readonly'],
    ];
/*    $form['collection_point_markup']['left_time_markup'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Left Time'),
      '#default_value' => $left_time,
      '#attributes' => ['readonly' => 'readonly'],
    ];*/
    $form['delivery_eta_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('ETA to Delivery'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['delivery_eta_markup']['eta_h_markup'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#default_value' => $eta[0],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['delivery_eta_markup']['eta_m_markup'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $eta[1],
      '#attributes' => ['readonly' => 'readonly'],
    ];
 /*   $form['actual_time_markup'] = [
      '#type' => 'fieldset',
      '#title' => t('Actual Delivery Time'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['actual_time_markup']['actual_time_h_markup'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#default_value' => $actual_time[0],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['actual_time_markup']['actual_time_m_markup'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $actual_time[1],
      '#attributes' => ['readonly' => 'readonly'],
    ];
    $form['name_pod_markup'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name of Person(Signing the POD)'),
      '#default_value' => $name_person_pod,
      '#attributes' => ['readonly' => 'readonly'],
    ];*/
    $form['collect_receipt_markup'] = [
      '#markup' => $collect_job,
    ];    
    $form['#cache'] = ['max-age' => 0];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
