<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Connection;
use Drupal\node\Entity\Node;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Render\Renderer;
use Drupal\Core\Form\FormBuilder;

/**
 * DispatcherMyJobsForm class.
 */
class DispatcherMyJobsForm extends FormBase {
  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * The database service.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $render;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user, Connection $connection, Renderer $render, FormBuilder $formBuilder) {
    $this->user = $user;
    $this->database = $connection;
    $this->render = $render;
    $this->formBuilder = $formBuilder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('database'),
      $container->get('renderer'),
      $container->get('form_builder')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_dispatcher_myjobs_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $output = [];
    $result = '';
    $uid = $this->user->id();

    $result = $this->database->select('my_jobs', 'd')
      ->distinct('d.nid')
      ->fields('d')
      ->condition('job_author', $uid)
      ->execute()
      ->fetchAll();

    if (!empty($result)) {
      $i = 0;
      foreach ($result as $row => $content) {
        $node = Node::load($content->nid);
        $mesaage_id = $content->nid;
        global $base_url;
        $message_link = $base_url . '/job/' . $mesaage_id . '/message';
        $options['attributes']['class'] = array('btn', 'btn-lg', 'btn-primary', 'job-messages');

        $message = Link::fromTextAndUrl('Message', Url::fromUri($message_link, $options))->toString();

        if ($content->status == 1) {
          $status = 'In-Progress';
        }
        elseif ($content->status == 2) {
          $status = 'Under-Dispute';
        }
        else {
          $status = 'Pending';
        }
        if ($status == "In-Progress" && $content->job_author == $uid) {
          $generated_url = Url::fromRoute('hgv_jobs.quote_status_update',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 0,
              'nid' => $content->nid,
            ]);
          $generated_url = Link::fromTextAndUrl(t('Reject'), $generated_url);
          $action = $generated_url->toRenderable();
          $action['#attributes'] = ['class' => ['use-ajax btn btn-sm btn-danger']];
          $update_post_url = Url::fromRoute('hgv_jobs.update_post',
            [
              'id' => $content->id,
              'uid' => $content->uid,
              'status' => 2,
              'nid' => $content->nid,
            ]);
          $update_post_url = Link::fromTextAndUrl(t('Status'), $update_post_url);
          $update_post = $update_post_url->toRenderable();
          $update_post['#attributes'] = ['class' => ['use-ajax', 'button']];
          if (!empty($content->arrived_time)) {
            $collect_job = '';
            $collect_status_url = Url::fromRoute('hgv_jobs.dispatcher_collect_job',
              [
                'id' => $content->id,
                'uid' => $content->job_author,
                'nid' => $content->nid,
              ]);
            $collect_status_url = Link::fromTextAndUrl(t('Collect Job'), $collect_status_url);
            $collect = $collect_status_url->toRenderable();
            $collect['#attributes'] = ['class' => ['use-ajax']];
            $collect_output = $this->render->renderRoot($collect);
            $output[$content->id]['collect_job'] = render($collect_output);
          }
          else {
            $output[$content->id]['collect_job'] = '';
          }         
          if (!empty($content->name_person_pod)) {
            $delivery_status = '';
            $delivery_status_url = Url::fromRoute('hgv_jobs.delivery_status',
              [
                'id' => $content->id,
                'uid' => $content->job_author,
                'nid' => $content->nid,
              ]);
            $delivery_status_url = Link::fromTextAndUrl(t('Delivery Status'), $delivery_status_url);
            $delivery = $delivery_status_url->toRenderable();
            $delivery['#attributes'] = ['class' => ['use-ajax']];
            $delivery_output = $this->render->renderRoot($delivery);
            $output[$content->id]['delivery_status'] = render($delivery_output);
          }
          else {
            $output[$content->id]['delivery_status'] = '';
          }
          if (!empty($content->invoice_job_fid)) {
            $status = 'Completed';
            $file = File::load($content->invoice_job_fid);
            $path = $file->url();
            $view_invoice = Url::fromUri($path);
            $view_invoice = Link::fromTextAndUrl(t('View Invoice'), $view_invoice);
            $view_invoice = $view_invoice->toRenderable();
            $view_invoice['#attributes'] = array('target' => array('_blank'));
            if (!empty($content->review)) {
              $review_output = '';
              $review_url = Url::fromRoute('hgv_jobs.job_review',
                [
                  'id' => $content->id,
                  'uid' => $content->job_author,
                  'nid' => $content->nid,
                ]);
              $review_url = Link::fromTextAndUrl(t('Update Review'), $review_url);
              $review = $review_url->toRenderable();
              $review['#attributes'] = ['class' => ['use-ajax', 'button']];
              $review_output = $this->render->renderRoot($review);
              $output[$content->id]['view_invoice'] = render($view_invoice);
              $output[$content->id]['review_output'] = render($review_output);
            }
            else {
              $review_output = '';
              $review_url = Url::fromRoute('hgv_jobs.job_review',
                [
                  'id' => $content->id,
                  'uid' => $content->job_author,
                  'nid' => $content->nid,
                ]);
              $review_url = Link::fromTextAndUrl(t('Write Review'), $review_url);
              $review = $review_url->toRenderable();
              $review['#attributes'] = ['class' => ['use-ajax', 'button']];
              $review_output = $this->render->renderRoot($review);
              // $output[$content->id]['view_invoice'] = ''; !
              $output[$content->id]['review_output'] = '';
            }
            if (!empty($content->driver_review)) {
              $review_form = '';
              $review_form = $this->formBuilder->getForm('\Drupal\hgv_jobs\Form\ReviewForm', $content->id, $content->nid);
              $output[$content->id]['review_form'] = render($review_form);
            }
            else {
              $output[$content->id]['review_form'] = '';
            }
            $output[$content->id]['view_invoice'] = render($view_invoice);
            $output[$content->id]['review_output'] = render($review_output);
            // $output[$content->id]['review_form'] = render($review_form); !
          }
          else {
            $output[$content->id]['view_invoice'] = '';
            $output[$content->id]['review_output'] = '';
            $output[$content->id]['review_form'] = '';
          }

          $myjob_url = Url::fromRoute('hgv_jobs.formAllQuote', [
            'jobid' => $content->nid,
          ]);
          $myjob_url = Link::fromTextAndUrl($node->getTitle(), $myjob_url);
          $myjob_action = $myjob_url->toRenderable();
          $output[$content->id]['title'] = render($myjob_action);
          $output[$content->id]['amount'] = $content->amount;
          $output[$content->id]['status'] = $status;
          $output[$content->id]['action'] = render($action);
          $output[$content->id]['update_post'] = render($update_post);
          $output[$content->id]['message'] = render($message);
        }
        else {
          $view_invoice = '';
          $review_form = '';
          $review_output = '';

          $generated_url = Url::fromRoute('hgv_jobs.quote_status_update', [
            'id' => $content->id,
            'uid' => $content->uid,
            'status' => 1,
            'nid' => $content->nid,
          ]);
          $generated_url = Link::fromTextAndUrl(t('Accept'), $generated_url);
          $action = $generated_url->toRenderable();
          $action['#attributes'] = ['class' => ['use-ajax btn btn-sm btn-success']];    
          $myjob_url = Url::fromRoute('hgv_jobs.formAllQuote', [
            'jobid' => $content->nid,
          ]);
          $myjob_url = Link::fromTextAndUrl($node->getTitle(), $myjob_url);
          $myjob_action = $myjob_url->toRenderable();

          $output[$content->id]['title'] = render($myjob_action);
          $output[$content->id]['amount'] = $content->amount;
          $output[$content->id]['status'] = $status;
          $output[$content->id]['action'] = render($action);
          $output[$content->id]['update_post'] = '';
          $output[$content->id]['collect_job'] = '';
          $output[$content->id]['delivery_status'] = '';
          $output[$content->id]['view_invoice'] = '';
          $output[$content->id]['review_output'] = '';
          $output[$content->id]['review_form'] = '';
          $output[$content->id]['message'] = render($message);
        }
        $i++;
      }
    }
    $header = array(
      'title' => t('Job'),
      'amount' => t('Quote Amount'),
      'status' => t('Status'),
      'action' => t('Action'),
      'update_post' => t('Update Post'),
      'collect_job' => t('Collect Job'),
      'delivery_status' => t('Delivery Status'),
      'view_invoice' => t('View Invoice'),
      'review_output' => t('Review'),
      'review_form' => t('Rate By Driver'),
      'message' => t('Message'),
    );
    $url = Url::fromUri('internal:/node/add/post_ad');
    $link_options = array(
      'attributes' => array(
        'class' => array(
          'button',
        ),
      ),
    );
    $url->setOptions($link_options);
    $post_job = Link::fromTextAndUrl(t('Post Job'), $url)->toString();

    $form['table'] = array(
      '#type' => 'tableselect',
      '#header' => $header,
      '#options' => $output,
      '#multiple' => TRUE,
      '#empty' => t('No data availables'),
      '#prefix' => $post_job,
      '#attributes' => array('class' => array('table')),
    );
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Submit'),

    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $ids = $form_state->getValues()['table'];
    foreach ($ids as $id) {
      $job_deleted = $this->database->delete('my_jobs')
        ->condition('id', $id)
        ->execute();
    }
/*    $url = Url::fromRoute('hgv_jobs.my_jobs');
    $form_state->setRedirectUrl($url);*/
    $form_state->setRedirect('view.all_jobs.page_1');
    drupal_set_message($this->t('Job successfully deleted.'));
  }

}
