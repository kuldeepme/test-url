<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * ReviewForm class.
 */
class StarRatingForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_star_rating_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $uid = NULL ,$rating = NULL) {
      
    $rating = !empty($rating) ? $rating : 1;
    
    $select = [
      '#type' => 'select',
      '#options' => [
        1 => t('Poor'),
        2 => t('Not so poor'),
        3 => t('Average'),
        4 => t('Good'),
        5 => t('very good'),
      ],
      '#default_value' => $rating,
    ];
    $form['rating'] = [
      '#type' => 'fivestar',
      '#attributes' => [
        'class' => ['vote'],
      ],
      'value' =>$select,
      '#default_value' => $rating,
    ];
    $form['#cache'] = ['max-age' => 0];
 
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
