<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Component\Datetime\DateTimePlus;
 
/**
 * CollectJobForm class.
 */
class CollectJobForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_collect_job_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $options = NULL) {
    $route_match = \Drupal::service('current_route_match');
    $status = $route_match->getParameter('status');
    $nid = $route_match->getParameter('nid');
    $id = $route_match->getParameter('id');
    $node = Node::load($nid);
    $title = $node->getTitle();
    $author = $node->getOwnerId();
    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();
    $output = get_driver_delivery_status($id, $nid, $uid);
    //$arrived_time = isset($output['arrived_time']) ? $output['arrived_time'] : new DrupalDateTime('now');
    $collect_job_fid = isset($output['collected_job_fid']) ? [$output['collected_job_fid']] : [];
    $eta = isset($output['eta_to_delivery']) ? $output['eta_to_delivery'] : '';
    $eta = explode(':', $eta);    
    $form['#prefix'] = '<div id="collect_job_form">';
    $form['#suffix'] = '</div>';

    // The status messages that will contain any form errors.
    $form['status_messages'] = [
      '#type' => 'status_messages',
      '#weight' => -10,
    ];
    
    $form['collection_point'] = [
      '#type' => 'fieldset',
      '#title' => t('Collection Point'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['collection_point']['arrived_time'] = [
      '#type' => 'datetime',
      '#title' => t('Arrived Time'),
      '#required' => TRUE,
      //'#default_value' => new DrupalDateTime('now'),
      '#default_value' => !empty($output['arrived_time']) ? new DrupalDateTime($output['arrived_time'], 'Europe/London') : new DrupalDateTime('now'),
     // '#date_date_element' => 'date',
    ];
    // $form['collection_point']['left_time'] = [
    //   '#type' => 'datetime',
    //   '#title' => $this->t('Left Time'),
    //   '#size' => 20,
    //   '#required' => TRUE,
  
      //   '#date_time_element' => 'time',
    //   '#default_value' => $left_time,
    // ];
    $form['delivery_eta'] = [
      '#type' => 'fieldset',
      '#title' => t('ETA to Delivery'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['delivery_eta']['eta_h'] = [
      '#title' => $this->t('Hour'),
      '#type' => 'number',
      '#required' => TRUE,
      '#default_value' => $eta[0],
      '#min' => 0,
    ];
    $form['delivery_eta']['eta_m'] = [
      '#title' => $this->t('Minute'),
      '#type' => 'number',
      '#default_value' => $eta[1],
      '#min' => 0,
    ];
    
    
    $form['collect_job'] = [
      '#type' => 'managed_file',
      '#description' => $this->t('Upload doc should be JPEG, PNG or PDF format'),
      '#title' => $this->t('Upload'),
      '#upload_location' => 'public://collect_job',
      '#upload_validators' => [
        'file_validate_extensions' => ['jpg jpeg png pdf'],
      ],
      '#default_value' => $collect_job_fid,
    ];
    $form['title'] = [
      '#type' => 'hidden',
      '#default_value' => $title,
    ];
    $form['nid'] = [
      '#type' => 'hidden',
      '#default_value' => $nid,
    ];
    $form['id'] = [
      '#type' => 'hidden',
      '#default_value' => $id,
    ];
    $form['uid'] = [
      '#type' => 'hidden',
      '#default_value' => $uid,
    ];
    $form['author'] = [
      '#type' => 'hidden',
      '#default_value' => $author,
    ];
    $form['status'] = [
      '#type' => 'hidden',
      '#default_value' => $status,
    ];
    $form['#cache'] = ['max-age' => 0];
    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#ajax' => [
        'callback' => [$this, 'submitCollectJobFormAjax'],
        'event' => 'click',
      ],
    ];

    return $form;
  }

  /**
   * AJAX callback handler that displays any errors or a success message.
   */
  public function submitCollectJobFormAjax(array $form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    // If there are any form errors, re-display the form.
    if ($form_state->hasAnyErrors()) {
      $response->addCommand(new ReplaceCommand('#collect_job_form', $form));
    }
    else {
      //$response->addCommand(new RedirectCommand(Url::fromRoute('hgv_jobs.my_jobs')->toString()));
      $response->addCommand(new RedirectCommand(Url::fromRoute('view.all_jobs.page_1')->toString()));
    }
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $collect_fid = $form_state->getValue('collect_job');
    $title = $form_state->getValue('title');
    $status = $form_state->getValue('status');
    $nid = $form_state->getValue('nid');
    $id = $form_state->getValue('id');
    $uid = $form_state->getValue('uid');
    $author = $form_state->getValue('author');
    if (isset($collect_fid[0]) && !empty($collect_fid[0])) {
      $file = File::load($collect_fid[0]);
      $file->setPermanent();
      $file->save();
      $collect_fid = $collect_fid[0];
    } 
    
    /*
    $arrived_time = $form_state->getValue('arrived_time')->__toString();
    $arrived_time = DrupalDateTime::createFromFormat('Y-m-d H:i:s A', $arrived_time);
    $left_time = $form_state->getValue('left_time')->__toString();
     $left_time = DrupalDateTime::createFromFormat('H:i A', $left_time);
    */
    
      if($form_state->getValue('arrived_time')){
        //$arrived_time = $form_state->getValue('arrived_time')->format("Y-m-d H:i:s A");
        $arrived_time = $form_state->getValue('arrived_time');
        $arrived_time = date("Y-m-d H:i:s A", strtotime($arrived_time));
    } 
    
    $left_time = $form_state->getValue('left_time');
    $left_time = date("H:i A", strtotime($left_time));
    
    
    $eta_h = $form_state->getValue('eta_h');
    $eta_m = $form_state->getValue('eta_m');
    if (!empty($eta_m)) {
     $eta_time = $eta_h . ':' . $eta_m;
    }
    else {
     $eta_time = $eta_h . ': 0';
    }
    
    $output = update_job_status($id, $nid, $uid, $author, $collect_fid, $status, $arrived_time, $left_time, $eta_time);
    if ($output) {
/*      $url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('File uploaded successfully!'));
    }
    else {
/*      $url = Url::fromRoute('hgv_jobs.my_jobs');
      $form_state->setRedirectUrl($url);*/
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Try again!'));
    }
  }

}
