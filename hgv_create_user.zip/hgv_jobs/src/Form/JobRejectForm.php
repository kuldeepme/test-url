<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Defines a confirmation form to confirm deletion of something by id.
 */
class JobRejectForm extends ConfirmFormBase {

  /**
   * ID of the item to delete.
   *
   * @var int
   */
  protected $id;

  /**
   * USER of the item to delete.
   *
   * @var int
   */
  protected $user;

  /**
   * {@inheritdoc}
   */
  public function getFormId() : string {
    return "hgv_job_reject_form";
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, string $id = NULL, $user = NULL) {
    $this->id = $id;
    $this->user = $user;
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // @todo: Do the deletion.
    $connection = \Drupal::database();
    $job_deleted = $connection->delete('my_jobs')
      ->condition('id', $this->id)
      ->condition('job_author', $this->user->id())
      ->execute();
    if ($job_deleted) {
      //$url = Url::fromRoute('hgv_jobs.my_jobs');
      //$form_state->setRedirectUrl($url);
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Job rejected successfully!'));
    }
    else {
      //$url = Url::fromRoute('hgv_jobs.my_jobs');
      //$form_state->setRedirectUrl($url);
      $form_state->setRedirect('view.all_jobs.page_1');
      drupal_set_message($this->t('Something went wrong try again!'), $type = 'error');
    }
  }

  /**
   * {@inheritdoc}
   */
  public function getDescription() {
    return $this->t('Do you want to reject this job!');
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText() {
    return $this->t('Yes');
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {

  }

  /**
   * {@inheritdoc}
   */
  public function getQuestion() {

  }

}
