<?php

namespace Drupal\hgv_jobs\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * ReviewForm class.
 */
class ReviewForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hgv_review_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $id = NULL, $nid = NULL) {
    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();
    $output = get_review($id, $nid, $uid);
    $rating = isset($output['driver_rating']) ? $output['driver_rating'] : 1;
    $review = isset($output['driver_review']) ? $output['driver_review'] : '';
    $select = [
      '#type' => 'select',
      '#options' => [
        1 => t('Poor'),
        2 => t('Not so poor'),
        3 => t('Average'),
        4 => t('Good'),
        5 => t('very good'),
      ],
      '#default_value' => $rating,
    ];
    $form['job_rating'] = [
      '#type' => 'fivestar',
      '#attributes' => [
        'class' => ['vote'],
      ],
      'value' => $select,
      '#default_value' => $rating,
    ];
    $form['review_markup'] = [
      '#markup' => $review,
    ];
    $form['#cache'] = ['max-age' => 0];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
