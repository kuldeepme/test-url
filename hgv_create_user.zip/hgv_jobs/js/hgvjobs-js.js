/**
 * @file
 * Js for park map block.
 */

(function($) {
  'use strict';
  Drupal.behaviors.hgvJobs = {
    attach: function(context, setting) {
      $( document ).ajaxComplete(function() {
         $('.ui-dialog .ui-dialog-titlebar .ui-dialog-titlebar-close').html('X');
      });
     /* $('select#edit-field-vehicle-required').on('change', function() {
        $.ajax({
        type: 'POST',
        url: Drupal.url('get-distance'),
        data: {vid: this.val},
        success: function(res) {
          alert(res);
        },
        error: function(jqXHR, textStatus, errorThrown) {
        alert(errorThrown);
        }
        });
      });*/
    }
  };
})(jQuery);
