<?php
namespace Drupal\rolechange\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Defines RoleChangeController class.
 */
class RoleChangeController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }

}