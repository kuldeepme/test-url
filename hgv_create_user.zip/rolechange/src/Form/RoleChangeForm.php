<?php
/**
 * @file
 * Contains \Drupal\rolechange\Form\ContributeForm.
 */
namespace Drupal\rolechange\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\user\Entity\User;


class RoleChangeForm extends FormBase {

private $selected_role;
/**
 * {@inheritdoc}
 */
public function getFormId() {
return 'rolechange_form';
}

/**
 * {@inheritdoc}
 */
public function buildForm(array $form, FormStateInterface $form_state) {
$current_user = \Drupal::currentUser();
$roles = $current_user->getRoles();
if (in_array("driver", $roles)){
	$this->selected_role = 'driver';
}
if (in_array("dispatcher", $roles)){
	$this->selected_role = 'dispatcher';
}
$form['rolename'] = array(
  '#title' => t(''),
  '#type' => 'select',
  '#options' => array(
                    t('Switch User'),
  					'driver' => t('Driver'),
                    'dispatcher' => t('Dispatcher'),
                ),
  '#default_value' => $this->selected_role,
  '#attributes' => array('onchange' => "form.submit()")
);

$form['submit'] = [
 '#type' => 'submit',
 '#value' => t('Submit'),
 '#attributes' => array('style' => array('display:none !important')),
];
return $form;
}

/**
 * {@inheritdoc}
 */
public function validateForm(array &$form, FormStateInterface $form_state) {

}

/**
 * {@inheritdoc}
 */
public function submitForm(array &$form, FormStateInterface $form_state) {
	$values = $form_state->getValues();
	$switch_to = $values['rolename']; 
	$uid = \Drupal::currentUser()->id();
	$current_user = \Drupal::currentUser();
	$roles = $current_user->getRoles();
	if (in_array("transport_provider_dispatcher", $roles)|| in_array("administrator", $roles)){
		$user = user_load($uid);
		if($switch_to == 'dispatcher'){
			$user->removeRole('driver');
			$user->addRole($switch_to);
		}
		if ($switch_to == 'driver') {
			$user->removeRole('dispatcher');
			$user->addRole($switch_to);
		}
	    $user->save();
	    return $user;
	}

}

}
?>