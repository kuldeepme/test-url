<?php

namespace Drupal\job_message;

use Drupal\block\Entity\Block;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Template\Attribute;
use Drupal\Core\Entity\Query\QueryInterface;

/**
 * Controller for message.
 */
class JobMessageController {

  /**
   * Mmessage callback.
   */
  public static function message($nid = NULL) {

    $values = array(
      'entity_type' => 'node',
      'entity_id' => $nid,
      'field_name' => 'comment',
      'comment_type' => 'comment',
      'pid' => NULL,
    );

    $comment = \Drupal::entityTypeManager()->getStorage('comment')->create($values);
    $formHTML = \Drupal::service('entity.form_builder')->getForm($comment);
    $node = \Drupal\node\Entity\Node::load($nid);
    $output = '';
    $entity_manager = \Drupal::entityTypeManager();
    try {
      $storage = $entity_manager->getStorage('comment');
      $commentField = $node->get('comment');
      $comments = $storage->loadThread($node, $commentField->getFieldDefinition()->getName(), \Drupal\comment\CommentManagerInterface::COMMENT_MODE_FLAT);
      if (empty($comments)) {
        $comments = '';
      }
      else {
        $output = '';
        global $base_url;
        $theme = \Drupal::theme()->getActiveTheme();
        $image_url = $base_url . '/' . $theme->getPath() . '/img/msg-profile.png';
        foreach ($comments as $comment) {
          if ($comment->getOwnerId() == \Drupal::currentUser()->id()) {
            $class = 'msg-container darker';
          }
          else {
            $class = 'msg-container';
          }
          $comment_body = $comment->get('comment_body')->getValue();
          $body = array_pop($comment_body);
          $output .= '<div class="' . $class . '">
                <img src="' . $image_url . '" alt="Avatar" style="width:100%;">
                
                <a class="user-alias" target="_blank"  style="display: none;" href="#">' . $comment->getAuthorName() . '</a>
                <a class="user-alias" target="_blank"  href="/user/' . $comment->getOwnerId() . '">' . $comment->getAuthorName() . '</a>
                <p>' . $body['value'] . '<p>
                <span class="time-right">' . date('Y-m-d H:i:s', $comment->getCreatedTime()) . '</span>
                
                </div>
                ';
        }
      }
      return [
        '#messages' => $output,
        '#message_form' => $formHTML,
        '#theme' => 'message',
      ];
    }
    catch (\Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException $e) {

    }
    catch (\Drupal\Component\Plugin\Exception\PluginNotFoundException $e) {
    }
  }

}
