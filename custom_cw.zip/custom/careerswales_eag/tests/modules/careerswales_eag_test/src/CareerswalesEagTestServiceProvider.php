<?php

namespace Drupal\careerswales_eag_test;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;

/**
 * The Careers Wales EAG test service provider class.
 */
class CareerswalesEagTestServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container) {
    // Breaking outbound http requests on kernel tests.
    // https://www.drupal.org/project/drupal/issues/2571475.
    $container->removeDefinition('test.http_client.middleware');
  }

}
