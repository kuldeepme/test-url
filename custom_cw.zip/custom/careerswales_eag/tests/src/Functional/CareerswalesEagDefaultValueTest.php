<?php

namespace Drupal\Tests\careerswales_eag\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Tests the default values for EAG form fields.
 *
 * @group careerswales
 */
class CareerswalesEagDefaultValueTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'twig_tweak',
    'twig_field_value',
    'careerswales_api',
    'careerswales_eag',
    'careerswales_eag_test',
    'careerswales_forms',
    'filter',
    'search',
    'content_translation',
    'locale',
    'field_group',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();

    $this->container->get('theme_handler')->install(['careerswales_gel']);

    $this->config('system.theme')
      ->set('default', 'careerswales_gel')
      ->save();
  }

  /**
   * Tests that the default values are being populated.
   */
  public function testPopulateDefaultValues() {
    $edit = [
      'dob[day]' => '1',
      'dob[month]' => '1',
      'dob[year]' => '1990',
    ];

    $this->drupalPostForm('test-provision-directory', $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'Back');

    $this->assertSession()->fieldValueEquals('dob[day]', $edit['dob[day]']);
    $this->assertSession()->fieldValueEquals('dob[month]', $edit['dob[month]']);
    $this->assertSession()->fieldValueEquals('dob[year]', $edit['dob[year]']);

    $this->drupalPostForm(NULL, NULL, 'Next');

    $edit = [
      'postcode' => 'CF1 1AB',
      'gender' => 'MALE',
      'ethnicity' => 'PREFER_NOT_TO_SAY',
      'start_business' => 'NO',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'Back');

    $this->assertSession()->fieldValueEquals('postcode', $edit['postcode']);
    $this->assertSession()->fieldValueEquals('gender', $edit['gender']);
    $this->assertSession()->fieldValueEquals('ethnicity', $edit['ethnicity']);
    $this->assertSession()->fieldValueEquals('start_business', $edit['start_business']);

    $this->drupalPostForm(NULL, NULL, 'Change');

    $this->drupalPostForm(NULL, NULL, 'select your local authority');

    $edit = [
      'authority' => 'W06000015',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'Back');

    $this->assertSession()->fieldValueEquals('authority', $edit['authority']);

    $this->drupalPostForm(NULL, NULL, 'Next');

    $edit = [
      'employment_status' => 'EMPLOYED_0HR_CONTRACT',
      'redundancy' => 'REDUNDANT',
      'sector' => 'FOOD_AND_FARMING',
      'education_status' => 'FULL_TIME_TRAINING_OR_EDUCATION',
      'education_institution' => 'IN_SCHOOL',
      'qualification' => 'ENTRY_LEVEL',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'Back');

    $this->assertSession()->fieldValueEquals('employment_status', $edit['employment_status']);
    $this->assertSession()->fieldValueEquals('redundancy', $edit['redundancy']);
    $this->assertSession()->fieldValueEquals('education_status', $edit['education_status']);
    $this->assertSession()->fieldValueEquals('education_institution', $edit['education_institution']);
    $this->assertSession()->fieldValueEquals('qualification', $edit['qualification']);

    $this->drupalPostForm(NULL, NULL, 'Next');

    $edit = [
      'special_circumstances[LEARNING_DISABILITY]' => 'LEARNING_DISABILITY',
      'special_circumstances[CRIMINAL_RECORD]' => 'CRIMINAL_RECORD',
      'special_circumstances[CHILDCARE_RESPONSIBILITIES]' => 'CHILDCARE_RESPONSIBILITIES',
    ];

    $this->drupalPostForm(NULL, $edit, 'Show me suitable programmes');

    $this->click('button[name="change_special_circumstances"]');

    $this->assertSession()->fieldValueEquals('special_circumstances[LEARNING_DISABILITY]', $edit['special_circumstances[LEARNING_DISABILITY]']);
    $this->assertSession()->fieldValueEquals('special_circumstances[CRIMINAL_RECORD]', $edit['special_circumstances[CRIMINAL_RECORD]']);
    $this->assertSession()->fieldValueEquals('special_circumstances[CHILDCARE_RESPONSIBILITIES]', $edit['special_circumstances[CHILDCARE_RESPONSIBILITIES]']);
  }

}
