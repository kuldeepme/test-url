<?php

namespace Drupal\Tests\careerswales_eag\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Tests routes through the EAG form.
 *
 * @group careerswales
 */
class CareerswalesEagRouteTest extends BrowserTestBase {

  /**
   * The xpath selector used to target programmes.
   *
   * @var string
   */
  const PROGRAMME_SELECTOR = '//div[contains(concat(" ", normalize-space(@class), " "), " programme ")]';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'twig_tweak',
    'twig_field_value',
    'careerswales_api',
    'careerswales_eag',
    'careerswales_eag_test',
    'careerswales_forms',
    'filter',
    'search',
    'content_translation',
    'locale',
    'field_group',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();

    $this->container->get('theme_handler')->install(['careerswales_gel']);

    $this->config('system.theme')
      ->set('default', 'careerswales_gel')
      ->save();

    $this->config('careerswales_eag.settings')
      ->set('pager', 15)
      ->save();
  }

  /**
   * Tests that the correct programmes are show for a given route.
   */
  public function testRouteOne() {
    $edit = [
      'dob[day]' => '1',
      'dob[month]' => '1',
      'dob[year]' => '1997',
    ];

    $this->drupalPostForm('test-provision-directory', $edit, 'Next');

    $edit = [
      'postcode' => 'LL23 7AA',
      'gender' => 'FEMALE',
      'ethnicity' => 'ASIAN_INDIAN',
      'start_business' => 'YES',
    ];

    $this->drupalPostForm(NULL, $edit, 'Confirm postcode');

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'employment_status' => 'UNEMPLOYED_LESS_THAN_6_MONTHS',
      'redundancy' => 'REDUNDANT',
      'education_status' => 'FULL_TIME_TRAINING_OR_EDUCATION',
      'education_institution' => 'IN_HIGHER_EDUCATION',
      'qualification' => 'LEVEL_3',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'special_circumstances[MENTAL_HEALTH_CONDITION]' => 'MENTAL_HEALTH_CONDITION',
      'special_circumstances[LEARNING_DISABILITY]' => 'LEARNING_DISABILITY',
    ];

    $this->drupalPostForm(NULL, $edit, 'Show me suitable programmes');

    $this->assertSession()->elementsCount('xpath', static::PROGRAMME_SELECTOR, 13);

    $this->assertSession()->pageTextContains('New Enterprise Allowance (NEA)');
    $this->assertSession()->pageTextContains('Communities for Work Plus');
    $this->assertSession()->pageTextContains('ADTRAC');
    $this->assertSession()->pageTextContains('Prince\'s Trust Enterprise Cymru');
    $this->assertSession()->pageTextContains('WCCF - Employment Training Skills in Customer Service for Contact Centre Employment');
    $this->assertSession()->pageTextContains('GO Wales: Achieve Through Work Experience');
    $this->assertSession()->pageTextContains('TRAC 11-24');
    $this->assertSession()->pageTextContains('Out of Work Peer Mentoring Service');
    $this->assertSession()->pageTextContains('Access to Work');
    $this->assertSession()->pageTextContains('KESS 2');
    $this->assertSession()->pageTextContains('Active Inclusion (Strand 1 & 2)');
    $this->assertSession()->pageTextContains('Jobs Growth Wales');
    $this->assertSession()->pageTextContains('ReAct III');
  }

  /**
   * Tests that the correct programmes are show for a given route.
   */
  public function testRouteTwo() {
    $edit = [
      'dob[day]' => '1',
      'dob[month]' => '1',
      'dob[year]' => '2000',
    ];

    $this->drupalPostForm('test-provision-directory', $edit, 'Next');

    $edit = [
      'postcode' => 'CF37 3AD',
      'gender' => 'MALE',
      'ethnicity' => 'WHITE',
      'start_business' => 'YES',
    ];

    $this->drupalPostForm(NULL, $edit, 'Confirm postcode');

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'employment_status' => 'UNEMPLOYED_MORE_THAN_12_MONTHS',
      'education_status' => 'ENROLLED_OR_STARTING_FULL_TIME_TRAINING_COURSE',
      'education_institution' => 'IN_SCHOOL',
      'qualification' => 'LEVEL_2',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'Show me suitable programmes');

    $this->assertSession()->elementsCount('xpath', static::PROGRAMME_SELECTOR, 10);

    $this->assertSession()->pageTextContains('New Enterprise Allowance (NEA)');
    $this->assertSession()->pageTextContains('Communities for Work Plus');
    $this->assertSession()->pageTextContains('Prince\'s Trust Enterprise Cymru');
    $this->assertSession()->pageTextContains('Access Programme');
    $this->assertSession()->pageTextContains('WCCF - Employment Training Skills in Customer Service for Contact Centre Employment');
    $this->assertSession()->pageTextContains('Communities for Work (C4W)');
    $this->assertSession()->pageTextContains('Active Inclusion (Strand 1 & 2)');
    $this->assertSession()->pageTextContains('Jobs Growth Wales');
    $this->assertSession()->pageTextContains('Inspire to Achieve');
    $this->assertSession()->pageTextContains('Inspire 2 Work');
  }

  /**
   * Tests that the correct programmes are show for a given route.
   */
  public function testRouteThree() {
    $edit = [
      'dob[day]' => '1',
      'dob[month]' => '1',
      'dob[year]' => '1993',
    ];

    $this->drupalPostForm('test-provision-directory', $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'select your local authority');

    $edit = [
      'authority' => 'W06000019',
      'gender' => 'PREFER_NOT_TO_SAY',
      'ethnicity' => 'BLACK_CARIBBEAN',
      'start_business' => 'NO',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'employment_status' => 'UNEMPLOYED_MORE_THAN_12_MONTHS',
      'education_status' => 'NOT_IN_EDUCATION_OR_TRAINING',
      'qualification' => 'NO_FORMAL',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'special_circumstances[CHILDCARE_RESPONSIBILITIES]' => 'CHILDCARE_RESPONSIBILITIES',
      'special_circumstances[JOBLESS_HOUSEHOLDS]' => 'JOBLESS_HOUSEHOLDS',
    ];

    $this->drupalPostForm(NULL, $edit, 'Show me suitable programmes');

    $this->assertSession()->elementsCount('xpath', static::PROGRAMME_SELECTOR, 9);

    $this->assertSession()->pageTextContains('Employability Skills Programme');
    $this->assertSession()->pageTextContains('Bridges into Work');
    $this->assertSession()->pageTextContains('Communities for Work Plus');
    $this->assertSession()->pageTextContains('Parents, Childcare & Employment (PaCE)');
    $this->assertSession()->pageTextContains('Access Programme');
    $this->assertSession()->pageTextContains('WCCF - Employment Training Skills in Customer Service for Contact Centre Employment');
    $this->assertSession()->pageTextContains('Communities for Work (C4W)');
    $this->assertSession()->pageTextContains('Sova Achieving Change through Employment (ACE)');
    $this->assertSession()->pageTextContains('Active Inclusion (Strand 1 & 2)');
  }

  /**
   * Tests that the correct programmes are show for a given route.
   */
  public function testRouteFour() {
    $edit = [
      'dob[day]' => '1',
      'dob[month]' => '1',
      'dob[year]' => '2001',
    ];

    $this->drupalPostForm('test-provision-directory', $edit, 'Next');

    $this->drupalPostForm(NULL, NULL, 'select your local authority');

    $edit = [
      'authority' => 'W06000005',
      'gender' => 'MALE',
      'ethnicity' => 'MIXED_WHITE_ASIAN',
      'start_business' => 'NO',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'employment_status' => 'EMPLOYED_0HR_CONTRACT',
      'sector' => 'CREATIVE',
      'education_status' => 'PART_TIME_TRAINING_OR_EDUCATION',
      'qualification' => 'LEVEL_5',
    ];

    $this->drupalPostForm(NULL, $edit, 'Next');

    $edit = [
      'special_circumstances[LEARNING_DISABILITY]' => 'LEARNING_DISABILITY',
    ];

    $this->drupalPostForm(NULL, $edit, 'Show me suitable programmes');

    $this->assertSession()->elementsCount('xpath', static::PROGRAMME_SELECTOR, 4);

    $this->assertSession()->pageTextContains('Wales Union Learning Fund (WULF)');
    $this->assertSession()->pageTextContains('Communities for Work Plus');
    $this->assertSession()->pageTextContains('Access to Work');
    $this->assertSession()->pageTextContains('SEE');
  }

}
