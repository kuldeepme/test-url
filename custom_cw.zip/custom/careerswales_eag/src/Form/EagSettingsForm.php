<?php

namespace Drupal\careerswales_eag\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Careers Wales EAG basic settings.
 */
class EagSettingsForm extends ConfigFormBase {

  use StringTranslationTrait;

  /**
   * The entity type manager class.
   *
   * @var object
   */
  protected $entityTypeManager;

  /**
   * EagSettingsForm constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(ConfigFactoryInterface $config_factory, EntityTypeManagerInterface $entity_type_manager) {
    parent::__construct($config_factory);
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'careerswales_eag_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'careerswales_eag.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $settings = $this->config('careerswales_eag.settings');

    $form['introduction'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Introduction'),
    ];

    $form['introduction']['introduction'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('introduction')['format'],
      '#default_value' => $settings->get('introduction')['value'],
    ];

    $form['results'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Results Summary Text'),
    ];
    $form['results']['results_introduction'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('results_introduction')['format'],
      '#default_value' => $settings->get('results_introduction')['value'],
    ];

    $form['favourites'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Favourites Summary Text'),
    ];

    $form['favourites']['favourites_introduction'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('favourites_introduction')['format'],
      '#default_value' => $settings->get('favourites_introduction')['value'],
    ];

    $form['favourites']['favourites_footer'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('favourites_footer')['format'],
      '#default_value' => $settings->get('favourites_footer')['value'],
    ];

    $form['contact'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Contact Summary Text'),
    ];

    $form['contact']['contact_introduction'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('contact_introduction')['format'],
      '#default_value' => $settings->get('contact_introduction')['value'],
    ];

    $form['contact']['contact_statements'] = [
      '#type'          => 'text_format',
      '#format'        => $settings->get('contact_statements')['format'],
      '#default_value' => $settings->get('contact_statements')['value'],
    ];

    $form['settings'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Settings'),
    ];

    $form['settings']['pager'] = [
      '#type'          => 'select',
      '#title' => $this->t('Number of programmes per page'),
      '#options' => [
        '1' => '1',
        '2' => '2',
        '3' => '3',
        '4' => '4',
        '5' => '5',
        '6' => '6',
        '7' => '7',
        '8' => '8',
        '9' => '9',
        '10' => '10',
        '11' => '11',
        '12' => '12',
        '13' => '13',
        '14' => '14',
        '15' => '15',
        '9999' => '9999',
      ],
      '#default_value' => $settings->get('pager'),
    ];

    $form['settings']['privacy_policy_page'] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'node',
      '#title' => $this->t('Set the pointer to the privacy policy page.'),
      '#default_value' => $this->entityTypeManager->getStorage('node')->load($settings->get('privacy_policy_page')),
    ];

    $form['contact_forms'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Contact Forms'),
    ];

    $form['contact_forms']['callback_page'] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'node',
      '#title' => $this->t('Set the pointer to the callback form page.'),
      '#default_value' => $this->entityTypeManager->getStorage('node')->load($settings->get('callback_page')),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $settings = $this->configFactory->getEditable('careerswales_eag.settings');

    // Save configurations.
    $settings->set('introduction', $form_state->getValue('introduction'))->save();
    $settings->set('results_introduction', $form_state->getValue('results_introduction'))->save();
    $settings->set('favourites_introduction', $form_state->getValue('favourites_introduction'))->save();
    $settings->set('favourites_footer', $form_state->getValue('favourites_footer'))->save();
    $settings->set('contact_introduction', $form_state->getValue('contact_introduction'))->save();
    $settings->set('contact_statements', $form_state->getValue('contact_statements'))->save();
    $settings->set('pager', $form_state->getValue('pager'))->save();
    $settings->set('age_redirect', $form_state->getValue('age_redirect'))->save();
    $settings->set('privacy_policy_page', $form_state->getValue('privacy_policy_page'))->save();

    $settings->set('callback_page', $form_state->getValue('callback_page'))->save();

  }

}
