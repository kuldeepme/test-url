<?php

namespace Drupal\careerswales_eag\Form;

use Drupal\careerswales_forms\Form\CareersWalesFormBase;
use Drupal\careerswales_forms\Form\Step\Factory\FormStepFactoryInterface;
use Drupal\careerswales_eag\EagBridgeInterface;
use Drupal\careerswales_forms\Form\Step\FormStepInterface;
use Drupal\Component\Utility\NestedArray;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Component\Render\FormattableMarkup;

/**
 * Implements the Eag form controller.
 *
 * @see \Drupal\Core\Form\FormBase
 */
class EagForm extends CareersWalesFormBase {

  /**
   * The EAG form step factory class.
   *
   * @var object
   */
  protected $formStepFactory;

  /**
   * The EAG bridge class.
   *
   * @var object
   */
  protected $eagBridge;

  /**
   * EagForm constructor.
   *
   * @param \Drupal\careerswales_forms\Form\Step\Factory\FormStepFactoryInterface $form_step_factory
   *   The form step factory.
   * @param \Drupal\careerswales_eag\EagBridgeInterface $eag_bridge
   *   The EAG bridge class.
   */
  public function __construct(FormStepFactoryInterface $form_step_factory, EagBridgeInterface $eag_bridge) {
    $this->formStepFactory = $form_step_factory;
    $this->eagBridge = $eag_bridge;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('careerswales_eag.form_step.factory'),
      $container->get('careerswales_eag.bridge')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'eag_form';
  }

  /**
   * An ordered list of the field names we care the most about.
   *
   * @return array
   *   Array of whitelisted api fields.
   */
  public function whitelist() {
    return [
      'dob',
      'postcode',
      'authority',
      'gender',
      'ethnicity',
      'employment_status',
      'redundancy',
      'sector',
      'education_status',
      'education_institution',
      'qualification',
      'start_business',
      'special_circumstances',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Load up the storage array.
    $storage = $form_state->getStorage();
    $form_state->setCached(FALSE);
    \Drupal::service('page_cache_kill_switch')->trigger();

    // If there are no responses yet initialise the storage.
    if (empty($storage['responses'])) {
      $storage['responses'] = [];
      $form_state->setStorage($storage);
    }

    // Load the current state or start ar the first.
    if (empty($storage['step'])) {
      $storage['step'] = 1;
      $form_state->setStorage($storage);
    }

    // Disable validation as the client has their own.
    $form = [
      '#attributes' => [
        'novalidate' => 'novalidate',
        'class' => [
          'form--eag-screener',
          'form--multi-step',
          'form--step-' . $storage['step'],
        ],
      ],
    ];

    /*if ($storage['step'] && ($storage['step'] != 1)) {
      $form['#attributes']['class'][] = 'js-form-unsaved';
      $form['#attributes']['data-form-unsaved'] = TRUE;
    }*/

    // Render the progress bar.
    $form['progress_bar'] = $this->renderProgressBar($form, $form_state);

    // Load the current step.
    $form_step = $this->formStepFactory->create($storage['step']);

    // Render the header.
    $form['header'] = $this->renderHeader($form, $form_state, $form_step);

    // Render the step content.
    $form_step->buildStep($form, $form_state);

    // Render the previous and next buttons.
    $form['actions'] = $this->renderNavigation($form, $form_state);

    // Allow the step to make custom overrides.
    $form_step->override($form, $form_state);

    // Return the form.
    return $form;
  }

  /**
   * Renders the header for the form.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   * @param \Drupal\careerswales_forms\Form\Step\FormStepInterface $form_step
   *   The current step of the form.
   *
   * @return array
   *   The render array.
   */
  public function renderHeader(array &$form, FormStateInterface $form_state, FormStepInterface $form_step) {
    $storage = $form_state->getStorage();

    $header = [
      '#type' => 'container',
      '#html_tag' => 'header',
      '#attributes' => [
        'class' => 'form__header',
      ],
    ];

    $header['title'] = [
      '#markup' => '<p class="form__title">' . $form_step->getName() . '</p>',
    ];

    $header['required'] = [
      '#markup' => '<p class="form__introduction">' . $this->t('All fields marked with <span class="style--required">*</span> are mandatory') . '</p>',
    ];

    if (($storage['step'] > 1)) {
      $back_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', [
        '@text' => $this->t('to previous page'),
      ]);

      $header['previous'] = [
        '#type' => 'submit',
        '#value' => $this->t('Back'),
        '#extra' => $back_button_text,
        '#submit' => ['::submitPrevious'],
        '#validate' => ['::validateSuppressErrors'],
        '#attributes' => [
          'class' => [
            'button',
            'button--icon',
            'icon--left',
            'icon--chevron-left',
            'button--secondary',
            'button--style-dark',
            'form__button-back',
          ],
        ],
      ];
    }

    return $header;
  }

  /**
   * Renders the navigation for the form.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The render array.
   */
  public function renderNavigation(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $navigation = [
      '#type' => 'container',
      '#html_tag' => 'footer',
      '#weight' => 1000,
      '#attributes' => [
        'class' => 'form__footer',
      ],
    ];

    // Only show the previous button after the first step.
    if ($storage['step'] > 1) {
      $back_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', [
        '@text' => $this->t('to previous page'),
      ]);

      $navigation['previous'] = [
        '#type' => 'submit',
        '#value' => $this->t('Back'),
        '#extra' => $back_button_text,
        '#submit' => ['::submitPrevious'],
        '#validate' => ['::validateSuppressErrors'],
        '#attributes' => [
          'class' => [
            'button',
            'button--icon',
            'icon--left',
            'icon--chevron-left',
            'button--style-dark',
            'form__button-back',
          ],
        ],
      ];
    }

    $next_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', [
      '@text' => $this->t('to next page'),
    ]);

    $navigation['next'] = [
      '#type' => 'submit',
      '#value' => $this->t('Next'),
      '#extra' => $next_button_text,
      '#submit' => [
        '::submitStoreValues',
        '::submitStoreResponses',
        '::submitNext',
      ],
      '#attributes' => [
        'class' => [
          'button',
          'button--icon',
          'icon--chevron-right',
          'button--style-dark',
          'form__button-next',
        ],
      ],
    ];

    return $navigation;
  }

  /**
   * Renders the progress bar for the form.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The render array.
   */
  public function renderProgressBar(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $progress_bar = [
      '#type' => 'container',
      '#attributes' => [
        'class' => [
          'form__progress',
        ],
      ],
    ];

    // Steps include in the progress bar.
    $steps = [1, 2, 3, 4, 5];

    // Loop through all the steps and render a submit button for each step.
    foreach ($steps as $step) {
      $progress_bar['step_' . $step] = [
        '#type' => 'container',
        '#attributes' => [
          'class' => [
            'progress__step',
          ],
        ],
      ];

      // Set visited steps to completed.
      if ($step < $storage['step']) {
        $progress_bar['step_' . $step]['#attributes']['class'][] = 'step--complete';
      }

      $form_step = $this->formStepFactory->create($step);

      $progress_bar['step_' . $step]['button_' . $step] = [
        '#type' => 'submit',
        '#value' => $form_step->getName(),
        '#target' => $step,
        '#submit' => ['::submitChangeStep'],
        '#validate' => ['::validateSuppressErrors'],
        '#attributes' => [
          'class' => [
            'step__button',
          ],
        ],
      ];

      // Set unvisited steps to disabled.
      if ($step > $storage['step']) {
        $progress_bar['step_' . $step]['button_' . $step]['#disabled'] = TRUE;
      }
    }

    return $progress_bar;
  }

  /**
   * Clears form errors to allow navigation without validation.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function validateSuppressErrors(array &$form, FormStateInterface $form_state) {
    $form_state->clearErrors();
  }

  /**
   * Checks that the location API is available.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function validateLocationApiAvailable(array &$form, FormStateInterface $form_state) {
    $available = $this->eagBridge->isEndpointApiAvailable('location');

    if (!$available) {
      $form_state->clearErrors();
      $form_state->setError($form, $this->t('We\'re sorry but the Support Finder is currently unavailable. Please try again later.'));
    }
  }

  /**
   * Checks that the programme API is available.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function validateProgrammeApiAvailable(array &$form, FormStateInterface $form_state) {
    $available = $this->eagBridge->isEndpointApiAvailable('programme');

    if (!$available) {
      $form_state->clearErrors();
      $form_state->setError($form, $this->t('We\'re sorry but the Support Finder is currently unavailable. Please try again later.'));
    }
  }

  /**
   * Checks that the contact API is available.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function validateContactApiAvailable(array &$form, FormStateInterface $form_state) {
    $available = $this->eagBridge->isEndpointApiAvailable('contact');

    if (!$available) {
      $form_state->clearErrors();
      $form_state->setError($form, $this->t('We\'re sorry but the Support Finder is currently unavailable. Please try again later.'));
    }
  }

  /**
   * Ajax submit callback to rebuild the results page.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   *
   * @return mixed
   *   The results part of the form.
   */
  public function rebuildResultsPage(array &$form, FormStateInterface $form_state) {
    $form_state->clearErrors();
    return $form['tabs'];
  }

  /**
   * Moves to the previous step of the form.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitPrevious(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['step']--;

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Adds a programme to your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitProgramme(array &$form, FormStateInterface $form_state) {
    // Check to make sure that a redirect has not already been set.
    if ($form_state->getRedirect()) {
      return;
    }

    $storage = $form_state->getStorage();
    $triggering_element = $form_state->getTriggeringElement();

    // Store the form values for the current step.
    $storage['values'][$storage['step']] = $form_state->getValues();
    // Programme id.
    $storage['programme'] = $triggering_element['#programme'];

    // Store the question and answer responses.
    $responses = $this->buildResponses($form, $form_state);
    $storage['responses'] = array_merge($storage['responses'], $responses);

    // Increment the form state.
    $storage['step']++;

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Moves to the next step of the form.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitNext(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['step']++;

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Adds a programme to your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitAddToFavourites(array &$form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Save to favourites.
    $storage['favourites'][$triggering_element['#programme']] = $triggering_element['#programme'];

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Removes a programme from your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitRemoveFromFavourites(array &$form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Delete from favourites.
    unset($storage['favourites'][$triggering_element['#programme']]);

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Changes the progress bar current step.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function submitChangeStep(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['step'] = $form_state->getTriggeringElement()['#target'];

    $form_state->setStorage($storage);

    $form_state->setCached(FALSE);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Flushes the stored form state values.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitFlushStorage(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    unset($storage['responses']);
    unset($storage['values']);
    unset($storage['postcode_verified']);
    unset($storage['postcode_entry_mode']);

    $form_state->setStorage($storage);
  }

  /**
   * Form submission handler.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   * Adds an array of field values to form storage.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitStoreValues(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['values'][$storage['step']] = $form_state->getValues();

    $form_state->setStorage($storage);
  }

  /**
   * Adds an array of question and answer responses to form storage.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitStoreResponses(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $mappings = [];
    foreach ($form_state->getValues() as $key => $value) {
      if (in_array($key, $this->whitelist())) {
        $matches = $this->recursiveFind($key, $form);

        foreach ($matches as $match) {
          if (isset($match['#type'])) {
            $mappings[] = $match['#array_parents'];
          }
        }
      }
    }

    $responses = [];
    foreach ($mappings as $mapping) {
      $field = NestedArray::getValue($form, $mapping);
      $field_key = end($mapping);
      $field_value = $form_state->getValue($field_key);

      if (!$this->isEmpty($field, $field_value)) {
        $responses[$field_key] = $this->formatResponse($field, $field_value);
      }
    }

    $storage['responses'][$storage['step']] = $responses;

    $form_state->setStorage($storage);
  }

  /**
   * Recursively find matching keys in an array.
   *
   * @param string $needle
   *   The key to search by.
   * @param array $haystack
   *   The array to search.
   *
   * @return array
   *   The matching values.
   */
  protected function recursiveFind($needle, array $haystack) {
    $iterator = new \RecursiveArrayIterator($haystack);
    $recursive = new \RecursiveIteratorIterator($iterator, \RecursiveIteratorIterator::SELF_FIRST);

    $results = [];
    foreach ($recursive as $key => $value) {
      if ($key === $needle) {
        $results[] = $value;
      }
    }

    return $results;
  }

  /**
   * Checks if a given field value is empty based on type.
   *
   * @param array $field
   *   The field array.
   * @param mixed $field_value
   *   The field value.
   *
   * @return bool
   *   The empty status flag.
   */
  protected function isEmpty(array $field, $field_value) {
    switch ($field['#type']) {
      case 'select':
        $empty = ($field_value == '') ? TRUE : FALSE;
        break;

      case 'checkboxes':
        $empty = (!in_array(TRUE, (array) $field_value)) ? TRUE : FALSE;
        break;

      default:
        $empty = (empty($field_value)) ? TRUE : FALSE;
        break;
    }

    return $empty;
  }

  /**
   * Formats the response question and answer based on type.
   *
   * @param array $field
   *   The field array.
   * @param mixed $field_value
   *   The field value.
   *
   * @return array
   *   The response array.
   */
  protected function formatResponse(array $field, $field_value) {
    switch ($field['#type']) {
      case 'datelist':
        $object = $field_value['object'];
        $answer = $object->format('d/m/Y');
        break;

      case 'select':
      case 'radios':
        $options = $field['#options'];
        $answer = $options[$field_value];
        break;

      case 'checkboxes':
        $options = $field['#options'];

        $selected_options = [];
        foreach ($field_value as $checkbox) {
          if (!empty($checkbox)) {
            $selected_options[] = $options[$checkbox];
          }
        }

        $answer = $selected_options;
        break;

      default:
        $answer = $field_value;
    }

    $response['question'] = $field['#title'];
    $response['answer'] = $answer;

    return $response;
  }

}
