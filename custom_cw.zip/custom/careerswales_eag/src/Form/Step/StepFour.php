<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides an object for a form step.
 */
class StepFour extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Special Circumstances');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    // Load the storage data we track 'step' and question responses in 'values'.
    $storage = $form_state->getStorage();

    $form['special_circumstances'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Any special circumstances?'),
      '#options' => $this->eagBridge->getSpecialCircumstances(),
      '#default_value' => isset($storage['values'][$storage['step']]['special_circumstances']) ? $storage['values'][$storage['step']]['special_circumstances'] : [],
      '#description' => $this->t('Do you consider yourself to have any of the following (Optional):'),
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('You may be eligible for different programmes depending on your circumstances'),
      ],
      '#element_validate' => [
        [$this, 'validateSpecialCircumstances'],
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {
    // Change styling of next button.
    $finish_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', [
      '@text' => $this->t('to results page'),
    ]);

    $form['actions']['next']['#value'] = $this->t('Show me suitable programmes');
    $form['actions']['next']['#extra'] = $finish_button_text;
    $form['actions']['next']['#attributes']['class'] = [
      'button',
      'button--icon',
      'icon--chevron-right',
      'form__button-submit',
    ];

    // Add programme API validation check.
    $form['actions']['next']['#validate'][] = '::validateProgrammeApiAvailable';
  }

  /**
   * Validates the special circumstances question.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validateSpecialCircumstances(array &$element, FormStateInterface $form_state, array &$form) {
    if (array_key_exists('NONE', $element['#value'])) {
      if (count($element['#value']) > 1) {
        $form_state->setError($element, $this->t("You cannot select both 'none' and special circumstances. Either select special circumstances or select 'none' if you have no special circumstances."));
      }

      $special_circumstances = $form_state->getValue('special_circumstances');
      unset($special_circumstances['NONE']);

      $form_state->setValue('special_circumstances', $special_circumstances);
    }
  }

}
