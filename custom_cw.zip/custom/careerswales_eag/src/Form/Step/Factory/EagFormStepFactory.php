<?php

namespace Drupal\careerswales_eag\Form\Step\Factory;

use Drupal\careerswales_eag\Form\Step\StepSeven;
use Drupal\careerswales_forms\Form\Step\Factory\FormStepFactoryBase;
use Drupal\careerswales_eag\Form\Step\StepOne;
use Drupal\careerswales_eag\Form\Step\StepTwo;
use Drupal\careerswales_eag\Form\Step\StepThree;
use Drupal\careerswales_eag\Form\Step\StepFour;
use Drupal\careerswales_eag\Form\Step\StepFive;
use Drupal\careerswales_eag\Form\Step\StepSix;

/**
 * Provides a factory for creating EAG form steps.
 */
class EagFormStepFactory extends FormStepFactoryBase {

  /**
   * {@inheritdoc}
   */
  public function create($current_step) {
    switch ($current_step) {
      case 1:
        $step = StepOne::class;
        break;

      case 2:
        $step = StepTwo::class;
        break;

      case 3:
        $step = StepThree::class;
        break;

      case 4:
        $step = StepFour::class;
        break;

      case 5:
        $step = StepFive::class;
        break;

      case 6:
        $step = StepSix::class;
        break;

      case 7:
        $step = StepSeven::class;
        break;

      default:
        $step = StepOne::class;
        break;
    }

    return $this->classResolver->getInstanceFromDefinition($step);
  }

}
