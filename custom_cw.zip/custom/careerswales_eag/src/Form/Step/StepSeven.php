<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Url;

/**
 * Provides an object for a form step.
 */
class StepSeven extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Contact us form');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    $form['#prefix'] = '<div id="eag-form-wrapper">' . $this->eagBridge->getContactIntroduction();
    $form['#suffix'] = '</div>';

    $language = $this->languageManager;
    $language = $language->getCurrentLanguage()->getId();

    $storage = $form_state->getStorage();
    $triggering_element = $form_state->getTriggeringElement();

    $fav_programmes = [];
    $target_step = 5;
    if ($triggering_element['#id'] == 'edit-contact') {
      // Step 6.
      $target_step = 6;
      foreach ($storage['programmes'] as $key => $programme) {
        if ($programme['id'] == $storage['programme']) {
          $fav_programmes[$programme['id']] = $programme['name'][$language];
        }
      }
    }
    elseif ($triggering_element['#id'] == 'edit-tabs-favourites-contact') {
      // Step 5.
      foreach ($storage['programmes'] as $key => $programme) {
        if (isset($storage['favourites'])) {
          if (in_array($key, $storage['favourites'])) {
            $fav_programmes[$programme['id']] = $programme['name'][$language];
          }
        }
      }
    }

    if ($form_state->getTemporaryValue('email_sent') === TRUE) {
      $form['results'] = [
        '#printed' => TRUE,
        '#type' => 'submit',
        '#value' => $this->t('View your results page'),
        '#extra' => new FormattableMarkup('<span class="visually-hidden">@text</span>',
          ['@text' => $this->t('to results page')]
        ),
        '#target' => $target_step,
        '#submit' => ['::submitChangeStep'],
        '#validate' => ['::validateSuppressErrors'],
        '#attributes' => [
          'class' => [
            'button',
            'button--as-link',
          ],
        ],
      ];

      $form['message'] = [
        '#type' => 'inline_template',
        '#template' => '<p class="notice notice--positive">{{ message }}<br><br>{{ button }}</p>',
        '#context' => [
          'message' => $this->t('Thank you for sharing your programme results with Careers Wales. We will contact you within 2 working days to discuss the results and your career plans.'),
          'button' => &$form['results'],
        ],
      ];
    }
    elseif ($form_state->getTemporaryValue('email_sent') === FALSE) {
      $form['message'] = [
        '#type' => 'inline_template',
        '#template' => '<p class="notice notice--warning-alert">{{ message }}</p>',
        '#context' => [
          'message' => $this->t('There was an error trying to send the email. Please try again later.'),
        ],
      ];
    }
    else {



      $form['name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Name'),
        '#width' => 'medium',
        '#required' => TRUE,
        '#required_error' => $this->t('Please enter your name. We require your name in order to be able to contact you.'),
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];

      $form['email'] = [
        '#type' => 'email',
        '#title' => $this->t('Email address'),
        '#width' => 'medium',
        '#element_validate' => [
          [$this, 'validateEmailAddress'],
        ],
        '#required' => TRUE,
        '#required_error' => $this->t('Please enter a valid email address. This will enable us to contact you.'),
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];

      $form['telephone'] = [
        '#type' => 'tel',
        '#title' => $this->t('Telephone number'),
        '#width' => 'medium',
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];

      $form['preferred'] = [
        '#title' => $this->t('How would you prefer to be contacted by us?'),
        '#type' => 'radios',
        '#options' => [
          'TELEPHONE' => $this->t('Telephone call'),
          'EMAIL' => $this->t('Email'),
          'TEXT_MESSAGE' => $this->t('Text message'),
        ],
        '#description' => $this->t('(Tick the box of your preferred contact method)'),
        '#description_display' => 'before',
        '#states' => [
          'visible' => [
            ':input[name="telephone"]' => ['filled' => TRUE],
          ],
          'required' => [
            ':input[name="telephone"]' => ['filled' => TRUE],
          ],
        ],
        '#element_validate' => [
          [$this, 'validatePreferred'],
        ],
      ];

      $form['programmes'] = [
        '#type' => 'textarea',
        '#title' => $this->t('These are the programme results that will be sent with your email:'),
        '#width' => 'large',
        '#default_value' => html_entity_decode(implode(', ', $fav_programmes)),
        '#disabled' => TRUE,
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];

      $form['comments'] = [
        '#type' => 'textarea',
        '#title' => $this->t('Comments and questions'),
        '#width' => 'large',
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];


      $form['statements'] = [
        '#type' => 'markup',
        '#markup' => $this->eagBridge->getContactStatements(),
      ];

      $form['declaration'] = [
        '#type' => 'checkbox',
        '#title' => $this->t('I have read and agree to all the above statements <span class="style--required">*</span>'),
        //        '#description_display' => 'after',
        //        '#description' => [
        //          '#type' => 'inline_template',
        //          '#template' => '{{ information }} {{ link }}.',
        //          '#context' => [
        //            'information' => $this->t('For more information on how Careers Wales uses personal data, you can view a copy of the Careers Wales privacy notice by clicking'),
        //            'link' => [
        //              '#type' => 'link',
        //              '#title' => $this->t('our privacy notice'),
        //              '#url' => Url::fromRoute('entity.node.canonical', ['node' => $this->eagBridge->getPrivacyPolicyPage()]),
        //              '#attributes' => [
        //                'target' => '_blank',
        //              ],
        //            ],
        //          ],
        //        ],
        '#required' => TRUE,
        '#required_error' => $this->t('In order to proceed with this email you will need to show you agree with the statements by ticking the checkbox.'),
      ];

      $form['warning'] = [
        '#type' => 'markup',
        '#markup' => '<p>@warning</p>',
        '#attached' => [
          'placeholders' => [
            '@warning' => ['#markup' => $this->t('If you are not happy with the above statements, please close the browser window. Please note that the results of the provision directory will not be saved once you have closed the browser window.')],
          ],
        ],
      ];
    }
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {
    unset($form['progress_bar']);
    unset($form['header']['title']);

    $back_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>',
      ['@text' => $this->t('to results page')]
    );

    // Change styling of header previous button.
    $form['header']['previous']['#value'] = $this->t('View your results page');
    $form['header']['previous']['#extra'] = $back_button_text;
    $form['header']['previous']['#submit'] = ['::submitChangeStep'];
    $form['header']['previous']['#target'] = 5;

    // Change styling of previous button.
    $form['actions']['previous']['#value'] = $this->t('View your results page');
    $form['actions']['previous']['#extra'] = $back_button_text;
    $form['actions']['previous']['#submit'] = ['::submitChangeStep'];
    $form['actions']['previous']['#target'] = 5;
    $form['actions']['previous']['#attributes']['style'] = 'float:right';

    // Change styling and function of next button.
    $next_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>',
      ['@text' => $this->t('send email')]
    );

    $form['actions']['next']['#value'] = $this->t('Send');
    $form['actions']['next']['#extra'] = $next_button_text;
    $form['actions']['next']['#limit_validation_errors'] = FALSE;
    $form['actions']['next']['#ajax'] = [
      'callback' => [$this, 'callbackRebuildForm'],
      'wrapper' => 'eag-form-wrapper',
      'keypress' => TRUE,
      'event' => 'click',
      'progress' => ['type' => 'none'],
    ];
    $form['actions']['next']['#submit'] = [
      [$this, 'submitSendEmail'],
    ];
    $form['actions']['next']['#attributes']['style'] = 'float:left';
    $form['actions']['next']['#attributes']['class'] = [
      'button',
      'form__button-submit',
      'spinner--right',
    ];

    if ($form_state->hasTemporaryValue('email_sent')) {
      unset($form['header']['previous']);
      unset($form['header']['required']);
      unset($form['actions']);
    }
  }

  /**
   * Rebuilds the form wrapper.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   *
   * @return mixed
   *   The location wrapper.
   */
  public function callbackRebuildForm(array &$form, FormStateInterface $form_state) {
    if ($form_state->getTemporaryValue('email_sent')) {
      unset($form['#prefix']);
      unset($form['#suffix']);
    }

    return $form;
  }

  /**
   * Validates that an email address was provided.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validateEmailAddress(array &$element, FormStateInterface $form_state, array &$form) {
    if (!$this->emailValidator->isValid($element['#value'])) {
      $form_state->setError($element, $this->t('Please enter a valid email address. This will enable us to contact you.'));
    }
  }

  /**
   * Validates the preferred method of contact.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validatePreferred(array &$element, FormStateInterface $form_state, array &$form) {
    $telephone = $form_state->getValue('telephone');

    if (!empty($telephone)) {
      if (empty($element['#value'])) {
        $form_state->setError($element, $this->t('Please select a preferred contact method.'));
      }
    }
  }

  /**
   * Sends an email with values from the contact form.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitSendEmail(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $programmes = [];
    if (isset($storage['programme'])) {
      $programmes[] = $storage['programme'];
    }
    if (isset($storage['favourites_pdf'])) {
      $programmes = $storage['favourites_pdf'];
    }

    $values = $form_state->getValues();

    $response = $this->eagBridge->contactAdvisor(
      $values['email'],
      $values['comments'],
      $values['name'],
      $values['preferred'],
      $programmes,
      $values['telephone']
    );

    $form_state->setTemporaryValue('email_sent', FALSE);
    if ($response->getStatusCode() == 200 && $response->getReasonPhrase() == 'OK' ||
        $response->getStatusCode() == 202 && $response->getReasonPhrase() == 'ACCEPTED') {
      $form_state->setTemporaryValue('email_sent', TRUE);
    }

    $form_state->setRebuild(TRUE);
  }

}
