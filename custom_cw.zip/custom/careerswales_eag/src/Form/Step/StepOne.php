<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * Provides an object for a form step.
 */
class StepOne extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Get started');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    $storage = $form_state->getStorage();

    $form['dob'] = [
      '#title' => $this->t('Tell us your Date of Birth'),
      '#required' => TRUE,
      '#type' => 'datelist',
      '#attributes' => [
        'autocomplete' => 'off',
      ],
      '#required_error' => $this->t('Please enter your Date of Birth'),
      '#element_validate' => [
        [$this, 'validateDobYearRange'],
      ],
      '#date_date_format' => 'd-m-Y',
      '#date_part_order' => [
        'day',
        'month',
        'year',
      ],
      '#date_year_range_min' => '1900',
      '#date_year_range_max' => date('Y'),
      '#date_text_parts' => ['day', 'month', 'year'],
      '#description' => $this->t('For example 31 03 1980'),
      '#default_value' => isset($storage['values'][$storage['step']]['dob']['object']) ? $storage['values'][$storage['step']]['dob']['object'] : NULL,
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Your date of birth will help us to find programmes suitable for your age'),
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {
    // Preface step one with introduction text.
    $form['#prefix'] = $this->eagBridge->getIntroduction();

    // Add location API validation check.
    $form['actions']['next']['#validate'][] = '::validateLocationApiAvailable';
  }

  /**
   * Validate the dob field.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   */
  public function validateDobYearRange(array &$form, FormStateInterface $form_state) {
    $dob = $form_state->getValue('dob');

    if (is_null($dob['object'])) {
      $form_state->setError($form, $this->t('Please enter your Date of Birth'));
    }

    // @todo Add leading zero to day and month if user has only input one digit
    if (!empty($dob['day']) && (strlen($dob['day'])) < 2) {
      $dob['day'] = '0' . $dob['day'];
    }

    if (!empty($dob['month']) && (strlen($dob['month'])) < 2) {
      $dob['month'] = '0' . $dob['month'];
    }

    // Check that a valid year has been entered.
    if (!in_array($dob["year"], range($form["#date_year_range_min"], $form["#date_year_range_max"]))) {
      $form_state->setError($form, $this->t('Please enter your Date of Birth'));
    }

    // To stop Drupal from stripping leading zero when reloading after an error.
    $form['#default_value'] = $dob;

    $form["day"]["#value"] = $dob['day'];
    $form["month"]["#value"] = $dob['month'];

    $storage = $form_state->getStorage();
    $storage['values'][$storage['step']]['dob'] = $dob;
    $form_state->setStorage($storage);
  }

  /**
   * Checks to see if the user should be redirected to the under 18's page.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   */
  public function submitDobRedirect(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    if (!is_null($values['dob']['object'])) {
      // Create a datetime object representing today.
      $now = DrupalDateTime::createFromTimestamp(time());
      // Create a datetime object representing the birthday.
      if (is_array($values['dob'])) {
        $dob = DrupalDateTime::createFromTimestamp($values['dob']['object']->format('U'));
      }
      else {
        $dob = DrupalDateTime::createFromTimestamp($values['dob']->format('U'));
      }
      // The difference between the two.
      $diff = $now->diff($dob);

      $redirect_nid = \Drupal::config('careerswales_eag.settings')
        ->get('age_redirect');

      if (is_null($redirect_nid)) {
        // Just as a fallback in case no node has been selected.
        $redirect_nid = \Drupal::config('system.site')
          ->get('page.front');
        $redirect_nid = explode('/', $redirect_nid);
        $redirect_nid = $redirect_nid[2];
      }

      if ($diff->y < 18) {
        $form_state->setRedirect('entity.node.canonical',
          ['node' => $redirect_nid]
        );
      }
    }

  }

}
