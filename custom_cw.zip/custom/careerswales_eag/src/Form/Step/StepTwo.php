<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides an object for a form step.
 */
class StepTwo extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Tell us a little about yourself');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    $storage = $form_state->getStorage();

    if (!isset($storage['postcode_entry_mode'])) {
      $storage['postcode_entry_mode'] = 1;
      $form_state->setStorage($storage);
    }

    if (!isset($storage['postcode_verified'])) {
      $storage['postcode_verified'] = 0;
      $form_state->setStorage($storage);
    }

    // Container with an ID used as the #ajax wrapping element.
    $form['location'] = [
      '#type' => 'container',
      '#id' => 'location',
      '#attributes' => [
        'id' => 'location',
      ],
    ];

    // Render array to provide the 'Verify Postcode' button.
    $form['postcode_suffix'] = [
      '#printed' => TRUE,
      '#type' => 'submit',
      '#value' => $this->t('Confirm postcode'),
      '#ajax' => [
        'callback' => [$this, 'callbackRebuildLocation'],
        'wrapper' => 'location',
        'keypress' => TRUE,
        'event' => 'click',
        'progress' => ['type' => 'none'],
      ],
      '#limit_validation_errors' => FALSE,
      '#attributes' => [
        'class' => [
          'button',
          'button--suffix',
          'button--style-blue',
          'spinner--right',
        ],
      ],
      '#validate' => [
        '::validateSuppressErrors',
        [$this, 'validateConfirmPostcode'],
      ],
      '#submit' => [
        '::submitStoreValues',
        [$this, 'submitConfirmPostcode'],
      ],
    ];

    // Render array to provide the 'Select your local authority' switch link.
    $form['postcode_switcher'] = [
      '#printed' => TRUE,
      '#type' => 'container',
      '#attributes' => [
        'class' => [
          'help-block',
        ],
      ],
      'text' => ['#markup' => $this->t('If you don’t know your postcode or would prefer, you can') . ' '],
      'switch' => [
        '#type' => 'submit',
        '#value' => $this->t("select your local authority"),
        '#attributes' => [
          'class' => [
            'button',
            'button--as-link',
            'spinner--right',
          ],
        ],
        '#limit_validation_errors' => [],
        '#ajax' => [
          'callback' => [$this, 'callbackRebuildLocation'],
          'wrapper' => 'location',
          'keypress' => TRUE,
          'event' => 'click',
          'progress' => ['type' => 'none'],
        ],
        '#submit' => [
          [$this, 'submitPostcodeEntryModeOff'],
        ],
      ],
    ];

    // Render array to provide the 'Change' postcode button.
    $form['postcode_verified_suffix'] = [
      '#printed' => TRUE,
      '#type' => 'submit',
      '#value' => $this->t('Change'),
      '#attributes' => [
        'class' => [
          'button',
          'button--suffix',
          'button--as-link',
          'spinner--right',
        ],
      ],
      '#limit_validation_errors' => [],
      '#ajax' => [
        'callback' => [$this, 'callbackRebuildLocation'],
        'wrapper' => 'location',
        'keypress' => TRUE,
        'event' => 'click',
        'progress' => ['type' => 'none'],
      ],
      '#submit' => [
        [$this, 'submitChangePostcode'],
      ],
    ];

    $form['authority_switcher'] = [
      '#printed' => TRUE,
      'description' => [
        '#type' => 'container',
        '#attributes' => [
          'class' => [
            'help-block',
          ],
        ],
        'text' => [
          '#markup' => $this->t('If you don’t know your local authority or would prefer, you can') . ' ',
        ],
        'switch' => [
          '#type' => 'submit',
          '#value' => $this->t('select your postcode'),
          '#attributes' => [
            'class' => [
              'button',
              'button--as-link',
              'spinner--right',
            ],
          ],
          '#limit_validation_errors' => [],
          '#ajax' => [
            'callback' => [$this, 'callbackRebuildLocation'],
            'wrapper' => 'location',
            'keypress' => TRUE,
            'event' => 'click',
            'progress' => ['type' => 'none'],
          ],
          '#submit' => [
            [$this, 'submitPostcodeEntryModeOn'],
          ],
        ],
      ],
    ];

    // $storage['postcode_entry_mode'] toggles between the
    // display of the postcode and local authority fields.
    // 1 = Show postcode field
    // 0 = Show local authority field.
    if ($storage['postcode_entry_mode'] == 1) {
      // If the API response set the postcode as verified.
      if ($storage['postcode_verified']) {
        // Set the local authority field to the api response.
        $form['location']['authority'] = [
          '#type' => 'hidden',
          '#title' => $this->t('Please select your local authority'),
          '#default_value' => isset($storage['values'][$storage['step']]['authority']) ? $storage['values'][$storage['step']]['authority'] : '',
        ];

        // Keep track of the postcode that was entered via a hidden field.
        $form['location']['postcode'] = [
          '#type' => 'hidden',
          '#title' => $this->t('Please enter your postcode'),
          '#default_value' => isset($storage['values'][$storage['step']]['postcode']) ? $storage['values'][$storage['step']]['postcode'] : '',
        ];

        // Show a disabled textfield that contains the verified postcode.
        $form['location']['postcode_verified'] = [
          '#type' => 'textfield',
          '#disabled' => TRUE,
          '#required' => TRUE,
          '#title' => $this->t('Please enter your postcode'),
          '#default_value' => isset($storage['values'][$storage['step']]['postcode']) ? $storage['values'][$storage['step']]['postcode'] : '',
          '#field_suffix' => &$form['postcode_verified_suffix'],
          '#advanced_description' => [
            'title' => $this->t('Why are we asking for this?'),
            'text' => $this->t('Your postcode or local authority will help us to provide programmes in your local area.'),
          ],
          '#width' => 'medium',
          '#attributes' => [
            'autocomplete' => 'off',
          ],
        ];
      }
      else {
        // If the postcode is not verified show an input field asking for it.
        $form['location']['postcode'] = [
          '#title' => $this->t('Please enter your postcode'),
          '#required' => TRUE,
          '#type' => 'textfield',
          '#default_value' => isset($storage['values'][$storage['step']]['postcode']) ? $storage['values'][$storage['step']]['postcode'] : '',
          '#description' => $this->t('For example, SW1A 2AA'),
          '#description_display' => 'before',
          '#advanced_description' => [
            'title' => $this->t('Why are we asking for this?'),
            'text' => $this->t('Your postcode or local authority will help us to provide programmes in your local area.'),
          ],
          '#width' => 'medium',
          '#field_suffix' => &$form['postcode_suffix'],
          '#information' => &$form['postcode_switcher'],
          '#limit_validation_errors' => [],
          '#required_error' => $this->t("Invalid postcode format. We can't find your postcode. Please try again or select your Local Authority"),
          '#element_validate' => [
            [$this, 'validatePostcode'],
          ],
          '#attributes' => [
            'autocomplete' => 'off',
          ],
        ];
      }
    }
    else {
      // Show the local authority field ($storage['postcode_entry_mode'] = 0).
      $form['location']['authority'] = [
        '#title' => $this->t('Please select your local authority'),
        '#required' => TRUE,
        '#type' => 'select',
        '#options' => $this->eagBridge->getLocalAuthorities(),
        '#advanced_description' => [
          'title' => $this->t('Why are we asking for this?'),
          'text' => $this->t('Your postcode or local authority will help us to provide programmes in your local area.'),
        ],
        '#width' => 'medium',
        '#empty_option' => $this->t('Please select'),
        '#default_value' => isset($storage['values'][$storage['step']]['authority']) ? $storage['values'][$storage['step']]['authority'] : NULL,
        '#information' => &$form['authority_switcher'],
        '#required_error' => $this->t('Please select your Local Authority'),
        '#attributes' => [
          'autocomplete' => 'off',
        ],
      ];
    }

    // Gender question.
    $form['gender'] = [
      '#title' => $this->t('Tell us your gender'),
      '#required' => TRUE,
      '#type' => 'radios',
      '#options' => $this->eagBridge->getGenders(),
      '#default_value' => isset($storage['values'][$storage['step']]['gender']) ? $storage['values'][$storage['step']]['gender'] : NULL,
      '#description' => '',
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Some programmes have specific eligibility which could include gender.'),
      ],
      '#required_error' => $this->t('Please select one of the options'),
    ];

    // Ethnicity question.
    $form['ethnicity'] = [
      '#title' => $this->t('What is your ethnic group?'),
      '#required' => TRUE,
      '#type' => 'select',
      '#options' => $this->eagBridge->getEthnicGroups(),
      '#default_value' => isset($storage['values'][$storage['step']]['ethnicity']) ? $storage['values'][$storage['step']]['ethnicity'] : NULL,
      '#empty_option' => $this->t('Select ethnic group'),
      '#description' => '',
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Some programmes have specific eligibility which could include ethnicity.'),
      ],
      '#width' => 'medium',
      '#required_error' => $this->t('Please enter your ethnic group'),
      '#attributes' => [
        'autocomplete' => 'off',
      ],
    ];

    $form['start_business'] = [
      '#title' => $this->t('Are you interested in starting a business?'),
      '#type' => 'radios',
      '#options' => $this->eagBridge->getYesNo(),
      '#default_value' => isset($storage['values'][$storage['step']]['start_business']) ? $storage['values'][$storage['step']]['start_business'] : NULL,
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Some programmes are to support those starting a business'),
      ],
      '#required' => TRUE,
      '#required_error' => $this->t('Please select whether you are interested in starting your own business.'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {}

  /**
   * Rebuilds the location question wrapper.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   *
   * @return mixed
   *   The location wrapper.
   */
  public function callbackRebuildLocation(array &$form, FormStateInterface $form_state) {
    return $form['location'];
  }

  /**
   * Validates the postcode question.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validatePostcode(array &$element, FormStateInterface $form_state, array &$form) {
    $postcode = $form_state->getValue('postcode');
    $postcode_check = $this->eagBridge->isValidPostcode($postcode);

    if (empty($postcode_check)) {
      $form_state->setErrorByName('postcode', $this->t("Invalid postcode format. We can't find your postcode. Please try again or select your local authority. If you live outside Wales but work in Wales please contact Careers Wales on 0800 028 4844."));
    }
    else {
      $storage = $form_state->getStorage();
      $storage['postcode_verified'] = 1;

      $form_state->setStorage($storage);
      $form_state->setValue('postcode_verified', $postcode);
      $form_state->setValue('authority', $postcode_check['localAuthorityCode']);
    }
  }

  /**
   * Validates the confirm postcode button.
   *
   * @param array $form
   *   The complete form structure.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function validateConfirmPostcode(array &$form, FormStateInterface $form_state) {
    $postcode = $form_state->getValue('postcode');
    $postcode_check = $this->eagBridge->isValidPostcode($postcode);

    if (empty($postcode_check)) {
      $form['#disable_inline_form_errors_summary'] = TRUE;
      $form_state->setErrorByName('postcode', $this->t("Invalid postcode format. We can't find your postcode. Please try again or select your local authority. If you live outside Wales but work in Wales please contact Careers Wales on 0800 028 4844."));
    }
    else {
      $form_state->setValue('authority', $postcode_check['localAuthorityCode']);
    }
  }

  /**
   * Sets the stored verified postcode flag to true.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitConfirmPostcode(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['postcode_verified'] = 1;

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Sets the stored postcode entry mode flag to true.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitPostcodeEntryModeOn(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['postcode_entry_mode'] = 1;

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Sets the stored postcode entry mode flag to false.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitPostcodeEntryModeOff(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['postcode_entry_mode'] = 0;

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Sets the stored verified postcode flag to false.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   */
  public function submitChangePostcode(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['postcode_verified'] = 0;

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

}
