<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Core\Url;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides an object for a form step.
 */
class StepSix extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Programme Details');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    $language = $this->languageManager;
    $language = $language->getCurrentLanguage()->getId();
    $callback_nid = \Drupal::config('careerswales_eag.settings')
      ->get('callback_page');

    $storage = $form_state->getStorage();

    $programme_key = 0;
    foreach ($storage['programmes'] as $key => $programme) {
      if ($programme['id'] == $storage['programme']) {
        $programme_key = $key;
      }
    }

    $programme = $storage['programmes'][$programme_key];

    $form['favourite_' . $programme_key] = [
      '#printed' => TRUE,
      'change' => [
        '#type' => 'submit',
        '#value' => $this->t('Add to favourites'),
        '#name' => 'favourite_' . $programme_key,
        '#programme' => $programme_key,
        '#attributes' => [
          'class' => [
            'button',
            'button--secondary',
            'button--icon',
            'icon--star-outline',
            'spinner--right',
          ],
        ],
        '#limit_validation_errors' => [],
        '#ajax' => [
          'callback' => [$this, 'rebuildResultPage'],
          'wrapper' => 'programme-wrapper',
          'keypress' => TRUE,
          'event' => 'click',
          'progress' => ['type' => 'none'],
        ],
        '#submit' => [
          [$this, 'submitAddToFavourites'],
        ],
      ],
    ];

    $form['unfavourite_' . $programme_key] = [
      '#printed' => TRUE,
      'change' => [
        '#type' => 'submit',
        '#value' => $this->t('Remove from favourites'),
        '#name' => 'unfavourite_' . $programme_key,
        '#programme' => $programme_key,
        '#attributes' => [
          'class' => [
            'button',
            'button--secondary',
            'button--icon',
            'icon--star',
            'spinner--right',
          ],
        ],
        '#limit_validation_errors' => [],
        '#ajax' => [
          'callback' => [$this, 'rebuildResultPage'],
          'wrapper' => 'programme-wrapper',
          'keypress' => TRUE,
          'event' => 'click',
          'progress' => ['type' => 'none'],
        ],
        '#submit' => [
          [$this, 'submitRemoveFromFavourites'],
        ],
      ],
    ];

    $form['contact'] = [
      '#printed' => TRUE,
      '#type' => 'submit',
      '#value' => $this->t('Email us via our online form'),
      '#extra' => '',
      '#validate' => ['::validateContactApiAvailable'],
      '#submit' => ['::submitNext'],
      '#attributes' => [
        'class' => [
          'link--large',
          'button--as-link',
          'style--icon-email',
        ],
      ],
    ];

    if (is_null($callback_nid)) {
      // Just as a fallback in case no node has been selected.
      $form['callback_webform_link'] = NULL;
    }
    else {
      $form['callback_webform_link'] = [
        '#printed' => TRUE,
        '#markup' => Url::fromRoute('entity.node.canonical', ['node' => $callback_nid])->toString(),
      ];
    }

    if (isset($programme['id'])) {
      $pdf_file_size = $this->eagBridge->getPdf($programme['id'], $language);
      $pdf_file_size = $pdf_file_size->getHeader('Content-Length');
      $pdf_file_size = format_size($pdf_file_size[0]);
      $pdf_file_size = $pdf_file_size->__toString();
    }
    else {
      $pdf_file_size = '';
    }

    $form['programme'] = [
      '#theme' => 'eag_programme_detailed',
      '#title' => isset($programme['name'][$language]) ? $programme['name'][$language] : '',
      '#description' => isset($programme['description'][$language]) ? $programme['description'][$language] : '',
      '#location' => isset($programme['location'][$language]) ? $programme['location'][$language] : '',
      '#eligibility' => isset($programme['eligibilityCriteriaSummary'][$language]) ? $programme['eligibilityCriteriaSummary'][$language] : '',
      '#how_would_i_benefit' => isset($programme['howWouldIBenefit'][$language]) ? $programme['howWouldIBenefit'][$language] : '',
      '#additional_info' => isset($programme['additionalInformation'][$language]) ? $programme['additionalInformation'][$language] : '',
      '#funded_by' => isset($programme['fundedByESF'][$language]) ? $programme['fundedByESF'][$language] : '',
      '#provided_by' => isset($programme['providedBy'][$language]) ? $programme['providedBy'][$language] : '',
      '#support_available' => isset($programme['supportAvailable'][$language]) ? $programme['supportAvailable'][$language] : '',
      '#duration' => isset($programme['duration'][$language]) ? $programme['duration'][$language] : '',
      '#cost' => isset($programme['cost'][$language]) ? $programme['cost'][$language] : '',
      '#favourite' => &$form['unfavourite_' . $programme_key],
      '#programme_id' => $programme['id'],
      '#file_size' => $pdf_file_size,
      '#contact' => $form['contact'],
      '#callback_webform_link' => $form['callback_webform_link'],
      '#lang_id' => $language,
    ];

    if (isset($storage['favourites'][$programme_key])) {
      $form['programme']['#favourite'] = &$form['unfavourite_' . $programme_key];
    }
    else {
      $form['programme']['#favourite'] = &$form['favourite_' . $programme_key];
    }

    $form['#suffix'] = '<div id="live-chat-no-js"><noscript><a href="https://www.livechatinc.com/chat-with/10272469/">Chat with us</a>, powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener" target="_blank">LiveChat</a></noscript></div>';


    $form['#attributes']['class'][] = 'form--double-back';
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {
    unset($form['progress_bar']);
    unset($form['header']['title']);
    unset($form['header']['required']);
    unset($form['actions']['next']);
  }

  /**
   * Adds a programme to your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitAddToFavourites(array &$form, FormStateInterface $form_state) {

    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Save to favourites.
    $storage['favourites'][$triggering_element['#programme']] = $triggering_element['#programme'];

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Removes a programme from your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitRemoveFromFavourites(array &$form, FormStateInterface $form_state) {

    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Delete from favourites.
    unset($storage['favourites'][$triggering_element['#programme']]);

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Ajax submit callback to rebuild the results page.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   *
   * @return mixed
   *   The results part of the form.
   */
  public function rebuildResultPage(array &$form, FormStateInterface $form_state) {
    $form_state->clearErrors();
    return $form['programme'];
  }

}
