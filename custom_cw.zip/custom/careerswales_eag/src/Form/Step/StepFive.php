<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Provides an object for a form step.
 */
class StepFive extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Results');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    $storage = $form_state->getStorage();
    $language = $this->languageManager;

    $language = $language->getCurrentLanguage()->getId();

    // Remove unnecessary title from this step.
    unset($form['header']['title']);

    $programmes = $this->eagBridge->getProgrammesByEligibility($storage['values']);

    $this->renderSearchCriteria($form, $form_state);

    // Results page.
    $form['tabs'] = [
      '#type' => 'horizontal_tabs',
      '#tree' => TRUE,
      '#prefix' => '<div id="results">',
      '#suffix' => '</div>',
      '#group_name' => 'results',
      '#entity_type' => 'node',
      '#bundle' => 'page',
    ];

    $form['tabs']['results'] = [
      '#type' => 'details',
      '#title' => $this->t('Results'),
      '#description' => '',
      '#summary_description' => '',
      '#summary_title' => $this->t('Results'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    ];

    $form['tabs']['results']['content'] = [
      '#markup' => $this->eagBridge->getResultsIntroductionText(),
    ];

    $form['tabs']['results']['content']['save'] = [
      '#markup' => '<p class="notice notice--info-icon">' . $this->t('Important - Adding to favourites allows you to download all your favourites in one PDF. Your favourites will not save after you close the window.') . '</p>',
    ];

    $form['tabs']['results']['content']['overview'] = [
      '#markup' => '<div class="results-counter"><span class="results-counter__count">' . count($programmes) . '</span>' . $this->t('results') . '</div>',
    ];

    foreach ($programmes as $key => $programme) {
      $form['tabs']['favourite_' . $key] = [
        '#printed' => TRUE,
        'change' => [
          '#type' => 'submit',
          '#value' => $this->t('Add to favourites'),
          '#extra' => new FormattableMarkup(' <span class="visually-hidden">@text</span>', ['@text' => t('for') . ' ' . $programme['name'][$language]]),
          '#name' => 'favourite_' . $key,
          '#programme' => $key,
          '#attributes' => [
            'class' => [
              'button',
              'button--secondary',
              'button--icon',
              'icon--star-outline',
              'spinner--left',
            ],
          ],
          '#limit_validation_errors' => [],
          '#ajax' => [
            'callback' => [$this, 'rebuildResultsPage'],
            'wrapper' => 'results',
            'keypress' => TRUE,
            'event' => 'click',
            'progress' => ['type' => 'none'],
          ],
          '#submit' => [
            [$this, 'submitAddToFavourites'],
          ],
        ],
      ];

      $form['tabs']['unfavourite_' . $key] = [
        '#printed' => TRUE,
        'change' => [
          '#type' => 'submit',
          '#value' => $this->t('Remove from favourites'),
          '#extra' => new FormattableMarkup(' <span class="visually-hidden">@text</span>', ['@text' => t('for') . ' ' . $programme['name'][$language]]),
          '#name' => 'unfavourite_' . $key,
          '#programme' => $key,
          '#attributes' => [
            'class' => [
              'button',
              'button--secondary',
              'button--icon',
              'icon--star',
              'spinner--left',
            ],
          ],
          '#limit_validation_errors' => [],
          '#ajax' => [
            'callback' => [$this, 'rebuildResultsPage'],
            'wrapper' => 'results',
            'keypress' => TRUE,
            'event' => 'click',
            'progress' => ['type' => 'none'],
          ],
          '#submit' => [
            [$this, 'submitRemoveFromFavourites'],
          ],
        ],
      ];

      $form['tabs']['apply_' . $key] = [
        '#printed' => TRUE,
        'change' => [
          '#type' => 'submit',
          '#value' => $this->t('Find out how to apply'),
          '#extra' => new FormattableMarkup(' <span class="visually-hidden">@text</span>', ['@text' => t('for') . ' ' . $programme['name'][$language]]),
          '#name' => 'apply_' . $key,
          '#programme' => $programme['id'],
          '#attributes' => [
            'class' => [
              'button',
              'button--primary',
              'button--icon',
              'icon--chevron-right',
            ],
          ],
          '#limit_validation_errors' => [],
          '#submit' => [
            [$this, 'submitProgramme'],
          ],
        ],
      ];

      $form['tabs']['results']['content'][$key] = [
        '#theme' => 'eag_programme',
        '#title' => isset($programme['name'][$language]) ? $programme['name'][$language] : '',
        '#provided_by' => isset($programme['providedBy'][$language]) ? $programme['providedBy'][$language] : '',
        '#location' => isset($programme['location'][$language]) ? $programme['location'][$language] : '',
        '#support_available' => isset($programme['supportAvailable'][$language]) ? $programme['supportAvailable'][$language] : '',
        '#duration' => isset($programme['duration'][$language]) ? $programme['duration'][$language] : '',
        '#cost' => isset($programme['cost'][$language]) ? $programme['cost'][$language] : '',
        '#favourite' => &$form['tabs']['favourite_' . $key],
        '#apply' => &$form['tabs']['apply_' . $key],
      ];

      // Render a favourite or unfavourite button.
      if (isset($storage['favourites'][$key])) {
        $form['tabs']['results']['content'][$key]['#favourite'] = &$form['tabs']['unfavourite_' . $key];
      }
      else {
        $form['tabs']['results']['content'][$key]['#favourite'] = &$form['tabs']['favourite_' . $key];
      }

    }

    /*$form['tabs']['results']['content']['load_more'] = [
    '#type' => 'button',
    '#value' => $this->t('Show more results'),
    '#attributes' => [
    'class' => [
    'button',
    'button--icon',
    'button--style-blue',
    'icon--plus',
    ],
    'onclick' => 'return false;',
    ],
    ];*/

    $count = isset($storage['favourites']) ? ' (' . count($storage['favourites']) . ')' : '';

    $form['tabs']['favourites'] = [
      '#type' => 'details',
      '#title' => $this->t('Favourites') . $count,
      '#description' => '',
      '#summary_description' => '',
      '#summary' => '',
      '#summary_title' => 'Favourites',
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    ];
    $form['tabs']['favourites']['contact'] = [
      '#printed' => TRUE,
      '#type' => 'submit',
      '#value' => $this->t('Email us via our online form'),
      '#extra' => '',
      '#submit' => [
        [$this, 'submitContactForm'],
      ],
      '#validate' => [
        '::validateSuppressErrors',
        '::validateContactApiAvailable',
      ],
      '#attributes' => [
        'class' => [
          'link--large',
          'button--as-link',
          'style--icon-email',
        ],
      ],
    ];

    $form['tabs']['favourites']['content'] = [
      '#markup' => $this->eagBridge->getFavouritesIntroductionText(),
    ];

    if (empty($storage['favourites'])) {
      $form['tabs']['favourites']['content']['empty'] = [
        '#markup' => '<p class="notice notice--info-icon">' . $this->t("You don't currently have any favourites.") . '</p>',
      ];
    }

    if (isset($storage['favourites']) && count($storage['favourites']) > 0) {
      $form['tabs']['favourites']['content']['save'] = [
        '#markup' => '<p class="notice notice--info-icon">' . $this->t('Important - Adding to favourites allows you to download all your favourites in one PDF. Your favourites will not save after you close the window.') . '</p>',
      ];
    }

    foreach ($programmes as $key => $programme) {
      if (isset($storage['favourites'])) {
        if (in_array($key, $storage['favourites'])) {
          $form['tabs']['favourites']['content'][$key] = [
            '#theme' => 'eag_programme',
            '#title' => isset($programme['name'][$language]) ? $programme['name'][$language] : '',
            '#provided_by' => isset($programme['providedBy'][$language]) ? $programme['providedBy'][$language] : '',
            '#location' => isset($programme['location'][$language]) ? $programme['location'][$language] : '',
            '#support_available' => isset($programme['supportAvailable'][$language]) ? $programme['supportAvailable'][$language] : '',
            '#duration' => isset($programme['duration'][$language]) ? $programme['duration'][$language] : '',
            '#cost' => isset($programme['cost'][$language]) ? $programme['cost'][$language] : '',
            '#favourite' => &$form['tabs']['unfavourite_' . $key],
            '#apply' => &$form['tabs']['apply_' . $key],
          ];
        }
      }
    }

    if (isset($storage['favourites_pdf'])) {
      $pdf_file_size = $this->eagBridge->getPdf(implode(",", $storage['favourites_pdf']), $language);
      if (!is_null($pdf_file_size)) {
        $pdf_file_size = $pdf_file_size->getHeader('Content-Length');
        $pdf_file_size = format_size($pdf_file_size[0]);
        $pdf_file_size = $pdf_file_size->__toString();
      }
      else {
        $pdf_file_size = '';
      }
    }
    else {
      $pdf_file_size = '';
    }

    $callback_nid = \Drupal::config('careerswales_eag.settings')
      ->get('callback_page');
    if (is_null($callback_nid)) {
      // Just as a fallback in case no node has been selected.
      $form['callback_webform_link'] = NULL;
    }
    else {
      $form['callback_webform_link'] = [
        '#printed' => TRUE,
        '#markup' => Url::fromRoute('entity.node.canonical', ['node' => $callback_nid])->toString(),
      ];
    }

    if (isset($storage['favourites']) && count($storage['favourites']) > 0) {
      $form['tabs']['favourites']['content']['summary'] = [
        '#theme' => 'favourites_tab_content',
        '#favourites_pdf_ids' => implode(",", $storage["favourites_pdf"]),
        '#favourites_pdf_size' => $pdf_file_size,
        '#favourites_footer_text' => $this->eagBridge->getFavouritesFooterText(),
        '#contact' => $form['tabs']['favourites']['contact'],
        '#callback_webform_link' => $form['callback_webform_link'],
        '#lang_id' => $language,
      ];
    }

    $storage['programmes'] = $programmes;
    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);

    $form['tabs']['#groups']['results'] = [0 => []];


    $form['#attached']['library'][] = 'field_group/formatter.horizontal_tabs';

  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {
    unset($form['header']);
    unset($form['actions']['next']);
    $form['actions']['previous']['#attributes']['class'][] = 'visually-hidden';
  }

  /**
   * Moves to the next step of the form.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitContactForm(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $storage['step']++;
    $storage['step']++;

    $form_state->setStorage($storage);

    if (!$form_state->getRedirect()) {
      $form_state->setRebuild(TRUE);
    }
  }

  /**
   * Render the search criteria specified by the user.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   */
  public function renderSearchCriteria(array &$form, FormStateInterface $form_state) {
    $storage = $form_state->getStorage();

    $responses = $storage['responses'];

    $change_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', ['@text' => t('to question step')]);

    $change_button = [
      '#printed' => TRUE,
      '#type' => 'submit',
      '#value' => $this->t('Change'),
      '#submit' => ['::submitChangeStep'],
      '#validate' => ['::validateSuppressErrors'],
      '#extra' => $change_button_text,
      '#attributes' => [
        'class' => [
          'button',
          'button--as-link',
        ],
      ],
    ];

    $items = [];

    if (isset($responses[2]['postcode'])) {
      unset($responses[2]['authority']);
    }

    foreach ($responses as $step => $fields) {
      foreach ($fields as $key => $response) {
        $button_id = 'change_' . $key;

        $form[$button_id] = $change_button;
        $form[$button_id]['#name'] = $button_id;
        $form[$button_id]['#target'] = $step;

        $items[] = [
          '#theme' => 'eag_response',
          '#question' => $response['question'],
          '#answer' => $response['answer'],
          '#call_to_action' => $form[$button_id],
        ];
      }
    }

    $form['criteria'] = [
      '#type' => 'details',
      '#title' => $this->t('View and edit your details'),
      'items' => $items,
    ];

    $restart_button_text = new FormattableMarkup('<span class="visually-hidden">@text</span>', ['@text' => t('restart the form')]);

    $form['criteria']['restart'] = [
      '#type' => 'submit',
      '#value' => $this->t('Start again'),
      '#target' => 1,
      '#submit' => [
        '::submitFlushStorage',
        '::submitChangeStep',
      ],
      '#validate' => ['::validateSuppressErrors'],
      '#extra' => $restart_button_text,
      '#attributes' => [
        'class' => [
          'button',
          'button--secondary',
          'button--icon',
          'icon--left',
          'icon--chevron-left',
        ],
      ],
    ];
  }

  /**
   * Adds a programme to your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitProgramme(array &$form, FormStateInterface $form_state) {
    // Check to make sure that a redirect has not already been set.
    if ($form_state->getRedirect()) {
      return;
    }

    $storage = $form_state->getStorage();
    $triggering_element = $form_state->getTriggeringElement();

    // Store the form values for the current step.
    $storage['values'][$storage['step']] = $form_state->getValues();
    // Programme id.
    $storage['programme'] = $triggering_element['#programme'];

    // Increment the form state.
    $storage['step']++;

    $form_state->setStorage($storage);

    $form_state->setRebuild(TRUE);
  }

  /**
   * Ajax submit callback to rebuild the results page.
   *
   * @param array $form
   *   Form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Form state.
   *
   * @return mixed
   *   The results part of the form.
   */
  public function rebuildResultsPage(array &$form, FormStateInterface $form_state) {
    $form_state->clearErrors();
    return $form['tabs'];
  }

  /**
   * Adds a programme to your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitAddToFavourites(array &$form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Save to favourites.
    $storage['favourites'][$triggering_element['#programme']] = $triggering_element['#programme'];

    $storage['favourites_pdf'][$triggering_element['#programme']] = $storage['programmes'][$triggering_element['#programme']]['id'];

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Removes a programme from your favourites.
   *
   * @param array $form
   *   Form render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of the form.
   */
  public function submitRemoveFromFavourites(array &$form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    $storage = $form_state->getStorage();

    // Delete from favourites.
    unset($storage['favourites'][$triggering_element['#programme']]);
    unset($storage['favourites_pdf'][$triggering_element['#programme']]);

    $form_state->setStorage($storage);
    $form_state->setRebuild(TRUE);
  }

}
