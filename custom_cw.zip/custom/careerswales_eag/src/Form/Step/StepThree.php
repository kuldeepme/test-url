<?php

namespace Drupal\careerswales_eag\Form\Step;

use Drupal\careerswales_forms\Form\Step\FormStepBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides an object for a form step.
 */
class StepThree extends FormStepBase {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->t('Employment and Qualifications');
  }

  /**
   * {@inheritdoc}
   */
  public function buildStep(array &$form, FormStateInterface &$form_state) {
    // Load the storage data we track 'step' and question responses in 'values'.
    $storage = $form_state->getStorage();

    // Employment status question.
    $form['employment_status'] = [
      '#type' => 'select',
      '#title' => $this->t('What is your employment status?'),
      '#empty_option' => $this->t('Select your employment status'),
      '#options' => $this->eagBridge->getEmploymentStatus(),
      '#default_value' => isset($storage['values'][$storage['step']]['employment_status']) ? $storage['values'][$storage['step']]['employment_status'] : '',
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Your eligibility for some programmes will vary depending on your employment status'),
      ],
      '#width' => 'large',
      '#required' => TRUE,
      '#required_error' => $this->t('Please select your Employment Status'),
      '#attributes' => [
        'autocomplete' => 'off',
      ],
    ];

    // Redundancy question.
    $form['redundancy'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Redundancy?'),
      '#options' => [
        'REDUNDANT' => $this->t('I have been made redundant in the last three months or am under notice of redundancy'),
      ],
      '#default_value' => isset($storage['values'][$storage['step']]['redundancy']) ? $storage['values'][$storage['step']]['redundancy'] : [],
      '#description' => $this->t('Please check the box if the following statement is true for you:'),
      '#description_display' => 'before',
      '#states' => [
        'visible' => [
          ':input[name="employment_status"]' => [
            ['value' => 'EMPLOYED_FULL_TIME_MORE_16HRS'],
            ['value' => 'EMPLOYED_LESS_16HRS'],
            ['value' => 'EMPLOYED_0HR_CONTRACT'],
            ['value' => 'UNEMPLOYED_LESS_THAN_6_MONTHS'],
          ],
        ],
      ],
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('There may be specific support available if you are facing or have been made redundant in the last 3 months'),
      ],
    ];

    // Sector question.
    $form['sector'] = [
      '#type' => 'select',
      '#title' => $this->t('What sector do you work in?'),
      '#empty_option' => $this->t('Select Employment Sector'),
      '#options' => $this->eagBridge->getEmploymentSectors(),
      '#default_value' => isset($storage['values'][$storage['step']]['sector']) ? $storage['values'][$storage['step']]['sector'] : '',
      '#description' => $this->t('Please select the one that is the closest match'),
      '#description_display' => 'before',
      '#states' => [
        'visible' => [
          ':input[name="employment_status"]' => [
            ['value' => 'EMPLOYED_FULL_TIME_MORE_16HRS'],
            ['value' => 'EMPLOYED_LESS_16HRS'],
            ['value' => 'EMPLOYED_0HR_CONTRACT'],
            ['value' => 'SELF_EMPLOYED'],
          ],
        ],
        'required' => [
          ':input[name="employment_status"]' => [
            ['value' => 'EMPLOYED_FULL_TIME_MORE_16HRS'],
            ['value' => 'EMPLOYED_LESS_16HRS'],
            ['value' => 'EMPLOYED_0HR_CONTRACT'],
            ['value' => 'SELF_EMPLOYED'],
          ],
        ],
      ],
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Eligibility for some programmes depends on the sector of the company you work for. If you are self employed select the sector of your business.'),
      ],
      '#element_validate' => [
        [$this, 'validateSector'],
      ],
      '#attributes' => [
        'autocomplete' => 'off',
      ],
    ];

    // Education status question.
    $form['education_status'] = [
      '#type' => 'radios',
      '#title' => $this->t('What is your training or educational status?'),
      '#options' => $this->eagBridge->getEducationStatus(),
      '#default_value' => isset($storage['values'][$storage['step']]['education_status']) ? $storage['values'][$storage['step']]['education_status'] : NULL,
      '#description' => $this->t('Please select the response that best applies'),
      '#description_display' => 'before',
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Eligibility for some programmes varies according to your training status'),
      ],
      '#required' => TRUE,
      '#required_error' => $this->t('Please select the option that best describes your training or educational status.'),
    ];

    // Education institution question.
    $form['education_institution'] = [
      '#type' => 'select',
      '#title' => $this->t('What type of educational institution are you studying at?'),
      '#empty_option' => $this->t('Select educational institution'),
      '#options' => $this->eagBridge->getEducationInstitutions(),
      '#default_value' => isset($storage['values'][$storage['step']]['education_institution']) ? $storage['values'][$storage['step']]['education_institution'] : '',
      '#states' => [
        'visible' => [
          [':input[name="employment_status"]' => ['value' => 'IN_EDUCATION']],
          [':input[name="education_status"]' => ['value' => 'FULL_TIME_TRAINING_OR_EDUCATION']],
        ],
        'required' => [
          [':input[name="employment_status"]' => ['value' => 'IN_EDUCATION']],
          [':input[name="education_status"]' => ['value' => 'FULL_TIME_TRAINING_OR_EDUCATION']],
        ],
      ],
      '#advanced_description' => [
        'title' => $this->t('Why are we asking for this?'),
        'text' => $this->t('Eligibility for some programmes varies depending on the type of educational institution you are studying at'),
      ],
      '#element_validate' => [
        [$this, 'validateEducationInstitution'],
      ],
      '#width' => 'medium',
      '#attributes' => [
        'autocomplete' => 'off',
      ],
    ];

    // Qualification question.
    $form['qualification'] = [
      '#title' => $this->t('What is your highest qualification level?'),
      '#type' => 'radios',
      '#options' => $this->eagBridge->getQualificationLevels(),
      '#default_value' => isset($storage['values'][$storage['step']]['qualification']) ? $storage['values'][$storage['step']]['qualification'] : NULL,
      '#description' => $this->t('Check the box that best applies'),
      '#description_display' => 'before',
      '#element_validate' => [
        [$this, 'validateQualifications'],
      ],
      '#required' => TRUE,
      '#required_error' => $this->t('Please select your highest qualification level'),
    ];

    // Add the radio button descriptions.
    $form['qualification']['NO_FORMAL']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => $this->t('You may have experience and skills and/or training on the job, but not gained certificates through an education or training provider.'),
    ];

    $form['qualification']['ENTRY_LEVEL']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Entry level award</li><li>Entry level certificate (ELC)</li><li>Entry level diploma</li><li>Entry level essential skills</li><li>Entry level functional skills </li><li>Skills for Life</li><li>Entry level (ESOL)</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_1']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>GCSE - grade D, E, F or G</li><li>First certificate</li><li>Level 1 award, certificate or diploma </li><li>Level 1 ESOL </li><li>Level 1 essential skills </li><li>Level 1 functional skills</li><li>Music grades 1, 2 and 3</li><li>Level 1 NVQ</li><li>Foundation Welsh Baccalaureate</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_2']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>CSE - grade 1</li><li>GCSE - grade A*, A, B or C </li><li>Foundation Apprenticeship</li><li>Level 2 award, certificate or diploma</li><li>Level 2 ESOL</li><li>Level 2 essential skills</li><li>Level 2 functional skills</li><li>Level 2 national certificate</li><li>National Welsh Baccalaureate</li><li>Level 2 national diploma</li><li>Level 2 NVQ</li><li>Level 2 QCF</li><li>O level - grade A, B or C</li><li>Music grades 4 and 5</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_3']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>A level - grade A, B, C, D or E</li><li>Access to higher education diploma</li><li>Apprenticeship/Advanced Apprenticeship</li><li>AS level</li><li>Advanced Welsh Baccalaureate</li><li>International Baccalaureate Diploma</li><li>Level 3 award, certificate or diploma</li><li>Level 3 QCF</li><li>Level 3 ESOL</li><li>Level 3 national certificate</li><li>Level 3 national diploma</li><li>Level 3 NVQ</li><li>Music grades 6, 7 and 8</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_4']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Certificate of higher education (CertHE)</li><li>Higher national certificate (HNC)</li><li>Level 4 award, certificate or diploma</li><li>Level 4 NVQ</li><li>Level 4 QCF</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_5']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Diploma of higher education (DipHE)</li><li>Foundation degree</li><li>Higher national diploma (HND)</li><li>Level 5 award, certificate or diploma</li><li>Level 5 NVQ</li><li>Level 5 QCF</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_6']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Honours Degree</li><li>Degree Apprenticeship</li><li>Graduate Certificate</li><li>Graduate diploma</li><li>Level 6 award, certificate or diploma</li><li>Level 6 NVQ</li><li>Degree (without honours)</li><li>Level 6 QCF</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_7']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Masters Degree (e.g.MA, MSc)</li><li>Postgraduate certificate</li><li>Postgraduate certificate in education (PGCE)</li><li>Postgraduate diploma</li></ul>'),
      ],
    ];

    $form['qualification']['LEVEL_8']['#advanced_description'] = [
      'title' => $this->t('View more examples'),
      'text' => [
        '#markup' => $this->t('<ul><li>Doctorate (e.g. PhD or DPhil)</li><li>Level 8 Award, Certificate or Diploma</li></ul>'),
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function override(array &$form, FormStateInterface &$form_state) {}

  /**
   * Validates that an option was selected for the sector question.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validateSector(array &$element, FormStateInterface $form_state, array &$form) {
    $employment_status = $form_state->getValue('employment_status');

    if (in_array($employment_status, [
      'EMPLOYED_FULL_TIME_MORE_16HRS',
      'EMPLOYED_LESS_16HRS',
      'EMPLOYED_0HR_CONTRACT',
      'SELF_EMPLOYED',
    ])) {
      if (empty($element['#value'])) {
        $form_state->setError($element, $this->t('Please select the sector of the company that employs you or, if self employed, select the sector of your business. (Select the closest match)'));
      }
    }
  }

  /**
   * Validates the education institution question.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validateEducationInstitution(array &$element, FormStateInterface $form_state, array &$form) {
    $employment_status = $form_state->getValue('employment_status');
    $education_status = $form_state->getValue('education_status');

    if ($employment_status == 'IN_EDUCATION' || $education_status == 'FULL_TIME_TRAINING_OR_EDUCATION') {
      if (empty($element['#value'])) {
        $form_state->setError($element, $this->t('Please select the type of educational institution'));
      }
    }
  }

  /**
   * Validates that an option was selected for the qualifications question.
   *
   * @param array $element
   *   The form element to process.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $form
   *   The complete form structure.
   */
  public function validateQualifications(array &$element, FormStateInterface $form_state, array &$form) {
    $education_institution = $form_state->getValue('education_institution');

    if (in_array($education_institution, [
      'IN_SCHOOL',
      'IN_FURTHER_EDUCATION',
      'IN_HIGHER_EDUCATION',
      'TRAINING_PROVIDER',
    ])) {
      if (empty($element['#value'])) {
        $form_state->setError($element, $this->t('Please select your highest qualification level'));
      }
    }
  }

}
