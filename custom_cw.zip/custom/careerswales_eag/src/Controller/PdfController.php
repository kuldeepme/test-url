<?php

namespace Drupal\careerswales_eag\Controller;

use Drupal\careerswales_eag\EagBridgeInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Language\LanguageManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * My module basic settings.
 */
class PdfController extends ControllerBase {

  /**
   * The EAG bridge class.
   *
   * @var object
   */
  protected $eagBridge;

  /**
   * The language manager class.
   *
   * @var object
   */
  protected $languageManager;

  /**
   * The current request.
   *
   * @var object
   */
  protected $currentRequest;

  /**
   * PdfController constructor.
   *
   * @param \Drupal\careerswales_eag\EagBridgeInterface $eag_bridge
   *   EAG bridge interface.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   Language manager interface.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   Request stack class.
   */
  public function __construct(EagBridgeInterface $eag_bridge, LanguageManagerInterface $language_manager, RequestStack $request_stack) {
    $this->eagBridge = $eag_bridge;
    $this->languageManager = $language_manager;
    $this->currentRequest = $request_stack->getCurrentRequest();
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('careerswales_eag.bridge'),
      $container->get('language_manager'),
      $container->get('request_stack')
    );
  }

  /**
   * Builds the PDF file from the programmes.
   *
   * @return mixed
   *   The generated PDF.
   */
  public function buildPdf() {
    $ids = $this->currentRequest->query->get('programmes');
    $language = $this->currentRequest->query->get('language');

    header('Content-Type: application/pdf');

    return $this->eagBridge->getPdf($ids, $language);
  }

}
