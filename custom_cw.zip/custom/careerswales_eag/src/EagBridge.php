<?php

namespace Drupal\careerswales_eag;

use Drupal\careerswales_api\ApiInterface;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * The Careers Wales EAG bridge class.
 */
class EagBridge implements EagBridgeInterface {

  use StringTranslationTrait;

  protected $configFactory;
  protected $language;
  protected $api;

  /**
   * Eag constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   Language manager interface.
   * @param \Drupal\careerswales_api\ApiInterface $api
   *   API interface.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LanguageManagerInterface $language_manager, ApiInterface $api) {
    $this->configFactory = $config_factory;
    $this->language = $language_manager->getCurrentLanguage();
    $this->api = $api;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('language_manager'),
      $container->get('careerswales_api.api')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getEndpointApi($endpoint) {
    $settings = $this->configFactory->get('careerswales_api.settings');

    return $settings->get($endpoint);
  }

  /**
   * {@inheritdoc}
   */
  public function getIntroduction() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('introduction')['value'], $settings->get('introduction')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getResultsIntroductionText() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('results_introduction')['value'], $settings->get('results_introduction')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getFavouritesIntroductionText() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('favourites_introduction')['value'], $settings->get('favourites_introduction')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getContactIntroduction() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('contact_introduction')['value'], $settings->get('contact_introduction')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getContactStatements() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('contact_statements')['value'], $settings->get('contact_statements')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getPrivacyPolicyPage() {
    $policy_page = $this->configFactory->get('careerswales_eag.settings')->get('privacy_policy_page');

    if (empty($policy_page)) {
      $policy_page = $this->configFactory->get('system.site')->get('page.front');
      $policy_page = explode('/', $policy_page);
      $policy_page = $policy_page[2];
    }

    return $policy_page;
  }

  /**
   * {@inheritdoc}
   */
  public function getFavouritesFooterText() {
    $settings = $this->configFactory->get('careerswales_eag.settings');

    return check_markup($settings->get('favourites_footer')['value'], $settings->get('favourites_footer')['format']);
  }

  /**
   * {@inheritdoc}
   */
  public function getYesNo() {
    return [
      'YES' => $this->t('Yes'),
      'NO' => $this->t('No'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getGenders() {
    return [
      'MALE' => $this->t('Male'),
      'FEMALE' => $this->t('Female'),
      'OTHER' => $this->t('Other'),
      'PREFER_NOT_TO_SAY' => $this->t('Prefer not to say'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getEmploymentStatus() {
    return [
      "EMPLOYED_FULL_TIME_MORE_16HRS" => $this->t('Employed - Full Time (16+ hours)'),
      "EMPLOYED_LESS_16HRS" => $this->t('Employed - Less than 16 hours'),
      "EMPLOYED_0HR_CONTRACT" => $this->t('Employed - 0hr contract'),
      "SELF_EMPLOYED" => $this->t('Self Employed'),
      "IN_EDUCATION" => $this->t('Full time education'),
      "UNEMPLOYED_LESS_THAN_6_MONTHS" => $this->t('Unemployed less than 6 months'),
      "UNEMPLOYED_6_TO_12_MONTHS" => $this->t('Unemployed 6-12 months'),
      "UNEMPLOYED_MORE_THAN_12_MONTHS" => $this->t('Unemployed for more than 12 months'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getEducationStatus() {
    return [
      'FULL_TIME_TRAINING_OR_EDUCATION' => $this->t('I am in full time training or education (Full time is 16 hours a week or over)'),
      'PART_TIME_TRAINING_OR_EDUCATION' => $this->t('I am in part time training or education (Part time is less than 16 hours a week)'),
      'ENROLLED_OR_STARTING_FULL_TIME_TRAINING_COURSE' => $this->t('I am enrolled on or waiting to start a full time training course'),
      'NOT_IN_EDUCATION_OR_TRAINING' => $this->t('I am not undertaking any education or training'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getEducationInstitutions() {
    return [
      'IN_SCHOOL' => $this->t('School'),
      'IN_FURTHER_EDUCATION' => $this->t('Further Education e.g. College'),
      'IN_HIGHER_EDUCATION' => $this->t('Higher Education e.g. University'),
      'TRAINING_PROVIDER' => $this->t('Training Provider'),
      'OTHER' => $this->t('Other'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getEmploymentSectors() {
    return [
      "ADVANCED_MATERIALS_AND_MANUFACTURING" => $this->t('Advanced Materials & Manufacturing (e.g. Aerospace, Defence, Automotive, Electronics)'),
      "CONSTRUCTION" => $this->t('Construction'),
      "CREATIVE" => $this->t('Creative Industries'),
      "CHILDCARE" => $this->t('Childcare'),
      "ENERGY_AND_ENVIRONMENT" => $this->t('Energy and Environment'),
      "FINANCIAL_AND_PROFESSIONAL_SERVICES" => $this->t('Financial and Professional Services'),
      "FOOD_AND_FARMING" => $this->t('Food and Farming'),
      "ICT" => $this->t('Information Communications Technology'),
      "LIFE_SCIENCES_AND_HEALTH" => $this->t('Health and Life Sciences'),
      "TOURISM_RECREATION_AND_LEISURE" => $this->t('Tourism, Recreation and Leisure'),
      "OTHER" => $this->t('Other sector not listed above'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getQualificationLevels() {
    return [
      "NO_FORMAL" => $this->t('No formal qualifications'),
      "ENTRY_LEVEL" => $this->t('Entry Level'),
      "LEVEL_1" => $this->t('Level 1 - NVQ Level 1 or GCSE Grade D-G'),
      "LEVEL_2" => $this->t('Level 2 - GCSE or O Level Grade C and above or equivalent'),
      "LEVEL_3" => $this->t('Level 3 - A Levels or equivalent'),
      "LEVEL_4" => $this->t('Level 4 - HNC or equivalent'),
      "LEVEL_5" => $this->t('Level 5 - HND, Foundation Degree or equivalent'),
      "LEVEL_6" => $this->t('Level 6 - Degree, NVQ / QCF Level 6 or equivalent'),
      "LEVEL_7" => $this->t('Level 7 - Master Degree or equivalent'),
      "LEVEL_8" => $this->t('Level 8 - Doctorate or equivalent'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getEthnicGroups() {
    $ethnicities = [
      "WHITE" => $this->t('White')->render(),
      "BLACK_CARIBBEAN" => $this->t('Black - Caribbean')->render(),
      "BLACK_AFRICAN" => $this->t('Black - African')->render(),
      "OTHER_BLACK_BACKGROUND" => $this->t('Other - Black Background')->render(),
      "ASIAN_INDIAN" => $this->t('Asian - Indian')->render(),
      "ASIAN_PAKISTANI" => $this->t('Asian - Pakistan')->render(),
      "ASIAN_BANGLADESH" => $this->t('Asian – Bangladeshi')->render(),
      "CHINESE" => $this->t('Chinese')->render(),
      "OTHER_ASIAN_BACKGROUND" => $this->t('Other Asian Background')->render(),
      "MIXED_WHITE_BLACK_CARIBBEAN" => $this->t('Mixed – White and Black Caribbean')->render(),
      "MIXED_WHITE_BLACK_AFRICAN" => $this->t('Mixed – White and Black African')->render(),
      "MIXED_WHITE_ASIAN" => $this->t('Mixed – White and Asian')->render(),
      "OTHER_MIXED_BACKGROUND" => $this->t('Other Mixed Background')->render(),
      "ARAB" => $this->t('Arab')->render(),
      "OTHER_ETHNIC_BACKGROUND" => $this->t('Other Ethnic Background')->render(),
    ];

    asort($ethnicities);

    $other = [
      "PREFER_NOT_TO_SAY" => $this->t('Prefer not to say'),
      "NOT_KNOWN" => $this->t('Not known'),
    ];

    $options = array_merge($ethnicities, $other);

    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function getSpecialCircumstances() {
    return [
      "PHYSICAL_DISABILITY" => $this->t('Physical Disability'),
      "LEARNING_DISABILITY" => $this->t('Learning Disability'),
      "WORK_LIMIT_HEALTH_CONDITION" => $this->t('Work Limiting Health Condition'),
      "MENTAL_HEALTH_CONDITION" => $this->t('Mental Health Condition'),
      "SUBSTANCE_DRUG_ALCOHOL_MISUSE" => $this->t('Involved in Substance/Drug/Alcohol Misuse'),
      "CRIMINAL_RECORD" => $this->t('Criminal Record (Offender/Ex-Offender)'),
      "CHILDCARE_RESPONSIBILITIES" => $this->t('Childcare Responsibilities'),
      "OTHER_CARE_RESPONSIBILITIES" => $this->t('Other Care Responsibilities'),
      "JOBLESS_HOUSEHOLDS" => $this->t('Live in a household where no one is in work'),
      "NONE" => $this->t('None'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getLocalAuthorities() {
    $endpoint = $this->getEndpointApi('location') . '/v1/locations/localAuthorities';

    $response = $this->api->get($endpoint);

    if ($response->getStatusCode() != 200) {
      return [];
    }

    $response_body = $response->getBody();
    $response_contents = $response_body->getContents();

    $authorities = JSON::decode($response_contents);

    $local_authorities = [];
    foreach ($authorities as $authority) {
      $local_authorities[$authority['localAuthorityCode']] = $authority['localAuthorityName'][$this->language->getId()];
    }

    asort($local_authorities);

    return $local_authorities;
  }

  /**
   * {@inheritdoc}
   */
  public function isValidPostcode($input) {
    $endpoint = $this->getEndpointApi('location') . '/v1/locations/postcodes/' . $input;

    $response = $this->api->get($endpoint);

    if ($response->getStatusCode() != 200) {
      return [];
    }

    $response_body = $response->getBody();
    $response_contents = $response_body->getContents();

    return JSON::decode($response_contents);
  }

  /**
   * {@inheritdoc}
   */
  public function getProgrammes(array $ids) {
    $endpoint = $this->getEndpointApi('programme') . '/v1/programmes/';

    $response = $this->api->get($endpoint, [
      'query' => [
        'ids' => implode(',', $ids),
      ],
    ]);

    if ($response->getStatusCode() != 200) {
      return [];
    }

    $response_body = $response->getBody();
    $response_contents = $response_body->getContents();

    return JSON::decode($response_contents);
  }

  /**
   * {@inheritdoc}
   */
  public function getPdf($ids, $language_id) {
    $endpoint = $this->getEndpointApi('programme') . '/v1/programmes/';

    $response = $this->api->get($endpoint, [
      'query' => [
        'ids' => $ids,
        'language' => $language_id,
      ],
      'headers' => [
        'Accept' => 'application/pdf',
      ],
    ]);

    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function getProgrammesByEligibility(array $answers) {
    $circumstances = [];
    foreach ($answers[4]['special_circumstances'] as $key => $circumstance) {
      if (is_string($circumstance)) {
        $circumstances[] = $key;
      }
    }

    $employment_status = [];
    if ($answers[3]['education_status'] == 'FULL_TIME_TRAINING_OR_EDUCATION' or $answers[3]['education_status'] == 'ENROLLED_OR_STARTING_FULL_TIME_TRAINING_COURSE') {
      $employment_status[] = $answers[3]['employment_status'];
      $employment_status[] = 'IN_EDUCATION';
    }
    else {
      $employment_status[] = $answers[3]['employment_status'];
    }

    if (strlen($answers[1]['dob']['month']) == 1) {
      $answers[1]['dob']['month'] = '0' . $answers[1]['dob']['month'];
    }
    if (strlen($answers[1]['dob']['day']) == 1) {
      $answers[1]['dob']['day'] = '0' . $answers[1]['dob']['day'];
    }

    $dob = $answers[1]['dob']['year'] . '-' . $answers[1]['dob']['month'] . '-' . $answers[1]['dob']['day'];
    $education_status = $answers[3]['education_institution'];
    $employment_sector = $answers[3]['sector'];
    $ethnicity = $answers[2]['ethnicity'];
    $gender = $answers[2]['gender'];
    $interested_in_starting_own_business = ($answers[2]['start_business'] === 'YES') ? TRUE : FALSE;
    $local_authority_area_code = $answers[2]['authority'];
    $postcode = isset($answers[2]['postcode_verified']) ? $answers[2]['postcode_verified'] : '';
    $qualification_level = $answers[3]['qualification'];
    $redundant_within_three_months = ($answers[3]['redundancy']['REDUNDANT'] === 'REDUNDANT') ? TRUE : FALSE;

    $query_array = [
      'circumstances' => empty($circumstances) ? '' : $circumstances,
      'dateOfBirth' => $dob,
      'educationStatus' => $education_status,
      'employmentSector' => $employment_sector,
      'employmentStatus' => $employment_status,
      'ethnicity' => $ethnicity,
      'gender' => $gender,
      'interestedInStartingOwnBusiness' => $interested_in_starting_own_business,
      'localAuthorityAreaCode' => $local_authority_area_code,
      'postcode' => $postcode,
      'qualificationLevel' => $qualification_level,
      'redundantWithin3Months' => $redundant_within_three_months,
    ];

    // Remove empty parameters from query array.
    foreach ($query_array as $key => $value) {
      if (empty($value)) {
        unset($query_array[$key]);
      }
    }

    $endpoint = $this->getEndpointApi('programme') . '/v1/programmes/byEligibility' . $this->api->buildQueryString($query_array);

    $response = $this->api->get($endpoint);

    if ($response->getStatusCode() != 200) {
      return [];
    }

    $response_body = $response->getBody();
    $response_contents = $response_body->getContents();

    return JSON::decode($response_contents);
  }

  /**
   * {@inheritdoc}
   */
  public function contactAdvisor($email, $message, $name, $preferred, array $programmes, $telephone) {
    $endpoint = $this->getEndpointApi('contact') . '/v1/contact/advisor';

    $response = $this->api->post($endpoint, [
      'json' => [
        'emailAddress' => $email,
        'message' => $message,
        'name' => $name,
        'preferredMethodOfContact' => $preferred,
        'programmeIds' => array_values($programmes),
        'telephoneNumber' => $telephone,
      ],
    ]);

    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function isEndpointApiAvailable($endpoint) {
    $endpoint = $this->getEndpointApi($endpoint);

    return $this->api->availability($endpoint);
  }

}
