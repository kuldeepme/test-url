<?php

namespace Drupal\careerswales_eag;

/**
 * Careers Wales EAG bridge interface.
 */
interface EagBridgeInterface {

  /**
   * Retrieves the introduction from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Form introduction text.
   */
  public function getIntroduction();

  /**
   * Retrieves the introduction from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Results page introduction text.
   */
  public function getResultsIntroductionText();

  /**
   * Retrieves the introduction from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Introduction text for the favourites page.
   */
  public function getFavouritesIntroductionText();

  /**
   * Retrieves the contact introduction from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Introduction text for the favourites page.
   */
  public function getContactIntroduction();

  /**
   * Retrieves the contact statements from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Introduction text for the favourites page.
   */
  public function getContactStatements();

  /**
   * Retrieves the privacy policy page from the settings.
   *
   * @return string
   *   Node identifier for the privacy policy page.
   */
  public function getPrivacyPolicyPage();

  /**
   * Retrieves the introduction from the settings.
   *
   * @return \Drupal\Component\Render\MarkupInterface
   *   Footer text for the favourites page.
   */
  public function getFavouritesFooterText();

  /**
   * Returns an array of yes/no question responses.
   *
   * @return array
   *   Yes/No.
   */
  public function getYesNo();

  /**
   * Returns an array of the possible gender responses.
   *
   * @return array
   *   Genders.
   */
  public function getGenders();

  /**
   * Returns and array of the possible employment status responses.
   *
   * @return array
   *   Employment statuses.
   */
  public function getEmploymentStatus();

  /**
   * Returns an array of the possible education institution responses.
   *
   * @return array
   *   Education statuses.
   */
  public function getEducationStatus();

  /**
   * Returns an array of the possible education status responses.
   *
   * @return array
   *   Education institutions.
   */
  public function getEducationInstitutions();

  /**
   * Returns an array of the possible employment sectors responses.
   *
   * @return array
   *   Employment sectors.
   */
  public function getEmploymentSectors();

  /**
   * Returns an array of the possible qualification levels responses.
   *
   * @return array
   *   Qualification levels.
   */
  public function getQualificationLevels();

  /**
   * Returns an array of possible ethnic group responses.
   *
   * @return array
   *   Ethnic groups.
   */
  public function getEthnicGroups();

  /**
   * Returns an array of possible special circumstances responses.
   *
   * @return array
   *   The special circumstances.
   */
  public function getSpecialCircumstances();

  /**
   * API call to the programme service to retrieve local authorities.
   *
   * @return array
   *   The local authorities.
   */
  public function getLocalAuthorities();

  /**
   * API call to the location service to check if postcode is valid.
   *
   * @param string $input
   *   The postcode input.
   *
   * @return bool
   *   The validity flag
   */
  public function isValidPostcode($input);

  /**
   * API call to the programme service to retrieve a set of programmes.
   *
   * @param array $ids
   *   The programme identifiers.
   *
   * @return array
   *   The programmes array.
   */
  public function getProgrammes(array $ids);

  /**
   * Get a pdf.
   *
   * @param mixed $ids
   *   The PDF identifiers.
   * @param string $language_id
   *   The requested language.
   *
   * @return mixed
   *   The PDF document.
   */
  public function getPdf($ids, $language_id);

  /**
   * API call to the programme service to retrieve programmes by eligibility.
   *
   * @param array $answers
   *   The response answers.
   *
   * @return array
   *   The programmes array.
   */
  public function getProgrammesByEligibility(array $answers);

  /**
   * API call to the email service to contact an advisor.
   *
   * @param string $email
   *   The email address.
   * @param string $message
   *   The message.
   * @param string $name
   *   The name of the sender.
   * @param string $preferred
   *   The preferred method of contact.
   * @param array $programmes
   *   The programme ID's.
   * @param string $telephone
   *   The telephone number.
   *
   * @return \GuzzleHttp\Psr7\Response
   *   The response object.
   */
  public function contactAdvisor($email, $message, $name, $preferred, array $programmes, $telephone);

  /**
   * API call to the check if an endpoint service is available.
   *
   * @param $endpoint
   *
   * @return mixed
   */
  public function isEndpointApiAvailable($endpoint);

}
