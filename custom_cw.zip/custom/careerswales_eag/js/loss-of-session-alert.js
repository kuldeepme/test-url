/**
 * @file
 * Careers Wales EAG change page titles.
 */

(function ($, Drupal) {

    'use strict';

    /**
     * @type {Drupal~behavior}
     */
    Drupal.behaviors.careerswalesEagSessionAlert = {
        attach: function (context, settings) {

          // Add smooth scrolling to all links, this stops updates to the history
          // and disables popstate for hashchanges...
          $("a").on('click', function(event) {

            if (this.hash !== "") {
              event.preventDefault();

              var hash = this.hash;
              $('html, body').animate({
                scrollTop: $(hash).offset().top
              }, 800, function(){


              });
            }
          });



            history.pushState(null, "", window.location.href);

            window.onpopstate = function(event) {
                event.preventDefault();
                if ($('#edit-previous--2').length) {
                    document.getElementById('edit-previous--2').click();
                } else if ($('#edit-previous').length) {
                    document.getElementById('edit-previous').click();
                }
            };
        }
    };

})(jQuery, Drupal);