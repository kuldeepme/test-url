/**
 * @file
 * Careers Wales EAG change page titles.
 */

(function ($, Drupal) {

    'use strict';

    /**
     * @type {Drupal~behavior}
     */
    Drupal.behaviors.careerswalesEagPageTitles = {
        attach: function (context, settings) {

            var title = jQuery(context).find('#block-careerswales-gel-page-title h1 > span');
            var step = settings.careerswalesEag.step;

            if (step === 5) {
                title.text(settings.careerswalesEag.results);
            }

            if (step === 6) {
                title.text(settings.careerswalesEag.programme);
            }

            if (step === 7) {
                title.text(settings.careerswalesEag.contact);
            }

        }
    };

})(jQuery, Drupal);
