/**
 * @file
 */

(function ($, Drupal) {

  Drupal.behaviors.outreachMap = {

    attach: function (context, settings) {

        var map = document.getElementById('outreach-map');

        //var googleGeocoder = new google.maps.Geocoder();

        var googleMap = new google.maps.Map(map, {
            center: {lat: 52.394775, lng: -3.388064},
            zoom: 8
        });

        var googleLayer = new google.maps.FusionTablesLayer({
            map: googleMap,
            heatmap: { enabled: false },
            query: {
                select: "col8",
                from: map.getAttribute('data-table'),
                where: ""
            },
            options: {
                styleId: map.getAttribute('data-style'),
                templateId: map.getAttribute('data-template')
            }
        });

        googleLayer.setMap(googleMap);

    }
  };
})(jQuery, Drupal);
