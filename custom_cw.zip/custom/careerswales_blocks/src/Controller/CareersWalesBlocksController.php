<?php

namespace Drupal\careerswales_blocks\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;

/**
 * Class CareersWalesBlocksController.
 *
 * @package Drupal\careerswales_blocks\Controller
 */
class CareersWalesBlocksController extends ControllerBase {

  /**
   * Checks access for a specific request.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   Run access checks for this account.
   *
   * @return \Drupal\Core\Access\AccessResult
   *   Access Result.
   */
  public function blockLayoutAccess(AccountInterface $account) {
    return AccessResult::allowedIf($account->hasPermission('access block layout'));
  }

}
