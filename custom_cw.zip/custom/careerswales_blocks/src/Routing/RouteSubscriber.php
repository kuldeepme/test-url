<?php

namespace Drupal\careerswales_blocks\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    $this->removeBlockLayoutAccess($collection);
  }

  /**
   * Remove access to "Block layout" page for non-super-users.
   *
   * @param \Symfony\Component\Routing\RouteCollection $collection
   *   Route collection.
   */
  private function removeBlockLayoutAccess(RouteCollection $collection) {
    if ($route = $collection->get('block.admin_display')) {
      $route->setRequirement('_access', 'access block layout');
    }
  }

}
