<?php

namespace Drupal\careerswales_table_responsive\Plugin\Filter;

use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;

/**
 * FilterCareerswalesTableResponsive.
 *
 * @Filter(
 *   id = "filter_table_responsive",
 *   title = @Translation("Table Responsive Filter"),
 *   description = @Translation("Custom filter to wrap tables in .table-responsive"),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_MARKUP_LANGUAGE,
 * )
 */
class FilterCareerswalesTableResponsive extends FilterBase {

  /**
   * Process.
   *
   * @param string $text
   *   The text.
   * @param string $langcode
   *    The langcode.
   *
   * @return \Drupal\filter\FilterProcessResult
   *   Filtered result.
   */
  public function process($text, $langcode) {
    $replace  = "<div class='table'><table";
    $new_text = str_replace("<table", $replace, $text);
    $new_text = str_replace("</table>", "</table></div>", $new_text);
    return new FilterProcessResult($new_text);
  }

}
