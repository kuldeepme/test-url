<?php

namespace Drupal\careerswales_settings\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\file\Entity\File;

/**
 * Careers Wales basic settings.
 */
class CareersWalesSettingsForm extends ConfigFormBase {

  use StringTranslationTrait;

  /**
   * The entity type manager class.
   *
   * @var object
   */
  protected $entityTypeManager;

  /**
   * EagSettingsForm constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(ConfigFactoryInterface $config_factory, EntityTypeManagerInterface $entity_type_manager) {
    parent::__construct($config_factory);
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'careerswales_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'careerswales_settings.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $settings = $this->config('careerswales_settings.settings');

    $form['beta'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Beta Banner'),
    ];
    
    $form['beta']['show_beta_banner'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Show Beta Banner'),
      '#default_value' => $settings->get('show_beta_banner'),
    ];

    $form['beta']['beta_url'] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'node',
      '#title' => $this->t('Beta page URL.'),
      '#default_value' => (is_numeric($settings->get('beta_url')) ? $this->entityTypeManager->getStorage('node')->load($settings->get('beta_url')) : ''),
    ];

    $form['beta']['about_url'] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'node',
      '#title' => $this->t('About the new site URL'),
      '#default_value' => (is_numeric($settings->get('about_url')) ? $this->entityTypeManager->getStorage('node')->load($settings->get('about_url')) : ''),
    ];

    $form['beta']['feedback_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Feedback URL'),
      '#default_value' => $settings->get('feedback_url'),
    ];

    $form['beta']['legacy_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Legacy wesbite URL'),
      '#default_value' => $settings->get('legacy_url'),
    ];
    
    $form['beta']['edit_wording'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Edit Label'),
    ];
    $form['beta']['edit_wording']['beta_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Beta Label'),
      '#default_value' => $settings->get('beta_text'),
    ];
    $form['beta']['edit_wording']['about_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('About Label'),
      '#default_value' => $settings->get('about_text'),
    ];
    $form['beta']['edit_wording']['give_feedback'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Give Feedback Label'),
      '#default_value' => $settings->get('give_feedback'),
    ];
    $form['beta']['edit_wording']['go_to_current_site'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Goto Site Label'),
      '#default_value' => $settings->get('go_to_current_site'),
    ];
    $form['beta']['edit_wording']['static_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Beta Banner Text'),
      '#default_value' => $settings->get('static_text'),
    ];    
    $form['cookies'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Cookies'),
    ];
    $form['cookies']['cookie_url'] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'node',
      '#title' => $this->t('Cookies URL'),
      '#default_value' => (is_numeric($settings->get('cookie_url')) ? $this->entityTypeManager->getStorage('node')->load($settings->get('cookie_url')) : ''),
    ];
    $form['cookies']['cookie_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Cookie Static Text'),
      '#default_value' => $settings->get('cookie_text'),
    ];
    $form['cookies']['cookie_link_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Cookie Link Text'),
      '#default_value' => $settings->get('cookie_link_text'),
    ];    
    $form['social'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Social media'),
    ];
    $form['social']['twitter_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Twitter URL.'),
      '#default_value' => $settings->get('twitter_url'),
    ];

    $form['social']['facebook_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Facebook URL.'),
      '#default_value' => $settings->get('facebook_url'),
    ];

    $form['social']['linkedin_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Linkedin URL.'),
      '#default_value' => $settings->get('linkedin_url'),
    ];

    $form['social']['youtube_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Youtube URL.'),
      '#default_value' => $settings->get('youtube_url'),
    ];

    $form['social']['instagram_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Instagram URL.'),
      '#default_value' => $settings->get('instagram_url'),
    ];

    $form['documents'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Documents'),
    ];

    $form['documents']['documents_email'] = [
      '#type' => 'email',
      '#title' => $this->t('Document request email.'),
      '#default_value' => $settings->get('documents_email'),
    ];

    $form['page'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Page options'),
    ];

    $form['page']['telephone_number'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Telephone number'),
      '#default_value' => $settings->get('telephone_number'),
    ];

    $form['page']['telephone_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Telephone text'),
      '#default_value' => $settings->get('telephone_text'),
    ];

    $form['page']['contact_email'] = [
      '#type' => 'email',
      '#title' => $this->t('Contact email.'),
      '#default_value' => $settings->get('contact_email'),
    ];

    $form['page']['share_email'] = [
      '#type' => 'email',
      '#title' => $this->t('Share email.'),
      '#default_value' => $settings->get('share_email'),
    ];

    $form['page']['search_enable'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Show Search'),
      '#default_value' => $settings->get('search_enable'),
    ];

    $form['page']['webchat_enable'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Show Webchat'),
      '#default_value' => $settings->get('webchat_enable'),
    ];
    
    $form['footer'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('Footer options'),
    ];
    
    $form['footer']['feedback_url_footer'] = [
      '#type' => 'url',
      '#title' => $this->t('Feedback about this page URL'),
      '#default_value' => $settings->get('feedback_url_footer'),
    ];
    
    $form['footer']['share_this_page'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Share this page text'),
      '#default_value' => $settings->get('share_this_page'),
    ];
    
    $form['footer']['back_to_top'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Back to top text'),
      '#default_value' => $settings->get('back_to_top'),
    ];
    
    $form['footer']['num_footer_logo'] = [
      '#type' => 'number',
      '#title' => $this->t('Number Of Footer Logo'),
      '#default_value' => (!empty($settings->get('num_footer_logo')) ? $settings->get('num_footer_logo') : 2),
      '#max' => 5,
      '#min' => 1,
      '#size' => 10
    ];
    $num_footer_logo = ($settings->get('num_footer_logo')) ? $settings->get('num_footer_logo') : 2;
    $languages = \Drupal::languageManager()->getLanguages();
    foreach($languages as $key => $value) {
        $language = $value->getName();
        $form['footer']['footer_logo'][$key] = [
          '#type'  => 'details',
          '#open'  => TRUE,
          '#title' => $this->t('Footer logo for ' . $language),
        ];        
        for ($i = 1; $i <= $num_footer_logo; $i++) {
          $footer_logo = 'footer_logo_' . $key . '_' . $i;
          $footer_url = 'footer_url_' . $key . '_' . $i;
          $footer_alt_text = 'logo_alt_text_' . $key . '_' . $i;
          $form['footer']['footer_logo'][$key][$footer_logo] = [
            '#type' => 'managed_file',
            '#default_value' => (!empty($settings->get($footer_logo)) ? [$settings->get($footer_logo)] : ''),
            '#title' => t('Footer logo ' . $i),
            '#upload_location' => 'public://footer-logo',
            '#upload_validators' => [
              'file_validate_extensions' => ['jpg jpeg gif png svg'],
            ],
            '#ajax' => [
              'callback' => '::updateFooterLogoCallback',
              'event' => 'change',
              'wrapper' => 'preview',
             ]
          ];
          $fid = !empty($form_state->getValue($footer_logo)[0]) ? $form_state->getValue($footer_logo)[0] : '' ;
          $form['footer']['footer_logo'][$key][$footer_alt_text] = [
            '#title' => $this->t('Alt text ' . $i),
            '#description' => $this->t('The alt text which is used for the image tool tip.'),
            '#type' => 'textfield',
            '#default_value' => (!empty($settings->get($footer_alt_text)) ? [$settings->get($footer_alt_text)] : ''),
            '#states' => [
              'visible' => [
                ':input[name="' . $footer_logo . '[fids]"]' => ['!value' => (string) $fid],
              ],
            ],
          ];
          $form['footer']['footer_logo'][$key][$footer_url] = [
            '#type' => 'url',
            '#title' => $this->t('Logo URL ' . $i),
            '#default_value' => ($settings->get($footer_url) ? $settings->get($footer_url) : ''),
            '#states' => [
              'visible' => [
                ':input[name="' . $footer_logo . '[fids]"]' => ['!value' => (string) $fid],
              ],
            ],
          ];
        }
    }
    $form['app_maintenance_mode'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => t('App Maintenance Mode'),
    ];
    $form['app_maintenance_mode']['app_maintenance'] = [
      '#type' => 'checkbox',
      '#title' => t('Put app into maintenance mode'),
      '#default_value' => \Drupal::state()->get('app_maintenance'),
    ];
    $form['app_maintenance_mode']['include_url'] = [
      '#type' => 'textarea',
      '#title' => t('Page Urls'),
      '#description' => t("Enter pages to be shown to visitors in maintenance mode. Enter one page per line as Drupal paths. Example like /app."),
      '#default_value' => $settings->get('include_url'),
    ];
    $form['app_maintenance_mode']['app_display_message'] = [
      '#type' => 'textarea',
      '#title' => t('Message to display when app in maintenance mode'),
      '#description' => t("@page-title use for current page title."),
      '#default_value' => (!empty($settings->get('app_display_message')) ? $settings->get('app_display_message') : ''),
    ];
    $form['app_maintenance_mode']['app_contact_us'] = [
      '#type' => 'textfield',
      '#title' => t('Contact us detail for app'),
      '#default_value' => (!empty($settings->get('app_contact_us')) ? $settings->get('app_contact_us') : ''),
    ];
    return $form;
  }

  /**
   * Return the tag list (Form)
   */
  public function updateFooterLogoCallback(array &$form, FormStateInterface $form_state) {
/*    $languages = \Drupal::languageManager()->getLanguages();
    foreach($languages as $key => $value) {
      return $form['footer']['footer_logo'][$key]['ftr_logo_values'];
    }*/
      \Drupal::logger('some_channel_name1')->warning('<pre><code>' . print_r('test', TRUE) . '</code></pre>');
  }
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $settings = $this->configFactory->getEditable('careerswales_settings.settings');
    $languages = \Drupal::languageManager()->getLanguages();
    // Save configurations.
    $settings->set('beta_url', $form_state->getValue('beta_url'))->save();
    $settings->set('about_url', $form_state->getValue('about_url'))->save();
    $settings->set('feedback_url', $form_state->getValue('feedback_url'))->save();
    $settings->set('legacy_url', $form_state->getValue('legacy_url'))->save();
    $settings->set('show_beta_banner', $form_state->getValue('show_beta_banner'))->save();
    $settings->set('beta_text', $form_state->getValue('beta_text'))->save();
    $settings->set('about_text', $form_state->getValue('about_text'))->save();
    $settings->set('give_feedback', $form_state->getValue('give_feedback'))->save();
    $settings->set('go_to_current_site', $form_state->getValue('go_to_current_site'))->save();
    $settings->set('static_text', $form_state->getValue('static_text'))->save();    
    $settings->set('cookie_url', $form_state->getValue('cookie_url'))->save();
    $settings->set('cookie_text', $form_state->getValue('cookie_text'))->save();
    $settings->set('cookie_link_text', $form_state->getValue('cookie_link_text'))->save();
    $settings->set('twitter_url', $form_state->getValue('twitter_url'))->save();
    $settings->set('facebook_url', $form_state->getValue('facebook_url'))->save();
    $settings->set('linkedin_url', $form_state->getValue('linkedin_url'))->save();
    $settings->set('youtube_url', $form_state->getValue('youtube_url'))->save();
    $settings->set('instagram_url', $form_state->getValue('instagram_url'))->save();
    $settings->set('documents_email', $form_state->getValue('documents_email'))->save();
    $settings->set('contact_email', $form_state->getValue('contact_email'))->save();
    $settings->set('share_email', $form_state->getValue('share_email'))->save();
    $settings->set('search_enable', $form_state->getValue('search_enable'))->save();
    $settings->set('webchat_enable', $form_state->getValue('webchat_enable'))->save();
    $settings->set('telephone_number', $form_state->getValue('telephone_number'))->save();
    $settings->set('telephone_text', $form_state->getValue('telephone_text'))->save();
    $settings->set('feedback_url_footer', $form_state->getValue('feedback_url_footer'))->save();
    $settings->set('share_this_page', $form_state->getValue('share_this_page'))->save();
    $settings->set('back_to_top', $form_state->getValue('back_to_top'))->save();
    $settings->set('num_footer_logo', $form_state->getValue('num_footer_logo'))->save();
    foreach($languages as $key => $value) {
        for ($i = 1; $i <= $settings->get('num_footer_logo'); $i++) {
          $footer_logo_key = 'footer_logo_' . $key . '_' . $i;
          $footer_url_key = 'footer_url_' . $key . '_' . $i;
          $footer_alt_text_key = 'logo_alt_text_' . $key . '_' . $i;
          $footer_url = $form_state->getValue($footer_url_key);
          $footer_alt_text = $form_state->getValue($footer_alt_text_key);
          if (!empty($form_state->getValue($footer_logo_key))) {
            $image_fid = $form_state->getValue($footer_logo_key);
            $file = File::load($image_fid[0]);
            if ($file) {
                $file->setPermanent();
                $file->save();
                $settings->set($footer_logo_key, $image_fid[0])
                ->set($footer_url_key, $footer_url)
                ->set($footer_alt_text_key, $footer_alt_text)->save();
            }
          }
          else if (!empty($form_state->getUserInput($footer_logo_key))) {
            $settings->set($footer_logo_key, '')->set($footer_url_key, '')
            ->set($footer_alt_text_key, '')->save();
          }
        }//die;
    }
    if ($form_state->getValue('app_maintenance')) {
       \Drupal::state()->set('app_maintenance', $form_state->getValue('app_maintenance'));
       $include_url = $form_state->getValue('include_url');
       $app_display_message = $form_state->getValue('app_display_message');
       $app_contact_us = $form_state->getValue('app_contact_us');
       if (!empty($include_url)) {
          $settings->set('include_url', trim($include_url))->save(); 
       }
       if(!empty($app_display_message)){
         $settings->set('app_display_message', trim($app_display_message))->save();       
       }
       if(!empty($app_contact_us)){
         $settings->set('app_contact_us', trim($app_contact_us))->save();       
       }
    }
    else {
      \Drupal::state()->set('app_maintenance', $form_state->getValue('app_maintenance'));
    }    

    drupal_flush_all_caches();

  }

}
