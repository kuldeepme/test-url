/**
 * @file
 * Careers Wales EAG change page titles.
 */

(function ($, Drupal) {

  'use strict';


  Drupal.AjaxCommands.prototype.CareersWalesModalFormClose = function (ajax, response) {
    alert('Your block has been created. Start typing the name of it in  reference field to use it.');
    var $dialog = jQuery('.ui-dialog-content');
    Drupal.dialog($dialog.get(0)).close();
  }


})(jQuery, Drupal);
