<?php

namespace Drupal\careerswales_forms\Ajax;

use Drupal\Core\Ajax\CommandInterface;

/**
 * The Careers Wales modal forms close class.
 */
class CareersWalesModalFormClose implements CommandInterface {

  /**
   * Return the render command.
   *
   * @return array
   *   The render array.
   */
  public function render() {
    return [
      'command' => 'CareersWalesModalFormClose',
    ];
  }

}
