<?php

namespace Drupal\careerswales_forms;

/**
 * Careers Wales Forms interface.
 */
interface FormsInterface {

  /**
   * Gets all weekdays for a given period.
   *
   * @param string $start
   *   The start date.
   * @param string $end
   *   The end date.
   *
   * @return array
   *   The weekdays.
   */
  public function getWeekdays($start = '2010-10-01', $end = '2010-10-05');

}
