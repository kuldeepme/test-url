<?php

namespace Drupal\careerswales_forms\Plugin\WebformElement;

use Drupal\webform\Plugin\WebformElement\DateList;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Provides a 'datelist' element.
 *
 * @WebformElement(
 *   id = "datelist",
 *   api = "https://api.drupal.org/api/drupal/core!lib!Drupal!Core!Datetime!Element!Datelist.php/class/Datelist",
 *   label = @Translation("Date list"),
 *   description = @Translation("Provides a form element for date & time selection using select menus and text fields."),
 *   category = @Translation("Date/time elements"),
 * )
 */
class CWDateList extends Datelist {

  /**
   * {@inheritdoc}
   */
  public function prepare(array &$element, WebformSubmissionInterface $webform_submission = NULL) {
    parent::prepare($element, $webform_submission);
    $element['#theme_wrappers'] = ['datetime_wrapper'];
  }

}
