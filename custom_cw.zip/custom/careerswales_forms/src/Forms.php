<?php

namespace Drupal\careerswales_forms;

use DateInterval;
use DatePeriod;
use DateTime;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * The Careers Wales Forms Class.
 */
class Forms implements FormsInterface {

  use StringTranslationTrait;

  protected $configFactory;
  protected $language;

  /**
   * Careers Wales Forms constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   Language manager interface.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LanguageManagerInterface $language_manager) {
    $this->configFactory = $config_factory;
    $this->language = $language_manager->getCurrentLanguage();
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('language_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getWeekdays($start = '2010-10-01', $end = '2010-10-05') {
    $period = new DatePeriod(
      new DateTime($start),
      new DateInterval('P1D'),
      new DateTime($end)
    );

    // Loop over the dates for the next two weeks.
    $weekdays = [];
    foreach ($period as $value) {
      // Add week days to the array.
      if (!$this->isWeekend($value)) {
        $day = $this->t($value->format('l'));
        $date = $this->t($value->format('jS'));
        $month = $this->t($value->format('F'));
        $year = $value->format('Y');

        $full_date = $day . ' ' . $date . ' ' . $month . ' ' . $year;

        $weekdays[$value->format('Y-m-d')] = $full_date;
      }
    }

    return $weekdays;
  }

  /**
   * Gets all weekdays for a given period.
   *
   * @param \DateTime $date
   *   The date.
   *
   * @return string
   *   The formatted date.
   */
  protected function isWeekend(DateTime $date) {
    return $date->format('N') >= 6;
  }

}
