<?php

namespace Drupal\careerswales_forms\Form;

use Drupal\Core\Form\FormBase;

/**
 * Provides a base object for a Careers Wales forms.
 */
abstract class CareersWalesFormBase extends FormBase {

}
