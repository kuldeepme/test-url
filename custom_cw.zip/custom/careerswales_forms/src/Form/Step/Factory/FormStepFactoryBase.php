<?php

namespace Drupal\careerswales_forms\Form\Step\Factory;

use Drupal\Core\DependencyInjection\ClassResolverInterface;

/**
 * Provides a base factory for form step factories.
 */
abstract class FormStepFactoryBase implements FormStepFactoryInterface {

  /**
   * The class resolver class.
   *
   * @var object
   */
  protected $classResolver;

  /**
   * FormStepFactoryBase constructor.
   *
   * @param \Drupal\Core\DependencyInjection\ClassResolverInterface $class_resolver
   *   Class resolver service.
   */
  public function __construct(ClassResolverInterface $class_resolver) {
    $this->classResolver = $class_resolver;
  }

}
