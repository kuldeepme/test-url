<?php

namespace Drupal\careerswales_forms\Form\Step\Factory;

/**
 * Provides an interface for a form step factory.
 */
interface FormStepFactoryInterface {

  /**
   * Builds the form step object.
   *
   * @param int $current_step
   *   A number that specifies what step is built.
   *
   * @return \Drupal\careerswales_forms\Form\Step\FormStepInterface|object
   *   The render array defining the form step.
   */
  public function create($current_step);

}
