<?php

namespace Drupal\careerswales_forms\Form\Step;

use Drupal\careerswales_eag\Controller\PdfController;
use Drupal\careerswales_eag\EagBridgeInterface;
use Drupal\Component\Utility\EmailValidatorInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\DependencyInjection\DependencySerializationTrait;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a base object for a form step.
 */
abstract class FormStepBase implements FormStepInterface, ContainerInjectionInterface {

  use StringTranslationTrait;
  use DependencySerializationTrait;

  /**
   * The EAG bridge class.
   *
   * @var object
   */
  protected $eagBridge;

  /**
   * The language manager class.
   *
   * @var object
   */
  protected $languageManager;

  /**
   * The email validator class.
   *
   * @var object
   */
  protected $emailValidator;

  /**
   * The pdf controller class.
   *
   * @var object
   */
  protected $pdfController;

  /**
   * FormStepBase constructor.
   *
   * @param \Drupal\careerswales_eag\EagBridgeInterface $eag_bridge
   *   The EAG bridge class.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager class.
   * @param \Egulias\EmailValidator\EmailValidatorInterface $email_validator
   *   The email validator class.
   * @param \Drupal\careerswales_eag\Controller\PdfController $pdf_controller
   *   The pdf controller class.
   */
  public function __construct(EagBridgeInterface $eag_bridge, LanguageManagerInterface $language_manager, EmailValidatorInterface $email_validator, PdfController $pdf_controller) {
    $this->eagBridge = $eag_bridge;
    $this->languageManager = $language_manager;
    $this->emailValidator = $email_validator;
    $this->pdfController = $pdf_controller;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('careerswales_eag.bridge'),
      $container->get('language_manager'),
      $container->get('email.validator'),
      $container->get('careerswales_eag.pdf')
    );
  }

}
