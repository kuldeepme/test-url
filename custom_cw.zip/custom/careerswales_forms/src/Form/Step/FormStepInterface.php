<?php

namespace Drupal\careerswales_forms\Form\Step;

use Drupal\Core\Form\FormStateInterface;

/**
 * Provides an interface for a form step.
 */
interface FormStepInterface {

  /**
   * Gets the name of the step.
   *
   * @return string
   *   The step name.
   */
  public function getName();

  /**
   * Builds the form step into the form structure.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The step structure.
   */
  public function buildStep(array &$form, FormStateInterface &$form_state);

  /**
   * Provides custom overrides to the form structure.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function override(array &$form, FormStateInterface &$form_state);

}
