<?php
namespace Drupal\cw_maintenance_page_setting\TwigExtension;

class GetUrlFromFid extends \Twig_Extension{

   /**
   * Generates a list of all Twig filters that this extension defines.
   */
  public function getFilters() {
    return [
      new \Twig_SimpleFilter('get_url_from_fid', array($this, 'get_url_from_fid')),
    ];
  }
 
  /**
   * Gets a unique identifier for this Twig extension.
   */
  public function getName() {
    return 'cw_maintenance_page_setting.get_url_from_fid';
  }


  public function get_url_from_fid($fid){
    //  kint($fid); die;
    $file = \Drupal\file\Entity\File::load($fid);
    if(!is_null($file)){
      $uri = $file->getFileUri();
      return file_create_url($uri);
    }else{
      return false;
    }
  }
}