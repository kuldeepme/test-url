CKEDITOR.plugins.setLang('blockquote_cite', 'en', {
	button : 'Inset blockquote with author',
	title : 'Inset blockquote with author',
	txtQuote : 'Enter your quote here (required)',
	txtAuthor : 'Enter the quote source here (optional)',
	invalidQuote : 'Please enter a quote or click cancel',
});
