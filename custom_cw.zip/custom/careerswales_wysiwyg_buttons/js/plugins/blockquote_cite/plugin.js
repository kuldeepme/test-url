/*
* Youtube Embed Plugin
*
* @author Jonnas Fonini <jonnasfonini@gmail.com>
* @version 2.1.13
*/
(function () {
    CKEDITOR.plugins.add('blockquote_cite', {
        lang: ['en'],
        init: function (editor) {
            editor.addCommand('blockquote_cite', new CKEDITOR.dialogCommand('blockquote_cite', {
                allowedContent: 'div{*}(*); iframe{*}[!width,!height,!src,!frameborder,!allowfullscreen,!allow]; object param[*]; a[*]; img[*]'
            }));

            editor.ui.addButton('BlockquoteCite', {
                label: editor.lang.blockquote_cite.button,
                toolbar: 'insert',
                command: 'blockquote_cite',
                icon: this.path + 'images/icon.png'
            });

            CKEDITOR.dialog.add('blockquote_cite', function (instance) {
                var disabled = editor.config.blockquote_cite_disabled_fields || [];

                return {
                    title: editor.lang.blockquote_cite.title,
                    minWidth: 510,
                    minHeight: 200,
                    onShow: function () {
                        for (var i = 0; i < disabled.length; i++) {
                            this.getContentElement('blockquote_citePlugin', disabled[i]).disable();
                        }
                    },
                    contents: [
                        {
                            id: 'blockquote_citePlugin',
                            expand: true,
                            elements: [
                                {
                                    id: 'txtQuote',
                                    type: 'textarea',
                                    label: editor.lang.blockquote_cite.txtQuote,
                                    validate: function () {
                                        if (!this.getValue()) {
                                            alert(editor.lang.blockquote_cite.invalidQuote);
                                            return false;
                                        }
                                    }
                                },
                                {
                                    id: 'txtAuthor',
                                    type: 'text',
                                    label: editor.lang.blockquote_cite.txtAuthor
                                }
                            ]
                        }
                    ],
                    onOk: function () {
                        var content = '<blockquote><p>' + this.getValueOf('blockquote_citePlugin', 'txtQuote') + '</p>';
                        if (this.getValueOf('blockquote_citePlugin', 'txtAuthor')) {
                            content += '<cite>' + this.getValueOf('blockquote_citePlugin', 'txtAuthor') + '</cite>';
                        }
                        content += '</blockquote>';
                        instance.insertHtml(content);
                    }
                };
            });
        }
    });
})();
