<?php

namespace Drupal\careerswales_wysiwyg_buttons\Plugin\CKEditorPlugin;

use Drupal\ckeditor\CKEditorPluginInterface;
use Drupal\ckeditor\CKEditorPluginButtonsInterface;
use Drupal\Component\Plugin\PluginBase;
use Drupal\editor\Entity\Editor;

/**
 * Defines the "BlockquoteCite" plugin, with a CKEditor.
 *
 * @CKEditorPlugin(
 *   id = "blockquote_cite",
 *   label = @Translation("Blockquote with author Plugin")
 * )
 */
class BlockquoteCite extends PluginBase implements CKEditorPluginInterface, CKEditorPluginButtonsInterface {

  /**
   * {@inheritdoc}
   */
  public function getDependencies(Editor $editor) {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getLibraries(Editor $editor) {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function isInternal() {
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function getFile() {
    return drupal_get_path('module', 'careerswales_wysiwyg_buttons') . '/js/plugins/blockquote_cite/plugin.js';
  }

  /**
   * Return the buttons to be added to the WYSIWYG.
   *
   * @return array
   *   Array of buttons and their properties.
   */
  public function getButtons() {
    $iconImage = drupal_get_path('module', 'careerswales_wysiwyg_buttons') . '/js/plugins/blockquote_cite/images/icon.png';

    return [
      'BlockquoteCite' => [
        'label' => t('Blockquote with author'),
        'image' => $iconImage,
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getConfig(Editor $editor) {
    return [];
  }

}
