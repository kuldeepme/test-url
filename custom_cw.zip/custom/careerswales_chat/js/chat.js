/**
 * @file
 * Careers Wales EAG change page titles.
 */

(function ($, Drupal) {

    'use strict';

    /**
     * @type {Drupal~behavior}
     */
    Drupal.behaviors.careerswalesChat = {
        attach: function (context, settings) {

            window.__lc = window.__lc || {};
            window.__lc.license = 10272469;
            (function() {
                var lc = document.createElement('script');
                lc.type = 'text/javascript';
                lc.async = true;
                lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';

                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(lc, s);
            })();

            $('.live-chat-no-js').remove();

            $('.chat-to-us-popup').on('click', function(e) {
                e.preventDefault();
                LC_API.open_chat_window();
            });

        }
    };

})(jQuery, Drupal);