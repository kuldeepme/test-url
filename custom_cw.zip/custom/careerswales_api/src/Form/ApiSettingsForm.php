<?php

namespace Drupal\careerswales_api\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Careers Wales API basic settings.
 */
class ApiSettingsForm extends ConfigFormBase {


  /**
   * The entity type manager class.
   *
   * @var object
   */
  protected $entityTypeManager;

  /**
   * ApiSettingsForm constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(ConfigFactoryInterface $config_factory, EntityTypeManagerInterface $entity_type_manager) {
    parent::__construct($config_factory);
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'careerswales_api_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'careerswales_api.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $settings = $this->config('careerswales_api.settings');

    $form['api'] = [
      '#type'  => 'details',
      '#open'  => TRUE,
      '#title' => $this->t('API Endpoints'),
    ];

    $form['api']['programme'] = [
      '#type'          => 'textfield',
      '#title' => 'Programme Service Endpoint',
      '#default_value' => $settings->get('programme'),
    ];

    $form['api']['location'] = [
      '#type'          => 'textfield',
      '#title' => 'Location Service Endpoint',
      '#default_value' => $settings->get('location'),
    ];

    $form['api']['contact'] = [
      '#type'          => 'textfield',
      '#title' => 'Contact Service Endpoint',
      '#default_value' => $settings->get('contact'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $settings = $this->configFactory->getEditable('careerswales_api.settings');

    // Save configurations.
    $settings->set('location', $form_state->getValue('location'))->save();
    $settings->set('programme', $form_state->getValue('programme'))->save();
    $settings->set('contact', $form_state->getValue('contact'))->save();
  }

}
