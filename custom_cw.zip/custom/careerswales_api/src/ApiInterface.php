<?php

namespace Drupal\careerswales_api;

/**
 * Careers Wales API interface.
 */
interface ApiInterface {

  /**
   * Performs a GET request to an endpoint.
   *
   * @param string $url
   *   The uniform resource locator.
   * @param array $options
   *   The options.
   *
   * @return \GuzzleHttp\Psr7\Response
   *   The response object.
   */
  public function get($url, array $options = []);

  /**
   * Performs a POST request to an endpoint.
   *
   * @param string $url
   *   The uniform resource locator.
   * @param array $data
   *   The data.
   *
   * @return \GuzzleHttp\Psr7\Response
   *   The response object.
   */
  public function post($url, array $data);

  /**
   * Checks whether an API is available.
   *
   * @param string $url
   *   The uniform resource locator.
   *
   * @return bool
   *   The availability flag.
   */
  public function availability($url);

  /**
   * Builds a query string from parameters.
   *
   * @param array $parameters
   *   The parameters.
   *
   * @return string
   *   The query string.
   */
  public function buildQueryString(array $parameters);

}
