<?php

namespace Drupal\careerswales_api;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * The Careers Wales API Class.
 */
class Api implements ApiInterface {

  use StringTranslationTrait;

  protected $configFactory;
  protected $language;
  protected $httpClient;
  protected $loggerFactory;

  /**
   * Api constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   Language manager interface.
   * @param \GuzzleHttp\ClientInterface $http_client
   *   HTTP client interface.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   Logger factory interface.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LanguageManagerInterface $language_manager, ClientInterface $http_client, LoggerChannelFactoryInterface $logger_factory) {
    $this->configFactory = $config_factory;
    $this->language = $language_manager->getCurrentLanguage();
    $this->httpClient = $http_client;
    $this->loggerFactory = $logger_factory->get('careerswales_api');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('language_manager'),
      $container->get('http_client'),
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function get($url, array $options = []) {
    try {
      $response = $this->httpClient->get($url, $options);
    }
    catch (RequestException $e) {
      $message = $e->getMessage();
      $this->loggerFactory->error($message);

      $response = $e->getResponse();
    }

    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function post($url, array $data) {
    try {
      $response = $this->httpClient->post($url, $data);
    }
    catch (RequestException $e) {
      $message = $e->getMessage();
      $this->loggerFactory->error($message);

      $response = $e->getResponse();
    }

    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function availability($url) {
    try {
      $response = $this->httpClient->get($url);
      return ($response->getStatusCode() == 200) ? TRUE : FALSE;
    }
    catch (RequestException $e) {
      $message = $e->getMessage();
      $this->loggerFactory->error($message);
      return FALSE;
    }
  }

  /**
   * Builds a query string from parameters.
   *
   * @param array $parameters
   *   The parameters.
   *
   * @return string
   *   The query string.
   */
  public function buildQueryString(array $parameters) {
    $query_string = '?';

    foreach ($parameters as $key => $option) {
      if (is_array($option)) {
        foreach ($option as $sub_option) {
          $query_string .= $key . '=' . $sub_option . '&';
        }
      }
      elseif (is_bool($option)) {
        if ($option == TRUE) {
          $raw_option = 'true';
        }
        else {
          $raw_option = 'false';
        }

        $query_string .= $key . '=' . $raw_option . '&';
      }
      else {
        $query_string .= $key . '=' . $option . '&';
      }
    }

    return rtrim($query_string, '&');
  }

}
