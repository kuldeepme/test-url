/**
 * @file
 * Careers Wales Buzz.
 */

(function ($, Drupal) {
  'use strict';
  /**
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.careerswalesBuzz = {
    attach: function (context, settings) {
    }
  };

})(jQuery, Drupal);


class Notice extends React.component {
  render() {
    return (

    )
  }
}


class CardTitleDescription extends React.Component {
  // React components are simple functions that take in props and state, and render HTML
  render() {
    return (
        <article className="card card--style-card js-card card--33">
          <div className="card__inner">
            <div className="card__content">
              <a href={ this.props.link } className="content__link" title={"Link to" + this.props.title}>
                <div className="link__image">
                  <img alt={ this.props.alt } src={ this.props.image }/>
                </div>
                <span>{ this.props.title }</span>
              </a>
              <div className="content__body">
                { this.props.description }
              </div>
            </div>
          </div>
        </article>
    )
  }
}



class Progress extends React.Component {
  // React components are simple functions that take in props and state, and render HTML
  render() {
    return (
        <div className="form__progress">
          <div className="progress__step step--complete">
            <button value="Get started" className="step__button">Get started</button>
          </div>
          <div className="progress__step">
            <button value="Tell us a little bit about yourself" className="step__button">Tell us a little bit about yourself</button>
          </div>
          <div className="progress__step">
            <button value="Employment and qualifications" className="step__button" disabled="">Employment and qualifications</button>
          </div>
          <div className="progress__step">
            <button value="Special circumstances" className="step__button" disabled="">Special circumstances</button>
          </div>
          <div className="progress__step">
            <button value="Results" className="step__button" disabled="">Results</button>
          </div>
        </div>
    )
  }
}

class Step1 extends React.Component {
  render() {
    return (
      <div>
        <div className="gel-content-row">
          <CardTitleDescription link="https://google.com" title={'THis is a title'} alt={'test alt'} description={'this is a description'} image={'https://source.unsplash.com/530x353/?business'}/>
          <CardTitleDescription link="https://google.com" title={'THis is a title'} alt={'test alt'}  description={'this is a description'} image={'https://source.unsplash.com/530x353/?business'}/>
          <CardTitleDescription link="https://google.com" title={'THis is a title'} alt={'test alt'}  description={'this is a description'} image={'https://source.unsplash.com/530x353/?business'}/>
        </div>
      </div>
    )
  }
}



class Actions extends React.Component {

  // React components are simple functions that take in props and state, and render HTML
  render() {
    return (

        <footer className="form__footer">
          <button className="button button--icon icon--left icon--chevron-left button--style-dark form__button-back" value="Back">Back</button>
          <button className="button button--icon icon--chevron-right button--style-dark form__button-next" value="Next">Next</button>
        </footer>

    )
  }
}



class Buzz extends React.Component {
  // React components are simple functions that take in props and state, and render HTML
  render() {
    return (
        <form>
          <Progress/>

          <Step1/>


          <div className="test">sdg</div>
           <Actions/>
        </form>
    )
  }
}

ReactDOM.render(<Buzz/>, document.getElementById('buzz'));