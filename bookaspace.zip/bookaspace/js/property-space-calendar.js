document.addEventListener('DOMContentLoaded', function() {
    var space_id = drupalSettings.space_ids;
    var uid = drupalSettings.uid;
    if (space_id.length > 0){
      jQuery.each(space_id, function(index, value){
        var calendar_id = 'calendar-property-'+value.nid;
        var minTime = value.minTime;
        var maxTime = value.maxTime;
        var calendarEl = document.getElementById(calendar_id);
        var calendar = new FullCalendar.Calendar(calendarEl, {
          plugins: ['interaction', 'dayGrid', 'timeGrid'],
          contentHeight: "auto",
          minTime: minTime,
          maxTime: maxTime,
          defaultDate: new Date(),
          header: {
            left: 'prev,next',
            center: 'title',
            right: ''
          },
          defaultView: 'timeGridWeek',
          selectable: true,
          editable: true,
          select: function(arg) {
            update_space_checkout_form(arg, calendar);
          },
          events: {
            url: '/bs_calendar_data_view?calendar_type=order&type=spaces&space='+value.nid+'&uid='+uid,
            type: 'POST',
            error: function() {
            },
            success: function(data) {
            },
          },
          eventDrop: function(event, revertFunc) {
            update_space_checkout_form_element(event.event.start, event.event.end);
          },
          eventResize: function(event) {
            update_space_checkout_form_element(event.event.start, event.event.end);
          }
        });
        calendar.render();
      });
   }
});

// Show reservation details
function update_space_checkout_form(arg, calendar) {
  var event_data = format_event_datetime(arg.startStr, arg.endStr);
  if (event_data.date <= event_data.current_date) {
    alert("Please select future date!");
  }
  else {
    var start = new Date(event_data.date + 'T' + event_data.start_time);
    var end = new Date(event_data.date + 'T' + event_data.end_time);
    var title = prompt('Enter title');
    if (title !== null) {
      calendar.addEvent({
        title: title,
        start: start,
        end: end,
        allDay: false
      });
    }
  }
}

// Show reservation details
function update_space_checkout_form_element(event_start, event_end) {
    var event_data = format_event_datetime(event_start, event_end);
    var space_title = jQuery(".colpsMainWrap .panel-group .panel .collapse.in").prev().find('span > .cont > h3').text();
    jQuery("#bs-form-space-checkout .price_calculations").html('');
    jQuery("#bs-form-space-checkout #instrument-fieldset-container .btn-check_availability").removeClass('hidden');
    jQuery("#bs-form-space-checkout .btn-reserve").addClass('hidden');
    jQuery(".bs-form-space-checkout .form-item-spaces .select-wrapper .form-select option").filter(function() {
      return jQuery(this).text() == space_title;
    }).attr('selected', true);
    jQuery(".bs-form-space-checkout .form-date").val(event_data.date);
    jQuery(".bs-form-space-checkout .form-item-from-time .select-wrapper .form-select option").filter(function() {
      return jQuery(this).text() == event_data.start_time;
    }).attr('selected', true);

    jQuery(".bs-form-space-checkout .form-item-to-time .select-wrapper .form-select option").filter(function() {
      return jQuery(this).text() == event_data.end_time;
    }).attr('selected', true);

/*    jQuery("html, body").stop().animate({
        scrollTop: jQuery(".main-container").offset().top - 20
    }, 1000);*/
}

// Update entry link add additional arguments.
function format_event_datetime(event_start, event_end) {
  var event_time = {};
  var start_str = event_start;
  var end_str = event_end;
  var date = new Date(start_str);
  var start_time = new Date(start_str);
  var end_time = new Date(end_str);

  var month = date.getMonth()+1;
  var day = date.getDate();
  var full_date = date.getFullYear() + '-' +
    ((''+month).length<2 ? '0' : '') + month + '-' +
    ((''+day).length<2 ? '0' : '') + day;

  var start_hour = ((''+start_time.getHours()).length<2 ? '0' :'') + start_time.getHours();
  var start_minute = ((''+start_time.getMinutes()).length<2 ? '0' :'') + start_time.getMinutes();
  var start_time_index = start_hour + ":" + start_minute;

  var end_hour = ((''+end_time.getHours()).length<2 ? '0' :'') + end_time.getHours();
  var end_minute = ((''+end_time.getMinutes()).length<2 ? '0' :'') + end_time.getMinutes();
  var end_time_index = end_hour + ":" + end_minute;

  var d = new Date();
  var month = d.getMonth()+1;
  var day = d.getDate();
  var current_date = d.getFullYear() + '-' +
      ((''+month).length<2 ? '0' : '') + month + '-' +
      ((''+day).length<2 ? '0' : '') + day;

  event_time = {
    current_date: current_date,
    date: full_date,
    start_time: start_time_index,
    end_time: end_time_index
  };
  return event_time;
}
