
jQuery( document ).ready(function() {
    if(jQuery("#spacemap").length){
                 spacemapinitMap();
             }
});

(function($) {
    Drupal.behaviors.myBehavior = {
        attach: function (context, settings) {
            var maxLength = 210;
            $(".field--name-field-space-description p").each(function(){

                var myStr = $(this).text();
                if($.trim(myStr).length > maxLength){
                    var newStr = myStr.substring(0, maxLength);
                    var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
                    $(this).empty().html(newStr);
                    $(this).append(' <a href="javascript:void(0);" class="read-more">Read more</a>');
                    $(this).append('<span class="more-text">' + removedStr + '</span>');
                }
            });
            $(".read-more").click(function(){
                $(this).siblings(".more-text").contents().unwrap();
                $(this).remove();
            });

            $('.my_properties_small_menu', context).once('html5').click(function () {
                $(this).next().toggle();
                return false;
            });

            // //Load the map
             

            //Scroll to the top of the page when clicking Search a space
            $(".homepage_style .block-views-blockhome-how-it-works-block-1 .search_a_space").once('html5').click(function() {
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return false;
            });

           //Footer accordion on mobile
            $('.region-footer-menu nav h2', context).once('html5').click(function () {
                var panel = this.nextElementSibling.nextElementSibling;
                $(panel).toggle("slow");
            });

            //FAQ - show questions when clicking on the categories on the left side
            $(".path-help .bs-region--left .field-content span").once('html5').click(function() {
                //Get the element id
                var elem_id = $(this).attr('id');
                //Get the category id
                var cat_id = elem_id.replace('faq_cat_','');
                //Hide all questions/answers on the right side
                $(".path-help .bs-region--right .view-content .views-row > div").hide("slow");
                //Show the ones with css of the cat_id
                $('.path-help .bs-region--right .view-content .views-row .' + cat_id).show("slow");
                //
                $('.path-help .bs-region--right .view-content .views-row .' + cat_id + ' div:nth-child(2)').hide();
                //Remove class "selected" from all span
                $(".path-help .bs-region--left .field-content span").removeClass("selected");
                //Add class "selected" to the current span
                $(this).addClass("selected");
            });

            //FAQ - toggle answers when clicking on the questions
            $(".path-help .bs-region--right .view-content .views-row > div > div").once('html5').click(function() {
                $(this).next().toggle("slow");
            });

            //FAQ - trigger click on the first category on the left side "menu"
            $(".path-help .bs-region--left .views-row:nth-child(1) .field-content span a").once('html5').click();


            //CHECKOUT PAGE
            //On the checkout page -> services -> requested items, add the + and - and set as the design
            //Adding the triggers is above, outside of document ready section
            //$('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter('.checkout-page .block-region-left .form-type-number input.form-number');
            if(!$('.quantity-nav-left').length){
                $('<div class="quantity-nav-left"><div class="quantity-button quantity-up">+</div></div>').once('html5').insertBefore('.checkout-page .block-region-left .form-type-number input.form-number');
                $('<div class="quantity-nav-right"><div class="quantity-button quantity-down">-</div></div>').once('html5').insertAfter('.checkout-page .block-region-left .form-type-number input.form-number');
            }



            //When a user changes the room layout, display on the form on the right side
            //$(".checkout-page .block-region-left #edit-space-layout-wrapper input").once('html5').click(function() {
            $('.checkout-page .block-region-left input[name="space_layout_wrapper"]').once('html5').click(function() {
                //Get the src of the clicked image
                var img_src = ($(this).next().attr('src'));
                //Put it on the right side
                $(".checkout-page .block-region-right .room_layout img").attr('src', img_src);
                //Get the text from the label
                var str_text = ($(this).next().next().text());
                //Put it on the right side
                $(".checkout-page .block-region-right .room_layout span").text(str_text);
            });

            //On the checkout page -> services -> requested items, set it as design
            //Adding the + and - to the select['number'] is below, on document ready section
            $('.checkout-page .block-region-left .form-type-number').each(function() {
                var spinner = jQuery(this),
                    input = spinner.find('input[type="number"]'),
                    btnUp = spinner.find('.quantity-up'),
                    btnDown = spinner.find('.quantity-down'),
                    min = input.attr('min'),
                    max = input.attr('max');

                var newVal = 0;
                btnUp.once('html5').click(function() {
                    var oldValue = parseFloat(input.val());
                    if (oldValue >= max) {
                        newVal = oldValue;
                    } else {
                        newVal = oldValue + 1;
                    }

                    //Call a function that will calculate the changes and display them
                    checkout_page_extra_services_changed(spinner, newVal);
                });

                btnDown.once('html5').click(function() {
                    var oldValue = parseFloat(input.val());
                    if (oldValue <= min) {
                        newVal = oldValue;
                    } else {
                        newVal = oldValue - 1;
                    }

                    //Call a function that will calculate the changes and display them
                    checkout_page_extra_services_changed(spinner, newVal);
                });
            });

            //Toggle next each tr line of table, such as on dashboard page
            $(".tr_opener_ds").once("ds_tr_open").click(function(){
                //Show/hide extra details tr
                $(this).siblings().toggle('slow');
            });
        },
    };




    /*REGION CHECKOUT FORM*/
    function checkout_page_extra_services_changed(spinner, new_val){
        //Update the spinner
        spinner.find("input").val(new_val);
        spinner.find("input").trigger("change");

        checkout_page_update_extra_services_on_checkout_form();
    }

    /*
     Update the services on the checkout form, on the right side of the checkout page
     */
    function checkout_page_update_extra_services_on_checkout_form(){

        //Empty all extra services on the right side
        $(".checkout-page .block-region-right .price_calculations .extra_services").empty();

        //Run on all extra services elements, check which ones are with values and add to display on the right side
        $(".checkout-page .block-region-left .extra_services .service_paid_item").each(function( index,element ) {
                var str_name = $(this).find($('.name_desc .name')).text();
                var str_currency = $(this).find($('.currency_price .currency')).text();
                var str_price = $(this).find($('.currency_price .price')).text();
                var requested_value = $(this).find($('.form-type-number .form-number')).val();

                if(parseFloat(requested_value) > 0){
                    checkout_page_extra_service_add_row_to_checkout_form(str_name, str_currency, str_price, requested_value);
                }
            }
        );

        checkout_page_calculate_totals();
    }

    /*
     Add a row to the checkout form, on the right side of the checkout page
     */
    function checkout_page_extra_service_add_row_to_checkout_form(str_name, str_currency, str_price, requested_value){
        var flt_total_price = parseFloat(requested_value) * parseFloat(str_price);

        var str_html =
            '<div class="row">' +
            '<div class="col-xs-9"><span class="name">'+str_name+'</span> <span class="currency">'+ str_currency +'</span><span class="price">'+ str_price +'</span> X <span class="amount">'+requested_value+'</span> unit</div>' +
            '<div class="col-xs-3"><span class="total_row_price"><span class="currency">'+ str_currency+'</span><span class="row_total_price">' + flt_total_price +'</span></div>' +
            '</div>';
        $(".checkout-page .block-region-right .price_calculations .extra_services").append(str_html);
    }

    /*
     Calculate totals on the checkout form, on the right side of the checkout page
     */
    function checkout_page_calculate_totals(){

        //Calculate sub total price
        var sub_total_price = 0;
        $(".checkout-page .block-region-right .row_total_price").each(function( index,element ) {
            sub_total_price += parseFloat($(this).text());
        });
        sub_total_price = sub_total_price.toFixed(2);
        $(".checkout-page .block-region-right .sub_total_price .price").text(sub_total_price);

        //Calculate VAT
        var flt_vat_percentage = $(".checkout-page .block-region-right .price_calculations #lbl_vat").text();


        var total_vat = parseFloat(sub_total_price * (flt_vat_percentage / 100)).toFixed(2);
        $(".checkout-page .block-region-right .total_vat .price").text(total_vat);

        //Calculate total price + vat
        var total_price_plus_vat = parseFloat(sub_total_price) + parseFloat(total_vat);
        $(".checkout-page .block-region-right .total_price .total_price_with_vat .price").text(total_price_plus_vat.toFixed(2));
    }
    /*END REGION CHECKOUT FORM*/







    //Enable/disable weekdays
    $('input[name^="weekdays_day_"]').once("html5").click(function(){
        var getCheckboxId = $(this).attr("name");
        var getTermId = getCheckboxId.split("weekdays_day_");
        if($(this).prop("checked") == true){
            //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').removeAttr("disabled");
            //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').removeAttr("disabled");
            $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').removeAttr("disabled");
            $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').removeAttr("disabled");

            //Blur event to validate data
            $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').blur(function() {
                var elem_start_time = $('select[name^="weekdays_start_time_'+getTermId[1]+'"]');
                var elem_end_time = $('select[name^="weekdays_end_time_'+getTermId[1]+'"]');
                var current_element = "start_time";
                //validate_time_range(elem_start_time, elem_end_time, current_element);
            });
            $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').blur(function() {
                var elem_start_time = $('select[name^="weekdays_start_time_'+getTermId[1]+'"]');
                var elem_end_time = $('select[name^="weekdays_end_time_'+getTermId[1]+'"]');
                var current_element = "end_time";
                //validate_time_range(elem_start_time, elem_end_time, current_element);
            });
        }
        else if($(this).prop("checked") == false){
            //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').attr("disabled",true);
            //$('input[name^="weekdays_start_time_'+getTermId[1]+'"]').val("");
            //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').attr("disabled",true);
            //$('input[name^="weekdays_end_time_'+getTermId[1]+'"]').val("");
            $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').attr("disabled",true);
            $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').prop('selectedIndex',0);
            $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').attr("disabled",true);
            $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').prop('selectedIndex',0);
            //Turn off the blur event
            $('select[name^="weekdays_start_time_'+getTermId[1]+'"]').off("blur");
            $('select[name^="weekdays_end_time_'+getTermId[1]+'"]').off("blur");
        }
    });



    //Empty chat area on chat messages, on ajaxComplete
    $(document).once('bs_chat').ajaxComplete(function (e, xhr, settings) {
        $('#edit-new-msg').val('');
    });


     $(document).ready(function(){

         //alert('a');

         //$("#edit-actions").once("html5").click(function(){
             //alert('1');
         //});

         $(document).click(function() {
             //alert("CLose .small_menu");
             $(".small_menu").hide();
         });



         //Click on TR of a chat to open the chat-messages page
         $(".tr_chat").once("html5").click(function(){
             var chat_id = $(this).attr('id');
             window.location.href = "inbox/" + chat_id;
         });

        //Toggle next line of table, such as on reservation page
        $(".tr_opener").once("html5").click(function(){

            //Show/hide extra details tr
            $(this).next().toggle('slow');

            //Handle the border of the opener
            if($(this).find("td").css("border-bottom-width") == "0px"){
                $(this).find("td").css("border-bottom-width", "1px");
                $(this).find("td:nth-child(1)").css("border-bottom-left-radius", "6px");
                $(this).find("td:last-child").css("border-bottom-right-radius", "6px");
            } else {
                $(this).find("td").css("border-bottom-width", "0px");
                $(this).find("td:nth-child(1)").css("border-bottom-left-radius", "0px");
                $(this).find("td:last-child").css("border-bottom-right-radius", "0px");
            }

        });

         //Update the services on the checkout form, on the right side of the checkout page, when the page loads
         checkout_page_update_extra_services_on_checkout_form();

        //MAP
        var maxLength = 280;
        $(".field--name-field-space-description p").each(function(){
            var myStr = $(this).text();
            if($.trim(myStr).length > maxLength){
                var newStr = myStr.substring(0, maxLength);
                var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
                $(this).empty().html(newStr);
                $(this).append(' <a href="javascript:void(0);" class="read-more">Read more</a>');
                $(this).append('<span class="more-text">' + removedStr + '</span>');
            }
        });
        $(".read-more").click(function(){
            $(this).siblings(".more-text").contents().unwrap();
            $(this).remove();
        });
        $('span').addClass('collapsed');




        //EDIT NEAR BY ON PROPERTY PAGE
         $("#edit-near-by-auto").once("html6").change(function() {
             edit_near_by_auto_set();
         });

         //SET ON PAGE LOAD
         edit_near_by_auto_set();
    });


})(jQuery);


/*
Show and hide fields on page edit properties -> near by section
*/
function edit_near_by_auto_set(){

    if (jQuery("#edit-near-by-auto").is(":checked")) {
        //Auto
        jQuery(".near_by #near_by_auto").addClass('selected');
        jQuery(".near_by #near_by_manual").removeClass('selected');
        jQuery(".near_by #parking-container").show();
        jQuery(".near_by #restaurant-container").show();
        jQuery(".near_by #edit-parking").hide();
        jQuery(".near_by #edit-restaurant").hide();
    } else {
        //Manual
        jQuery(".near_by #near_by_manual").addClass('selected');
        jQuery(".near_by #near_by_auto").removeClass('selected');
        jQuery(".near_by #parking-container").hide();
        jQuery(".near_by #restaurant-container").hide();
        jQuery(".near_by #edit-parking").show();
        jQuery(".near_by #edit-restaurant").show();
    }
}

/*
Show the fields that add language on edit property and edit space pages
 */
function show_add_langauge(){
    var lang = jQuery("#edit-other-languages").val();
    jQuery(".div_language_" + lang).removeClass('hide');
}




function spacemapinitMap(lat, lng, zoom_level, context) {
    if(!zoom_level){
        zoom_level = 15;
    }
    var vlat = jQuery('#spacemap').attr('lat');
    var vlng = jQuery('#spacemap').attr('lng');
    
    var map = new google.maps.Map(document.getElementById('spacemap'), {
          center: {lat: Number(vlat), lng: Number(vlng)},
          zoom: zoom_level,
        });
  var marker = new google.maps.Marker({
    position: {lat: Number(vlat), lng: Number(vlng)},
    map: map,
  });
}





