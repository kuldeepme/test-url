/*
	Load more content with jQuery - May 21, 2013
	(c) 2013 @ElmahdiMahmoud
*/

(function ($, Drupal, drupalSettings) {

    Drupal.behaviors.loadMore = {
        attach: function (context, settings) {
            var selector = $("details[data-drupal-selector='edit-tabs-results'] div.programme");

            var show_more_pager = drupalSettings.show_more_pager;
            var number_to_display = selector.length;
            var number_already_displayed = show_more_pager;

            selector.css('display', 'none');

            if (number_to_display == 0) {
                $("[data-drupal-selector='edit-tabs-results-content-load-more']").css('display', 'none');
            }

            if (number_to_display == number_already_displayed) {
                $("[data-drupal-selector='edit-tabs-results-content-load-more']").css('display', 'none');
            }

            if (drupalSettings.num_prog_to_display) {
                selector.slice(0, drupalSettings.num_prog_to_display).css('display', 'block');
            } else {
                selector.slice(0, show_more_pager).css('display', 'block');
            }

            $("[data-drupal-selector='edit-tabs-results-content-load-more']").once('loadMore').on('click', function (e) {
                e.preventDefault();
                selector.filter(function() {
                    return $(this).css('display') == 'none';
                }).slice(0, show_more_pager).css('display', 'block');

                number_already_displayed = selector.filter(function() {
                    return $(this).css('display') !== 'none';
                }).length;

                drupalSettings.num_prog_to_display = number_already_displayed;

                if (number_to_display == number_already_displayed) {
                    $("[data-drupal-selector='edit-tabs-results-content-load-more']").css('display', 'none');
                }
            });
        }
    };

})(jQuery, Drupal, drupalSettings);