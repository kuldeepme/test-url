
(function ($) {

  'use strict';

  Drupal.behaviors.videos = {
    attach: function (context) {

      if ($('.js-video').length) {
        $(window).once('videos').on('resize load', function() {

          $('.js-video').each(function() {
            var video = $(this).find('iframe');

            video.css('width', '100%');
            video.height((video.width() / 16) * 9);
          });
        });
      }
      $(".card .stack-video").on('click', function (ev) {
        var src_url;
        var video_url = $(this).attr('href');
        var width = $(this).find(".content_ratio").innerWidth();
        var height = $(this).find(".content_ratio").innerHeight();
        var video_id = video_url.split('v=')[1];
        if (video_id.indexOf('&') > -1) {
            var video_id_split = video_id.split('&');
            src_url = "https://www.youtube.com/embed/" + video_id_split[0] + "?rel=0&autoplay=1&" + video_id_split[1];
        }
        else {
            src_url = "https://www.youtube.com/embed/" + video_id + "?rel=0&autoplay=1";
        }
        var youtube_iframe = "<iframe src='" + src_url + "' width='" + width + "' height='" + height + "'>";
        $(this).find(".content__image__new").html(youtube_iframe);
        ev.preventDefault();    
      });
    }
  }

})(jQuery, Drupal);


