(function ($, Drupal) {

  Drupal.behaviors.accordion = {

    attach: function (context, settings) {

      if ($('.js-accordion').length) {

        $(context).find('.js-accordion').once('accordion').each(function (index) {

          // Cache repeated selectors.
          var accordions = document.querySelectorAll('.accordion');
          var panelLinks = document.querySelectorAll('.accordion__heading');
          var expandAll = document.querySelectorAll('.accordion__action--expand');
          var collapseAll = document.querySelectorAll('.accordion__action--collapse');

          // Old browser code. If classList not supported then...
          if (!document.querySelector('body').classList || typeof document.body.style.transition !== 'string') {

            // For each accordion on the page update the class to contain
            // no-support class which opens all panels by default and removes
            // chevrons via CSS.
            for (var n = 0; n < accordions.length; n++) {
              accordions[n].setAttribute('class', 'panel-group accordion accordion--no-support');
            }

            // Exit the panelsClosure because we don't want to run the rest.
            return;
          }

          // For every accordion remove no js class if js.
          for (var g = 0; g < accordions.length; g++) {
            accordions[g].classList.remove('accordion--no-js');
          }

          // For every accordion add a unique id to the buttons.
          for (var i = 0; i < accordions[index].childNodes.length; i++) {
            if (accordions[index].childNodes[i].className === 'accordion__actions') {
              var childNodes = accordions[index].childNodes[i];

              var expandButtonText = document.createTextNode(Drupal.t('Expand all'));
              var collapseButtonText = document.createTextNode(Drupal.t('Close all'));

              var expandButton = document.createElement('button');
              expandButton.classList.add('accordion__action');
              expandButton.classList.add('accordion__action--expand');
              expandButton.appendChild(expandButtonText);

              var collapseButton = document.createElement('button');
              collapseButton.classList.add('accordion__action');
              collapseButton.classList.add('accordion__action--collapse');
              collapseButton.appendChild(collapseButtonText);

              accordions[index].childNodes[1].appendChild(expandButton);
              accordions[index].childNodes[1].appendChild(collapseButton);

              for (var x = 0; x < childNodes.childNodes.length; x++) {
                var actionsNodes = childNodes.childNodes;
                if (actionsNodes[x].classList) {
                  actionsNodes[x].setAttribute('title', Drupal.t('Expand accordion !id', {'!id': index + 1}));
                  if (actionsNodes[x].classList.contains('accordion__action--collapse')) {
                    actionsNodes[x].setAttribute('title', Drupal.t('Close accordion !id', {'!id': index + 1}));
                  }
                }
              }
              expandAll = document.querySelectorAll('.accordion__action--expand');
              collapseAll = document.querySelectorAll('.accordion__action--collapse');
            }
          }

          var getParent = function (tag, selectorClass) {

            // Check if parent is .panel, if not then go to next parent until we
            // find it. Equivalent of jQuery.parents()
            while (!tag.parentNode.classList.contains(selectorClass)) {

              // If we aren't inside a .panel then stop this loop because JS will
              // error out otherwise.
              if (tag.tagName.toLowerCase() === 'body') {
                break;
              }
              tag = tag.parentNode;
            }

            // While stops on first child of .panel, so we return .panel itself.
            return tag.parentNode;
          };

          var testAll = function (thisAccordion) {
            var thisAccordionOpen = thisAccordion.querySelectorAll('.accordion__panel.js-open');
            var thisAccordionPanels = thisAccordion.querySelectorAll('.accordion__panel');

            // Removed assumption all panels are collapsed or open.
            thisAccordion.classList.remove('accordion--all-expanded');
            thisAccordion.classList.remove('accordion--all-collapsed');
            // If all are open.
            if (thisAccordionOpen.length === 0) {
              thisAccordion.classList.add('accordion--all-collapsed');
            }

            // If all are collapsed.
            if (thisAccordionOpen.length === thisAccordionPanels.length) {
              thisAccordion.classList.add('accordion--all-expanded');
            }
          };

          var togglePanel = function (panel, toOpen) {

            // If add or remove class passed in specifically then use that,
            // otherwise use default of toggle.
            toOpen = typeof toOpen === 'undefined' ? !panel.hasAttribute('open') : toOpen;

            // Cache repeated selectors.
            var panelBody = panel.querySelector('.accordion__body');
            var panelInner = panel.querySelector('.accordion__body-inner');
            var thisAccordion = getParent(panel, 'accordion');

            if (toOpen) {
              panel.setAttribute('open', true);
              panel.classList.add('js-open');
              setTimeout(function () {
                panelBody.style.height = panelInner.offsetHeight + 'px';
                panelBody.style.opacity = 1;

                testAll(thisAccordion);
              }, 1);
            }
            else {
              panelBody.style.height = panelInner.offsetHeight + 'px';
              setTimeout(function () {
                panelBody.style.height = 0;
                panelBody.style.opacity = 0;
                panel.classList.remove('js-open');
              }, 1);
            }
          };

          // For every panel link in every accordion.
          for (var i = 0; i < panelLinks.length; i++) {

            // Closure required to stop leaky variables because for loops
            // do not have a scope.
            (function () {
              var thisTag = panelLinks[i];

              // Set our panel to the last element our while loop hit before
              // exiting.
              var panel = getParent(thisTag, 'accordion__panel');

              // Cache repeated selectors.
              var panelBody = panel.querySelector('.accordion__body');

              // If this panel is animating.
              var animating = false;

              // Remove the directly set height attribute after transition to
              // stop height issues after resize.
              panelBody.addEventListener('transitionend', function () {
                if (panel.classList.contains('js-open')) {
                  panelBody.style.height = 'auto';
                }
                else {
                  panelBody.removeAttribute('style');
                  panel.removeAttribute('open');
                }
                testAll(getParent(panel, 'accordion'));
                animating = false;
              }, false);

              panelLinks[i].onclick = function (e) {
                e.preventDefault();

                // Only if the panel is not currently animating do we do anything.
                // This prevents weird things when spam clicking.
                if (animating !== true) {
                  animating = true;

                  togglePanel(panel);
                }
              };
            }());
          }

          // For every expand all button (in case of multiple accordions).
          for (var j = 0; j < expandAll.length; j++) {
            expandAll[j].onclick = function () {

              // Cache repeated selectors.
              var thisAccordion = getParent(this, 'accordion');
              var thisPanels = thisAccordion.querySelectorAll('.accordion__panel');

              // For every panel that this expand all button should effect.
              for (var k = 0; k < thisPanels.length; k++) {

                // Closure important because for loop has no scope.
                (function () {
                  var thisPanel = thisPanels[k];

                  // Toggle the panel, specifically removing the collapsed class.
                  togglePanel(thisPanel, true);
                }());
              }
            }
          }

          // For every collapse all button (in case of multiple accordions).
          for (var l = 0; l < collapseAll.length; l++) {
            collapseAll[l].onclick = function () {

              // Cache repeated selectors.
              var thisAccordion = getParent(this, 'accordion');
              var thisPanels = thisAccordion.querySelectorAll('.accordion__panel');

              // For every panel that this collapse all button should effect.
              for (var m = 0; m < thisPanels.length; m++) {

                // Closure important because for loop has no scope.
                (function () {
                  var thisPanel = thisPanels[m];

                  // Toggle the panel, specifically adding the collapsed class.
                  togglePanel(thisPanel, false);
                }());
              }
            }
          }

        });
      }
    }
  }
      //Collapsible
      $(".collapsible-content").hide();
        $(".collapsible_show_hide").on("click", function (event) {
            $(this).toggleClass('up');
            var txt = $(this).prev('.collapsible-content').is(':visible') ? 'show more ' : 'show less';
            $(this).text(txt);
            $(this).prev('.collapsible-content').slideToggle(200);
            event.preventDefault();
        });
})(jQuery, Drupal);
