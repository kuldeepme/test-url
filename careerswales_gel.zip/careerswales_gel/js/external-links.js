(function ($) {
    'use strict';

    Drupal.behaviors.external = {
        attach: function (context) {

            // Helper function to determine whether a link is external.
            function is_external(l) {

              var host = window.location.host;
              var link = $('<a>', { href: l })[0].hostname;

              if ((l.indexOf('.gov.wales') !== -1) || (l.indexOf('.llyw.cymru') !== -1)) {
                return false;
              }
              if (host && link) {
                return link !== host
              }

              return false;
            }

            var $a = $('a:not(.ignore-external):not(.ignore-link)');

            if ($a.length) {

                var mailtoTitleText =  Drupal.t('Email link to');
                var mailtoHiddenText =  Drupal.t('opens email client');

                var externalTitleText =  Drupal.t('Link to');
                var externalHiddenText =  Drupal.t('external website');

                $a.once('external').each(function () {

                      var link = $(this);
                      var href = link.attr('href');
                      if (href) {
                        if (href.indexOf('mailto:') >= 0) {
                          link.attr('title', mailtoTitleText + ' ' + href.replace('mailto:', ''));
                          link.append('<span class="external">(' + mailtoHiddenText + ')</span>');
                        }

                        // Internal cards and links.
                        if (!(href.indexOf('mailto:') >= 0) && !is_external(href)) {

                          // Handle cards.
                          if (link.hasClass('content__link')) {
                            var linkTitle = link.find('span').html();
                          }
                          // Icon cards.
                          else if (link.hasClass('card__inner')) {
                            var linkTitle = link.find('.body__title').html();
                          }
                          // Banners and image only links.
                          else if (link.find('img')[0]) {
                            var linkTitle = link.find('img').attr('alt');
                          }
                          // And normal links.
                          else {
                            var linkTitle = link.html();
                          }
                            var cleanedTitle = linkTitle.replace(/(<([^>]+)>)/ig, '');
                            link.attr('title', externalTitleText + ' ' + cleanedTitle.replace(/\s\s+/g, ' ').replace('&amp;', '&').replace(/ {1,}/g, ' '));
                        }

                        // External cards and links.
                        if (!(href.indexOf('mailto:') >= 0) && is_external(href)) {

                          // Handle cards.
                          if (link.hasClass('content__link')) {
                            var linkTitle = link.find('span').html();
                          }
                          // Icon cards.
                          else if (link.hasClass('card__inner')) {
                            var linkTitle = link.find('.body__title').html();
                          }
                          // Banners and image only links.
                          else if (link.find('img')[0]) {
                            var linkTitle = link.find('img').attr('alt');
                          }
                          // And normal links.
                          else {
                            var linkTitle = link.html();
                          }

                            var cleanedTitle = linkTitle.replace(/(<([^>]+)>)/ig, '');
                            link.attr('title', externalTitleText + ' ' + cleanedTitle.replace(/\s\s+/g, ' ').replace('&amp;', '&').replace(/ {1,}/g, ' '));
                            link.append('<span class="external">(' + externalHiddenText + ')</span>');
                        }

                        if (!(href.indexOf('mailto:') >= 0) && is_external(href) && link.hasClass('button--icon')) {
                          link.addClass('icon--external-link');
                        }
                      }

                });
            }
        }
    }
})(jQuery, Drupal);