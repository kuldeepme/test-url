(function ($) {
  Drupal.behaviors.cookieControl = {

    createCookie:function(name, value, days) {
      var date = new Date();
      var time = date.getTime();
      var expireTime = time + 1000 * 36000;
      date.setTime(expireTime);
      document.cookie = name + "=" + value + ';expires=' + date.toGMTString() + ';path=/;secure';
    },
    readCookie: function(name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(';');
      for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
      }
      return null;
    },
    attach: function (context) {
      if (Drupal.behaviors.cookieControl.readCookie("bw-cookieMessage") === null) {
        jQuery("#bwales-cookie-notice").show();
        Drupal.behaviors.cookieControl.createCookie("bw-cookieMessage", true);
        jQuery('body').addClass('cookie-message-visible');
      } else if (Drupal.behaviors.cookieControl.readCookie("bw-cookieMessage") !== null) {
        jQuery("#bwales-cookie-notice").hide();
      }
    }
  }
})(jQuery, Drupal);
