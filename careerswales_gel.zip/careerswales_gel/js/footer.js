(function ($) {

  'use strict';

  Drupal.behaviors.footer = {
    attach: function (context) {

      if ($('.js-share-this-page').length) {
        $('.js-share-this-page').once('share').on('click', function() {
          $(this).toggleClass('active');
        })
      }

      if ($('.js-back-to-top').length) {
        $('.js-back-to-top').once('back').on('click', function() {
          window.scrollTo(0, 0);
        })
      }

      if ($('.js-share-this-page').length) {
        var shareButton = $('.js-share-this-page');
        var shareLinks = shareButton.find('a');
        shareLinks.on('focus', function() {
          shareButton.addClass('active');
        });
        shareLinks.on('blur', function() {
          shareButton.removeClass('active');
        });
      }

    }
  }
})(jQuery, Drupal);