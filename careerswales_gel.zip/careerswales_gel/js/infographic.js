

(function ($, Drupal) {
// Helper function to determine whether or not an element is on screen.
  $.fn.isVisible = function() {
    var elTop = $(this).offset().top;
    var elBottom = elTop + $(this).outerHeight();
    var vpTop = $(window).scrollTop();
    var vpBottom = vpTop + $(window).height();
    return elBottom > vpTop && elTop < vpBottom;
  };

  Drupal.behaviors.infographic = {




    attach: function (context, settings) {


      if ($('.js-card-infographic').length) {

          $(window).once('infographic').on('scroll resize', function () {
            // Runs through each Infographic type card.
            $('.js-card-infographic').each(function () {
              var $this, countTo;
              // If the count has not already run and the card is visible to the
              // viewport.
              if ($(this).isVisible() && !$(this).hasClass('has-counted')) {
                $this = $(this);
                countTo = $(this).data('count-to');
                // If the card has a number to count to.
                if (countTo) {
                  // Counter function.
                  $({Counter: 0}).animate({Counter: countTo}, {
                    duration: 2000,
                    easing: 'swing',
                    step: function () {
                      var currentVal = Math.ceil(this.Counter);
                      // Adds a comma to any number in the thousands.
                      $this.find('.js-counter').html(currentVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                    }
                  });
                  // Adds a has counted class to prevent animations running more
                  // than once.
                  $this.addClass('has-counted');
                }
              }
            });
          })
   

      }

    }
  };

})(jQuery, Drupal);