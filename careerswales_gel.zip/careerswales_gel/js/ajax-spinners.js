/**
 * @file
 * Careers Wales EAG add AJAX spinners.
 */

(function ($) {
    Drupal.behaviors.ajaxSpinners = {
        attach: function (context) {
            if (Drupal.Ajax) {
                var beforeSend = Drupal.Ajax.prototype.beforeSend;
                var success = Drupal.Ajax.prototype.success;
                var error = Drupal.Ajax.prototype.error;

                Drupal.Ajax.prototype.beforeSend = function (xmlhttprequest, options) {
                    beforeSend.call(this, xmlhttprequest, options);

                    $(document).trigger('ajaxBeforeSend', $(this.element));
                };

                Drupal.Ajax.prototype.success = function (response, status) {
                    success.call(this, response, status);

                    $(document).trigger('ajaxSuccess', $(this.element));
                };

                Drupal.Ajax.prototype.error = function (xmlhttprequest, uri, customMessage) {
                    error.call(this, xmlhttprequest, uri, customMessage);

                    $(document).trigger('ajaxError', $(this.element));
                };
            }

            $(document, context).once('attachBeforeSend').bind('ajaxBeforeSend', function (event, element) {
                $(element).addClass('spinner');
            });

            $(document, context).once('attachSuccessError').bind('ajaxSuccess ajaxError', function (event, element) {
                $(element).removeClass('spinner');
            });
        }
    }

})(jQuery, Drupal);
