
(function ($) {

  'use strict';

  Drupal.behaviors.cards = {
    attach: function (context) {

      if ($('.js-card').length) {

        $('.js-card').once('cards').each(function() {
          var card = $(this);
          var prev = $(this).prev();
          var next = $(this).next();
          if (prev.hasClass('card')) {
            card.addClass('card--has-previous');
            var prevCardType = prev.attr('class').split(' ');
            for (var classIndex = 0; classIndex < prevCardType.length; ++classIndex) {
              if (prevCardType[classIndex].match(/card--style-/)) {
                var prevCardClass = prevCardType[classIndex].split('card--style-')[1];
                card.addClass('card-previous-type--' + prevCardClass);
              }
            }
          }
          if (next.hasClass('card')) {
            card.addClass('card--has-next');
            var nextCardType = next.attr('class').split(' ');
            for (var classIndex = 0; classIndex < nextCardType.length; ++classIndex) {
              if (nextCardType[classIndex].match(/card--style-/)) {
                var nextCardClass = nextCardType[classIndex].split('card--style-')[1];
                card.addClass('card-next-type--' + nextCardClass);
              }
            }
          }
        });

      }
    }
  }

})(jQuery, Drupal);


