(function ($) {

  'use strict';

  Drupal.behaviors.header = {
    attach: function (context) {


      if ($('.js-toggle-nav').length) {
        $('.js-toggle-nav').once('nav').on('click', function () {
          $('.js-primary-nav').toggleClass('nav--is-open');
          $('.js-main-content-area').toggleClass('nav--is-open');
        });
      }

      if ($('.js-helper-nav').length) {

        $('.js-helper-nav').once('helper-nav').each(function () {


          var helper = $('.js-helper-nav');
          var primary = $('.js-primary-nav ul');
          // Get only the links from the Helper nav.
          var helperLinks = [];
          helper.find('a').each(function () {
            var href = $(this).attr('href');
            var target = $(this).attr('target');
            var text = $(this).html()
            helperLinks.push('<li class="is-helper"><a href="' + href + '" target="' + target + '">' + text + '</a></li>');
          });
          // Add new links to Primary nav.
          primary.append(helperLinks);


        });


      }


    }
  }
})(jQuery, Drupal);