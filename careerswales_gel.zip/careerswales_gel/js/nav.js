

(function ($) {

  'use strict';

  Drupal.behaviors.nav = {
    attach: function (context) {

    }
  }

})(jQuery, Drupal);


