
(function ($) {

  'use strict';

  Drupal.behaviors.beta = {
    attach: function (context) {

      if ($('.js-beta-banner').length) {
        var betaMessageShouldBeOpen = document.cookie.replace(/(?:(?:^|.*;\s*)betaMessageShouldBeOpen\s*\=\s*([^;]*).*$)|^.*$/, '$1');
        if (betaMessageShouldBeOpen == 'true') {
          $('.js-beta-banner').removeClass('closed');
        }
        else {
          $('.js-beta-banner').addClass('closed');
        }
        $('.js-beta-banner-toggle').once('beta').on('click', function() {
          if (!$('.js-beta-banner').hasClass('closed')) {
            $('.js-beta-banner').addClass('closed');
            document.cookie = 'betaMessageShouldBeOpen=false';
          }
          else {
            $('.js-beta-banner').removeClass('closed');
            document.cookie = 'betaMessageShouldBeOpen=true';
          }
        });
      }



    }
  }

})(jQuery, Drupal);



