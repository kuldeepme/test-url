(function ($, Drupal) {

  Drupal.behaviors.advancedDescription = {
    attach: function (context, settings) {


      $('.js-form-advanced-description-text').hide();
      $('.js-form-advanced-description-link', context).once('advancedDescriptionLink').on('click', function (el) {
        el.preventDefault();
        $(this).toggleClass('advanced-description__link--active');
        $(this).parents('.js-form-group').find('.js-form-advanced-description-text').toggle();
      });

      $('.js-form-advanced-description-text-inline').hide();
      $('.js-form-advanced-description-link-inline', context).once('advancedDescriptionLinkInline').on('click', function (el) {
        el.preventDefault();
        $(this).toggleClass('advanced-description__link--active');
        $(this).parents('.js-group-element').find('.js-form-advanced-description-text-inline').toggle();
      });

    }
  };

})(jQuery, Drupal);
