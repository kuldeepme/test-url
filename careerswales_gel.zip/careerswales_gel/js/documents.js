(function ($) {

  'use strict';

  Drupal.behaviors.documents = {
    attach: function (context) {

      $('.js-document-request',context).once('documents').on('click', function (e) {
          e.preventDefault();
          $(this).next('.js-document-request-body').toggleClass('visible');
      });
    }
  }

})(jQuery, Drupal);