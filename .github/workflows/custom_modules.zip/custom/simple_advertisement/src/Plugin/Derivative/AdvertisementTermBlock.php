<?php

namespace Drupal\simple_advertisement\Plugin\Derivative;

use Drupal\Component\Plugin\Derivative\DeriverBase;

/**
 * Provides block plugin definitions for simple advertisement blocks.
 *
 * @see \Drupal\simple_advertisement\Plugin\Block\SimpleAdvertisementBlock
 */
class AdvertisementTermBlock extends DeriverBase {

  /**
   * {@inheritdoc}
   */
  public function getDerivativeDefinitions($base_plugin_definition) {
    $vid = 'advertisement';
    $terms = \Drupal::entityTypeManager()
      ->getStorage('taxonomy_term')
      ->loadTree($vid, 0, NULL, TRUE);
    if (!empty($terms)) {
      foreach ($terms as $term) {
        $this->derivatives[$term->id()] = $base_plugin_definition;
        $this->derivatives[$term->id()]['admin_label'] = t('Simple Advertisement Block: @name', ['@name' => $term->getName()]);
      }
    }
    return $this->derivatives;
  }

}
