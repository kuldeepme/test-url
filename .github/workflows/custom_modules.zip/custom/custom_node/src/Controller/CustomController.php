<?php

namespace Drupal\custom_node\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * CustomController class.
 */
class CustomController extends ControllerBase {

  /**
   * Callback for content.
   */
  public function content() {
    $build = [];
    $rows = [];
    $create_url = Url::fromRoute('custom_node.create_node');
    $create = Link::fromTextAndUrl(t('Create'), $create_url);
    $update_url = Url::fromRoute('custom_node.update_node');
    $update = Link::fromTextAndUrl(t('Update'), $update_url);
    $delete_url = Url::fromRoute('custom_node.delete_node');
    $delete = Link::fromTextAndUrl(t('Delete'), $delete_url);        
    $rows[] = ['create' => $create, 'update' => $update, 'delete' => $delete];
    $header = [
      'create' => t('Create Node'),
      'update' => t('Update Node'),
      'delete' => t('Delete Node'),
    ];
    //Build the table
    $build['data'] = [
      '#type'    => 'table',
      '#header' => $header,
      '#rows'   => $rows,
      '#empty' => t('No data found'),
    ];
    return [
      '#markup' => render($build),
      '#cache' => ['max-age' => 0],
    ];
  }

}
