<?php

namespace Drupal\custom_node\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;

/**
 * CreateNodeForm class.
 */
class CreateNodeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'create_node_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Title'),
      '#description' => $this->t('Enter node title'),
      '#required' => TRUE,
    ];
    $form['description'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Body'),
      '#description' => $this->t('Enter node body'),
    ];
    $form['#cache'] = ['max-age' => 0];
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $node = Node::create(['type' => 'article']);
    $title = $form_state->getValue('title');
    $body = $form_state->getValue('description');
    $node->set('title', $title);
    //Body can now be an array with a value and a format.
    //If body field exists.
    $body = [
     'value' => $body,
     'format' => 'basic_html',
    ];
    $node->set('body', $body);
    $node->set('uid', 1);
    $node->status = 1;
    $node->enforceIsNew();
    $node->save();    
    drupal_set_message("Node created sucessfully!\n");
  }

}
