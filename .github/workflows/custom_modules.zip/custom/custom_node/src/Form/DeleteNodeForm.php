<?php

namespace Drupal\custom_node\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;

/**
 * DeleteNodeForm class.
 */
class DeleteNodeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'delete_node_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $title = [];

    // Get the form values and raw input (unvalidated values).
    $values = $form_state->getValues();

    // Define a wrapper id to populate new content into.
    $ajax_wrapper = 'my-ajax-wrapper';

    $query = \Drupal::entityQuery('node')
      ->condition('status', 1) //published or not
      ->condition('type', 'article') //content type
      ->pager(10); //specify results to return
    $nids = $query->execute();
    foreach ($nids as $nid) {
      $node = Node::load($nid);
      $title[$node->id()] = $node->getTitle();  
    }
    $form['title_list'] = [
      '#type' => 'select',
      '#title' => $this->t('Title List'),      
      '#options' => $title,
      '#empty_option' => $this->t('- Select node -'),
      '#default_value' => (isset($values['title_list']) ? $values['title_list'] : ''),
      '#ajax' => [
        'callback' => [$this, 'selectNodeTitle'],
        'event' => 'change',
        'wrapper' => $ajax_wrapper,
      ],      
    ];

    // Build a wrapper for the ajax response.
    $form['ajax_container'] = [
      '#type' => 'container',
      '#attributes' => [
        'id' => $ajax_wrapper,
      ]
    ];
    // ONLY LOADED IN AJAX RESPONSE OR IF FORM STATE VALUES POPULATED.
    if (!empty($values) && !empty($values['title_list'])) {      
      $node = Node::load($values['title_list']);
      $form['ajax_container']['title'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Title'),
        '#description' => $this->t('Enter node title'),
        '#required' => TRUE,
        '#value' => $node->getTitle(),
        '#defaule_value' => $node->getTitle(),
      ];
      $form['ajax_container']['description'] = [
        '#type' => 'textarea',
        '#title' => $this->t('Body'),
        '#description' => $this->t('Enter node body'),
        '#value' => $node->body->value,
        '#defaule_value' => $node->body->value,
      ];
      $form['#cache'] = ['max-age' => 0]; 
      $form['actions'] = [
        '#type' => 'actions',
      ];
      // Add a submit button that handles the submission of the form.
      $form['ajax_container']['actions']['submit'] = [
        '#type' => 'submit',
        '#value' => $this->t('Delete'),
      ];       
    }
    return $form;
  }

  /**
   * The callback function for when the `my_select` element is changed.
   *
   * What this returns will be replace the wrapper provided.
   */
  public function selectNodeTitle(array $form, FormStateInterface $form_state) {
    // Return the element that will replace the wrapper (we return itself).
    return $form['ajax_container'];
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $nid = $form_state->getValue('title_list');
    $storage_handler = \Drupal::entityTypeManager()->getStorage("node");
    $entities = $storage_handler->load($nid);
    $entities->delete($entities);   
    drupal_set_message( "Node deleted sucessfully!\n");
  }

}
