<?php

namespace Drupal\custom_user\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * CustomController class.
 */
class CustomController extends ControllerBase {

  /**
   * Callback for content.
   */
  public function content() {
    $build = [];
    $rows = [];
    $create_url = Url::fromRoute('custom_user.create_user');
    $create = Link::fromTextAndUrl(t('Create'), $create_url);
    $update_url = Url::fromRoute('custom_user.update_user');
    $update = Link::fromTextAndUrl(t('Update'), $update_url);
    $delete_url = Url::fromRoute('custom_user.delete_user');
    $delete = Link::fromTextAndUrl(t('Delete'), $delete_url);
    $rows[] = ['create' => $create, 'update' => $update, 'delete' => $delete];
    $header = [
      'create' => t('Create User'),
      'update' => t('Update User'),
      'delete' => t('Delete User'),
    ];
    //Build the table
    $build['data'] = [
      '#type'    => 'table',
      '#header' => $header,
      '#rows'   => $rows,
      '#empty' => t('No data found'),
    ];
    return [
      '#markup' => render($build),
      '#cache' => ['max-age' => 0],
    ];
  }

}
