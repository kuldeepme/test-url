<?php

namespace Drupal\custom_user\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\user\Entity\User;
use Drupal\Core\Url;

/**
 * UpdateUserForm class.
 */
class UpdateUserForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'update_User_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $users = [];

    // Get the form values and raw input (unvalidated values).
    $values = $form_state->getValues();

    // Define a wrapper id to populate new content into.
    $ajax_wrapper = 'my-ajax-wrapper';
    $error_wrapper = 'my-error-wrapper';

    $query = \Drupal::entityQuery('user')
             ->condition('status', 1);
    $ids = $query->execute();    
    //kint($ids); die("tese");
    foreach ($ids as $uid) {
      $user = User::load($uid);
      if ($user->id() != 1) {
        $users[$user->id()] = $user->getUsername();
      }
    }    
    $form['user_list'] = [
      '#type' => 'select',
      '#title' => $this->t('User List'),      
      '#options' => $users,
      '#empty_option' => $this->t('- Select user -'),
      '#default_value' => (isset($values['user_list']) ? $values['user_list'] : ''),
      '#ajax' => [
        'callback' => [$this, 'selectUserName'],
        'event' => 'change',
        'wrapper' => $ajax_wrapper,
      ],      
    ];

    // Build a wrapper for the ajax response.
    $form['ajax_container'] = [
      '#type' => 'container',
      '#attributes' => [
        'id' => $ajax_wrapper,
      ]
    ];
    // ONLY LOADED IN AJAX RESPONSE OR IF FORM STATE VALUES POPULATED.
    if (!empty($values) && !empty($values['user_list'])) {      
      $user = User::load($values['user_list']);
      $form['ajax_container']['user_name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('User Name'),
        '#description' => $this->t('Enter user name without whitespace'),
        '#required' => TRUE,
        '#value' => $user->getUsername(),
        '#defaule_value' => $user->getUsername(),
/*        '#ajax' => [
          'callback' => [$this, 'validateFormNew'],
          'event' => 'submit',
          'wrapper' => $error_wrapper,
        ], */            
      ];
      $form['ajax_container']['email'] = [
        '#type' => 'email',
        '#title' => $this->t('Email'),
        '#description' => $this->t('Enter email id'),
        '#required' => TRUE,
        '#value' => $user->getEmail(),
        '#defaule_value' => $user->getEmail(),
/*        '#ajax' => [
          'callback' => [$this, 'validateFormNew'],
          'event' => 'submit',
          'wrapper' => $error_wrapper,
        ],*/               
      ];
      $form['#cache'] = ['max-age' => 0]; 
      $form['actions'] = [
        '#type' => 'actions',
      ];
      // Add a submit button that handles the submission of the form.
      $form['ajax_container']['actions']['submit'] = [
        '#type' => 'submit',
        '#value' => $this->t('Submit'),
        '#ajax' => [
          'callback' => [$this, 'validateFormNew'],
          'event' => 'submit',
          'wrapper' => $error_wrapper,
        ],        
      ];           
    }
    return $form;
  }

  /**
   * The callback function for when the `my_select` element is changed.
   *
   * What this returns will be replace the wrapper provided.
   */
  public function selectUserName(array $form, FormStateInterface $form_state) {
    // Return the element that will replace the wrapper (we return itself).
    return $form['ajax_container'];
  }

public function validateFormNew(array &$form, FormStateInterface $form_state) {
 kint($form_state); die("tes");
}
  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $triggerdElement = $form_state->getTriggeringElement();    
    if ($triggerdElement['#type'] == "submit") {
      $user_name = $form_state->getValue('user_name');
      $email = $form_state->getValue('email');
      $user_name_space = strrpos($user_name," ");
      $exist_user = user_load_by_name($user_name);
      $exist_email = user_load_by_mail($email);   
      if ($user_name_space) {
         $form_state->setErrorByName('user_name', t('Space not allowed between user name'));
      }    
      elseif ($exist_user) {
        $form_state->setErrorByName('user_name', t('This user already exist')); 
      }
      elseif ($exist_email) {
        $form_state->setErrorByName('email', t('This email already exist')); 
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $inputValues = $form_state->getUserInput();
    kint($inputValues); die("test");
    $nid = $form_state->getValue('title_list');
    $node = User::load($nid);
    if (isset($inputValues['title'])) {
      $node->set('title', $inputValues['title']);      
    }
    $node->set('body', $inputValues['description']);
    $node->save();    
    drupal_set_message( "User updated sucessfully!\n");
  }

}
