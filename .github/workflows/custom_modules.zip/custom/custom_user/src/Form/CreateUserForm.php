<?php

namespace Drupal\custom_user\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\user\Entity\User;
use Drupal\Core\Url;

/**
 * CreateUserForm class.
 */
class CreateUserForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'create_user_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['user_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('User Name'),
      '#description' => $this->t('Enter user name without whitespace'),
      '#required' => TRUE,
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#description' => $this->t('Enter email id'),
      '#required' => TRUE,
    ];
    $form['#cache'] = ['max-age' => 0];
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Create'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $user_name = $form_state->getValue('user_name');
    $email = $form_state->getValue('email');
    $user_name_space = strrpos($user_name," ");
    $exist_user = user_load_by_name($user_name);
    $exist_email = user_load_by_mail($email);    
    if ($user_name_space) {
      $form_state->setErrorByName('user_name', t('Space not allowed between user name'));
    }    
    elseif ($exist_user) {
      $form_state->setErrorByName('user_name', t('This user already exist')); 
    }
    elseif ($exist_email) {
      $form_state->setErrorByName('email', t('This email already exist')); 
    }    
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $user_name = $form_state->getValue('user_name');
    $email = $form_state->getValue('email');

    $user = User::create();
    
    $password = $user_name . $email;
    //Mandatory settings
    $user->setPassword($password);
    $user->enforceIsNew();
    $user->setEmail($email);

    //This username must be unique and accept only a-Z,0-9, - _ @ .
    $user->setUsername($user_name);

    //Optional settings
    $language = 'en';
    $user->set("init", $email);
    $user->set("langcode", $language);
    $user->set("preferred_langcode", $language);
    $user->set("preferred_admin_langcode", $language);
    $user->activate();

    //Save user
    $user->save();  
    drupal_set_message("User created sucessfully!\n");
  }

}
