<?php

namespace Drupal\test_code\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class TestCode.
 */
class TestCodeController extends ControllerBase {

  public function testPage() {
    $connection = \Drupal::database();
    //$connection = \Drupal::service('database');

    // Create an object of type Select
    $query = $connection->select('users_field_data', 'u');
     
    // Add extra detail to this query object: a condition, fields and a range
    $query->condition('u.uid', 0, '<>');
    $query->fields('u', ['uid', 'name', 'status', 'created', 'access']);
  
    $result = $query->execute();

    foreach ($result as $record) {
      kint($record);
    }
    
    die('---- end ----');
    return [
        '#type' => 'markup',
        '#markup' => '$config'
    ];
  }
}
