(function($) {
  // Argument passed from InvokeCommand.
  $.fn.myAjaxCallback = function(argument) {
    // Set textfield's value to the passed arguments.
    $('input#edit-output').attr('value', argument);
  };
  $.fn.myTest = function(data) {
    console.log(data);
  };  
})(jQuery);
