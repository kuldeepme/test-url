<?php

namespace Drupal\custom_paragraph\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * Provides custom paragraph form.
 *
 * @package Drupal\custom_paragraph\Form
 */
class CustomParagraphForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_paragraph';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
      $i = 0;
      $entry_field = $form_state->get('num_entry');
      $form['#tree'] = TRUE;
      $form['entry_fieldset'] = [
          '#type' => 'fieldset',
          '#title' => $this->t('Add entry'),
          '#prefix' => '<div id="entry-fieldset-wrapper">',
          '#suffix' => '</div>',
      ];
      if (empty($entry_field)) {
          $entry_field = $form_state->set('num_entry', 1);
      }
      if ($form_state->get('num_entry')>0) {
          $value = $form_state->get('num_entry');
      }
      else {
          $value=1;
      }
    for ($i = 0; $i < $value; $i++) {
        $form['entry_fieldset']['field_text_' . $i] = [
            '#type' => 'textfield',
            '#title' => $this->t('Title'),
        ];
        $form['entry_fieldset']['field_body_' . $i] = [
            '#type' => 'text_format',
            '#title' => $this->t('Body'),
        ];
    }
      $form['actions'] = [
          '#type' => 'actions',
      ];
      $form['entry_fieldset']['actions']['add_name'] = [
          '#type' => 'submit',
          '#value' => t('Add one more'),
          '#submit' => array('::addOne'),
          '#ajax' => [
              'callback' => '::addmoreCallback',
              'wrapper' => 'entry-fieldset-wrapper',
          ],
      ];
      if ($value > 1) {
          $form['entry_fieldset']['actions']['remove_name'] = [
              '#type' => 'submit',
              '#value' => t('Remove one'),
              '#submit' => array('::removeCallback'),
              '#ajax' => [
                  'callback' => '::addmoreCallback',
                  'wrapper' => 'entry-fieldset-wrapper',
              ]
          ];
      }
      $form_state->setCached(FALSE);
      $form['actions']['submit'] = [
          '#type' => 'submit',
          '#value' => $this->t('Save'),
      ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function addOne(array &$form, FormStateInterface $form_state) {
      $entry_field = $form_state->get('num_entry');
      $add_button = $entry_field + 1;
      $form_state->set('num_entry', $add_button);
      $form_state->setRebuild();
  }

/**
* {@inheritdoc}
*/
  public function addmoreCallback(array &$form, FormStateInterface $form_state) {
      $items = [];
      $entry_field = $form_state->get('num_entry');
      $getValues = $form_state->getValues();
      $items = $getValues['entry_fieldset'];
      foreach ($items as $key => $value) {
        $x = $form_state->getValue($key);
        if (empty($x)) {
          //print_r($key);
          $form_state->setErrorByName('field_text_0', $this->t('Please fill value'));
        }
      } //die;
      return $form['entry_fieldset'];
  }

/**
* {@inheritdoc}
*/
  public function removeCallback(array &$form, FormStateInterface $form_state) {
      $entry_field = $form_state->get('num_entry');
      if ($entry_field > 1) {
          $remove_button = $entry_field - 1;
          $form_state->set('num_entry', $remove_button);
      }
      $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $getValues = [];
    $items = [];
    $getValues = $form_state->getValues();
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if(!isset($language)){
        $language = "en";
    }
    $user = \Drupal::currentUser();
    $layout_paragraph = [];
    $items = $getValues['entry_fieldset'];
    foreach ($items as $key2 => $value2) {
       if (strpos($key2, 'text') !== false) {
         $paragraph = Paragraph::create(['type' => 'add_entry']);
         $paragraph->set('field_title', $value2);
       }
       if (strpos($key2, 'body') !== false) {
         $body = $items[$key2];
         $paragraph->set('field_body', $body['value']);
       }
        $paragraph->save();

        $layout_paragraph[] = [
            'target_id' => $paragraph->id(),
            'target_revision_id' => $paragraph->getRevisionId(),
        ];
    }
    $layout_paragraph = array_map("unserialize", array_unique(array_map("serialize", $layout_paragraph)));
    $node = Node::create([
        // The node entity bundle.
        'type' => 'article',
        'langcode' => $language,
        // The user ID.
        'uid' => $user->id(),
        'moderation_state' => 'published',
        //'moderation_state' => 'draft',
        'title' => "Test new article new",
        'field_add_entry' => $layout_paragraph
    ]);
    $node->setPublished(TRUE);
    $node->save();
  }
}
