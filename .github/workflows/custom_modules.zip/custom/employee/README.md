# Drupal8 Module -- Crud Appliaction

This is an crud application with a custom database table which demonstrates
the use of various drupal8 APIs e.g form, block, configuration, views etc.

This will helpfull to those who are new to drupal 8.
