<?php

namespace Drupal\custom_breadcrumb\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Routing\RouteMatch;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\custom_breadcrumb\Breadcrumb\MymoduleBreadcrumbBuilder;
//use Drupal\Core\Breadcrumb\BreadcrumbBuilderInterface;

/**
 * Provides a 'Custom Breadcrumb' block.
 *
 * @Block(
 *   id = "custom_breadcrumb",
 *   admin_label = @Translation("Custom Breadcrumb"),
 * )
 */
class CustomBreadcrumbBlock extends BlockBase implements ContainerFactoryPluginInterface{

  /**
   * The breadcrumb manager.
   *
   * @var \Drupal\Core\Breadcrumb\BreadcrumbBuilderInterface
   */
  protected $custombreadcrumbManager;

  /**
   * The current route match.
   *
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $routeMatch;

  /**
   * Constructs a new SystemBreadcrumbBlock object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *   The current route match.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RouteMatchInterface $route_match) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    //$this->custombreadcrumbManager = $breadcrumb_manager;
    $this->routeMatch = $route_match;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      //$container->get('custom_breadcrumb.breadcrumb'),
      $container->get('current_route_match')     
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $service = \Drupal::service('custom_breadcrumb.breadcrumb');
    return $service->build($this->routeMatch)->toRenderable();
    //return $this->custombreadcrumbManager->build($this->routeMatch)->toRenderable();
  }

}