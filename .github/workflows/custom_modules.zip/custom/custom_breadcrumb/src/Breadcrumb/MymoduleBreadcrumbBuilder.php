<?php

namespace Drupal\custom_breadcrumb\Breadcrumb;

use Drupal\Core\Breadcrumb\Breadcrumb;
use Drupal\Core\Breadcrumb\BreadcrumbBuilderInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Link;
use Drupal\Core\Path\PathMatcherInterface;

class MymoduleBreadcrumbBuilder implements BreadcrumbBuilderInterface{
  
  /**
   * The patch matcher service.
   *
   * @var \Drupal\Core\Path\PathMatcherInterface
   */
  protected $pathMatcher;

  public function __construct(PathMatcherInterface $path_matcher = NULL) {
    $this->pathMatcher = $path_matcher ?: \Drupal::service('path.matcher');
  }

   /**
    * {@inheritdoc}
    */
   public function applies(RouteMatchInterface $route_match) {
      return true;
   }

   /**
    * {@inheritdoc}
    */
   public function build(RouteMatchInterface $route_match) {
    $breadcrumb = new Breadcrumb();
    $links = [];       
    $request = \Drupal::request();

    // Add the url.path.parent cache context. This code ignores the last path
    // part so the result only depends on the path parents.
    $breadcrumb->addCacheContexts(['url.path.parent', 'url.path.is_front']);

    // Do not display a breadcrumb on the frontpage.
    if ($this->pathMatcher->isFrontPage()) {
      return $breadcrumb;
    }

      try {
                    
          $path = trim($request->getPathInfo(), '/');
          $path_elements = explode('/', $path);
          $route = \Drupal::routeMatch()->getRouteObject();
          
          // Do not adjust the breadcrumbs on admin paths.
          if ($route && !$route->getOption('_admin_route')) {
            $title = \Drupal::service('title_resolver')->getTitle($request, $route);
            if (!isset($title)) {
              // Fallback to using the raw path component as the title if the
              // route is missing a _title or _title_callback attribute.
              $title = str_replace(array('-', '_'), ' ', Unicode::ucfirst(end($path_elements)));
            }            
            $links[] = Link::createFromRoute($title, '<none>');
            //$url = Url::fromRouteMatch($route_match);
            //$links[] = new Link($title, $url);            
          }
          // Home
          $links[] = Link::createFromRoute('Home', '<front>');

          $reversed = array_reverse($links);
          return $breadcrumb->setLinks($reversed);    

          // Finally, attach current page title and make it nolink
          //$page_title = \Drupal::service('title_resolver')->getTitle($request, $route);
          //$breadcrumb->addLink(Link::createFromRoute($page_title, '<nolink>'));
      }
      catch (\Exception $e) {
        // log to watchdog
        $breadcrumb->addLink(Link::createFromRoute($e->getMessage(), '<nolink>'));
        \Drupal::logger('php')->notice('Custom_breadcrumb error: %message',
          ['%message' =>  $e->getMessage()]);
        return $breadcrumb;
      }

      // This breadcrumb builder is based on a route parameter, and hence it
      // depends on the 'route' cache context.
      //$breadcrumb->addCacheContexts(['route']);      
      //return $breadcrumb;
   }

}