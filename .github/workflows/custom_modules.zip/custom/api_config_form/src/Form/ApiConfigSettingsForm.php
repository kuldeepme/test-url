<?php

/**
 * @file
 * Contains \Drupal\api_config_form\ApiConfigSettingsForm.
 */

namespace Drupal\api_config_form\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Manage API settings
 */
class ApiConfigSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'api_config_form_settings';
  }
    /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'api_config_form.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = array();
    $config = $this->config('api_config_form.settings');

    // Services
    //$request_service = \Drupal::service('amazon.amazon_request');
    //$helpers_service = \Drupal::service('amazon.amazon_helpers');

    $form['message'] = array(
      '#markup' => $this->t('Manage the API Settings'),
    );

    // Amazon Web Services Key || Textfield
    $form['api_key'] = array(
      '#type' => 'textfield',
      '#title' => t('API Key'),
      '#description' => t('Enter API Key.'),
      '#default_value' => $config->get('api_key'),
      '#required' => TRUE,
    );

    // Amazon Web Servies Secret Key || Textfield
    $form['secret_key'] = array(
      '#type' => 'textfield',
      '#title' => t('Secret Key'),
      '#description' => t('Enter API Secret.'),
      '#default_value' => $config->get('secret_key'),
      '#required' => TRUE,
    );

    $form['add']['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Save Configuration'),
      '#button_type' => 'primary',
    );

    $form['#theme'] = 'system_config_form';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $this->config('api_config_form.settings')
        ->set('api_key', $form_state->getValue('api_key'))
        ->set('secret_key', $form_state->getValue('secret_key'))
        ->save();
   
    parent::submitForm($form, $form_state);
  }

}
