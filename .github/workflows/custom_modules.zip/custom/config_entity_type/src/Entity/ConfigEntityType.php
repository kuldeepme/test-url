<?php
namespace Drupal\config_entity_type\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\config_entity_type\ConfigEntityTypeInterface;

/**
 * Defines the Example entity.
 *
 * @ConfigEntityType(
 *   id = "config_entity_type",
 *   label = @Translation("Example"),
 *   handlers = {
 *     "list_builder" = "Drupal\config_entity_type\Controller\ConfigEntityTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\config_entity_type\Form\ConfigEntityTypeForm",
 *       "edit" = "Drupal\config_entity_type\Form\ConfigEntityTypeForm",
 *       "delete" = "Drupal\config_entity_type\Form\ConfigEntityTypeDeleteForm",
 *     }
 *   },
 *   config_prefix = "config_entity_type",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *   },
 *   config_export = {
 *     "id",
 *     "label"
 *   },
 *   links = {
 *     "edit-form" = "/admin/config/system/config_entity_type/{config_entity_type}",
 *     "delete-form" = "/admin/config/system/config_entity_type/{config_entity_type}/delete",
 *   }
 * )
 */
class ConfigEntityType extends ConfigEntityBase implements ConfigEntityTypeInterface {

  /**
   * The Example ID.
   *
   * @var string
   */
  public $id;

  /**
   * The Example label.
   *
   * @var string
   */
  public $label;

  // Your specific configuration property get/set methods go here,
  // implementing the interface.
}


