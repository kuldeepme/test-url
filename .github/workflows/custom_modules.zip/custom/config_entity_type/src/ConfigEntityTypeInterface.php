<?php

namespace Drupal\config_entity_type;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining an Example entity.
 */
interface ConfigEntityTypeInterface extends ConfigEntityInterface {
  // Add get/set methods for your configuration properties here.
}