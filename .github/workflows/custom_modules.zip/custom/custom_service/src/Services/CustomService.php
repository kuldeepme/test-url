<?php

namespace Drupal\custom_service\Services;

use Drupal\Core\Database\Connection;

/**
 * Class CustomService.
 */
class CustomService {
  /*
   * @var \Drupal\Core\Database\Connection $database
   */
  protected $database;

  /**
   * Constructs a new CustomService object.
   * @param \Drupal\Core\Database\Connection $connection
   */
  public function __construct(Connection $connection) {
    $this->database = $connection;
  }

  public function NidReturn() {
    $query = $this->database->query('SELECT nid FROM {node}');
    $result = $query->fetchAssoc();
    return $result;
  }
}