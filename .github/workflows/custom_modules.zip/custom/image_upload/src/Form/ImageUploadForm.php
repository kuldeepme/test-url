<?php

namespace Drupal\image_upload\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\file\Entity\File;

/**
 * ImageUploadForm class.
 */
class ImageUploadForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'image_upload_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $options = NULL) {
    $form['image'] = [
      '#type' => 'managed_file',
      '#description' => $this->t('Image should be JPEG Or PNG format'),
      '#title' => $this->t('Upload Image'),
      '#upload_location' => 'public://image',
      '#upload_validators' => [
        'file_validate_extensions' => ['jpg jpeg png'],
      ],
      '#required' => TRUE,
    ];
    $form['#cache'] = ['max-age' => 0];
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    /*
     * This would normally be replaced by code that actually does something
     * with the title.
     */
    $image = $form_state->getValue('image');
    if (isset($image[0]) && !empty($image[0])) {
      $file = File::load($image[0]);
      $file->setPermanent();
      $file->save();
      drupal_set_message($this->t('File uploaded successfully!'));
    }
  }

}
