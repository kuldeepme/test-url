<?php

namespace Drupal\dependency_injection\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;

/**
 * Defines DependencyInjectionController class.
 */
class DependencyInjectionController extends ControllerBase {



}
