Drupal 8 Multi Step Form
=====================

Module example to demostrate how to build a Multi Step Form in Drupal 8
### Install
```bash
$ cd path/to/drupal/8/modules/custom
$ git clone git@github.com:enzolutions/drupal8_multi_step_form.git

enable this module via UI
```

### Usage

 * After enable go to URL http://example.com/multi/step/form
 * Follow step until you get Find a car button
