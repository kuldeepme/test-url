<?php

namespace Drupal\custom_menu\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\menu_link_content\Entity\MenuLinkContent;
use Drupal\Core\Url;
use Drupal\file\Entity\File;

/**
 * Controller for user.page route.
 */
class TestController extends ControllerBase {

  /**
   * Content callback for the user.page route.
   */
  public function menuTest() {
    $menu_name = 'test4';
    $menu_tree = \Drupal::menuTree();
    $parameters = \Drupal::menuTree()->getCurrentRouteMenuTreeParameters('test4');
    $parameters->setTopLevelOnly();
    $main_menu_top_level = $menu_tree->load('test4', $parameters);
    foreach ($main_menu_top_level as $item) {
      $item->link->deleteLink();
    }

    $menuArray = [];
    $menuArray = [
        //'continents' => [
            0 => [
                'lable' => 'Europe',
                'link' => '#',
                'subheading' => 'europe',
                'countries' => [
                    0 => [
                        'lable' => 'Fineland',
                        'link' => '#',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/fi.svg',
                        'country_code' => 'fi',
                        'languages' => [
                            0 => [
                                'lable' => 'Suomi',
                                'link' => 'http://www.howdenfinland.fi/fi/etusivu/',
                                'languagecode' => 'etusivu',
                            ],
                            1 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdenfinland.fi/en/home/',
                                'languagecode' => 'en',
                            ]
                        ]
                    ],
                    1 => [
                        'lable' => 'Germany',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/de.svg',
                        'country_code' => 'de',
                        'languages' => [
                            0 => [
                                'lable' => 'Deutsch',
                                'link' => 'https://howdengroup.de/',
                                'languagecode' => 'de',
                            ]
                        ]
                    ],
                    2 => [
                        'lable' => 'Netherlands',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/nl.svg',
                        'country_code' => 'nl',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://www.howdengroup.com/en-nl',
                                'languagecode' => 'nl-en',
                            ]
                        ]
                    ],
                    3 => [
                        'lable' => 'Norway',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/no.svg',
                        'country_code' => 'no',
                        'languages' => [
                            0 => [
                                'lable' => 'Norsk',
                                'link' => 'https://www.howdengroup.no/no/hjem/',
                                'languagecode' => 'no',
                            ]
                        ]
                    ],
                    4 => [
                        'lable' => 'Poland',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/pl.svg',
                        'country_code' => 'pl',
                        'languages' => [
                            0 => [
                                'lable' => 'Polski',
                                'link' => 'http://www.donoria.pl/pl/strona-g%C5%82%C3%B3wna/',
                                'languagecode' => 'pl',
                            ]
                        ]
                    ],
                    5 => [
                        'lable' => 'Portugal',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/pt.svg',
                        'country_code' => 'pt',
                        'languages' => [
                            0 => [
                                'lable' => 'Português',
                                'link' => 'https://www.howdenportugal.com/',
                                'languagecode' => 'pt',
                            ]
                        ]
                    ],
                    6 => [
                        'lable' => 'United Kingdom',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/gb.svg',
                        'country_code' => 'gb',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://www.howdengroup.co.uk/en/home/',
                                'languagecode' => 'uk-en',
                            ]
                        ]
                    ],
                    7 => [
                        'lable' => 'Spain',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/es.svg',
                        'country_code' => 'es',
                        'languages' => [
                            0 => [
                                'lable' => 'Español',
                                'link' => 'https://howdeniberia.com/',
                                'languagecode' => 'es',
                            ]
                        ]
                    ],
                    8 => [
                        'lable' => 'Sweden',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/se.svg',
                        'country_code' => 'se',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-se',
                                'languagecode' => 'se',
                            ]
                        ]
                    ],
                    9 => [
                        'lable' => 'Turkey',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/tr.svg',
                        'country_code' => 'tr',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://howdeniberia.com/',
                                'languagecode' => 'tr',
                            ]
                        ]
                    ]
                ]
               ],
            1 => [
                'lable' => 'Asia Pacific',
                'link' => '#',
                'subheading' => 'asia',
                'countries' => [
                    0 => [
                        'lable' => 'Hong Kong',
                        'link' => '#',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/hk.svg',
                        'country_code' => 'hk',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-hk',
                                'languagecode' => 'hk',
                            ]
                        ]
                    ],
                    1 => [
                        'lable' => 'India',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/in.svg',
                        'country_code' => 'in',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://www.howdenindia.in/',
                                'languagecode' => 'in',
                            ]
                        ]
                    ],
                    2 => [
                        'lable' => 'Indonesia',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/id.svg',
                        'country_code' => 'id',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://www.howdenindonesia.com/#p=home',
                                'languagecode' => 'id',
                            ]
                        ]
                    ],
                    3 => [
                        'lable' => 'Malaysia',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/my.svg',
                        'country_code' => 'my',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-my',
                                'languagecode' => 'my',
                            ]
                        ]
                    ],
                    4 => [
                        'lable' => 'Philippines',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/ph.svg',
                        'country_code' => 'ph',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-ph',
                                'languagecode' => 'ph',
                            ]
                        ]
                    ],
                    5 => [
                        'lable' => 'Singapore',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/sg.svg',
                        'country_code' => 'sg',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'https://www.howdensingapore.com/',
                                'languagecode' => 'sg',
                            ]
                        ]
                    ],
                    6 => [
                        'lable' => 'Thailand',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/th.svg',
                        'country_code' => 'th',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-th',
                                'languagecode' => 'th',
                            ]
                        ]
                    ]
                ]
            ],
            2 => [
                'lable' => 'The Americas',
                'link' => '#',
                'subheading' => 'americas',
                'countries' => [
                    0 => [
                        'lable' => 'Brasil',
                        'link' => '#',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/br.svg',
                        'country_code' => 'br',
                        'languages' => [
                            0 => [
                                'lable' => 'Português',
                                'link' => 'http://www.howdenharmonia.com.br/',
                                'languagecode' => 'br',
                            ]
                        ]
                    ],
                    1 => [
                        'lable' => 'Chile',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/cl.svg',
                        'country_code' => 'cl',
                        'languages' => [
                            0 => [
                                'lable' => 'España',
                                'link' => 'http://www.howdenpatagonia.com/',
                                'languagecode' => 'cl',
                            ]
                        ]
                    ],
                    2 => [
                        'lable' => 'Colombia',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/co.svg',
                        'country_code' => 'co',
                        'languages' => [
                            0 => [
                                'lable' => 'España',
                                'link' => 'https://www.howdencolombia.co/',
                                'languagecode' => 'co',
                            ]
                        ]
                    ],
                    3 => [
                        'lable' => 'Ecuador',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/ec.svg',
                        'country_code' => 'ec',
                        'languages' => [
                            0 => [
                                'lable' => 'España',
                                'link' => 'http://www.howdengroup.com/wacolda/peru-ecuador',
                                'languagecode' => 'ec',
                            ]
                        ]
                    ],
                    4 => [
                        'lable' => 'Peru',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/pe.svg',
                        'country_code' => 'pe',
                        'languages' => [
                            0 => [
                                'lable' => 'España',
                                'link' => 'http://www.howdengroup.com/wacolda/peru-ecuador',
                                'languagecode' => 'pe',
                            ]
                        ]
                    ]
                ]
            ],
            3 => [
                'lable' => 'Middle East & Africa',
                'link' => '#',
                'subheading' => 'middle-east',
                'countries' => [
                    0 => [
                        'lable' => 'UAE',
                        'link' => '#',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/ae.svg',
                        'country_code' => 'ae',
                        'languages' => [
                            0 => [
                                'lable' => 'English',
                                'link' => 'http://www.howdengroup.com/en-ae',
                                'languagecode' => 'ae',
                            ]
                        ]
                    ],
                    1 => [
                        'lable' => 'Israel',
                        'link' => '',
                        'flag_url' => 'https://www.howdengroup.com/themes/custom/howden_base/assets/dist/flags/il.svg',
                        'country_code' => 'il',
                        'languages' => [
                            0 => [
                                'lable' => 'עברית',
                                'link' => 'http://howden.co.il/',
                                'languagecode' => 'il',
                            ]
                        ]
                    ]
                ]
            ]
        //]
    ];
    foreach($menuArray as $key => $continent) {
      $continent_menu = MenuLinkContent::create([
        'title' => $continent['lable'],
        'link' => ['uri' => 'internal:#'],
        'menu_name' => $menu_name,
        'expanded' => TRUE,
        'weight' => $key,
      ]);
      $continent_menu->save();
      foreach($continent['countries'] as $key => $countries) {
        $countries_menu = MenuLinkContent::create([
          'title' => $countries['lable'],
          'link' => ['uri' => 'internal:#'],
          'parent' => $continent_menu->getPluginId(),
          'menu_name' => $menu_name,
          'expanded' => TRUE,
          'weight' => $key,
        ]);
        if (!empty($countries['flag_url'])) {
          $url = explode('/', $countries['flag_url']);
          $file_name = array_pop($url);
          $data = file_get_contents($countries['flag_url']);
          $destination = 'public://inline-images/' . $file_name; 
          $file = file_save_data($data, $destination, FILE_EXISTS_REPLACE);
          $file_usage = \Drupal::service('file.usage');
          $file_usage->add($file, 'simple_menu_icons','default_image', $file->id());
          if (is_object($file)) {
            $file = File::load($file->id());
            $file->status = FILE_STATUS_PERMANENT;
            $file->save();
            $file_usage = \Drupal::service('file.usage');
            $file_usage->add($file, 'inline-images','default_image', $file->id());
            $options = ['menu_icon' => ['fid' => $file->id()]];
            $menu_link_options = $countries_menu->link->first()->options;
            $countries_menu->link->first()->options = array_merge($menu_link_options, $options);
          }
        }
        $countries_menu->save();
        foreach($countries['languages'] as $key => $languages) {
            $languages_menu = MenuLinkContent::create([
              'title' => $languages['lable'],
              'link' => ['uri' => $languages['link']],
              'parent' => $countries_menu->getPluginId(),
              'expanded' => TRUE,
              'menu_name' => $menu_name,
              'external' => TRUE,
              'weight' => $key,
            ]);
            $languages_menu->save();
        }
      }
    }
  }

}
