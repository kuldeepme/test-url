# Drupal8 Configuration Entity 模块

主要实现了以下功能:

1. Routing
2. Menu Link
3. Local Action
4. Schema
5. Form
6. Configuration Entity


....

其他功能后续会陆续加进来.