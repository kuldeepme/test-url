/**
 * @file
 * Js for park map block.
 */

(function ($) {
  $( document ).ajaxComplete(function() {
    $( "#parkInfo .map_address .address p span.textLabel" ).each(function() {
      var labelText = $(this).text().trim();
      $(this).text(Drupal.t(labelText));
    });
    var websiteText = $( "#parkInfo .map_address .address h6 a").text().trim();
    $( "#parkInfo .map_address .address h6 a").text(Drupal.t(websiteText));
    $( "#parkInfo .search_addrres .address_field .map_select").each(function(){
      var filterText = $(this).find("option:first").text();
      $(this).find("option:first").text(Drupal.t(filterText));
    });
  });
  $(document).ready(function () {
    initMap();
  });
}(jQuery))

function getval(){
    var title = jQuery('.search_addrres .address_field .titles-list').val();
    var category = jQuery('.search_addrres .address_field .categories-list').val();
    var localizacao = jQuery('.search_addrres .address_field .localizacaos-list').val();
    initMap(title, category, localizacao);
}

/**
 * Google map initialization function.
 */
function initMap(title, category, localizacao) {
  if (typeof title == 'undefined') {
    var title = 'all';
  }
  if (typeof category == 'undefined') {
    var category = 'all';
  }
  if (typeof localizacao == 'undefined') {
    var localizacao = 'all';
  }
  var query = '';
  var base_path = drupalSettings.path.baseUrl;
  // var module_path = window.location.origin;
  var module_path = drupalSettings.module_path;
  if (typeof drupalSettings.path.baseUrl !== 'undefined') {
    base_path = drupalSettings.path.baseUrl;
    module_path = drupalSettings.module_path;
  }
  if (typeof drupalSettings.language_id !== 'undefined' && drupalSettings.language_id != '') {
    base_path = base_path + drupalSettings.language_id + '/';
  }

  var map_style = [ { "featureType": "administrative.locality", "elementType": "labels.text", "stylers": [ { "color": "#4d4e4c" }, { "weight": 0.5 } ] }, { "featureType": "landscape.natural", "elementType": "geometry", "stylers": [ { "color": "#e3e3e2" } ] }, { "featureType": "poi.attraction", "elementType": "labels.text.fill", "stylers": [ { "color": "#e8892d" } ] }, { "featureType": "poi.business", "elementType": "geometry", "stylers": [ { "color": "#e8892d" } ] }, { "featureType": "poi.park", "elementType": "geometry", "stylers": [ { "color": "#e8892d" } ] }, { "featureType": "poi.sports_complex", "elementType": "geometry", "stylers": [ { "color": "#e8892d" } ] }, { "featureType": "water", "elementType": "geometry", "stylers": [ { "color": "#f5bf24" }, { "weight": 1.5 } ] } ];
  var map_current_icon = "https://autocaravanalgarve.com/"+module_path+"/img/current-red-lg.png";
  query = '?title=' + title + '&category=' + category + '&localizacao=' + localizacao;
  var location_api = base_path + "api/parks/location" + query;
  jQuery.getJSON(location_api).done(function (data) {
    if (data[0]) {
      var center_coords = data[0]['field_address'].split(",");
      var map = new google.maps.Map(document.getElementById('parksMap'), {
        zoom: 8,
        center: new google.maps.LatLng(center_coords[0], center_coords[1]),
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        styles: map_style
      });
      var infowindow = new google.maps.InfoWindow();
      var marker, i;
      var markers = [];
      var bounds = new google.maps.LatLngBounds();
      for (i = 0; i < data.length; i++) {
        var location_coords = data[i]['field_address'].split(",");
        bounds.extend(new google.maps.LatLng(location_coords[0], location_coords[1]));
        // Don't zoom in too far on only one marker
        if (bounds.getNorthEast().equals(bounds.getSouthWest())) {
            var extendPoint1 = new google.maps.LatLng(bounds.getNorthEast().lat() + 0.01, bounds.getNorthEast().lng() + 0.01);
            var extendPoint2 = new google.maps.LatLng(bounds.getNorthEast().lat() - 0.01, bounds.getNorthEast().lng() - 0.01);
            bounds.extend(extendPoint1);
            bounds.extend(extendPoint2);
        }
        map.fitBounds(bounds);
        marker = new google.maps.Marker({
          position: new google.maps.LatLng(location_coords[0], location_coords[1]),
          map: map,
          nid: data[i]['nid'],
          icon: data[i]['field_map_icon'],
        });
        google.maps.event.addListener(marker, 'click', (function (marker, i) {
          //marker.setIcon(map_current_icon_lg);
          return function () {
            infowindow.setContent(data[i]['title']);
            infowindow.open(map, marker);
            jQuery.ajax({
              type: 'POST',
              url: base_path + 'park/location/info',
              success: updateDiv,
              dataType: 'json',
              data: {nid: marker.nid, title: title, category: category, localizacao:localizacao},
            }); 
            for (var j = 0; j < markers.length; j++) {
              markers[j].setIcon(data[j]['field_map_icon']);
            }
            marker.setIcon(map_current_icon);
          }
        })(marker, i));
        markers.push(marker);
      }
      markers[0].setIcon(map_current_icon);
      jQuery.ajax({
        type: 'POST',
        url: base_path + 'park/location/info',
        success: updateDiv,
        dataType: 'json',
        data: {nid: data[0]['nid'], title: title, category: category, localizacao:localizacao},
      });
    }
    else {
      var map = new google.maps.Map(document.getElementById('parksMap'), {
        zoom: 8,
        center: new google.maps.LatLng(37.2159422, -8.445943),
        mapTypeId: google.maps.MapTypeId.ROADMAP
      });
    }
  });
}

var updateDiv = function (data) {
  jQuery('#parkInfo').html(data);
};
