<?php

namespace Drupal\caravanismo_common_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * PresentationController class.
 */
class PresentationController extends ControllerBase {

  /**
   * Callback for presentation.
   */
  public function presentation($id) {
    $rows_temp = [];
    $rows_result = [];
    $connection = \Drupal::database();
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();    
    $node = Node::load($id);
    if (!empty($node)) {
      if ($node->field_image->entity->getFileUri()) {
        $uri = $node->field_image->entity->getFileUri();      
        $image = file_create_url($uri);
      }    
      if ($node->bundle() == 'article') {
        $paragraph = $node->field_horizontal_float_menus->getValue();
        // Loop through the result set.
        foreach ($paragraph as $element) {
          $paragraph_float_menus = Paragraph::load($element['target_id']);
          $paragraph_float_menu = $paragraph_float_menus->field_horizontal_float_menu->getValue();
          foreach ($paragraph_float_menu as $paragraph_items) {
            $result = $connection->select('paragraphs_item_revision_field_data', 'j')
              ->fields('j', ['revision_id'])
              ->condition('id', $paragraph_items['target_id'])
              ->condition('langcode', $language)
              ->orderBy('revision_id', 'DESC')
              ->execute()->fetchField();
            $revision = \Drupal::entityManager()->getStorage('paragraph')->loadRevision($result);
            if ($revision) {
              $title = $revision->field_title->value;
              $menu_title = $revision->field_menu_title->value;
              $body = $revision->field_body->value;
            }
            $rows_temp['image'] = $image;
            $rows_temp['title'] = $title;
            $rows_temp['body_title'] = $menu_title;
            $rows_temp['body'] = '<div style="font-size:15px;">' . $body . '</div>';
            $rows_result[] = $rows_temp;
          }
          $result = [
            'Status' => TRUE,
            'Data' => $rows_result,
            'Message' => 'Success'
          ];
        }
      }
    }
    else{
      $result = [
        'Status' => FALSE,
        'Data' => [],
        'Message' => 'Fail'
      ];      
    }
    return new JsonResponse($result);
  }

}
