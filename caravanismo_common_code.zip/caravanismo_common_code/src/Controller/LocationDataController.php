<?php

namespace Drupal\caravanismo_common_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * A Webservice controller.
 */
class LocationDataController extends ControllerBase {

  /**
   * Provides the configuration interface for Nokia.
   */
  public function getLocation(Request $request) {
    $output = '';
    $nid = $title = $category = $localizacao = '';
    if ($request->request->has('nid')) {
      $nid = $request->request->get('nid');
    }
    if ($request->request->has('title')) {
      $title = $request->request->get('title');
    }
    if ($request->request->has('category')) {
      $category = $request->request->get('category');
    }
    if ($request->request->has('localizacao')) {
      $localizacao = $request->request->get('localizacao');
    }
    $output .= _get_parks_map_data($nid, $title, $category, $localizacao);
    return new JsonResponse($output);
  }

}
