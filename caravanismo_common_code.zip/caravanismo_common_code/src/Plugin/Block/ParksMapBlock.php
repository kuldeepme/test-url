<?php

namespace Drupal\caravanismo_common_code\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Parks Map block.
 *
 * @Block(
 *   id = "parks_map_block",
 *   admin_label = @Translation("Parks Map Block"),
 * )
 */
class ParksMapBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $default_lang = \Drupal::languageManager()->getDefaultLanguage()->getId();
    $current_lang = \Drupal::languageManager()->getCurrentLanguage()->getId();
    return [
      '#attached' => [
        'library' => ['caravanismo_common_code/map'],
        'drupalSettings' => [
          'base_path' => base_path(),
          'module_path' => base_path().'/'.drupal_get_path('module', 'caravanismo_common_code'),
          'language_id' => ($default_lang == $current_lang) ? '' : $current_lang,
        ],
      ],
      '#cache' => ['max-age' => 0],
      '#title' => 'Parks Block',
      '#theme' => 'parks_map__block',
      '#content' => [],
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowed();
  }

}
