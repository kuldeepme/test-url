(function($) {
  $( document ).ready(function() {      
      if($("#map-block").length){
        SearchInitMap("",'map-block');
      }
  });
})(jQuery);

function SearchInitMap(urlStringparam, map_id='map-block') {
  if(urlStringparam!=""){
    var urlString = urlStringparam;
  }else{
  var urlString = location.search;
  }
  jQuery.ajax({
    data: {},
  	type: 'GET',
    url: '/search-result-map-location'+urlString,
    //url: '#',
    success: function (res) {
    	var data = jQuery.parseJSON(res);
      if (data.length === 0) {
        var latLng = new google.maps.LatLng(50.736129,-1.988229);
        var zoomLevel = 8;
        var minZoom = 2;
        var maxZoom = 5;
      }
      else {
        var latLng = data[0].location;
        var zoomLevel = 8;
        var minZoom = 2;
        var maxZoom = 15;
      }
    	var bounds = new google.maps.LatLngBounds();
    	var map = new google.maps.Map(document.getElementById(map_id), {
    	  zoom: zoomLevel,
        minZoom: minZoom,
        maxZoom: maxZoom,
    	  center: latLng,
         zoomControlOptions: {
          position: google.maps.ControlPosition.TOP_LEFT
        },
        mapTypeControl: false,
        streetViewControl: false,
        scaleControl: false,
        fullscreenControl: false
        });
        var markers = [];
        for (var i = 0; i < data.length; i++) {
            var position = data[i].location;
            var price = data[i].price;
            var icon = {
		      url: '/themes/bookaspace/images/white.png',
		    };
	    	var marker = new google.maps.Marker({
              'position': position,
              icon: icon,
              label: {
                text: price,
                color: "#000",
                fontSize: "15px",
                fontWeight: "bold",
              },
              title: 'Search Map',
              map: map,
            });
	       infoWindow = new google.maps.InfoWindow;	       
           bounds.extend(marker.position);
           google.maps.event.addListener(marker, 'click', (function (marker, i) {
              return function () {
                var nid = data[i].nid;
                for (var j = 0; j < markers.length; j++) {
                  markers[j].setIcon('/themes/bookaspace/images/white.png');
                  var label = markers[j].getLabel();
				  label.color = "black";
				  markers[j].setLabel(label);
                }
                marker.setIcon({
                  url : '/themes/bookaspace/images/color.png',
                });
                var label = marker.getLabel();
			    label.color = "white";
			    marker.setLabel(label);
                map.setCenter(marker.getPosition());
                infoWindow.close();
                getPropertyValues(nid, map, marker, infoWindow);             
			 	
              }
            })(marker, i));
	    	markers.push(marker);
	    }
      if (bounds !== null && typeof bounds != "undefined") {
        map.fitBounds(bounds);
      }
      else {
        bounds.extend(new google.maps.LatLng(50.736129,-1.988229));
        map.fitBounds(bounds);
      }
    }
  });
}
function getPropertyValues(nid, map, marker, infoWindow) {
	console.log(nid);
	jQuery.ajax({
	    type: 'POST',
	    url: '/show-map-location?nid='+nid,
	    success: function (res) {
	    	var data = jQuery.parseJSON(res);
	    	var address = data.address;
	    	var space_image = data.space_image;
	    	var price = data.price;
	    	var property_title = data.property_title;
	    	var property_type_name = data.property_type_name;
	    	var space_id = data.space_id;
	    	var space_layout_max_participant = data.space_layout_max_participant;
	    	var space_name = data.space_name;
	    	var popup_string = '<div class="mrooms-block">'+
		      '<div class="mrimg-block">' +
		       '<img  src="' + space_image + '" class="mrimg" alt="img"/>' + 
		       '<span class="new">New</span>' +
		      '</div>' +
		      '<div class="mrooms-body">' +
		        '<div class="private">' +
		          '<h5 class="plabel">' + property_type_name + '</h5>' +
		          '<div class="pstars">' +
		            '<img src="/themes/bookaspace/images/img-star.png" class="mrimg" alt="img"/>' +
		          '</div>' +
		        '</div>' +
		        '<h4>' + space_name + '</h4>' +
		       '<h5>' + property_title + '</h5>' +
		       '<p><img src="/themes/bookaspace/images/icon-lo1.png" class="mrimg" alt="img"/>' + address + '</p>' +
		       '<div class="mrooms-footer">' +
		        '<ul class="msfoo-list">' +
		          '<li>' +
		            '<a href="javascript:void(0);">' +
		              '<img src="/themes/bookaspace/images/icon-ab3.png" class="mrimg" alt="img"/>' + space_layout_max_participant + '</a>' +
		          '</li>' +
		         ' <li>' +
		            '<a href="javascript:void(0);">' +
		              '<img src="/themes/bookaspace/images/icon-par1.png" class="mrimg" alt="img"/>' +
		            '</a>' +
		          '</li>' +
		          '<li>' +
		            '<a href="javascript:void(0);">' +
		              '<img src="/themes/bookaspace/images/icon-par2.png" class="mrimg" alt="img"/>' +
		            '</a>' +
		          '</li>' +
		        '</ul>' +
		        '<div class="msfoo-cost">' +
		          '<span class="scost">from</span>' +
		          '<span class="boldcost">' + price + '</span>' +
		        '</div>' +
		       '</div>' +
		      '</div>' +
		    '</div>';	    	
	    	// var infowindow = new google.maps.InfoWindow({
	        // content: popup_string
	        // });
	        infoWindow.setContent(popup_string);
	        infoWindow.open(map, marker);
	    }
	});	
}

function getAllUrlParams(url) {

  // get query string from url (optional) or window
  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);

  // we'll store the parameters here
  var obj = {};

  // if query string exists
  if (queryString) {

    // stuff after # is not part of query string, so get rid of it
    queryString = queryString.split('#')[0];

    // split our query string into its component parts
    var arr = queryString.split('&');

    for (var i = 0; i < arr.length; i++) {
      // separate the keys and the values
      var a = arr[i].split('=');

      // set parameter name and value (use 'true' if empty)
      var paramName = a[0];
      var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];

      // (optional) keep case consistent
      paramName = paramName.toLowerCase();
      if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();

      // if the paramName ends with square brackets, e.g. colors[] or colors[2]
      if (paramName.match(/\[(\d+)?\]$/)) {

        // create key if it doesn't exist
        var key = paramName.replace(/\[(\d+)?\]/, '');
        if (!obj[key]) obj[key] = [];

        // if it's an indexed array e.g. colors[2]
        if (paramName.match(/\[\d+\]$/)) {
          // get the index value and add the entry at the appropriate position
          var index = /\[(\d+)\]/.exec(paramName)[1];
          obj[key][index] = paramValue;
        } else {
          // otherwise add the value to the end of the array
          obj[key].push(paramValue);
        }
      } else {
        // we're dealing with a string
        if (!obj[paramName]) {
          // if it doesn't exist, create property
          obj[paramName] = paramValue;
        } else if (obj[paramName] && typeof obj[paramName] === 'string'){
          // if property does exist and it's a string, convert it to an array
          obj[paramName] = [obj[paramName]];
          obj[paramName].push(paramValue);
        } else {
          // otherwise add the property
          obj[paramName].push(paramValue);
        }
      }
    }
  }

  return obj;
}