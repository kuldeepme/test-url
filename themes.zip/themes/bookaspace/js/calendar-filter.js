(function($) {
    Drupal.behaviors.calendar_filter = {
        attach: function (context, settings) {
             $(".cal-ft-space-wrap .header-wrap p").once("html5").click(function(){
                $(".cal-ft-space-wrap #cal-ft-form").slideToggle();
             });
             $(".my_calendar_small_menu").once("html5").click(function(){  
                $("#cal-link-container").slideToggle();
             });
             
        },
    };

})(jQuery);