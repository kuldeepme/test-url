function click_handler(node_id, host, $csv_spaces_ids){

    //alert(host);

    //var str_url = "http://bookaspace.dd:8083/handle_direct_sales_tool/" + node_id + "?"
    var str_url = "http://" + host + "/handle_direct_sales_tool/" + node_id + "?"

    if($('#sel_properties').length > 0){
        var selected_property = $('#sel_properties').val();
        if(selected_property != 0){
            //Add selected property to the list
            str_url += "property=" + selected_property + "&";
        } else {
            //Add all properties to the list
            var csv_properties = "";
            $("#sel_properties option").each(function()
            {
                // Add $(this).val() to your list
                if($(this).val() != 0){
                    if(csv_properties != ""){
                        csv_properties += ",";
                    }
                    csv_properties += $(this).val();
                }
            });
            str_url += "property=" + csv_properties + "&";
        }
    } else if($csv_spaces_ids != ""){
        str_url += "property=" + $csv_spaces_ids + "&";
    }
    //alert(str_url);die;



    var selected_activity = $('#sel_activities').val();
    if(selected_activity != 0){
        //Add selected activity to the list
        str_url += "activities=" + selected_activity + "&";
    } else {
        //Add all activities to the list
        var csv_activities = "";
        $("#sel_activities option").each(function()
        {
            // Add $(this).val() to your list
            if($(this).val() != 0){
                if(csv_activities != ""){
                    csv_activities += ",";
                }
                csv_activities += $(this).val();
            }
        });
        str_url += "activities=" + csv_activities + "&";
    }


    var selected_date = $('#input_date').val();
    str_url += "date=" + selected_date + "&";

    var selected_start_time = $('#sel_start_time').val();
    str_url += "start_time=" + selected_start_time + "&";

    var selected_end_time = $('#sel_end_time').val();
    str_url += "end_time=" + selected_end_time + "&";

    var selected_people = $('#sel_people').val();
    str_url += "people=" + selected_people + "&";

    if(selected_start_time != 0 && selected_start_time >= selected_end_time){
        alert("End time must be bigger then start time");
        return false;
    }

    //alert(str_url);

    window.location.href = str_url;
}