require 'compass/import-once/activate'

http_path = ""
css_dir = "assets/css"
sass_dir = "assets/scss"
images_dir = "assets/img"
javascripts_dir = "assets/js"

# output_style = :expanded or :nested or :compact or :compressed

# relative_assets = true

line_comments = false
