$ = jQuery;

$(document).ready(function() {

    // Controls the Width to display.
    $('.js-options-width-button').on('click', function() {
        var size = $(this).data('size');
        var totalSize = size + $('.js-guide-menu').width();
        var reducedSize = size - $('.js-guide-menu').width();
        if ($(window).width() < totalSize) {
            size = reducedSize - 80;
        }
        $('.js-guide-content').width(size + 17);
        $('.js-options-width-button, .js-options-width-input').removeClass('active');
        $(this).addClass('active');
        $('.js-options-width-input').val(size + 'px');
        setAnchorOffsets();
    });

    $('.js-options-width-input').on('focus', function() {
        $(this).val('').addClass('active');
        $('.js-options-width-button').removeClass('active');
    });
    $('.js-options-width-input').on('blur', function() {
        $(this).removeClass('active');
    });
    $('.js-options-width-input').on('keyup', function() {
        var size = $(this).val();
        $('.js-guide-content').width(size + 'px');
        $(this).addClass('active');
        setAnchorOffsets();
    });

    // Initially hides all menus.
    $('.js-menu-options').hide();

    // Controls the Section display.
    // Shows that Sections Index.
    $('.js-sections-select-button').on('click', function() {
        var content = $(this).data('content');
        $('.js-menu-options').hide();
        $('.js-menu-' + content).show();

        var file = 'content/' + content + '/index.html';
        $('.js-guide-content').attr('src', file);

        $('.js-sections-select-button').removeClass('active');
        $(this).addClass('active');

        $('.js-element-menu-link').removeClass('parent-active');
        $('.js-element-menu-link').removeClass('js-active');
    });

    $('.js-theme-select-input').on('change', function() {
        updateTheme($(this).val());
    });

    // Selects the Width on load.
    $('.js-options-width-button').eq(4).click();

    // Loads first Section if none selected.
    if (!window.location.hash) {
        $('.js-sections-select-button[data-content="get-started"]').click();
    }

    // Display the Index of the current Section.
    $('.js-element-menu-link.level-1').on('click', function() {
        var section = $(this).parent('.js-menu-options').data('section');
        var file = 'content/' + section + '/' + 'index.html';
        $('.js-guide-content').attr('src', file);
        $('.js-element-menu-link').removeClass('parent-active');
        $('.js-element-menu-link').removeClass('js-active');
    });

    // Loads content into iFrame.
    $('.js-element-menu-link.level-2').on('click', function() {
        if (!$(this).hasClass('js-active')) {
            $('.js-element-menu-link').removeClass('parent-active');
            $(this).nextUntil('.js-element-menu-link.level-2').addClass('parent-active');
            $('.js-element-menu-link.level-2').removeClass('.js-active');
            var section = $(this).parent('.js-menu-options').data('section');
            var content = $(this).attr('href').substring(1);
            var file = 'content/' + section + '/' + content + '.html';
            $('.js-guide-content').attr('src', file);
            $('.js-element-menu-link').removeClass('js-active');
            $(this).addClass('js-active');
        }
    });

    // Scrolls to an anchor with a Section.
    $('.js-element-menu-link.level-3').on('click', function() {
        var iframe = document.getElementById('guide-content');
        var toScroll = $(this).data('offset');
        $(iframe).contents().find('html, body').animate({ scrollTop: toScroll });
    });

    // Show correct Section and Content on load.
    if (window.location.hash) {
        var hash = window.location.hash.substring(1);
        var hashLink = $('.js-element-menu-link[href="#' + hash + '"]');
        // If it's a section, open that.
        if ($('.js-sections-select-button[data-content="' + hash + '"]').length) {
            $('.js-sections-select-button[data-content="' + hash + '"]').click();
        }

        // If its a sub Section, open the Section then that.
        if (hashLink.hasClass('level-2')) {
            var section = hashLink.prevAll('.level-1:first').attr('href').substring(1);
            $('.js-sections-select-button[data-content="' + section + '"]').click();
            hashLink.click();
        }
        if (hashLink.hasClass('level-3')) {
            var section = hashLink.prevAll('.level-1:first').attr('href').substring(1);
            $('.js-sections-select-button[data-content="' + section + '"]').click();
            hashLink.prevAll('.level-2:first').click();
            setTimeout(function() {
                hashLink.click();
            }, 500);
        }
    }

    // Show theme switcher.
    $('.guide-title h1').on('click', function() {
        var pass = prompt('...', '');
        if (pass !== null || pass == 'nrw') {
            $('.js-theme-select-input').show();
        }
    });

    // When iFrame has loaded:
    // Add offsets to relevant anchors.
    // Scroll to section from url.
    $('.js-guide-content').on('load', function() {
        var iframe = document.getElementById('guide-content');
        var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
        updateTheme($('body').attr('data-theme'));

        // Anchors for menu build.
        setAnchorOffsets();

        // Build element tabs.
        $(innerDoc).find('.js-gc-element').each(function() {
            // Copy and format the markup into it's tab.
            var element = $(this);
            var markup = $(this).find('.js-view-content').html();
            var styles = '';
            element.find('.js-markup-content').html('<pre></pre>').find('pre').text(markup);

            // Copy and format the styles into their tab.
            // Only if js-show-styles class is present.
            // Also show Styles tab is this class present.
            element.find('.js-gc-element-tab[data-tab="styles"]').hide();
            if (element.hasClass('js-show-styles')) {
                element.find('.js-gc-element-tab[data-tab="styles"]').show();
                element.find('.js-gc-element-tab[data-tab="css"]').hide();
                element.find('.js-view-content').children().each(function(e) {});
                element.find('.js-styles-content').html('<pre></pre>').find('pre').text(JSON.stringify(styles, null, "\t"));
            }
        });

        // Add copy Markup button.
        $(innerDoc).find('.js-gc-element').each(function() {
            if (!$(this).hasClass('js-hide-copy-markup')) {
                $(this).css('position', 'relative').find('.js-markup-content').append('<button class="button--cta button--gc-copy-markup js-copy-markup">Copy markup</button>');
            }
        });
        // Copy markup button functionality.
        $(innerDoc).find('.js-copy-markup').on('click', function() {
            var toCopy = $(this).prev().text();
            var temp = '<textarea id="copy-temp">' + toCopy + '</textarea>';
            $('body').append(temp);
            $('#copy-temp').select();
            document.execCommand('copy');
            $('#copy-temp').remove();
        });

        // Clicks for element tabs.
        $(innerDoc).find('.js-gc-element-tab').on('click', function() {
            var element = $(this).parents('.js-gc-element');
            var tab = $(this);
            var contentToView = tab.data()['tab'];
            // Update active tabs.
            element.find('.js-gc-element-tab').removeClass('is-active');
            tab.addClass('is-active');

            // Update active content.
            element.find('.js-content').removeClass('is-active');
            element.find('.js-' + contentToView + '-content').addClass('is-active');
        });
    });

});

// Controls the theme.
// Adds new stylsheets to contianer and iframe.
function updateTheme(theme) {

    var iframe = document.getElementById('guide-content');
    var innerDoc = iframe.contentDocument || iframe.contentWindow.document;

    if (theme && (theme !== 'cw')) {
        var styleguideFile = 'assets/css/themes/' + theme + '/styleguide_' + theme + '.css';
        var contentFileInner = '../../assets/css/themes/' + theme + '/content_' + theme + '.css';
        var elementsFileInner = '../../assets/css/themes/' + theme + '/elements_' + theme + '.css';
        var elementsFile = 'assets/css/themes/' + theme + '/elements_' + theme + '.css';

        $('head').append('<link class="js-theme-rel" rel="stylesheet" type="text/css" href="' + styleguideFile + '"></link>');
        $('head').append('<link class="js-theme-rel" rel="stylesheet" type="text/css" href="' + elementsFile + '"></link>');
        $('body').attr('data-theme', theme);
        $('body').addClass('theme-active');

        $(innerDoc).find('head').append('<link class="js-theme-rel" rel="stylesheet" type="text/css" href="' + elementsFileInner + '"></link>');
        $(innerDoc).find('head').append('<link class="js-theme-rel" rel="stylesheet" type="text/css" href="' + contentFileInner + '"></link>');

    } else {
        $('.js-theme-rel').remove();
        $(innerDoc).find('.js-theme-rel').remove();
        $('body').attr('data-theme', 'cw');
        $('body').removeClass('theme-active');
    }

    setTimeout(function() { innerDoc, buildColours(innerDoc) }, 50);
}

// Calculates element offsets and adds them to menu.
function setAnchorOffsets() {
    var iframe = document.getElementById('guide-content');
    var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
    var anchors = $(innerDoc).find('.js-anchor');
    anchors.each(function() {
        $('.js-element-menu-link[href="#' + $(this).attr('name') + '"]').attr('data-offset', $(this).offset().top);
    })
}

// Helper to get actual offset of element.
function offset(el) {
    var rect = el.getBoundingClientRect(),
        scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
        scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
}

// Build colour blocks.
function buildColours(innerDoc) {
    $(innerDoc).find('.js-gc-colour').each(function() {
        var element = $(this);
        if (element.is(':visible')) {
            var colour = element.find('.js-gc-colour-colour').css('backgroundColor');
            element.find('.js-gc-colour-hex').html(rgbtohex(colour));
            element.find('.js-gc-colour-rgb').html(colour);
        }
    });
}

// Helper to convert rgb to hex.
function rgbtohex(rgb) {
    if (/^#[0-9A-F]{6}$/i.test(rgb)) return rgb;
    rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);

    function hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
}