$ = jQuery;

$(document).ready(function() {

    if ($('.js-toggle-nav').length) {
        $('.js-toggle-nav').on('click', function() {
            $('.js-primary-nav').toggleClass('nav--is-open');
            $('.js-main-content-area').toggleClass('nav--is-open');
        });
    }

    if ($('.js-helper-nav').length) {
        var helper = $('.js-helper-nav');
        var primary = $('.js-primary-nav ul');
        // Get only the links from the Helper nav.
        var helperLinks = [];
        helper.find('a').each(function() {
            var href = $(this).attr('href');
            var target = $(this).attr('target');
            var text = $(this).html()
            helperLinks.push('<li class="is-helper"><a href="' + href + '" target="' + target + '">' + text + '</a></li>');
        });
        // Add new links to Primary nav.
        primary.append(helperLinks);
    }

    if ($('.js-document').length) {
        $('.js-document-request').on('click', function(e) {
            e.preventDefault();
            $(this).next('.js-document-request-body').toggleClass('visible');
        })
    }

    if ($('.js-video').length) {
        $(window).on('resize load', function() {
            $('.js-video').each(function() {
                var video = $(this).find('iframe');
                video.css('width', '100%');
                video.height((video.width() / 16) * 9);
            });
        });
    }

    if ($('.js-accordion').length) {
        (function() {
            var panelsClosure = (function() {
                // Cache repeated selectors.
                var accordions = document.querySelectorAll('.accordion');
                var panelLinks = document.querySelectorAll('.accordion__heading');
                var expandAll = document.querySelectorAll('.accordion__action--expand');
                var collapseAll = document.querySelectorAll('.accordion__action--collapse');
                // Old browser code. If classList not supported then...
                if (!document.querySelector('body').classList || typeof document.body.style.transition !== 'string') {
                    // For each accordion on the page update the class to contain no-support class
                    // which opens all panels by default and removes chevrons via CSS.
                    for (var n = 0; n < accordions.length; n++) {
                        accordions[n].setAttribute('class', 'panel-group accordion accordion--no-support');
                    }
                    // Exit the panelsClosure because we don't want to run the rest.
                    return;
                }
                // For every accordion remove no js class if js.
                for (var g = 0; g < accordions.length; g++) {
                    accordions[g].classList.remove('accordion--no-js');
                }
                // For every accordion add a unique id to the buttons.
                for (var j = 0; j < accordions.length; j++) {
                    for (var i = 0; i < accordions[j].childNodes.length; i++) {
                        if (accordions[j].childNodes[i].className == 'accordion__actions') {
                            var childNodes = accordions[j].childNodes[i];

                            var expandButtonText = document.createTextNode('Expand all');
                            var collapseButtonText = document.createTextNode('Close all');

                            var expandButton = document.createElement('button');
                            expandButton.classList.add('accordion__action');
                            expandButton.classList.add('accordion__action--expand');
                            expandButton.appendChild(expandButtonText);

                            var collapseButton = document.createElement('button');
                            collapseButton.classList.add('accordion__action');
                            collapseButton.classList.add('accordion__action--collapse');
                            collapseButton.appendChild(collapseButtonText);

                            accordions[j].childNodes[1].appendChild(expandButton);
                            accordions[j].childNodes[1].appendChild(collapseButton);

                            for (var x = 0; x < childNodes.childNodes.length; x++) {
                                var actionsNodes = childNodes.childNodes;
                                if (actionsNodes[x].classList) {
                                    actionsNodes[x].setAttribute('title', 'Expand accordion ' + (j + 1));
                                    if (actionsNodes[x].classList.contains('accordion__action--collapse')) {
                                        actionsNodes[x].setAttribute('title', 'Collapse accordion ' + (j + 1));
                                    }
                                }
                            }
                            expandAll = document.querySelectorAll('.accordion__action--expand');
                            collapseAll = document.querySelectorAll('.accordion__action--collapse');
                        }
                    }
                }
                var getParent = function(tag, selectorClass) {
                    // Check if parent is .panel, if not then go to next parent until we find it.
                    // Equivalent of jQuery.parents()
                    while (!tag.parentNode.classList.contains(selectorClass)) {
                        // If we aren't inside a .panel then stop this loop because JS will
                        // error out otherwise.
                        if (tag.tagName.toLowerCase() === 'body') {
                            break;
                        }
                        tag = tag.parentNode;
                    }
                    // While stops on first child of .panel, so we return .panel itself.
                    return tag.parentNode;
                };
                var testAll = function(thisAccordion) {
                    var thisAccordionOpen = thisAccordion.querySelectorAll('.accordion__panel.js-open');
                    var thisAccordionPanels = thisAccordion.querySelectorAll('.accordion__panel');
                    // Removed assumption all panels are collapsed or open.
                    thisAccordion.classList.remove('accordion--all-expanded');
                    thisAccordion.classList.remove('accordion--all-collapsed');
                    // If all are open.
                    if (thisAccordionOpen.length === 0) {
                        thisAccordion.classList.add('accordion--all-collapsed');
                    }
                    // If all are collapsed.
                    if (thisAccordionOpen.length === thisAccordionPanels.length) {
                        thisAccordion.classList.add('accordion--all-expanded');
                    }
                };
                var togglePanel = function(panel, toOpen) {
                    // If add or remove class passed in specifically then use that,
                    // otherwise us default of toggle.
                    toOpen = typeof toOpen === 'undefined' ? !panel.hasAttribute('open') : toOpen;
                    // Cache repeated selectors.
                    var panelBody = panel.querySelector('.accordion__body');
                    var panelInner = panel.querySelector('.accordion__body-inner');
                    var thisAccordion = getParent(panel, 'accordion');
                    if (toOpen) {
                        panel.setAttribute('open', true);
                        panel.classList.add('js-open');
                        setTimeout(function() {
                            panelBody.style.height = panelInner.offsetHeight + 'px';
                            panelBody.style.opacity = 1;
                            testAll(thisAccordion);
                        }, 1);
                    } else {
                        panelBody.style.height = panelInner.offsetHeight + 'px';
                        setTimeout(function() {
                            panelBody.style.height = 0;
                            panelBody.style.opacity = 0;
                            panel.classList.remove('js-open');
                        }, 1);
                    }
                };
                // For every panel link in every accordion.
                for (var i = 0; i < panelLinks.length; i++) {
                    // Closure required to stop leaky variables because for loops
                    // do not have a scope.
                    (function() {
                        var thisTag = panelLinks[i];
                        // Set our panel to the last element our while loop hit before exiting.
                        var panel = getParent(thisTag, 'accordion__panel');
                        // Cache repeated selectors.
                        var panelBody = panel.querySelector('.accordion__body');
                        // If this panel is animating.
                        var animating = false;
                        // Remove the directly set height attribute after transition to
                        // stop height issues after resize.
                        panelBody.addEventListener('transitionend', function() {
                            if (panel.classList.contains('js-open')) {
                                panelBody.style.height = 'auto';
                            } else {
                                panelBody.removeAttribute('style');
                                panel.removeAttribute('open');
                            }
                            testAll(getParent(panel, 'accordion'));
                            animating = false;
                        }, false);
                        panelLinks[i].onclick = function(e) {
                            e.preventDefault();
                            // Only if the panel is not currently animating do we do anything.
                            // This prevents weird things when spam clicking.
                            if (animating !== true) {
                                animating = true;
                                togglePanel(panel);
                            }
                        };
                    }());
                }
                // For every expand all button (in case of multiple accordions).
                for (var j = 0; j < expandAll.length; j++) {
                    expandAll[j].onclick = function() {
                        // Cache repeated selectors.
                        var thisAccordion = getParent(this, 'accordion');
                        var thisPanels = thisAccordion.querySelectorAll('.accordion__panel');
                        // For every panel that this expand all button should effect.
                        for (var k = 0; k < thisPanels.length; k++) {
                            // Closure important because for loop has no scope.
                            (function() {
                                var thisPanel = thisPanels[k];
                                // Toggle the panel, specifically removing the collapsed class.
                                togglePanel(thisPanel, true);
                            }());
                        }
                    }
                }
                // For every collapse all button (in case of multiple accordions).
                for (var l = 0; l < collapseAll.length; l++) {
                    collapseAll[l].onclick = function() {
                        // Cache repeated selectors.
                        var thisAccordion = getParent(this, 'accordion');
                        var thisPanels = thisAccordion.querySelectorAll('.accordion__panel');
                        // For every panel that this collapse all button should effect.
                        for (var m = 0; m < thisPanels.length; m++) {
                            // Closure important because for loop has no scope.
                            (function() {
                                var thisPanel = thisPanels[m];
                                // Toggle the panel, specifically adding the collapsed class.
                                togglePanel(thisPanel, false);
                            }());
                        }
                    }
                }
            }());
        }());
    }

    if ($('.js-card').length) {
        $('.js-card').each(function() {
            var card = $(this);
            var prev = $(this).prev();
            var next = $(this).next();
            if (prev.hasClass('card')) {
                card.addClass('card--has-previous');
                var prevCardType = prev.attr('class').split(' ');
                for (var classIndex = 0; classIndex < prevCardType.length; ++classIndex) {
                    if (prevCardType[classIndex].match(/card--style-/)) {
                        var prevCardClass = prevCardType[classIndex].split('card--style-')[1];
                        card.addClass('card-previous-type--' + prevCardClass);
                    }
                }
            }
            if (next.hasClass('card')) {
                card.addClass('card--has-next');
                var nextCardType = next.attr('class').split(' ');
                for (var classIndex = 0; classIndex < nextCardType.length; ++classIndex) {
                    if (nextCardType[classIndex].match(/card--style-/)) {
                        var nextCardClass = nextCardType[classIndex].split('card--style-')[1];
                        card.addClass('card-next-type--' + nextCardClass);
                    }
                }
            }
        });
    }

    if ($('.js-card-infographic').length) {
        $(window).on('scroll resize', function() {
            // Runs through each Infographic type card.
            $('.js-card-infographic').each(function() {
                var $this, countTo;
                // If the count has not already run and the card is visible to the viewport.
                if ($(this).isVisible() && !$(this).hasClass('has-counted')) {
                    $this = $(this);
                    countTo = $(this).data('count-to');
                    // If the card has a number to count to.
                    if (countTo) {
                        // Counter function.
                        $({ Counter: 0 }).animate({ Counter: countTo }, {
                            duration: 2000,
                            easing: 'swing',
                            step: function() {
                                var currentVal = Math.ceil(this.Counter);
                                // Adds a comma to any number in the thousands.
                                $this.find('.js-counter').html(currentVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                            }
                        });
                        // Adds a has counted class to prevent animations running more than once.
                        $this.addClass('has-counted');
                    }
                }
            });
        })
    }

    if ($('.js-form-advanced-description-link').length) {
        // Hide text initially (to make sure this is visible without js).
        $('.js-form-advanced-description-text, .js-form-advanced-description-text-inline').hide();
        // Control click on help link.
        $('.js-form-group .js-form-advanced-description-link').on('click', function(e) {
            e.preventDefault();
            $(this).toggleClass('advanced-description__link--active');
            $(this).parents('.js-form-group').find('.js-form-advanced-description-text').toggle();
        });
        $('.js-group-element .js-form-advanced-description-link-inline').on('click', function(e) {
            e.preventDefault();
            $(this).toggleClass('advanced-description__link--active');
            $(this).parents('.js-group-element').find('.js-form-advanced-description-text-inline').toggle();
        })
    }

    if ($('.js-tabs').length) {
        $('.js-tabs').each(function() {
            var tabWidth = 0;
            var tabCount = 0
            var containerWidth = $(this).parent().width();
            var tabs = $(this).find('.js-tab');
            $(this).find('.js-tab').each(function() {
                var tab = $(this);
                tabCount++;
                if (tab.width() > tabWidth) {
                    tabWidth = tab.width();
                }
            });
            if (((tabWidth * tabCount) > containerWidth) && (tabCount > 2)) {
                tabs.addClass('tabs__tab--has-set-width');
            }
            if (tabCount == 2) {
                tabs.addClass('tabs__tab--has-single-sibling');
            }
        });
    };

    if ($('.js-beta-banner').length) {
        var betaMessageShouldBeOpen = document.cookie.replace(/(?:(?:^|.*;\s*)betaMessageShouldBeOpen\s*\=\s*([^;]*).*$)|^.*$/, '$1');
        if (betaMessageShouldBeOpen == 'true;secure') {
            $('.js-beta-banner').removeClass('closed');
        } else {
            $('.js-beta-banner').addClass('closed');
        }
        $('.js-beta-banner-toggle').on('click', function() {
            if (!$('.js-beta-banner').hasClass('closed')) {
                $('.js-beta-banner').addClass('closed');
                document.cookie = 'betaMessageShouldBeOpen=false;secure';
            } else {
                $('.js-beta-banner').removeClass('closed');
                document.cookie = 'betaMessageShouldBeOpen=true;secure';
            }
        });
    }

    if ($('.js-modal').length) {
        $('.js-modal').each(function() {
            var modal = $(this);
            modal.remove();
            $('body').prepend(modal);
        });
        $('.js-triggers-modal').on('click', function(e) {
            e.preventDefault();
            var modal = $(this).data('modal');
            $('.js-modal[data-modal-id="' + modal + '"]').addClass('modal--open');
        });
        $('.js-modal-close').on('click', function() {
            $(this).closest('.js-modal').removeClass('modal--open');
        });
    }

    if ($('.js-share-this-page').length) {
        $('.js-share-this-page').on('click', function() {
            $(this).toggleClass('active');
        });
    }

    if ($('.js-back-to-top').length) {
        $('.js-back-to-top').on('click', function() {
            window.scrollTo(0, 0);
        });
    }

    if ($('.js-share-this-page').length) {
        var shareButton = $('.js-share-this-page');
        var shareLinks = shareButton.find('a');
        shareLinks.on('focus', function() {
            shareButton.addClass('active');
        });
        shareLinks.on('blur', function() {
            shareButton.removeClass('active');
        });
    }

    if ($('a').length) {
        var mailtoTitleText = 'Email link to';
        var mailtoHiddenText = 'opens email client';

        var externalTitleText = 'Link to';
        var externalHiddenText = 'external website';
        $('a:not(.ignore-external):not(.ignore-link)').each(function() {
            var link = $(this);
            var href = link.attr('href');
            if (href) {
                if (href.indexOf('mailto:') >= 0) {
                    link.attr('title', mailtoTitleText + ' ' + href.replace('mailto:', ''));
                    link.append('<span class="external">(' + mailtoHiddenText + ')</span>');
                }
                // Internal cards and links.
                if (!(href.indexOf('mailto:') >= 0) && !is_external(href)) {

                    // Handle cards.
                    if (link.hasClass('content__link')) {
                        var linkTitle = link.find('span').html();
                    }
                    // Icon cards.
                    else if (link.hasClass('card__inner')) {
                        var linkTitle = link.find('.body__title').html();
                    }
                    // Banners and image only links.
                    else if (link.find('img')[0]) {
                        var linkTitle = link.find('img').attr('alt');
                    }
                    // And normal links. 
                    else {
                        var linkTitle = link.html();
                    }
                    var cleanedTitle = linkTitle.replace(/(<([^>]+)>)/ig, '');
                    link.attr('title', externalTitleText + ' ' + cleanedTitle.replace(/\s\s+/g, ' ').replace('&amp;', '&').replace(/ {1,}/g, ' '));
                }

                // External cards and links.
                if (!(href.indexOf('mailto:') >= 0) && is_external(href)) {
                    // Handle cards.
                    if (link.hasClass('content__link')) {
                        var linkTitle = link.find('span').html();
                    }
                    // Icon cards.
                    else if (link.hasClass('card__inner')) {
                        var linkTitle = link.find('.body__title').html();
                    }
                    // Banners and image only links.
                    else if (link.find('img')[0]) {
                        var linkTitle = link.find('img').attr('alt');
                    }
                    // And normal links. 
                    else {
                        var linkTitle = link.html();
                    }
                    var cleanedTitle = linkTitle.replace(/(<([^>]+)>)/ig, '');
                    link.attr('title', externalTitleText + ' ' + cleanedTitle.replace(/\s\s+/g, ' ').replace('&amp;', '&').replace(/ {1,}/g, ' '));
                    link.append('<span class="external">(' + externalHiddenText + ')</span>');
                }
                if (!(href.indexOf('mailto:') >= 0) && is_external(href) && link.hasClass('button--icon')) {
                    link.addClass('icon--external-link');
                }

            }
        });
    }
    // Tab with content JS.
    $('ul.gel_tabs li').click(function(){
	  var tab_id = $(this).attr('data-tab');
	  $('ul.gel_tabs li').removeClass('current');
	  $('.tab-content').removeClass('current');
	  $(this).addClass('current');
	  $("#"+tab_id).addClass('current');
	});
	
	
	//Collapsible
	
	
	$(".collapsibleContent").hide();
    $(".collapsible_show_hide").on("click", function () {
        var txt = $(".collapsibleContent").is(':visible') ? 'Read More ' : 'Read Less';
        $(".collapsible_show_hide").text(txt);
        $(this).next('.collapsibleContent').slideToggle(200);
    });
});

// Helper function to determine whether or not an element is on screen.
$.fn.isVisible = function() {
    var elTop = $(this).offset().top;
    var elBottom = elTop + $(this).outerHeight();
    var vpTop = $(window).scrollTop();
    var vpBottom = vpTop + $(window).height();
    return elBottom > vpTop && elTop < vpBottom;
};

// Helper function to determine whether a link is external.
function is_external(l) {
    var host = window.location.host;
    var link = $('<a>', { href: l })[0].hostname;
    if ((l.indexOf('.gov.wales') !== -1) || (l.indexOf('.llyw.cymru') !== -1)) {
        return false;
    }
    if (host && link) {
        return link !== host
    }
    return false;
}