# Career Wales Styleguide

The Careers Wales styleguide contains the HTML markup and CSS styles for each of the UI elements defined. Each elements is presented via a UI interface allowing each element to be previewed in isolation.

## Supported guides
To include the styleguide in your application you will need to include the following css/js files along with the assets directory. The styleguides have a dependency on jQuery version 3 or higher.

### Careers Wales
The fully compiled styleguide for careerswales requires
* /assets/css/gel-elements.css 
* /assets/js/gel-elements.js

### Working Wales
The fully compiled styleguide for workingwales requires
* /assets/css/gel-elements.css 
* /assets/themes/ww/elements_ww.css
* /assets/js/gel-elements.js

## Compile
The styleguide is built using compass and can be compiled via the following command from the root folder.

    compass compile

## Deployment
The styleguide should be hosted on a webserver that points to the root directory of the repository's folder structure.
 