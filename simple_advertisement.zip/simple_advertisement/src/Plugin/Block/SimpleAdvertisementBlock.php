<?php

namespace Drupal\simple_advertisement\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Simple Advertisement block.
 *
 * @Block(
 *   id = "simple_advertisement_block",
 *   admin_label = @Translation("Simple Advertisement Block"),
 *   module = "simple_advertisement",
 *   deriver = "Drupal\simple_advertisement\Plugin\Derivative\AdvertisementTermBlock"
 * )
 */
class SimpleAdvertisementBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $id = $this->getDerivativeId();
    $config = $this->configuration;
    $config['tid'] = $id;
    $this->configuration = $config;
    return [
      '#cache' => ['max-age' => 0],
      '#title' => 'Simple Advertisement Block',
      '#theme' => 'simpleads_advertisement_block',
      '#advertisement' => [
        'base_path' => base_path(),
        'configuration' => !empty($this->configuration) ? $this->configuration : [],
        'content' => _get_simple_advertisement_data($this->configuration),
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {

    if ($account->hasPermission('access advertisement entities')) {
      return AccessResult::allowed();
    }
    return AccessResult::forbidden();
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $max_ads = 25;
    $options = [];
    for ($i = 1; $i <= $max_ads; $i++) {
      $options[$i] = $i;
    }
    $form['ads_limit'] = [
      '#type' => 'select',
      '#title' => $this->t('Number of ads to display'),
      '#default_value' => $this->configuration['ads_limit'],
      '#options' => $options,
    ];
    $form['ads_page'] = [
      '#type' => 'textfield',
      '#title' => t('Advertisement page'),
      '#description' => t('Insert internal path such as <em>node/add</em>.'),
      '#default_value' => $this->configuration['ads_page'],
    ];
    $form['ads_width'] = [
      '#type' => 'textfield',
      '#title' => t('Advertisement width'),
      '#description' => t('Insert the width in pixels, do not add "px" after width.'),
      '#default_value' => $this->configuration['ads_width'],
    ];
    $form['ads_height'] = [
      '#type' => 'textfield',
      '#title' => t('Advertisement height'),
      '#description' => t('Insert the hight in pixels, do not add "px" after hight.'),
      '#default_value' => $this->configuration['ads_height'],
    ];
    $order_options = [
      'order_created_desc' => 'Order by created date DESC',
      'order_modified_desc' => 'Order by modifed date DESC',
      'order_title_asc' => 'Order by node title ASC',
    ];
    $form['ads_order'] = [
      '#type' => 'select',
      '#title' => t('Ads order'),
      '#default_value' => $this->configuration['ads_order'],
      '#options' => $order_options,
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockValidate($form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    if ($values['ads_page'] != NULL && substr($values['ads_page'], 0, 1) === '/') {
      $form_state->setErrorByName('ads_page', t("Path shouldn't start with /."));
    }
    if ($values['ads_width'] != NULL && !is_numeric($values['ads_width'])) {
      $form_state->setErrorByName('ads_width', t('Inter the numeric values for the width.'));
    }
    if ($values['ads_height'] != NULL && !is_numeric($values['ads_height'])) {
      $form_state->setErrorByName('ads_height', t('Inter the numeric values for the height.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    foreach ($values as $key => $default_value) {
      $this->configuration[$key] = $values[$key];
    }
  }

}
