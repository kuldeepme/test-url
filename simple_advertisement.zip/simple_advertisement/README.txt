CONTENTS OF THIS FILE
---------------------

 * Introduction 
 * Installation
 * Configuration
 * Benefits
 * Credits

#Introduction

 The Simple advertisement module will show advertise block on any specfic pages. Admin 
 can create advertisement contents & terms according to their requirement. After term creation, It will create respective term block. Admin can publish & unpublish advertise block on specific date.

#Installation

 Install as you would normally install a contributed Drupal module. Visit:
 [https://www.drupal.org/docs/8/extending-drupal-8/installing-drupal-8-modules]
 for further information.

#Configuration

 This module will create a "Simple Advertisement" content type, "Advertisement" vocab with 
 "Content" term & "Simple Advertisement Block: Content" block.
 To create simple advertisement content go to
 Administration » Content » Add content » Simple Advertisement.

 To create advertisement term go to
 Administration » Structure » Taxonomy » Advertisement.

 To place advertisement block go to
 Administration » Structure » Block layout.

 Admin user can configure advertise block accroding to their requirement like how many ad wants to show on ad block, ad content order etc.

#Benefits

 This module provides lots of configuration like
 This module will automatically hide advertise block on specified end date.

#Credits

  Current maintainers:
   * Rahul Patidar(https://www.drupal.org/u/rahul-patidar)
