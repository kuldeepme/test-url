<?php

namespace Drupal\custom_access\Controller;

/**
 * @file
 * HGV jobs controller.
 */

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Database;
use Drupal\node\Entity\Node;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\Core\Render\Renderer;
use Drupal\file\Entity\File;
use Drupal\Core\Form\FormBuilder;

/**
 * User CusotmAccessController controller.
 */
class CusotmAccessController extends ControllerBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $user;

  /**
   * {@inheritdoc}
   */
  public function __construct(AccountInterface $user) {
    $this->user = $user;
  }

  /**
   * Creates new mock file finder objects.
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user')
    );
  }

  /**
   * Content.
   */
  public function content() {
    $build = [];
    $build = [
      '#markup' => $this->t('Hello World!'),
    ];
    return $build;
  }

}
