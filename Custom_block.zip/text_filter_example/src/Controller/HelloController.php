<?php

namespace Drupal\hello_world\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;

/**
 * Defines HelloController class.
 */
class HelloController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    /*return [
      '#type' => 'markup',
      '#markup' => 'Hello World!',
    ];*/
    $form = $this->formBuilder()->getForm('Drupal\hello_world\Form\FilterTextForm');
    return [
      '#theme' => 'hello_world',
      '#search_form' => $form,
      '#nodes' => $this->raw_data(),
      '#attached' => [
        'library' => [
          'hello_world/search_js',
        ],
      ],
    ];
  }

  /**
   * Template preprocess function for Hello World.
   *
   * @param array $variables
   *   An associative array containing:
   *   - source_text
   */
  public function raw_data() {
    $nids = \Drupal::entityQuery('node')->condition('type', 'article')->execute();
    $nodes = Node::loadMultiple($nids);
    foreach ($nodes as $key => $value) {
      $variables[$key] = ['id' => $value->id(), 'title' => $value->getTitle()];
    }
    /*$punctuation = array('A', 'B', 'C', 'D', 'E');
    for ($i = 0; $i < count($punctuation); $i++) {
      $variables[$i] = $punctuation[$i];
    }*/
    //kint($variables);
    //die('dd');
    return $variables;
  }

}
