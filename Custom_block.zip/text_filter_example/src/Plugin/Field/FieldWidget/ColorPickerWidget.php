<?php

namespace Drupal\hello_world\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the 'hello_world_colorpicker' widget.
 *
 * @FieldWidget(
 *   id = "hello_world_colorpicker",
 *   module = "hello_world",
 *   label = @Translation("Color Picker"),
 *   field_types = {
 *     "hello_world_rgb"
 *   }
 * )
 */
class ColorPickerWidget extends TextWidget {

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element = parent::formElement($items, $delta, $element, $form, $form_state);
    $element['value'] += [
      '#suffix' => '<div class="hello-world-colorpicker"></div>',
      '#attributes' => ['class' => ['edit-hello-world-colorpicker']],
      '#attached' => [
        // Add Farbtastic color picker and javascript file to trigger the
        // colorpicker.
        'library' => [
          'core/jquery.farbtastic',
          'hello_world/colorpicker',
        ],
      ],
    ];

    return $element;
  }

}
