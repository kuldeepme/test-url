<?php

namespace Drupal\custom_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'Hello' Block.
 *
 * @Block(
 *   id = "hello_block",
 *   admin_label = @Translation("Hello block"),
 *   category = @Translation("Hello World"),
 * )
 */
class HelloBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function blockForm($form, FormStateInterface $form_state) {
      $form['name'] = array(
        '#type' => 'textfield',
        '#title' => $this->t('Name'),
        '#description' => $this->t('Your name'),
        '#default_value' => isset($this->configuration['name']) ? $this->configuration['name'] : 'John Doe',
        '#maxlength' => 64,
        '#size' => 64,
        '#weight' => '0',
      );

      return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function blockSubmit($form, FormStateInterface $form_state) {
      $this->configuration['name'] = $form_state->getValue('name');
    }
  /**
   * {@inheritdoc}
   */
/*  public function build() {
    return array(
      '#markup' => $this->t('Hello, World!'),
    );
  }*/

    /**
     * {@inheritdoc}
     */
    public function build() {
/*      $build = [];
      $build['hello_block']['#markup'] = '<p>' . $this->configuration['name'] . '</p>';

      return $build;*/
      return [
/*         '#attached' => [
           'library' => ['caravanismo_common_code/map'],
           'drupalSettings' => [
             'base_path' => base_path(),
             'module_path' => base_path().'/'.drupal_get_path('module', 'caravanismo_common_code'),
             'language_id' => ($default_lang == $current_lang) ? '' : $current_lang,
            ],
          ],*/
          '#cache' => ['max-age' => 0],
          '#title' => 'Hello World Block',
          '#theme' => 'hello_world_block',
          '#content' => 'This is test block',
        ];
    }

  /**
   * {@inheritdoc}
   */
/*  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowed();
  }*/


}
