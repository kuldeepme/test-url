<?php

namespace Drupal\custom_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'Hello' Block Config.
 *
 * @Block(
 *   id = "hello_block_config",
 *   admin_label = @Translation("Hello block config"),
 *   category = @Translation("Hello World Config"),
 * )
 */
class HelloBlockConfig extends BlockBase implements BlockPluginInterface {
  
  /**
   * {@inheritdoc}
   */  
  public function build() {    
    $config = $this->getConfiguration();

    if (!empty($config['hello_block_config'])) {
      $name = $config['hello_block_config'];
    }
    else {
      $name = $this->t('to no one');
    }
    return array(
      '#markup' => $this->t('Hello @name!', array(
        '@name' => $name,
      )),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $default_config = \Drupal::config('hello_world.settings');    
    return [
      'hello_block_config' => $default_config->get('hello.name'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form = parent::blockForm($form, $form_state);

    $config = $this->defaultConfiguration();

    $form['hello_block_config'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Who'),
      '#description' => $this->t('Who do you want to say hello to?'),
      '#default_value' => isset($config['hello_block_config']) ? $config['hello_block_config'] : '',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $values = $form_state->getValues();
    $this->configuration['hello_block_config'] = $values['hello_block_config'];
  }  

}
