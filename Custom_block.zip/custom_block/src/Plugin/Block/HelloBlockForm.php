<?php

namespace Drupal\custom_block\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides a Hello world block with which you can generate dummy text anywhere.
 *
 * @Block(
 *   id = "hello_world_block",
 *   admin_label = @Translation("Hello World block form"),
 * )
 */
class HelloBlockForm extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    // Return the form @ Form/HelloWorldBlockForm.php.
    return \Drupal::formBuilder()->getForm('Drupal\custom_block\Form\HelloWorldBlockForm');
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'generate hello world');
  }

 /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {

    $form = parent::blockForm($form, $form_state);

    $config = $this->getConfiguration();

    return $form;
  } 
  
  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->setConfigurationValue('hello_world_block_settings', $form_state->getValue('hello_world_block_settings'));
  }

} 