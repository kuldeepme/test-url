# users_list
Show list of users in block - Drupal8 Module. The following are the points covered in this module. 

1. Creating a custom block programatically with the title 'Users List'.
2. Display the users from database as list items.
3. The number of user elements should be decided in block configration form. Default is 5.
4. Used theme_item_list to list all the users in block.
5. The User name should have link to his/her profile page.
6. The link should have title attribute as user name.
